# -*- coding: utf-8 -*-
#############################################################################
# Copyright (c) 2008-2021 Accenture.
# All rights reserved.
# 
# This source code and any compilation or derivative thereof is the
# proprietary information of Accenture and is confidential in nature.
# 
# Use of this source code is subject to the terms of the applicable
# Accenture license agreement.
# 
# Under no circumstances is this component (or portion thereof) to be in any
# way affected or brought under the terms of any Open Source License without
# the prior express written permission of Accenture.
# 
# For the purpose of this clause, the term Open Source License includes:
#     (i) any license that requires as a condition of use, modification
#         and/or distribution of a software/component, that such software/
#         component:
#             a. be disclosed or distributed in source code form;
#             b. be licensed for the purpose of making derivative works; and/or
#             c. can be redistributed only free of enforceable intellectual property
#                 rights (e.g. patents); and/or
#     (ii) any license applicable to a software/component that contains, is derived in any  
#          manner (in whole or in part) from, or statically or dynamically links against any
#          software/component specified under (i).
# 
# -----------------------------------------------------
# http://www.accenture.com
# -----------------------------------------------------
#
#  MODULE: ClientAPI
#
#  DESCRIPTION: The ClientAPI module provides APIs for user to script tests and talks to server.
#
#################################################################################
##
## @file ClientAPI.py
## @brief The ClientAPI module provides APIs for user to script tests and talks to server.

#################################################################################
# Import modules
#################################################################################

import sys
import time
from . import stormtest_client
from . import Imaging
from . import Sdo
from .stormtest_client import StormTestExceptions
from .stormtest_client import ApiFunction                # the decorator



#################################################################################
# Public Function Definitions
#################################################################################

## @defgroup Group1 Server Interaction API
# The Server Interaction API functions are used to establish a connection to the StormTest server and to reserve a slot on the StormTest cabinet.
#
# API functions are also provided that allow a test script to retrieve information about all the servers in the test facility.\n\n
# A test facility is a collection of one or more StormTest servers that are physically co-located and connected to the same LAN.
# Each StormTest facility will have one and only one PC that is designated the StormTest Configuration Server. It will host the StormTest database, web server, subversion
# repository and license server.
# For an installation that consists of only one rack, the StormTest server in that rack will most likely also be the Configuration server.\n\n
# The sort of information that the facility APIs allow a user to retrieve includes the names of all the servers in the facility, the
# configuration of each server and the set-top-boxes in each slot of each server.
## @{

## @par Description
#  Gets the raw facility data from the StormTest configuration server. This can then be passed to other functions to retrieve more specific data.\n\n
#  Every StormTest facility has a single configuration server and via this server, information about the entire test facility can be retrieved.
#  @param[in] configServer @b String: The location of the StormTest configuration server. Can be a hostname or IP address.
#  @return @e rawData @b List: The raw facility data.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>rawData = GetFacilityData('config_server')
#   or
#   >>rawData = GetFacilityData('10.0.1.2')
#  @endcode
@ApiFunction
def GetFacilityData(configServer):
    """
    Get Raw facility data from the StormTest configuration Server.  Use helper functions such as
    GetServerNames etc. to extract data.

    Return: complex object of data.

    configServer: (String) host name or address of config server.
    """
    return stormtest_client.stc.get_facility_data(configServer)

## @par Description
#  Get the list of servers in the test facility. This information is extracted from the raw facility data.
#  @param[in] rawData @b List: The raw data from the GetFacilityData() function.
#  @return @e serverList @b List: A list of strings representing the hostnames of servers in the facility.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>servers = GetServerNames(GetFacilityData(configServer))
#   >>print(servers)
#   >>['server1', 'server2']
#  @endcode
@ApiFunction
def GetServerNames(rawData):
    """
    Get list of server names in the facility.

    Return: List.  List of servers, each a string

    rawData: (object) raw data returned from GetFacilityData.
    """
    return stormtest_client.stc.get_server_names(rawData)

## @par Description
#  Get a specific field from the configuration data of a StormTest server.
#  All fields can be retrieve by requesting field @b 'all'.
#  @param[in] rawData @b String: The raw data from the GetFacilityData() function.
#  @param[in] serverName @b String: The name of the server that you want to get information on (normally got from a call to GetServerNames()).
#  @param[in] fieldWanted @b String: The actual field required, or 'all' for all fields.
#  @return @e data @b Dictionary/String/Integer: If one field was requested, the return will be a String or an Integer. If all fields are requested then a dictionary of requested data in the form @b field:value is returned.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>rawData = GetFacilityData(configServer)
#   >>servers = GetServerNames(rawData)
#   >>for server in servers:
#   >>  allFields = GetServerField(rawData,server,'all')
#   >>  oneField = GetServerField(rawData,server,'SlotCount')
#   >>
#   >>print(str(allFields))
#   >>{'DefaultBitRate': 2097000, 'DefaultFrameRate': 25, 'SlotCount': 16,.....}
#   >>
#   >>print(str(oneField))
#   >>16
#  @endcode
@ApiFunction
def GetServerField(rawData, serverName, fieldWanted):
    """
    Get a specific piece of data about a server (or all possible information)

    Return: single string/integer if one item requested OR a dictionary keyed by field name if all
      data requested.

    rawData: (object) raw data returned from GetFacilityData.

    serverName: (String) name of server.

    fieldWanted: (String) name of field wanted or the string 'all' to get all fields.
    """
    return stormtest_client.stc.get_server_field(rawData, serverName, fieldWanted)

## @par Description
#  Get a specific field from the DUT data of the DUT instance in the slot of a StormTest server.
#  All fields can be retrieve by requesting field @b 'all'.
#  @param[in] rawData @b String: The raw data from the GetFacilityData() function.
#  @param[in] serverName @b String: The name of the server that the DUT is in (normally got from a call to GetServerNames()).
#  @param[in] slotNumber @b Integer: The slot number that the DUT is in.
#  @param[in] fieldWanted @b String: The actual field required, or 'all' for all fields.
#  @return @e data @b Dictionary/String/Integer: If one field was requested, the return will be a String or an Integer. If all fields are requested then a dictionary of requested data in the form @b field:value is returned.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>rawData = GetFacilityData(configServer)
#   >>servers = GetServerNames(rawData)
#   >>for server in servers:
#   >>  slotCount = GetServerField(rawData,server,'SlotCount')
#   >>  for slot in range(slotcount):
#   >>      allFields = GetStbField(raw,server,slot+1,'all')
#   >>      oneField = GetStbField(raw,server,slot+1,'Manufacturer')
#   >>
#   >>print(str(allFields))
#   >>{'Manufacturer': 'Generic', 'HardwareVersion': 'zapper',.....}
#   >>
#   >>print(str(oneField))
#   >>Generic
#  @endcode
@ApiFunction
def GetStbField(rawData, serverName, slotNumber, fieldWanted):
    """
    Get a specific piece of data about a DUT in a server using slot number as a key.

    Return: single string/integer if one item requested OR a dictionary keyed by field name if all
      data requested.

    rawData: (object) raw data returned from GetFacilityData.

    serverName: (String) name of server.

    slotNumber: (Integer) slot number (1 - 16) of DUT for which information is requested.

    fieldWanted: (String) name of field wanted or the string 'all' to get all fields.
    """
    return stormtest_client.stc.get_stb_field(rawData, serverName, slotNumber, fieldWanted)

## @par Description
#  Establishes the connection to the StormTest server.
#  @param[in] name @b String: A server host name or ip address.
#  @param[in] description @b String: (optional) A description of the client connecting.
#  @return  @e retStatus @b Bool: 1 always.  On a failure to connect throws a sys.exit exception
#  and exits the script.  NOTE: Ever since version 1, this has been the behavior - the documentation
#  was incorrect to claim a False return on error.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>ret = ConnectToServer("stormtest01","TestUser Connecting to Server")
#   or
#   >>ret = ConnectToServer("193.120.62.187","TestUser Connecting to Server")
#   >>print(str(ret))
#   >>1             #Operation was a success
#  @endcode
@ApiFunction
def ConnectToServer(name, description='-'):
    """
    Connect to a server.  Used to start the process of running a test.

    Return: Bool. Always True.  A failure to establish connection throws a SystemExit exception and
      the test script exits.

    name: (String) host name or IP address of server.  May include the port in format host:port. If
      port omitted the standard 8000 is used.

    description: (String, optional) A description to identify the connection.  Default value us '-'.
    """
    returnValue = stormtest_client.stc.connect_to_server(name, description)
    if _use_legacy_server_colors:
        stormtest_client.stc._set_use_legacy_server_colors()
    if _use_legacy_capture:
        stormtest_client.stc._set_use_legacy_capture()
    return returnValue

## @par Description
#  This function releases the previously established connection from the StormTest server as well as all previously reserved slots.
#  @param None
#  @return  @e retStatus @b Bool: 1 success, 0 fail
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>ret = ReleaseServerConnection()
#   >>print(str(ret))
#   >>1             #Operation was a success
#  @endcode
@ApiFunction
def ReleaseServerConnection():
    """
    Release a previously established connection, unreserving all slots.

    Return: Bool. True on success.
    """
    return stormtest_client.stc.release_server_connection()

## @par Description
#  This function reserves a slot on the StormTest server. If serial port parameters are passed into the function, then StormTest will commence logging of the serial data from the DUT in that slot.\n\n
#  Note that this function will fail if a @e signalDb is passed that does not exist on the StormTest server.
#  @param[in]  slotNo @b Integer: Slot number to reserve.
#  @param[in]  signalDb @b String: IR signal database to use when controlling the DUT in the slot. If the string @e 'default' is used, the StormTest will use the default IR signal database for the DUT in that slot.
#  @param[in]  serialParams @b List: (optional) Serial port parameters to use for communicating with the serial port on the DUT (see @ref _serialParams).
#  @param[in]  videoFlag @b Bool: (optional) Setting this to true causes video to be streamed to the client.  This is necessary for video logging, viewing of video on the client and client side video
#  analysis.  If this is set to false, video logging is not possible and image capture, detect motion and similar functions perform
#  server side capture and pass the images to the client for processing. If a large number of such captures are performed in a short period of time, this can lead
#  to IP port exhaustion and test failures.  The limit is API dependent but would be around 1000 per 4 minute interval across all slots employing server side
#  capture (it is a server issue, not a client issue).  Setting the flag to false reduces CPU loading on the client as video decode is not needed.
#  @return  @e retStatus @b Bool: 1 success, 0 fail
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >># Reserve slot using the default IR signal database
#   >>ret = ReserveSlot(1, "default",[19200,8,'none',1,'none',"Test_name"])
#   >>print(str(ret))
#   >>1             # Operation was a success - slot is reserved
#   >>
#   >># Reserve slot using a specific IR signal database
#   >>ret = ReserveSlot(2, "MY_SIGNAL_DB.txt",[19200,8,'none',1,'none',"Test_name"])
#   >>print(str(ret))
#   >>1             # Operation was a success - slot is reserved
#  @endcode
#  @note When the @e videoFlag = False, there is no video streaming from the StormTest server.
#  @note This reduces the load on the network and may be useful for remote testing.
@ApiFunction
def ReserveSlot(slotNo, signalDb, serialParams=[], videoFlag=True):
    """
    Reserve a slot on the server for future use in the test.  You cannot use non reserved slots to
    control the DUT.

    Return: Integer. A status code: 0 => reserved by someone else, 1 => OK, -1 =>
      ConnectToServer() failed, 10000 => invalid IR database, 10 - 160 => invalid slot number
      (value is 10 * max slot number allowed)

    slotNo: (Integer) slot number to reserve in range 1 - max slots in server.

    signalDb: (String) IR signal database to use when controlling the DUT in the slot. If 'default'
      is used, the StormTest server will use the default IR signal database for the DUT in that slot.

    serialParams: (List, optional) Serial port parameters to use for communicating with the serial
      port on the DUT. Empty implies no serial data wanted.  Contents of list are:
        baud rate (Integer) 50 - 115200 in 'standard' values
        data bits (Integer) 5 - 8 only
        Parity (String) "none", "odd" or "even"
        Stop bits (Integer) 1 or 2
        Flow Control (String) "none", "soft", "hard" or "both"
        Serial Log File Prefix (String, optional) Default is "Slot"

    videoFlag: (Bool, optional) If the test script wants to perform video analysis or create a video
      log, then this parameter must be set to True.
    """
    return stormtest_client.stc.select(slotNo, signalDb, parl=serialParams, video=videoFlag)

## @par Description
#  This function reserves a DUT of a particular type in a StormTest test facility. If serial port parameters are passed into the function, then StormTest will commence logging of the serial data from the DUT.\n\n
#  The function will reserve the first DUT that matches the model name. To be more specific, the test can also specify that the DUT must have a specific serial number/viewing card number etc.
#  @param[in]  facilityData @b List: The raw data from the GetFacilityData() function.
#  @param[in]  signalDb @b String: IR signal database to use when controlling the DUT.
#  @param[in]  modelName @b String: The name of the DUT model that you wish to reserve.
#  @param[in]  serialParams @b List: (optional) Serial port parameters to use for communicating with the serial port on the DUT (see @ref _serialParams).
#  @param[in]  videoFlag @b Bool: (optional) If the test script is not performing video analysis, then this parameter must be set to False.
#  @param[in]  stbSnum @b String: (optional) The test script can optionally reserve a DUT with a specific serial number.
#  @param[in]  stbManf @b String: (optional) The test script can optionally reserve a DUT from a specific manufacturer.
#  @param[in]  stbHwVersion @b String: (optional) The test script can optionally reserve a DUT with a specific hardware version.
#  @param[in]  smartcard @b String: (optional) The test script can optionally reserve a DUT with a specific smartcard number.
#  @return  @e retStatus @b Integer: 1 success, 0 fail
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>print(ReserveStb(GetFacilityData(configServer),"MY_SIGNAL_DB.txt","Zapper"))
#   >>1     # A zapper DUT has been reserved
#  @endcode
@ApiFunction
def ReserveStb(facilityData, signalDb, modelName, serialParams=[], videoFlag=True, stbSnum="", stbManf="", stbHwVersion="", smartcard=""):
    """
    Reserve a DUT based on DUT characteristics rather then specific slot number.  Only DUTs in
    the server specifed in a prior ConnectToServer() call can be used.

    Return: Integer. A status code: 0 => reserved by someone else, 1 => OK, -1 =>
      ConnectToServer() failed, 10000 => invalid IR database, 10 - 160 => invalid slot number
      (value is 10 * max slot number allowed)

    rawData: (object) raw data returned from GetFacilityData.

    signalDb: (String) IR signal database to use when controlling the DUT in the slot. If 'default'
      is used, the StormTest server will use the default IR signal database for the DUT in that slot.

    modelName: (String) Name of the DUT model you wish to reserve.

    serialParams: (List, optional) Serial port parameters to use for communicating with the serial
      port on the DUT. Empty implies no serial data wanted.

    videoFlag: (Bool, optional) If the test script wants to perform video analysis or create a video
      log, then this parameter must be set to True.

    stbSnum: (String, optional) The test script can optionally reserve a DUT with a specific serial
      number.

    stbManf: (String, optional) The test script can optionally reserve a DUT from a specific
      manufacturer.

    stbHwVersion: (String, optional) The test script can optionally reserve a DUT with a specific
      hardware version.

    smartcard: (String, optional) The test script can optionally reserve a DUT with a specific
      smartcard number.
    """
    return stormtest_client.stc.reserve_stb(facilityData, modelName, stbSnum, stbManf, stbHwVersion, smartcard, signalDb, serialParams, videoFlag)

## @par Description
#  In an HS64 system, one slot has four subslots and this function sets the current subslot within a slot used for testing. Due to
#  the nature of video switching, there will be a delay (several seconds) before the client video stabilises after setting the
#  sub slot.  Scripts should wait until the video has settled before performing image processing functions such as CaptureImageEx,
#  DetectMotionEx etc.
#  @param[in]  subslotNo @b Integer: Subslot number to be used for testing.
#  @param[in]  slotNo @b Integer: (optional): Slot number to set the current subslot for.
#  @return  @e retStatus @b Integer: 1 success, 0 fail
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >># Set the current subslot to 4 for slot 1
#   >>ret = SetCurrentSubslot(4, 1)
#   >>print(str(ret))
#   >>1             # Operation was a success - subslot 4 was set to be the current subslot for slot 1
#   >>
#   >># Set the current subslot to 4 for all reserved slots
#   >>ret = SetCurrentSubslot(4)
#   >>print(str(ret))
#   >>1             # Operation was a success - subslot 4 was set to be the current subslot for all reserved slots
#   >>
#  @endcode
#  @note If the @e slotNo parameter is omitted the default is to set the current subslot for all slots reserved
@ApiFunction
def SetCurrentSubslot(subslotNo, slotNo=0):
    """
    In an HS64 system, one slot has four subslots and this function sets the current subslot used for testing.

    Return: Integer. 1 success, 0 fail

    slotNo: (Integer) slot number to reserve in range 1 - max slots in server.

    subslotNo: (Integer) subslot number - max 4 in the context of HS64
    """
    return stormtest_client.stc.set_current_subslot(subslotNo, slotNo)

## @par Description
#  In an HS64 system, one slot has four subslots and this function gets the current subslot used for testing.
#  @param[in]  slotNo @b Integer: (optional): Slot number to get the current subslot for.
#  @return @e currentSubslot @b Integer @b Array: An array of tuples consisting of slot number and subslot number.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Given that slot 1 and 2 have been reserved previously in the test and the current subslot for slot 1 is 3 and the current subslot for slot 2 is 4.
#   # Get current subslots of all reserved slots
#   >>ret=GetCurrentSubslot()
#   >>print(str(ret))
#   >>[[1, 3], [2, 4]]
#
#   # Get current subslot of slot 2
#   >>ret=GetCurrentSubslot(2)
#   >>print(str(ret))
#   >>4
#  @endcode
#  @note If the @e slotNo parameter is omitted the current subslot returned are for all slots reserved.
@ApiFunction
def GetCurrentSubslot(slotNo=0):
    """
    In an HS64 system, one slot has four subslots and this function gets the current subslot used for testing.

    Return: List of Lists (if slotNo is 0) or an Integer.  When slotNo is 0, the List is [SlotNumber,
      SubslotNumber] and otherwise the return is the subslot number.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.get_current_subslot(slotNo)

## @par Description
#  This function frees a previously reserved slot on the StormTest server.
#  @param[in] slotNo @b Integer: Slot number to free. If slot was not previously reserved, then no action will be taken.
#  @return @e Integer: return value may be ignored. 0 is returned if the slotNo is not of an integer type.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>FreeSlot(2)
#  @endcode
@ApiFunction
def FreeSlot(slotNo):
    """
    Frees a previously reserved slot on the StormTest server.

    Return: Integer - may be ignored.

    slotNo: (Integer) Slot number to free. If slot was not previously reserved, then no action
      will be taken.
    """
    return stormtest_client.stc.release_slot(slotNo)

## @par Description
#  This function forcibly frees a slot. It is different from FreeSlot() in that it can be used on slots that the test has not reserved. For this reason it should be used with great care and should not be used in normal tests. Any test in progress on the slot will be disrupted.
#  @param[in] slotNo @b Integer: Slot number to be freed.
#  @return @b Bool: True if a server supports this feature
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>KillSlot(2)
#  @endcode
@ApiFunction
def KillSlot(slotNo):
    """
    Forcibly frees a slot. It is different from FreeSlot() in that it can be used on slots that
    the test has not reserved. For this reason it should be used with great care and should not
    be used in normal tests. Any test in progress on the slot will be disrupted.

    Return: Bool.  True if server supports this feature and slot was forcibly freed.

    slotNo: (Integer) Slot number to be freed.
    """
    return stormtest_client.stc.kill_slot(slotNo)


## @par Description
#  This function resets the slot. It has no effect on SD or 4K systems.
#  On HD servers it performs a full software reset of the slot.  It will disrupt the
#  audio and video stream for several seconds so should only be used when necessary and when the slot is doing nothing
#  of importance for the test.  It has been found that occasionally, the HDMI input could get in an unusual state such
#  that a reset would help.  This has been largely superceded by safe mode in release 3.3.0 so this call should only be used
#  in rare circumstances.  ResetSlot() performs one activity that normal safe mode resolution change does not: It causes
#  HDCP renegotiation.  If ResetSlot is called while a resolution change is in progress, the behaviour depends on safe/fast mode:
#  If fast mode is in operation, ResetSlot converts it to safe mode and notes the need for HDCP renegotiation and returns.  
#  If in safe mode, it simply notes the need for HDCP renegotiation but no other action is taken.
#  @param[in] slotNo @b Integer: (optional) This sets the mode for a specific slot only, 0 for all reserved slots
#  @return None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>ResetSlot(6)
#  @endcode
@ApiFunction
def ResetSlot(slotNo=0):
    """
    Reset Slot. This is only for HD systems.  It will disrupt the audio and video stream so will 
    alter all video logging, viewing, audio analysis, video analysis, motion detection, 
    sdo execution etc.  It should be called when nothing of importance is happening.  
    Return: None.  Exception thrown on error.
    """
    return stormtest_client.stc.reset_slot(slotNo)


## @par Description
#  SignalRecoveryMode Enum. Defines the names for signal recovery mode.  See SetSignalRecoveryMode()
#  @param Safe : The hardware performs in a safe manner, assuming the worst case scenario
#  @param Fast : The hardware performs in a fast manner.  This assumes that the video resolution
#  on signal recovery was the same as when it was lost.
class SignalRecoveryMode:
    Safe = 0
    Fast = 1


## @par Description
#  This function modifies the behaviour of the hardware (and thus the system) when HDMI signal
#  has been lost.  It has no impact on SD and 4K systems (but does not throw an exception or indicate
#  any error).  HD systems can, on rare occasions, "freeze" if the signal resolution changes after it 
#  has been lost while the hardware input capture logic is active.  The default mode (from release 3.3.1)
#  is to turn off the hardware input capture when signal loss is detected.  When a signal is detected 
#  then the hardware input capture is turned on at the newly detected resolution.  However, this can 
#  take up to 6 seconds.  If your application is time critical and you know the device connected to 
#  the StormTest system won't change its resolution then you can set Fast mode.  However, if the device
#  does change its resolution, even briefly (perhaps especially briefly) then there is a risk that the
#  slave server will freeze.  In that case, the recovery procedure is a manual power cycle of the slave server.
#  Until power cycle, tests on any of the 4 slots on the slave server will fail.
#  Script writers are advised to exercise extreme caution before using Fast mode and use it for the minimum possible time.
#  @param[in] mode @b SignalRecoveryMode : The mode to use for the signal recovery operation
#  @param[in] slotNo @b Integer: (optional) This sets the mode for a specific slot only, 0 for all reserved slots
#  @return None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetSignalRecoveryMode(SignalRecoveryMode.Fast, 8)
#  @endcode
#  @note When a slot is released it automatically is set to Safe mode.
@ApiFunction
def SetSignalRecoveryMode(mode, slotNo=0):
    if mode == SignalRecoveryMode.Safe or mode == SignalRecoveryMode.Fast:
        stormtest_client.stc.set_signal_recovery_mode(mode, slotNo)
    else:
        raise StormTestExceptions("The signal recovery mode must be Safe or Fast, not {0}".format(mode))


## @par Description
#  This function returns the current signal recovery mode as set by SetSignalRecoveryMode.  Although the
#  signal recovery mode has no impact on SD or 4K systems, this function is supported.  This function was introduced
#  in release 3.3.1 of StormTest
#  @param[in] slotNo @b Integer: (optional) This gets the mode for a specific slot only, 0 for all reserved slots
#  @return SignalRecoveryMode if slotNo is non zero, otherwise a list of lists with each sub list being [slot, SignalRecoveryMode]
#  Python will actually return the associated integer from the enumeration instead of the object type.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>print(GetSignalRecoveryMode(8))
#   >>0
#   >>print(str(GetSignalRecoveryMode(0)))
#   >>[[1,0],[4,1],[5,0]]
#  @endcode
@ApiFunction
def GetSignalRecoveryMode(slotNo=0):
    return stormtest_client.stc.get_signal_recovery_mode(slotNo)

# Deprecated Function
@ApiFunction
def GetReservedSlots():
    """
    DEPRECATED. Use GetLogicalReservedSlots() or GetPhysicalAllocations()
    """
    return stormtest_client.stc.get_reserved_slots()

## @par Description
#  This function returns a list of logical slots reserved by the test script - these are the slot numbers passed to ReserveSlot() and
#  thus can be used for any later function call which requires a slot number.  This is only important when running under the client daemon
#  as the actual slot used (the physical slot) is NOT the same as the slot reserved via ReserveSlot() (the logical slot).  This function,
#  together with GetPhysicalAllocations() allows the script to find out either piece of information, depending on how the script wishes to
#  use the information.  When NOT under the client daemon, physical slots == logical slots.
#  @param None
#  @return @b List: a list of the logical slots reserved by the test.
#  @subsection _eg1:
#  @b Example:
#  @code
#   >> print(str(GetLogicalReservedSlots()))
#   >>  [1,2,3]
#  @endcode
@ApiFunction
def GetLogicalReservedSlots():
    """
    Returns a list of slots reserved by the test script - these are the slot numbers passed to
    ReserveSlot() and represent the LOGICAL slot number as known to the test (under the Client
    Daemon, the actual physical slot could be different).

    Return: List.  List of the logical slots reserved by the test, each an integer
    """
    return stormtest_client.stc.get_logical_slots()

## @par Description
#  This function returns the list of physical slots allocated to the test, along with the physical server name and port used.  It can be called
#  before ConnectToServer() or ReserveSlot() to gather information about how the StormTestScheduler has allocated resources to the script
#  It will return None if the script is not running under the client daemon (ie has NOT been scheduled by the StormTest Scheduler)
#  @param None
#  @return @b Tuple: a tuple of 2 items, the server name:port and the list of physical slots allocated to the test.  None if not under daemon
#  @subsection _eg1:
#  @b Example:
#  @code
#   >> print(str(GetPhysicalAllocations()))
#   >> ("stormtest01:8000", [5,6])
#  @endcode
@ApiFunction
def GetPhysicalAllocations():
    """
    Returns the list of physical slots allocated to the test, along with the physical server name
    and port used.  It can be called before ConnectToServer() or ReserveSlot() to gather
    information about how the StormTestScheduler has allocated resources to the script.

    Return: Tuple. 1st item is server name & port (server:port) and the second is a List of
      integers indicating physical slot numbers. Will return None if script is not running under
      the Client Daemon.
    """
    return stormtest_client.stc.get_physical_allocations()

##  @par Description
#  This returns a simple boolean indicating whether the test is running under the client daemon (i.e. has been scheduled or run remotely) or
#  not.
#  @param none
#  @return @b Bool: True if running under daemon. False if test invoked from command line manually (or by some means other than StormTest
#  scheduler)
#  @subsection _eg1 eg1:
#  @b Example:
#  @code
#   >> print(str(IsUnderDaemon()))
#   >> False
#  @endcode
@ApiFunction
def IsUnderDaemon():
    """
    Returns a simple boolean indicating whether the test is running under the client daemon or not.

    Return: Bool. True if running under daemon. False if test invoked from command line manually
      (or by some means other than StormTest scheduler)
    """
    return stormtest_client.stc.is_under_daemon()

## @par Description
#  TM Enum. Defines the valid values expected by the StormTest Test Manager after a test runs.
#  @param PARTIAL_PASS : Test passed on some of the slots it ran on.
#  @param FAIL : Test failed.
#  @param PASS : Test passed.
#  @param NOT_RUN: The test did not run.  This is never returned by a test script but can be returned by a test step to indicate that the test step did not run.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>ReturnTestResult(TM.PASS)
#  @endcode
class TM:
    """
    Defines the valid values expected by the StormTest Test Manager after a test runs.

    PARTIAL_PASS: Test passed on some of the slots it ran on.
    FAIL : Test failed.
    PASS : Test passed.
    NOT_RUN: The test step (not the test script) did not run.
    """
    PASS         = 111
    PARTIAL_PASS = 110
    FAIL         = 100
    NOT_RUN      = 101

# Deprecated Class
## @par Deprecated
class TestResult:
    """
    DEPRECATED.
    """
    NotRun, Fail, Pass= list(range(1, 4))

## @par Description
#  This function is used to return a test result to the calling process. Calling this function will cause the test script process to
#  exit, so this should be the very last function call in a test script.\n\n
#  Specify the test result using the TM enum.

#  @param[in] testResult @b TM: The result of the test run.
#  @param[in] saveResultToDB @b Boolean (optional): whether save the test results into database.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Preferred method
#   >>ReturnTestResult(TM.PASS)    # Test passed
#
#
#  @endcode
#  @note The following values are allowable valid test result values if the TM enum is not used:
#  - 111 PASS
#  - 110 PARTIAL_PASS
#  - 100 FAIL
#  - 101 NOT_RUN
@ApiFunction
def ReturnTestResult(testResult, saveResultToDB = True):
    """
    Used to return a test result to the calling process. Calling this function will cause the
    test script process to exit, so this should be the very last function call in a test script.
    It must be used to return a value other than 'unknown' to store in the database when the
    test is run via the StormTest scheduler.

    Return: None.  The function does not return as it causes an exit of the script

    testResult: (TM or Integer) The result of the test. Best practice is to use TM.PASS
      or another value from TM. An integer can be used but Developer Suite may not interpret
      the result for you.

    saveResultToDB: (Bool, optional) whether save the test results into database.
    """
    return stormtest_client.return_test_result(testResult, saveResultToDB)

## @par Description
#  This function allows a test script writer to divide the test script into "Test Steps". Each test step in the script is then able to write a result to the StormTest database.
#  The database will also capture the length of each test step. Versions prior to 2.0 called this function BeginTestCase and that exists for compatibility purposes
#  @param[in] testStepName @b String: The name of the test step.
#  @return @b Bool: True if ok, False if error.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >> BeginTestStep("test step one")
#  @endcode
@ApiFunction
def BeginTestStep(testStepName):
    """
    Start a 'test step' - a logical division of a script defined by the script writer. Each test
    step in the script is then able to write a result to the StormTest database. The database will
    also capture the length of each test step.

    Return: Bool. True if ok, False if error.

    testStepName: (String) The name of the test step.
    """
    return stormtest_client.stc.begin_test_step(testStepName)

# Deprecated Function
@ApiFunction
def BeginTestCase(testCaseName):
    """
    DEPRECATED - use BeginTestStep()
    """
    return stormtest_client.stc.begin_test_case(testCaseName)

## @par Description
#  This function should be called at the end of each test step. BeginTestStep() must have been called previously with the same @e testStepName.
#  Versions prior to 2.0 called this function EndTestStep and that exists for compatibility purposes.
#  @param[in] testStepName @b String: The name of the test step.
#  @param[in] testResult @b Integer: The result of the test step. This can be any integer value and is not significant to StormTest. It will be recorded in the database and displayed in the StormTest Developer Suite.
#  @param[in] testComment @b String: A comment regarding the test step. This can be any value and is not significant to StormTest. It will be recorded in the database and displayed in the StormTest Developer Suite.
#  @param[in] startTimeStamp @b Integer: (optional) The timestamp representing when the test step started. Use 0 to allow StormTest to find this automatically.  Value is in seconds since the Unix epoch (1/1/1970)
#  @return @b Bool: True if ok, False if error.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >> BeginTestStep("test step one")
#   >> ...
#   >> EndTestStep("test step one", 111, 'A comment')
#  @endcode
@ApiFunction
def EndTestStep(testStepName, testResult, testComment, startTimeStamp=0):
    """
    Called at the end of each test step. BeginTestStep() must have been called previously with
    the same testStepName.

    Return: Bool. True if ok, False if error.

    testStepName: (String) The name of the test step.

    testResult: (Integer) The result of the test step. This can be any integer value and is not
      significant to StormTest. It will be recorded in the database and displayed in the StormTest
      Developer Suite.

    testComment: (String) A comment regarding the test step. This can be any value and is not
      significant to StormTest. It will be recorded in the database and displayed in the
      StormTest Developer Suite.

    startTimeStamp: (Integer, optional) The timestamp representing when the test step started.
      Use 0 to allow StormTest to find this automatically.
    """
    return stormtest_client.stc.end_test_step(testStepName, testResult, testComment, startTimeStamp)

# Deprecated Function
@ApiFunction
def EndTestCase(testCaseName, testResult, testComment, startTimeStamp=0):
    """
    DEPRECATED - use EndTestStep()
    """
    return stormtest_client.stc.end_test_case(testCaseName, testResult, testComment, startTimeStamp)

# Deprecated Function
@ApiFunction
def GetTestStepResult(testStepName):
    """
    DEPRECATED
    """
    return stormtest_client.stc.get_test_step_result(testStepName)

# Deprecated Function
@ApiFunction
def GetTestCaseResult(testCaseName):
    """
    DEPRECATED - use GetTestStepResult()
    """
    return stormtest_client.stc.get_test_case_result(testCaseName)

## @par Description
#  This function returns the software version of the StormTest client application.
#  @param None
#  @return @e softwareVersion @b String: The client software version.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>ret = GetClientVersion()
#   >>print(str(ret))
#   >>1.1.0
#  @endcode
@ApiFunction
def GetClientVersion():
    """
    Return software version of the StormTest client application.

    Return: String. The client software version, e.g. 2.5.0.1234
    """
    return stormtest_client.stc.get_client_version()

## @par Description
#  This function returns the status of all slots in the StormTest cabinet, independent of whether they are reserved by the user or not.
#  @param None
#  @return @e slotInfo @b List: An array of 16 lists. Each one corresponding to a slot in the StormTest cabinet. See @ref _checkSlots.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>ret=CheckSlots()
#   >>print(str(ret))
#   >>[[1, 'Baggio', 'Stress Test'], [1, 'Zidan', 'Live Pause Test'],
#      [0, ' ', ' '], [0, ' ', ' '], [0, ' ', ' '], [0, ' ', ' '],
#      [0, ' ', ' '], [0, ' ', ' '], [0, ' ', ' '], [0, ' ', ' '],
#      [0, ' ', ' '], [0, ' ', ' '], [0, ' ', ' '], [0, ' ', ' '],
#      [0, ' ', ' '], [0, ' ', ' ']]
#  @endcode
#  @note This function will wait a maximum of 10 seconds before returning.
#  @note These are the valid returned slot indicator values:
#  - 0: The slot is free.
#  - 1: The slot is reserved.
#  - 2: The slot is available but powered off.
@ApiFunction
def CheckSlots():
    """
    Get the status of all slots in the StormTest sever, independent of whether they are
    reserved by the user or not.

    Return: List of Lists.  Each list represents a slot and the contents of the list is another
      list.  This has 3 elements: Status, User, Description (as specified in ConnectToServer())
      Status is 0 (Free), 1 (Reserved), 2 (Free but powered off)
    """
    return stormtest_client.stc.check_ports()

## @par Description
#  This function returns information about the locked and reserved status of 1 or more slots, independent of whether they are
#  reserved or not.  It is not necessary to call ConnectToServer() or ReserveSlot() before calling this function.  You may call
#  SetMasterConfigurationServer() to select the facility to query but it is not necessary - the default will be used if no
#  explicit configuration server is set.  This function is available in release 3.3.4.
#  @param[in] server @b String : (optional) The name of the server where the slot of interest is located.  If omitted, data is
#  returned for all servers in the facility.
#  @param[in] slot @b Integer : (optional) The slot number where the slot of interest is located.  If omitted, data is returned
#  for all slots on the specified server.  It is not an error to specify a slot but set the server to 'None' - however, in this case
#  data is returned for all slots on all servers in the facility.
#  @return @e slotInfo @b List of Dictionary : In all cases a list of dictionary objects is returned, one for each slot.  This is
#  the case even when an explicit server/slot is specified.  Each dictionary contains the following key value pairs:\n
#  Server - the server name\n
#  Slot - the slot number\n
#  Locked - True/False indicating whether a slot is locked, see note<SUP>1</SUP>\n
#  LockUser - Name of user who has locked the slot. None if slot is not locked\n
#  LockStart - A DateTime object indicating when the lock started. None is slot is not locked\n
#  Reserved - True/False indicating whether the slot is reserved, see note<SUP>1</SUP>\n
#  ReservedUser - Name of user who has reserved the slot, None if slot is not reserved\n
#  ReservationEnd - A DateTime object indicating when the reservation ends, None if slot is not reserved\n
#  ActiveSchedule - The name of the schedule that is active on this slot, None if the slot is not reserved\n
# 
#  @note
#  -# A slot is 'Locked' if a test / user has called ReserveSlot on the slot.  It is 'Reserved' if there is a non shared, non disabled
#  schedule allocated to the slot.  This terminology matches DeveloperSuite GUI.
#
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>ret=GetReservedStatus('myserver', 9)
#   >>print(str(ret))
#   >>[{'Server': 'myserver', 'Slot': 9, 'Locked': True, 'LockUser': 'me', 
#       'LockStart': datetime.datetime(2016, 4, 25, 14, 57, 58, 145000),
#       'Reserved': True, 'ReservedUser': 'me', 
#       'ReservationEnd': datetime.datetime(2016, 4, 25, 19, 0, 0, 0), 
#       'ActiveSchedule': 'my schedule'}]
#
#   >>ret=GetReservedStatus()
#   >>print(str(ret))
#   >>[{'Server': 'myserver', 'Slot': 1, ...}, {'Server': 'myserver', 'Slot': 2, ...}, ... 
#      {'Server': 'server2', 'Slot': 1, ...}, ...]
#  @endcode
@ApiFunction
def GetReservedStatus(server=None, slot=None):
    return stormtest_client.stc.GetReservedStatus(server, slot)

## @par Description
#  This function pauses a script execution for @e sec number of seconds.
#  @param[in] sec @b Float: Time in seconds.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>WaitSec(0.5)
#  @endcode
@ApiFunction
def WaitSec(sec):
    """
    Pause for a while.  This is client side pause and has no impact on the server.

    Return: None

    sec: (Float) Time in seconds to pause.
    """
    return stormtest_client.stc.wait(sec)

## @par Description
#  This function tests for the availability of features of the API, system or a server.
#  @param[in] capabilityList @b List: list of capabilities
#  @param[in] server @b String: (optional) server name to query capabilites for.  if the
#  capability being tested is related to a server then the server name must be provided if
#  HasCapability is called before ConnectToServer.
#  @return @e status @b bool: If all capabilities are supported, then True is returned, else False.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>HasCapability([SystemCapability.Serial],"StormTest01")
#   >>True   # So, server StormTest01 has serial capability
#  @endcode
@ApiFunction
def HasCapability(capabilityList, server=None):
    """
    This function tests for the availability of features of the API, system or a server.
    If the capability being tested is related to a server then the server name must be provided if
    HasCapability is called before ConnectToServer.

    return bool: If all capabilities are supported, then True is returned, else False.
    """
    return stormtest_client.stc.has_capability(capabilityList, server)

## @par Description
#  This function returns the full list of system and server capabilities.
#  @param[in] server @b String: (optional) server name to query capabilites for.  If None
#  and ConnectToServer has been called then the connected server is assumed.  If called with None prior to
#  ConnectToServer then just the system (non server specific) capabilities are returned.
#  @return @e capabilities @b List: List of strings corresponding to the SystemCapability enumerated types
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>GetCapabilities("StormTest01")
#   >>['IR', 'Power', 'Serial', 'BasicAV', 'OCR', 'VTA', 'NamedResources']
#  @endcode
@ApiFunction
def GetCapabilities(server=None):
    """
    This function returns the full list of system and server capabilities.
    param server String: (optional) server name to query capabilites for.  If None
    and ConnectToServer has been called then the connected server is assumed.  If called with None prior to
    ConnectToServer then just the system (non server specific) capabilities are returned.
    return capabilities List: List of strings corresponding to the SystemCapability enumerated types
    """
    return stormtest_client.stc.get_capabilities(server)

## @par Description
#  SystemCapability Enum. Defines the names for all the system and server capabilities.  The supported list is:
#  @param IR : The server has IR device installed
#  @param Power : The server has RPS power device installed
#  @param Serial : The server has serial controller device installed
#  @param BasicAV : The server has audio video capture card installed and can do basic AV functions
#  @param HD : The server has HD audio video capture card installed and can do basic AV functions at High Definition
#  @param OCR : The server has OCR and a valid license for OCR
#  @param VTA : The server can do High Speed Video Timing (this implies BasicAV)
#  @param AVAnalysis : The server can do audio/video analysis (is licensed for it)
#  @param NamedResources : The System supports named resources.
#  @param DUTSpecificResources : The System supports named resources per DUT model
#  @param SDO : The server supports screen definition objects
#  @param GPUVideoCompression : The server is doing Video Compression using the GPU (host based s/w encoding) rather than hardware encoding.  Some servers
#  cannot do hardware encoding.  If GPU encoding is being used, there is a higher CPU cycle usage so video streaming (eg log file recording or viewing) should
#  only be used when absolutely necessary.  When GPU encoding is used in HD it is possible to control the streaming resolution with SetResolution.  This capability
#  was added in release 3.3.0
class SystemCapability:
    IR = stormtest_client.SystemCapability.IR
    Power = stormtest_client.SystemCapability.Power
    Serial = stormtest_client.SystemCapability.Serial
    BasicAV = stormtest_client.SystemCapability.BasicAV
    HD = stormtest_client.SystemCapability.HD
    OCR = stormtest_client.SystemCapability.OCR
    VTA = stormtest_client.SystemCapability.VTA
    AVAnalysis = stormtest_client.SystemCapability.AVAnalysis
    NamedResources = stormtest_client.SystemCapability.NamedResources
    DUTSpecificResources = stormtest_client.SystemCapability.DUTSpecificResources
    SDO = stormtest_client.SystemCapability.SDO
    GPUVideoCompression = stormtest_client.SystemCapability.GPUVideoCompression

## @par Description
#  This function marks the beginning of a region in the log file.  Regions are shown in the
#  log file with the name and are 'closed up' with the contents not visible until the user
#  clicks to open and reveal them.  This can be useful to demarcate parts of a log for ease of
#  review.  The name is mandatory and is case sensitive.  The style is one of the
#  LogRegionStyle values to indicate the style of the region.
#  @param[in] name @b String: The name of the region.
#  @param[in] style @b LogRegionStyle: (optional) the style of the region
#  @param[in] comment @b String: (optional) An optional comment, appended to the name for display purposes.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>BeginLogRegion("set up DUT")
#  @endcode
@ApiFunction
def BeginLogRegion(name, style=None, comment=None):
    """
    This function marks the beginning of a region in the log file.  Regions are shown in the
    log file with the name and are ‘closed up’ with the contents not visible until the user
    clicks to open and reveal them.  This can be useful to demarcate parts of a log for ease of
    review.  The name is mandatory and is case sensitive.  The style is one of the
    LogRegionStyle values to indicate the style of the region.
    param name String: The name of the region.
    param style LogRegionStyle: (optional) the style of the region
    param comment String: (optional) An optional comment, appended to the name for display purposes.

    return None
    """
    return stormtest_client.stc.begin_log_region(name, style, comment)

## @par Description
#  This function marks the end of a region in the log file.  Regions are shown in the log file
#  with the name and are 'closed up' with the contents not visible until the user clicks to
#  open and reveal them.  This can be useful to demarcate parts of a log for ease of review.
#  The name is mandatory and must match a previous BeginLogRegion.  It is case sensitive.
#  The style and comment, if not None, will override any style or comment set with BeginLogRegion.
#  It is not necessary to set the style or comment on a log region (either the begin or end)
#   - in that case, the default style will be used.
#  @param[in] name @b String: The name of the region.
#  @param[in] style @b LogRegionStyle: (optional) the style of the region
#  @param[in] comment @b String: (optional) An optional comment, appended to the name for display purposes.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>EndLogRegion("set up DUT", LogRegionStyle.Pass, "All OK, Version 1.0 found")
#  @endcode
@ApiFunction
def EndLogRegion(name, style=None, comment=None):
    """
    This function marks the end of a region in the log file.  Regions are shown in the log file
    with the name and are ‘closed up’ with the contents not visible until the user clicks to
    open and reveal them.  This can be useful to demarcate parts of a log for ease of review.
    The name is mandatory and must match a previous BeginLogRegion.  It is case sensitive.
    The style and comment, if not None, will override any style or comment set with BeginLogRegion.
    It is not necessary to set the style or comment on a log region (either the begin or end)
    in that case, the default style will be used.

    param name String: The name of the region.
    param style LogRegionStyle: (optional) the style of the region
    param comment String: (optional) An optional comment, appended to the name for display purposes.

    return None
    """
    return stormtest_client.stc.end_log_region(name, style, comment)

## @par Description
#  LogRegionStyle Enum. Defines the names for the log region styles.  The supported styles are:
#  @param Pass : this is color coded Green.
#  @param Warn : this is color coded Orange.
#  @param Fail : this is color coded Red.
#  @param Serial : this is color coded gray (the same as serial logs in the log files)
#  @param Observe : this is color coded purple (the same as Observe lines in the log files)
#  @param Console : this is color coded gray (the same as console output in the log files)
#  @param Verbose : this is color coded light magenta (the same as verbose lines in the log file)
#  @param Entry : this is color coded blue (the same as function entry/exit lines in the log file)
class LogRegionStyle:
    Pass = stormtest_client.LogRegionStyle.Pass
    Warn = stormtest_client.LogRegionStyle.Warn
    Fail = stormtest_client.LogRegionStyle.Fail
    Serial = stormtest_client.LogRegionStyle.Serial
    Observe = stormtest_client.LogRegionStyle.Observe
    Console = stormtest_client.LogRegionStyle.Console
    Verbose = stormtest_client.LogRegionStyle.Verbose
    Entry = stormtest_client.LogRegionStyle.Entry

## @}

############################################################################################

## @defgroup Group2 IR command API
# The IR command functions control the irNetBox.\n\n
# The functions in this section of the API are used to emulate the remote control keys and also to
# modify the power of the IR signal being sent to the box.
## @{

## @par Description
#  This function sends an IR key press to the DUT(s).
#  @param[in] button @b String or NamedString: The remote control key you wish to emulate.  If the
#  button is a NamedString then the resource is looked up.  The format of the string is the same
#  as the .mac file saved from the StormTest Developer Suite record macro feature.  It allows you
#  to send multiple buttons with individual delays after each button press.
#  @param[in] slotNo @b Integer: (optional) This sends the IR pulse to a specific slot only.
#  @return @e status @b Integer: Returns 1 if the button press succeeded, otherwise 0.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>PressButton(button)   #Press button for all slots
#   or
#   >>PressButton(button,7) #Press button for slot 7 only
#  @endcode
#  @note The @e button parameter is a generic key name that will be translated into an IR pulse,
#            depending on the remote type selected.
#  @note If the @e slot parameter is left out then the IR pulse will be sent
#            on all slots that were reserved.
@ApiFunction
def PressButton(button, slotNo=0):
    """
    Sends an IR key press to the DUT(s).

    Return: Integer. Returns 1 if the button press succeeded, otherwise 0.

    button: (String) The remote control key you wish to emulate.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.press(button, slotNo)

## @par Description
#  This function enables or disables the critical section around the
#  PressDigits() call.  Prior to release 1.4.2, the IR was locked for the duration of a
#  PressDigits() call.  To improve performance with multiple users this was changed to avoid
#  locking the IR.  So multiple users could interleave IR key presses with another script's
#  PressDigits() call.  You can restore the 1.4.1 and earlier behaviour either by using 
#  EnablePressDigitsCriticalSection(True) at the start of the script.  Calling the
#  function with no parameters will return the current setting without making a change to
#  behaviour.
#  @param[in] enable @b Boolean: True to put a critical section around every PressDigits() call
#  to restore 1.4.1 and earlier behaviour.  False to avoid the critical section and use 1.4.2 and later
#  behaviour.  This function affects all later calls to PressDigits() and may be called at any time.
#  Default behaviour is no critical section.
#  @param[in] timeout @b Integer: Timeout on critical section, in seconds.  Default is 10 and should
#  be set to be the overall expected time of the longest PressDigits() call - never shorter.
#  @return @e Tuple: (enable, timeout) as a mirror of the most recent parameters used.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>EnablePressDigitsCriticalSection(True, 5)
#  @endcode
@ApiFunction
def EnablePressDigitsCriticalSection(enable=None, timeout=10):
    """
    Enable or disable the critical section around the PressDigits() call.  Prior to release
    1.4.2, the IR was locked for the duration of a PressDigits() call.  To improve performance
    this was removed.  Multiple users can now interleave IR key presses with another script's
    PressDigits() call. You can restore the 1.4.1 and earlier behaviour by using
    EnablePressDigitsCriticalSection(True) at the start of the script.

    Return: Tuple. (enable, timeout) as a mirror of the most recent parameters used.

    enable: (Bool, optional): Enable/Disable the critical section. Omit parameter and no action
      is taken but the return value reflects the current status.

    timeout: (Integer, optional): Timeout on critical section, in seconds.  Default is 10 and
      should be set to be the overall expected time of the longest PressDigits() call - never
      shorter.
    """
    return stormtest_client.stc.enable_press_digits_critical_section(enable, timeout)

## @par Description
#  This function sends a sequence of IR key presses, representing a sequence of digits to the DUT(s).
#  Typically this command will be used to switch the DUT to a particular channel. Alternatively it can also be used to send
#  a PIN or any other sequence of digits. All other characters are ignored.\n\n
#  Note that the digits can be passed as an integer or as a string. If the string of digits includes one or more
#  leading zeros then it @b MUST be sent as a string.
#  @param[in] digits @b Integer/String: The sequence of digits you wish to send to the DUT(s).
#  @param[in] slotNo @b Integer: (optional) This sends the IR pulse on a specific slot only.
#  @param[in] waitSec @b Float: (optional) The interval in seconds between digits being pressed.
#  @return @e status @b Integer: Returns 1 if the digit presses succeeded, otherwise 0.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>PressDigits(123)       # Tune all reserved slots to channel 123
#   or
#   >>PressDigits('0123',7)  # Tune slot 7 to channel 0123 (digits sent as a string)
#  @endcode
#  @note The @e digits parameter is a numeric argument that will be translated into a series of IR pulses, depending on the remote type
#            selected.
#  @note If the @e slot parameter is left out then the IR pulse will be sent
#            on all slots that were reserved.
@ApiFunction
def PressDigits(digits, slotNo=0, waitSec = 0.1):
    """
    Send a sequence of IR key presses, representing a sequence of digits to the DUT(s).
    All non digit characters are ignored.

    Return: Integer. Returns 1 if the digit presses succeeded, otherwise 0.

    digits: (Integer or String) The sequence of digits you wish to send to the DUT(s).  If you wish
      to send a number with leading zeros then you must use a string ('0089') and not an integer

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.

    waitSec: (Float, optional) The interval in seconds between digits being pressed.
    """
    return stormtest_client.stc.channel(digits, slotNo, waitSec)

## @par Description
#  This function returns the number of IR control interfaces available. By default there is only one, but it is possible for a StormTest server
#  to be configured with a secondary IR interface.
#  @param None
#  @return @b Integer: Number of IR interfaces defined for the StormTest server
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>print(str(GetCountIRInterfaces()))
#   >>1
#  @endcode
@ApiFunction
def GetCountIRInterfaces():
    """
    Get the number of IR control interfaces available. By default there is only one, but it is
    possible for a StormTest server to be configured with a secondary IR interface.

    Return: Integer. Number of IR interfaces defined for the StormTest server.
    """
    return stormtest_client.stc.get_count_ir_interfaces()

## @par Description
#  This function sets the IR interface to use for the PressButton(), PressDigits() and
#  IRSetSignalPower() functions.  The default interface is 0 and others start at 1.
#  Inteface 0 is always available and is the default after reserving a slot.  All standard
#  systems have just one IR interface.  Unless you are working on a known non standard
#  server, you should not use this function.
#  @param[in] interfaceIndex @b Integer: The index of the IR interface to use.
#  @param[in] slotNo @b Integer: (optional) This sets the IR interface on a specific slot only.
#  @return @e 1 on success, 0 on a server error and None if slot is not reserved.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetIRControlInterface(1)
#  @endcode
@ApiFunction
def SetIRControlInterface(interfaceIndex, slotNo=0):
    """
    Set the IR interface to use for the PressButton(), PressDigits() and IRSetSignalPower()
    functions. The default interface is 0 and others start at 1. Inteface 0 is always available
    and is the default after reserving a slot.

    Return: 1 on success, 0 on server error, None if slot not reserved.

    interfaceIndex: (Integer) The index of the IR interface to use.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.set_ir_control_interface(interfaceIndex, slotNo)

## @par Description
#  This function gets the current IR interface.
#  @param[in] slotNo @b Integer: (optional) This fets the IR interface for a specific slot only.
#  @return @b List: A list of List, one for each slot. Values are [SlotNo, InterfaceNo]. If a slot is passed in, the result is a single integer for the interface No.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>print(str(GetIRControlInterface()))
#   >>[[1, 0]]    # Slot 1 is using IR interface 0
#   >>
#   >>print(str(GetIRControlInterface(2)))
#   >>1           # Slot 2 is using IR interface 1
#  @endcode
@ApiFunction
def GetIRControlInterface(slotNo=0):
    """
    Get the current IR interface.

    Return: List of Lists / Integer. If slotNo is 0 then a list of Lists is returned. Otherwise
      just 1 Integer.  The content of the list is [Slot Number, Interface Number in use].

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.get_ir_control_interface(slotNo)

# Deprecated Function
@ApiFunction
def BeginCriticalSection(timeout = 10):
    """
    DEPRECATED
    """
    return stormtest_client.stc.begin_critical_section(timeout)

# Deprecated Function@ApiFunction
def EndCriticalSection():
    """
    DEPRECATED
    """
    return stormtest_client.stc.end_critical_section()

## @par Description
#  This function sets the IR signal output power level.
#  @param[in] powerLevel @b Integer: The signal output power level.
#  @param[in] slotNo @b Integer: (optional) This changes the power level on a specific slot only.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>IRSignalPower(2,1) #Sets the signal output power level to 2 on slot 1
#     or
#   >>IRSignalPower(2)   #Sets the signal output power level to 2 for all reserved slots
#  @endcode
#  @note A valid power level is 1-3 where 1 means low, 2 means medium, 3 means high.
#  @note If the @e slotNo parameter is omitted the default is to set the signal output power level for all slots reserved.
#  @note If the power level is set too high, it may cause interference with other adjacent DUTs.
@ApiFunction
def IRSetSignalPower(powerLevel, slotNo=0):
    """
    Set the IR signal output power level.

    Return: None

    powerLevel: (Integer) The signal output power level. 1 is low, 2 is medium and 3 is high.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.ir_set_signal_power(powerLevel, slotNo)

## @}

############################################################################################

## @defgroup Group18 Navigator API
# These functions control the high level navigation API.  This is a new feature introduced
# in version 3.0 of StormTest providing a simple to use high level navigation function. A
# Navigator is designed using StormTest Developer Suite and can be saved to a file for use
# local to the script or uploaded using StormTest Developer Suite to the central repository
# for shared use.  It can be associated with a DUT using the StormTest Admin Console.
## @{

## @par Description
# This function opens a Navigator and associates it with a reserved slot.  The Navigator
# used must have been uploaded to the StormTest Repository in the Navigators area, either by using
# StormTest Developer Suite or using the UploadPublicNavigator method.
# @param[in] navigatorName @b String: The name of the Navigator to open.  If this is None then
# the default Navigator allocated for the DUT in the slot will be used.
# @param[in] slotNo @b Integer: (optional) Specifies the slot for which the Navigator will be
# opened.  If 0 then all reserved slots will have the specified Navigator.  If None is specified
# as the navigatorName then each slot will have its default Navigator (if that has been configured)
# @return @e List of lists if slotNo = 0, (each list is [slot number, string]) otherwise a single string.
# The value of the string is the name of the Navigator for the slot, None if the default is requested
# and there is no default.  If an explicit Navigator is specified and it does not exist then an
# exception of type StormTestExceptions is thrown.
# @subsection _eg1 eg1:
# @b Example:
# @code
#  >> OpenNavigator("mynavigator")          # slots 4 and 5 are reserved
#  >> [[4,"mynavigator"],[5,"mynavigator"]]
#  >> OpenNavigator(None)                   # slots 4 and 5 are reserved but slot 5 has no default
#  >> [[4,"nav1"],[5, None]]
# @endcode
# @note The default Navigator is configured using the Admin Console web based tool.
# @note If there is already a Navigator open on a slot, it will be closed first.  This will occur
# before an attempt is made to open the requested Navigator.
@ApiFunction
def OpenNavigator(navigatorName = None, slotNo = 0):
    return stormtest_client.stc.OpenNavigator(navigatorName, slotNo, AllowIgnoredScreens)

## @par Description
# This function opens a Navigator from a file and associates it with a reserved slot.
# The file can be any path accessible to the script running.
# @param[in] navigatorFile @b String: The path and filename of the Navigator to open. If this
# is not an absolute path then the file will be assumed to be in the same folder as images
# configured via SetDirectories function.
# @param[in] slotNo @b Integer: (optional) Specifies the slot for which the Navigator will be
# opened.  If 0 then all reserved slots will have the specified Navigator.
# @return @e List of lists if slotNo = 0, (each list is [slot number, boolean]) otherwise a single boolean.
# The value of the boolean is true if the Navigator was opened, false if the Navigator was corrupt or
# missing something important.  If the file does not exist then an exception of type
# StormTestExceptions is thrown.
# @subsection _eg1 eg1:
# @b Example:
# @code
#  >> OpenNavigatorFile("mynavigator.stnav_runtime")          # slots 4 and 5 are reserved
#  >> [[4,True],[5,True]]
# @endcode
# @note If there is already a Navigator open on a slot, it will be closed first.  This will occur
# before an attempt is made to open the requested Navigator.
@ApiFunction
def OpenNavigatorFile(navigatorFile, slotNo = 0):
    return stormtest_client.stc.OpenNavigatorFile(navigatorFile, slotNo, AllowIgnoredScreens)

## @par Description
# This function closes a Navigator, freeing resources and breaks the association with its slot.
# @param[in] slotNo @b Integer: (optional) Specifies the slot for which the Navigator will be
# closed.  If 0 then all reserved slots will have their Navigator closed.
# @return @e List of lists if slotNo = 0, (each list is [slot number, boolean]) otherwise a single boolean.
# The value of the boolean is true if the Navigator was closed, false if there was no Navigator
# open on the slot.
# @subsection _eg1 eg1:
# @b Example:
# @code
#  >> CloseNavigator()              # slots 4 and 5 are reserved but only 5 has a Navigator
#  >> [[4,False],[5,True]]
# @endcode
# @note The API is 'smart' in the sense that if the same Navigator is assigned to multiple slots
# and closed on just one slot, no resources are freed and the Navigator is still usable on other
# slots.  It closes per slot not the underlying object.
@ApiFunction
def CloseNavigator(slotNo = 0):
    return stormtest_client.stc.CloseNavigator(slotNo)

## @par Description
# This function gets the list of screen in the Navigator associated with a slot.
# @param[in] slotNo @b Integer: (optional) Specifies the slot for which the list of screens will
# be returned.  If 0 then the list of screens for all reserved slots will be returned.
# @return @e List of lists if slotNo = 0, (each list is [slot number, List of strings]) otherwise a single
# list of strings.  The list of strings will be the screen names defined in the Navigator.  The order
# of the strings is not specified.  It will be the same on repeated calls to this function but may
# change if the Navigator file is edited.  If there is no Navigator for a slot, then an empty list
# is returned.
# @subsection _eg1 eg1:
# @b Example:
# @code
#  >> GetNavigatorScreens()              # slots 4 and 5 are reserved but only 5 has a Navigator
#  >> [[4,[]],[5,["screen1","epg_start","main menu" ...]]]
#  >> GetNavigatorScreens(5)
#  >> ["screen1","epg_start","main menu"]
# @endcode
@ApiFunction
def GetNavigatorScreens(slotNo = 0):
    return stormtest_client.stc.GetNavigatorScreens(slotNo)

## @par Description
# This function validates that the current DUT screen is equal to a specified screen in the Navigator.
# @param[in] screenName @b String: The name of a screen in the Navigator.
# @param[in] slotNo @b Integer: (optional) Specifies the slot for which the screen will be validated.
# If 0 then all reserved slots will be validated.  It is not required that all slots have the same
# Navigator but it is required that the screen name is valid in all slots.
# @return @e List of lists if slotNo = 0, (each list is [slot number, status tuple]) otherwise a single
# status tuple.  The status tuple is (bool (pass/fail), List Of Tests). The list of tests is the list of
# validation criteria for the screen in the format [ConditionName, bool (Pass/Fail), valueObject]. The
# valueObject is a dictionary of keys in format of parameter=>value.  If a slot does not have a
# Navigator defined or the screen is not valid for the slot, then an exception of type StormTestExceptions
# is thrown.
# @subsection _eg1 eg1:
# @b Example:
# @code
#  >> ValidateNavigatorScreen("epg", 4)
#  >> (True,[["IconExist",True, {'ImageSimilarity': 98}],["Title", True, {'ObtainedString': "MENU"}]])
#  >> ValidateNavigatorScreen("main", 4)
#  >> (False,[["RightColor",False, {'DetectedColor': [55,90,9], 'Detected Flatness': 6, 'Detected Peak Error': 67.88}]])
#  >> ValidateNavigatorScreen("epg")
#  >> [[4,(True,[["IconExist",True, {'ImageSimilarity': 98}],["Title", True, {'ObtainedString': "MENU"}]])],[5,(False,[["IconExist",False, {'ImageSimilarity': 50}],["Title", True, {'ObtainedString': "MENU"}]])]]
# @endcode
@ApiFunction
def ValidateNavigatorScreen(screenName, slotNo = 0):
    return stormtest_client.stc.ValidateNavigatorScreen(screenName, slotNo)

## @par Description
# This function navigates to a specific screen.  Note that this validates the source screen as the first step
# if the source screen is specified.
# @param[in] destinationScreen @b String: The name of a screen in the Navigator to navigate to.
# @param[in] sourceScreen @b String: The name of a screen in the Navigator which the script believes is visible on the
# DUT.  If this is None, then no assumptions are made and the API uses the defined Start Key sequence in the
# Navigator to bring the DUT to a known location and then continues navigation.  If there are no such keys defined
# in the Navigator then an exception of type StormTestExceptions is thrown.  The overall script execution
# time will be improved if the sourceScreen is specified (this may not be possible on the first call, of course).
# @param[in] progressCallback @b Function: (optional) A function to be called on each navigation event.
# This allows the script to get progress about the navigation.  The callback function is defined by the
# user script and gets paramters of slotNumber, screeenName, nextScreen, keysToPress.  The intended purpose
# of the callback is as an aid to debugging (you get to see the path) and to allow the script to stop the
# navigation, if for instance, the 'wrong' screen is used as an intermediate screen.
# @param[in] slotNo @b Integer: (optional) Specifies the slot for which the Navigator will navigate.
# Due to the complexity of navigation, if 0 is used then the API will execute <b>if and only if</b> the
# script has reserved 1 slot.  It will throw an exception if 2 or more slots have been reserved.
# @return @e List of lists if slotNo = 0, (each list is [slot number, status tuple]) otherwise a single
# status tuple.  The status tuple is (bool (pass/fail), ScreenName, List Of Tests). The screen name is
# the screen the Navigator expects to be visible (if all has gone well, this is the destinationScreen,
# otherwise it is an intermediate screen which failed to validate). The list of tests is the list of
# validation criteria for the screen in the format [ConditionName, bool (Pass/Fail), valueObject]. The
# valueObject is a dictionary of keys in format of parameter=>value.  If a slot does not have a
# Navigator defined or the screen is not valid for the slot, then an exception of type StormTestExceptions
# is thrown.
# @subsection _eg1 eg1:
# @b Example 1:
# @code
#  >> NavigateTo("epg", 4)
#  >> (True, "epg",[["IconExist",True, {'ImageSimilarity': 98}],["Title", True, {'ObtainedString': "MENU"}]])
#  >> NavigateTo("main", 4)
#  >> (False,"setup",[["RightColor",False, {'DetectedColor': [55,90,9], 'Detected Flatness': 6, 'Detected Peak Error': 67.88}]])
#  >> NavigateTo("epg", "setup", 4)
#  >> (True, "epg",[["IconExist",True, {'ImageSimilarity': 98}],["Title", True, {'ObtainedString': "MENU"}]])
# @endcode
# @subsubsection _eg2 eg2:
# @b Example 2:
# @code
#  >> def NavSpy(slot, screen, nextScreen, keys):
#  >>    print("navigating on slot:"+str(slot)+"screen:"+str(screen)+"next screen:"+str(nextScreen)+"with IR keys:"+str(keys))
#
#  >> NavigateTo("epg", None, NavSpy, 4)
#  >> navigating on slot: 4 screen: None next screen: Main with IR keys: ['Back','Back','Back','Back','Back']
#  >> navigating on slot: 4 screen: Main next screen: Menu with IR keys: ['Menu']
#  >> navigating on slot: 4 screen: Menu next screen: Menu1 with IR keys: ['Down']
#  >> navigating on slot: 4 screen: Menu1 next screen: epg with IR keys: ['OK']
#  >> navigating on slot: 4 screen: epg next screen: None with IR keys: None
#  >> (True, "epg",[["IconExist",True, {'ImageSimilarity': 98}],["Title", True, {'ObtainedString': "MENU"}]])
# @endcode
@ApiFunction
def NavigateTo(destinationScreen, sourceScreen = None, progressCallback = None, slotNo = 0):
    return stormtest_client.stc.NavigateTo(destinationScreen, sourceScreen, progressCallback, slotNo)

## @par Description
# This function validates the entire Navigator attempting to navigate to all screens and using all links
# specified (it implements a solution to the Chinese Postman Problem, Wikpedia has details)
# If the source screen is specified the validation assumes that the DUT is at that screen and validates
# from that point.  If no source screen is specified, the the validation uses the Start Key sequence in the Navigator
# to bring the DUT to a known location and then starts validation.  If there are no such keys defined in the
# Navigator then an exception is thrown.  Due to the complexity of validation, the slot number must be
# explicitly given and it is not possible to run more than one validation in a script at the same time.  An exception
# of type StormTestExceptions is thrown if no Navigator has been opened for the slot.
# @param[in] sourceScreen @b String: The name of a screen in the Navigator which the script believes is visible on the
# DUT.
# @param[in] progressCallback @b Function: (optional) A function to be called on each navigation event.
# This allows the script to get progress about the validation.  The callback function is defined by the
# user script and gets paramters of slotNumber, screeenName, nextScreen, keysToPress.  The intended purpose
# of the callback is as an aid to debugging (you get to see the path) and to allow the script to stop the
# validation, if for instance, it is taking too long.
# @param[in] slotNo @b Integer: Specifies the slot for which the Navigator will validate.
# @return @e Status tuple.  The status tuple is (bool (pass/fail), ScreenName, List Of Tests). The screen name is
# the screen the Navigator stopped validing on an error.  If all has gone well, this is None.
# The list of tests is the list of validation criteria for the screen that failed in the format
# [ConditionName, bool (Pass/Fail), valueObject]. The valueObject is a dictionary of keys in format of
# parameter=>value.
# @subsection _eg1 eg1:
# @b Example:
# @code
#  >> def Spy(slot, screen, nextScreen, keys):
#  >>    print("navigating on slot:"+str(slot)+"screen:"+str(screen)+"next screen:"+str(nextScreen)+"with IR keys:"+str(keys))
#  >> ValidateNavigator(None, Spy, 4)
#  >> navigating on slot: 4 screen: None next screen: Main with IR keys: ['Back','Back','Back','Back','Back']
#  >> navigating on slot: 4 screen: Main next screen: Menu with IR keys: ['Menu']
#  >> navigating on slot: 4 screen: Menu next screen: Menu1 with IR keys: ['Down']
#  >> navigating on slot: 4 screen: Menu1 next screen: epg with IR keys: ['OK']
#  >> # ... many lines here as the navigation map is traversed.
#  >> (True, None, None)
#
#  >> ValidateNavigator(None, Spy, 5)
#  >> navigating on slot: 5 screen: None next screen: Main with IR keys: ['Back','Back','Back','Back','Back']
#  >> navigating on slot: 5 screen: Main next screen: Menu with IR keys: ['Menu']
#  >> (False, "Menu", [["RightColor",False, {'DetectedColor': [55,90,9], 'Detected Flatness': 6, 'Detected Peak Error': 67.88}]])
# @endcode
@ApiFunction
def ValidateNavigator(sourceScreen = None, progressCallback = None, slotNo = 0):
    return stormtest_client.stc.ValidateNavigator(sourceScreen, progressCallback, slotNo)

## @par Description
# This function stops navigation.  This cannot be called on the thread that is navigating (because the
# navigation/validation is synchronous).  So either the script must be multi-threaded or the Stop
# has to be called within the callback on some condition (for example, too much time has elapsed).
# @param[in] slotNo @b Integer: (optional) Specifies the slot for which the Navigator will be
# stopped.  If 0 then all reserved slots will have their Navigator stopped.
# @return @e List of lists if slotNo = 0, (each list is [slot number, boolean]) otherwise a single boolean.
# The value of the boolean is true if the Navigator was stopped, false if there was no Navigator
# open on the slot or the Navigator was not running. Note that if you just call StopNavigator on a reserved
# slot then you cannot determine whether this is due to no Navigator or it has completed the navigation
# before you called StopNavigator.
# @subsection _eg1 eg1:
# @b Example:
# @code
#  >> StopNavigator()
#  >> [[4,False]]
# @endcode
@ApiFunction
def StopNavigator(slotNo = 0):
    return stormtest_client.stc.StopNavigator(slotNo)

## @par Description
# This function gets a list of valid Navigators for the DUT in a specific slot.  The Admin Console must
# have been previously used to configure a DUT in the slot and associate Navigators with the DUT model
# of the DUT instance.  Any of these Navigators should work the the DUT in the specified slot and can
# be used by calling OpenNavigator()
# @param[in] slotNo @b Integer: (optional) Specifies the slot for which the list of Navigators will be
# returned.  If 0 then all reserved slots will have their Navigators returned.
# @return @e List of lists if slotNo = 0, (each list is [slot number, List of strings]) otherwise a single
# list of strings.  The list of strings is all the Navigators which are valid for the slot with the
# first in the list being the 'default' preferred Navigator.  Typically there is only 1 value.  If no
# Navigators are valid, then an empty list is returned.
# @subsection _eg1 eg1:
# @b Example:
# @code
#  >> GetValidNavigators()               # slots 4,5 and 6 are reserved.
#  >> [[4,["Nav2", "Nav88"]], [5, []], [6,["nav1"]]]
# @endcode
@ApiFunction
def GetValidNavigators(slotNo = 0):
    return stormtest_client.stc.GetValidNavigators(slotNo)

## @par Description
# This function gets the current Navigator for the slot.
# @param[in] slotNo @b Integer: (optional) Specifies the slot for which the Navigator is wanted.
# If 0 then all reserved slots will have their Navigators returned.
# @return @e List of lists if slotNo = 0, (each list is [slot number, strings]) otherwise a single
# string.  The string is the Navigator name (if opened with a name) or a filename if opened from
# a file.  If no Navigator is open on a slot, then None is returned.
# @subsection _eg1 eg1:
# @b Example:
# @code
#  >> GetCurrentNavigator()               # slots 4,5 and 6 are reserved.
#  >> [[4,"Nav2"], [5, None], [6,"some_navigation.stnav_runtime"]]
# @endcode
@ApiFunction
def GetCurrentNavigator(slotNo = 0):
    return stormtest_client.stc.GetCurrentNavigator(slotNo)

## @par Description
# This function converts 1 or more screens of a navigator to a ScreenDefinition object. The
# slotNo must have an associated Navigator.
# @param[in] screenToConvert @b String: a string (or a list of strings) specifying the screen to convert. 
# Each screen must be a valid name in the navigator.  If an empty list is specified then all navigator
# screens are returned.  The order is the same as returned in GetNavigatorScreens.
# @param[in] slotNo @b Integer: (optional) The slot number to identify an open navigator. The slot must have a valid
# navigator opened on it.  Can be 0 to mean all reserved slots.
# @return @e List of Lists if slot = 0, (each list is [slot number, result]) otherwise the result.  The result
# is a single ScreenDefinition if a single string is supplied for screenToConvert but if a list is supplied for 
# screenToConvert then the result is also a list of ScreenDefinitions
# @note This API converts a navigator screen so that it can be used in an API call such as WaitScreenDefMatch. 
# The Navigator evaluation of color regions would round the flatness and peak error to the nearest integer
# before checking against the thresholds (the GUI uses integers). Python uses floating point so the conversion
# will adjust the color and peak error by 0.5 percentage points to allow a test that passes in Navigator using
# integers to pass in Python when using floating point.  This change is intentional and not a bug.
# @subsection _eg1 eg1:
# @b Example:
# @code
#  >> ConvertNavigatorToScreenDef("main", 5)               # slot 5 is reserved with an open navigator
#  >> <ScreenDefinition instance at 0x02800070>
#  >> ConvertNavigatorToScreenDef([], 5)               # slot 5 is reserved with an open navigator
#  >> [<ScreenDefinition instance at 0x0280070>,<ScreenDefinition instance at 0x0280FE0>, ...]
# @endcode
@ApiFunction
def ConvertNavigatorToScreenDef(screenToConvert, slotNo=0):
    return stormtest_client.stc.ConvertNavigatorToScreenDef(screenToConvert, slotNo)

## @par Description
# This function uploads a navigator from the local machine to the public navigator area.  It will overwrite
# any existing public navigator of the same name.  You must upload the .stnav_runtime for a navigator to be
# used as a public navigator and you may also upload the stnav_edit file as a useful backup (but the .stnav_edit
# file is usually quite large compared to the .stnav_runtime).
# @param[in] localFile @b String : The path to a navigator file (either .stnav_runtime or .stnav_edit).  If a relative
# path is used then it is relative to the directory set by SetProjectDir().
# @param[in] navigatorName @b String : The name of the public navigator to upload.  It will be created if it does
# not exist.  To associate a newly created navigator with one or more models, use the AdminConsole.
# @return @e None 
# 
# @subsection _eg1 eg1:
# @b Example:
# @code
#  >> # create/overwrite a navigator called 'Box5' from a local file - the file saved will be 'Box5.stnav_runtime'
#  >> UploadPublicNavigator("c:\\projects\\myproject\\mynavigator.stnav_runtime", "Box5")
# @endcode
# @Note This function is available in release 3.3.3
@ApiFunction
def UploadPublicNavigator(localFile, navigatorName):
    stormtest_client.stc.UploadPublicNavigator(localFile, navigatorName)

## @par Description
# This function downloads a public navigator to the local machine.  It will download the specified runtime or edit
# file.
# @param[in] navigatorName @b String : The public navigator to download.  It may have the suffix .stnav_runtime or
# .stnav_edit but if omitted, then .stnav_runtime is assumed.
# @param[in] localFile @b String : The local file to write.  If the extension (.stnav_runtime or .stnav_edit) is omitted
# then the file saved will have the same extension as the navigator file.  An exception will be raised if the local file
# extension is invalid (either totally invalid such as .txt or trying to save a .stnav_runtime navigator to a .stnav_edit
# local file).  If a relative path is used then it is relative to the directory set by SetProjectDir().
# @return @e None
#
# @subsection _eg1 eg1:
# @b Example:
# @code
#  >> # download the runtime and edit files from a navigator called 'Box5'
#  >> DownloadPublicNavigator("Box5", "mynav")  # saves to mynav.stnav_runtime in current directory
#  >> DownloadPublicNavigator("Box5.stnav_edit", "mynav") # saves to mynav.stnav_edit in current directory
# @endcode
# @Note This function is available in release 3.3.3
@ApiFunction
def DownloadPublicNavigator(navigatorName, localFile):
    stormtest_client.stc.DownloadPublicNavigator(navigatorName, localFile)

## @par Description
# This function lists all available public navigators.
# @param None
# @return @e List : List of strings of all public navigators.  The full extension will be listed.  The list is not sorted
# in any way. It is not guaranteed to be repeatable between successive calls to this function.
# 
# @subsection _eg1 eg1:
# @b Example:
# @code
#  >> ListPublicNavigators()
#  >> ["Box5.stnav_runtime", "Box5.stnav_edit", "Nav6.stnav_runtime", ...]
# @endcode
# @Note This function is available in release 3.3.3
@ApiFunction
def ListPublicNavigators():
    return stormtest_client.stc.ListPublicNavigators()

## @}

############################################################################################

## @defgroup Group3 Power State API
# These functions control the power state of the set top box.
## @{

## @par Description
#  This function powers on the DUT.
#  @param[in] timeDelay @b Float: (optional) The delay in seconds after the DUT is powered up and before the function returns, see note<SUP>1</SUP>.
#  @param[in] slotNo @b Integer: (optional) Powers on one specific slot instead of all reserved slots.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>PowerOnSTB()      # Power on, waiting the default 30 seconds
#   or
#   >>PowerOnSTB(10,3)  # Power on waiting for 10 seconds the DUT in slot 3
#  @endcode
#  @note
#  -# This delay is used to avoid the damage to the DUT(s) caused by immediate power-off again.
#  @note If the @e timeDelay parameter is left out the default delay is 30 seconds.
#  @note If the @e slotNo parameter is omitted, the default is for all reserved slots.
@ApiFunction
def PowerOnSTB(timeDelay = 30,slotNo=0):
    """
    Powers on the DUT.

    Return: None

    timeDelay (Float, optional) The delay in seconds after the DUT is powered up and
      before the function returns.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.power_on(timeDelay, slotNo)

## @par Description
#  This function powers off the DUT.
#  @param[in] timeDelay @b Float: (optional) The delay in seconds after the DUT is powered down and before the function returns, see note<SUP>1</SUP>.
#  @param[in] slotNo @b Integer: (optional) Powers off one specific slot instead of all reserved slots.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>PowerOffSTB()     # Power off using the default 30 sec
#   or
#   >>PowerOffSTB(10,3) # power off and delay by 10 seconds the DUT in slot 3
#  @endcode
#  @note
#  -# This delay is used to avoid the damage to the DUT(s) caused by immediate power-on again.
#  @note If the @e timeDelay parameter is left out the default is 30 seconds.
#  @note If the @e slotNo parameter is omitted, the default is for all reserved slots.
@ApiFunction
def PowerOffSTB(timeDelay = 30,slotNo=0):
    """
    Powers off the DUT.

    Return: None

    timeDelay (Float, optional) The delay in seconds after the DUT is powered down and
      before the function returns.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.power_off(timeDelay, slotNo)

## @par Description
#  This function returns whether a slot is powered on.  The CheckSlots() function has a limitation in
#  that if a slot is reserved, you cannot find out if the slot is powered on or off.  This function 
#  resolves that limitation.  This function is supported in release 3.3.4.
#  @param[in] slotNo @b Integer: (optional) Specifies which slot to return data for. Use 0 for all reserved slots.
#  return @e Bool : The value is True or False for slot powered on or off.  If the server has no RPS installed
#  then None is returned.  When the slotNo is 0 the return is a list as [[slot, status], [slot, status]] with one
#  item in the list for each slot and the status of True, False or None.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>IsSlotPowerOn(5)
#   >>True
#   >>IsSlotPowerOn()
#   >>[[1, True], [2, False]]
#  @endcode
@ApiFunction
def IsSlotPowerOn(slotNo=0):
    return stormtest_client.stc.IsSlotPowerOn(slotNo)
## @}

############################################################################################

## @defgroup Group4 Serial Port API
# These functions are to access serial data on each StormTest slot. In order to access the serial data, the script should pass the serial port
# parameters to the ReserveSlot() function. This will enable the serial data stream.\n\n
# Note that it is possible for the user to monitor the serial stream while a test is running by using a standard telnet program to telnet to the
# StormTest server on a port that is a slot based increment off the base port. The base port is configured using the web based Admin Console.\n
# For example, if the base port is 12001 (the default), then the serial stream for slot 5 is on port 12005.  The data from the serial port is
# inserted into the main html log file and for compatibility in a text file with a auto generated name - the exact filename can be found by a
# script by calling GetSerialLog()
#
## @{

## @par Description
#  This function allows the user to observe the serial output for a specific text. If that text is seen in the output, then StormTest will log
#  the entire line containing the text to a new log file. This new log file will have the same name as the main log file, but with an @b _mon suffix.\n
#  A callback can also be passed to StormTest and this callback will be executed every time the text is observed.\n\n
#  Please note that StormTest assumes that the output from the DUT is encoded using the latin1 (ISO-8859-1) character set. The observe text that is passed
#  into this function should be of type bytes and encoded with latin1. If this is not the case, the function will not work as expected.
#  @param[in] observingText  @b Bytes: The text, which the serial port output will be checked for. This text should be of type bytes and use latin1 (ISO-8859-1) character encoding.
#  @param[in] callbackFunction @b Function (optional) The callback function that should be called in case the text occurs.
#  @param[in] slotNo @b Integer: (optional) Used to specify the slot number to start observing on.
#  @param[in] waitForEOL @b Bool: (optional) If this parameter is True, in case of a matching text, StormTest will wait for an end-of-line character before writing the received text to the @b _mon log file. Default is False.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>AddObserve(b"ERR") # The serial output will be monitored for the text ERR
#  @endcode
#  @note If @e callbackFunction is not specified the default callback handler will be used (logging to a file).
#  @note   The callback function is defined as follows:
#  @subsubsection _cb1 cb1:
#  @b callbackFunction(slotNo, subSlot, a_key, a_text).
#  @param[in] slotNo @b Integer: The slot number the text was found on.
#  @param[in] subSlot @b Integer: The sub slot number the text was found on.
#  @param[in] a_key @b Bytes: The matching text in the debug line as defined via the @e observingText.
#  @param[in] a_text @b Bytes: The text line from the serial port.
#  @note the subSlot parameter is needed for HS64 systems.  However scripts written with 3 parameters in the
#  callback will work perfectly.  StormTest detects the signature and adjusts accordingly.  HS64 scripts can
#  also use 3 parameters but won't know which sub slot has found the observed text.
@ApiFunction
def AddObserve(observingText, callbackFunction = None, slotNo=0, waitForEOL=False):
    """
    Add a callback when the serial output has a specific text. If that text is seen in
    the output, then StormTest will log the entire line containing the text to a new log file.
    The callback can be None - then the logging occurs but no callback. StormTest assumes that
    the serial data is encoded in the latin1 (ISO-8859-1) character set.

    Return: None

    observingText: (Bytes) The text to search for. Should be of type bytes and use latin1 (ISO-8859-1)
      character encoding.

    callbackFunction: (Function, optional) The callback to be called when the text occurs.
      Signature of function is callback(slotNumber, matchedText, matchedLine) - the slotNumber
      and matchedText are repeats of the input parameters so this allows one callback to handle
      multiple observe cases.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.

    waitForEOL: (Bool, optional) When True, StormTest will wait for an end-of-line character
      in the line matching the text before writing the line to the log file.

    """
    if slotNo == 0:
        return stormtest_client.stc.observe(observingText, callbackFunction, waitForEOL)
    else:
        return stormtest_client.stc.observe_on_port(slotNo, observingText, callbackFunction, waitForEOL)

## @par Description
#  This function is used to stop observing the text set in AddObserve.
#  @param[in] observingText  @b Bytes: The text to stop observing. This should be of type bytes and use latin1 (ISO-8859-1) character encoding.
#  @param[in] slotNo @b Integer: (optional) Used to specify the slot number to call RemoveObserve on.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>RemoveObserve(b"ERR") # Monitoring for text ERR will be stopped
#  @endcode
@ApiFunction
def RemoveObserve(observingText,slotNo=0):
    """
    Stop observing the text set in AddObserve.

    Return: None

    observingText: (Bytes) The text to stop observing. This text needs to match a text
      set by AddObserve.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    if slotNo == 0:
        return stormtest_client.stc.del_observe(observingText)
    else:
        return stormtest_client.stc.del_observe_on_port(slotNo, observingText)

## @par Description
#  A test script can monitor the serial output for a number of texts by calling the AddObserve() function. StormTest will then record any instances of these texts in a separate log file with an @b _mon suffix.
#  This function is then used to check if any of the texts that the test script is monitoring for have been found by StormTest by looking at the size of the @b _mon log file.
#  @param None
#  @return see @ref _checkDebugRetValue
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>print(str(GetObserveLog())
#   >>[(11, 0L, 'C:\\test\\Prefix_11_Timestamp_mon.log'),     # 0 bytes in the monitor log
#                                                             # for slot 11
#
#   >> (12, 25L, 'C:\\test\\Prefix_12_Timestamp_mon.log')]    # 25 bytes in the monitor log
#                                                             # for slot 12
#  @endcode
@ApiFunction
def GetObserveLog():
    """
    Get the filename created by AddObserve()

    Return: List.  Each item in the list represents one reserved slot.  The items are tuples
      of the form (slot number, log size in bytes, observe log file name)
    """
    return stormtest_client.stc.check_debug_log()

## @par Description
#  This function is used to check logging data from the serial port.
#  @param None
#  @return see @ref _checkDebugRetValue
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>print(str(GetSerialLog())
#   >>[(11, 0L, 'C:\\test\\Prefix_11_Timestamp.log'),     # 0 bytes in the monitor log
#                                                         # for slot 11
#
#   >> (12, 25L, 'C:\\test\\Prefix_12_Timestamp.log')]    # 25 bytes in the monitor log
#                                                         # for slot 12
#  @endcode
@ApiFunction
def GetSerialLog():
    """
    Get the filename used to log serial data.  This is ALL the serial data from the DUT
    not just the matched text.

    Return: List.  Each item in the list represents one reserved slot.  The items are tuples
      of the form (slot number, log size in bytes, serial log file name)
    """
    return stormtest_client.stc.check_terminal_log()

## @par Description
#  This function is used to begin logging data from the serial port. Note that this function should @b only be used if serial port logging has previously been stopped by a call to the StopSerialLog() function call. All subsequent serial data will be logged to a new file
#  @param[in] serialParam @b Serial Port Setup Parameters:@b Parameters to use for communicating with the serial port on the DUT (see @ref _serialParams).
#  @param[in] slotNo @b Integer: (optional) The slot number to start monitoring for serial data.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>StartSerialLog([19200,8,"none",1,"none"],3)   # Start logging on slot number 3
#  @endcode
#  @note If the @e slotNo parameter is omitted the default is to start logging for all slots reserved.
@ApiFunction
def StartSerialLog(serialParam,slotNo=0):
    """
    Start logging data from the serial port. Can only be used after StopSerialLog() function call.
    Serial data will be logged to a new file.

    Return: None

    serialParam: (List) Parameters to use for communicating with the serial port on the DUT.
      Content of List is:
        baud rate (Integer) 50 - 115200 in 'standard' values
        data bits (Integer) 5 - 8 only
        Parity (String) "none", "odd" or "even"
        Stop bits (Integer) 1 or 2
        Flow Control (String) "none", "soft", "hard" or "both"
        Serial Log File Prefix (String, optional) Default is "Port"

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    if slotNo == 0:
        return stormtest_client.stc.start_serial_log(None, serialParam)
    else:
        return stormtest_client.stc.start_serial_log(slotNo, serialParam)

## @par Description
#  This function is used to stop logging data from the serial port.
#  @param[in] slotNo @b Integer: (optional) The slot number to stop monitoring for serial data.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>StopSerialLog()
#  @endcode
#  @note If the @e slotNo parameter is omitted the default is to stop logging for all slots reserved.
@ApiFunction
def StopSerialLog(slotNo=0):
    """
    Stop logging data from the serial port.  Serial Logging must have been started by
    calling ReserveSlot() with valid serial parameters.

    Return: None

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    if slotNo == 0:
        return stormtest_client.stc.stop_serial_log(None)
    else:
        return stormtest_client.stc.stop_serial_log(slotNo)

## @par Description
#  This function allows a user to develop an external parser for the serial data. The callback function passed to this API will
#  receive the raw serial data from the DUT in each reserved slot.  This should be used when the data is line based text data
#  as complete lines are sent to the callback.  For parsing binary data or data without line feed characters, SetRawDataReceiver should be used.
#  @param[in] callbackFunction @b Function: The definition of the function can be found below.
#  @param[in] slotNo @b Integer: (optional) Only installs the external parser for serial data from one slot.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>def callbackFunction(slot, data):
#   >>  print(b"Received "+bytes(data)+b" on slot %d" % slot)
#   >>
#   >>SetExtParser(callbackFunction)
#  @endcode
#  @note If the @e slotNo parameter is omitted the default is to install the parser for all slots reserved.
#  @note The callback function is defined as follows:
#  @subsubsection _cb1 cb1:
#  @b callbackFunction(slotNo, subSlot, data)
#  @param[in] slotNo @b Integer: The slot number the data is coming from.
#  @param[in] subSlot @b Integer: The sub slot number the data is coming from.
#  @param[in] data @b Bytes: Data received from the DUT in that slot.
#  @note the subSlot parameter is needed for HS64 systems.  However scripts written with 2 parameters in the
#  callback will work perfectly.  StormTest detects the signature and adjusts accordingly.  HS64 scripts can
#  also use 2 parameters but won't know which sub slot has found the observed text.

@ApiFunction
def SetExtParser(callbackFunction,slotNo=0):
    """
    Set a callback to receive serial data.  Allows development of external serial data parser.
    If the DUT uses binary or a character encoding other than latin1 (ISO-8859-1), use
    SetRawDataReceiver() instead.

    Return: None

    callbackFunction: (Function) function to call on each chunk of serial data from DUT. Note that
      StormTest does not wait for end of line or any other special meaning of data.  Callback is:
      callback(slotNumber, data) where data is of type bytes.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    if slotNo == 0:
        return stormtest_client.stc.set_ext_parser(callbackFunction, None)
    else:
        return stormtest_client.stc.set_ext_parser(callbackFunction, slotNo)

## @par Description
#  This function is used to change the parameters used to communicate with the serial port on the DUT. Serial port logging must have been enabled previously. Subsequent serial port data is logged into the same file as before.
#  @param[in] serialParam @b Serial @b Port @b Setup @b Parameters: to use for communicating with the serial port on the DUT (see @ref _serialParams).
#  @param[in] slotNo @b Integer: (optional) The slot number to change the serial parameters on.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>ChangeSerialParameters([19200,8,"none",1,"none"],3)
#   # Change serial parameters on slot number 3
#  @endcode
#  @note If the @e slotNo parameter is omitted the default is to change serial parameters for all slots reserved.
@ApiFunction
def ChangeSerialParameters(serialParam,slotNo=0):
    """
    Change the parameters used to communicate with the serial port on the DUT. Serial port logging
    must have been enabled previously. This does not change the log file unlike StopSerialLog()
    followed by StartSerialLog()

    Return: None

    serialParam: (List) Parameters to use for communicating with the serial port on the DUT.
      Content of List is:
        baud rate (Integer) 50 - 115200 in 'standard' values
        data bits (Integer) 5 - 8 only
        Parity (String) "none", "odd" or "even"
        Stop bits (Integer) 1 or 2
        Flow Control (String) "none", "soft", "hard" or "both"
        Serial Log File Prefix (String, optional) Default is "Port"

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.

    """
    if slotNo == 0:
        return stormtest_client.stc.reset_serial_log(None, serialParam)
    else:
        return stormtest_client.stc.reset_serial_log(slotNo, serialParam)

## @par Description
#  This function can be used to interact with a DUT via its serial port.\n\n If a DUT is running an application that takes input via the serial port, then this function can be used to send commands to that application.
#  The function sends the \a commandText to the serial port and will wait up to \a timeDelay seconds for the text \a expectText to appear on the serial output. An example of how this might work is that the user could send
#  b"4" to run test number 4 and then wait up to 60 seconds for b"TEST PASSED" to appear on the serial output.\n\n The return value from the function will contain the line from the serial log that the 'expect text' was seen
#  in and can then be parsed further by the test script if necessary.
#  @param[in] commandText @b Bytes: The command text. This text should be of type bytes and use latin1 (ISO-8859-1) character encoding. StormTest will append a line feed and a carriage return (b'\\r\\n') to the end of this text.
#  @param[in] expectText @b Bytes: The expected text. This text should be of type bytes and use latin1 (ISO-8859-1) character encoding.
#  @param[in] timeDelay @b Float: Time in seconds.
#  @param[in] slotNo @b Integer: (optional) Used to specify the slot number to send the serial command on.
#  @param[in] waitForEOL @b Bool: (optional) If this parameter is True, at a matching text, wait for a linefeed character (b'\\n') before returning from the function. Default is False.
#  @return @e Array see @ref _serialCommandRetValue
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>ret=SendCommandViaSerial(b"4",b"TEST PASSED",60)
#   >>print(str(ret))
#   >>[(1, True, b'TEST PASSED', b'CMD> 4\nLine of text containing TEST PASSED and some
#       text until a newline character\n'),
#   >> (2, False, b'TEST PASSED', b'CMD> 4\n')]                    # slot 1 success, slot 2 failure
#  @endcode
@ApiFunction
def SendCommandViaSerial(commandText, expectText, timeDelay,slotNo=0, waitForEOL=False):
    """
    Send text to the DUT and wait for a response.

    Return: List of Tuples (if slotNo is zero) or a single Tuple.  The contents of the Tuple are:
      (slot number, status (bool), the expectText, full line of text from DUT)

    commandText: (Bytes) Data to send to the DUT. This should be of type bytes use latin1 (ISO-8859-1) character
      encoding. StormTest will append a line feed and a carriage return (b'\\r\\n') to the end of
      this text.

    expectText: (Bytes) The expected text from the DUT. This should be of type bytes and use latin1 (ISO-8859-1)
      character encoding.

    timeDelay: (Float) Time in seconds.  The function will wait this long to see expectText.
      If it does not find it, then the return status is False.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.

    waitForEOL: (Bool, optional) If True, at a matching text, function wait for a linefeed
      character (b'\\n') before returning from the function.
    """
    if slotNo == 0:
        return stormtest_client.stc.command(commandText, expectText, timeDelay, waitForEOL)
    else:
        return stormtest_client.stc.command_on_port(slotNo, commandText, expectText, timeDelay, waitForEOL)

## @par Description
#  This function allows a user to develop an external parser or a binary data receiver for the serial data. The callback function passed to this API will
#  receive the raw serial data from the DUT in each reserved slot.  If you know the data is text based with line feeds you can use either SetExtParser or
#  SetRawDataReceiver
#  @param[in] callbackFunction @b Function: The definition of the function can be found below.
#  @param[in] slotNo @b Integer: (optional) Only installs the external parser for serial data from one slot.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>def callbackFunction(slot, data):
#   >>  print(b"Received "+bytes(data)+b" on slot %d" slot)
#   >>
#   >>SetRawDataReceiver(callbackFunction)
#  @endcode
#  @note If the @e slotNo parameter is omitted the default is to install the parser for all slots reserved.
#  @note The callback function is defined as follows:
#  @subsubsection _cb1 cb1:
#  @b callbackFunction(slotNo, data)
#  @param[in] slotNo @b Integer: The slot number the data is coming from.
#  @param[in] subSlot @b Integer: The sub slot number the data is coming form.
#  @param[in] data @b Bytes: Data received from the DUT in that slot. The raw serial data is not decoded and it is up to a user.
#  @note the subSlot parameter is needed for HS64 systems.  However scripts written with 2 parameters in the
#  callback will work perfectly.  StormTest detects the signature and adjusts accordingly.  HS64 scripts can
#  also use 2 parameters but won't know which sub slot has found the observed text.

@ApiFunction
def SetRawDataReceiver(callbackFunction,slotNo=0):
    """
    Set a callback to receive raw binary serial data.

    Return: None

    callbackFunction: (Function) function to call on each chunk of serial data from DUT. Note that
      StormTest does not wait for end of line or any other special meaning of data.  Callback is:
      callback(slotNumber, data) where data is of type bytes.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.

    """
    if slotNo == 0:
        return stormtest_client.stc.SetRawDataReceiver(callbackFunction, None)
    else:
        return stormtest_client.stc.SetRawDataReceiver(callbackFunction, slotNo)

## @par Description
#  This function can send binary raw data to a DUT via its serial port. While sending data, other serial port related APIs will be blocked.
#  @param[in] hexBytes @b Bytes: The raw data to send. This is of type bytes - it is up to a user how to encode it.
#  @param[in] slotNo @b Integer: (optional) Used to specify the slot number to send the serial command on.
#  @return @b Array
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>ret=SendRawData(bytes(bytearray((0xff,0xfa))))
#   >>print(str(ret))
#   >>[(1, True, 2), (2, False, 0)]     # slot 1 success and sent 2 bytes, slot 2 failure
#  @endcode
@ApiFunction
def SendRawData(hexBytes,slotNo=0):
    """
    Send binary raw data to a DUT via its serial port.

    Return: List of Tuples (if slotNo is zero) or a single Tuple. Tuple is:
      (slot number, status (Bool), bytes sent)

    hexBytes: (Bytes) The data to send. For example: bytes(bytearray((0xff,0xfa))) to send 2 bytes in hex.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    if slotNo == 0:
        return stormtest_client.stc.SendRawData(hexBytes, None)
    else:
        return stormtest_client.stc.SendRawData(hexBytes, slotNo)

## @par Description
#  This function is used to write text to the serial log. This allows the user to write a test script that will automatically mark the point in the serial log that certain events in the test script occurred.
#  @param[in] commentText @b Bytes: Text that will be written to the serial log.  This should by of type bytes and use latin1 (ISO-8859-1) character encoding.
#  @param[in] slotNo @b Integer: (optional) If used, the comment text will only be written to the serial log of the slot specified.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>CommentToLog(b"Event A is about to happen")
#   # Write the text "Event A is about to happen" to the serial log file of all
#   # reserved slots
#  @endcode
@ApiFunction
def CommentToLog(commentText, slotNo=0):
    """
    Write text to the serial log.

    Return: None

    commentText: (Bytes) Text that will be written to the serial log.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    if slotNo == 0:
        return stormtest_client.stc.comment_to_log(commentText, None)
    else:
        return stormtest_client.stc.comment_to_log(commentText, slotNo)

## @}

############################################################################################

## @defgroup Group5 Audio and Video API
# These are the audio and video capture and analysis functions.\n\n
# To use all these functions, the video stream to the client must be enabled (it is enabled by default). The video stream is enabled/disabled by a
# flag passed to the ReserveSlot() function.
## @{

# Deprecated Function
@ApiFunction
def OpenVideoWindow(arg1, arg2 = None):
    """
    DEPRECATED
    """
    return stormtest_client.stc.OpenVideoWindow(arg1, arg2)

# Deprecated Function
@ApiFunction
def CloseVideoWindow():
    """
    DEPRECATED
    """
    return stormtest_client.stc.CloseVideoWindow()

## @par Description
#  This function controls the level of CPU used by the client to decode and display the video streamed to the StormTest client.
#  CPU Usage can either be high (1) or low (0).\n\n
#  Note that changing this setting to low has no impact on the ability of a
#  StormTest script to run. Image comparisons etc will still operate as normal. It's only effect is to make the video playback look
#  less smooth to the human eye.\n\n
#  If low CPU usage is selected, the CPU usage per test is reduced by approximately 50%.
#  For this reason, it is recommended that low CPU usage is selected when running tests on a PC where you wish to run multiple tests at once (ie if you are running
#  your tests on the StormTest server itself).\n\n
#  Note that this is a client side function only - it has no effect on the contents of the video stream being sent from the server and stored
#  to disk by the StartVideoLog() function.
#  @param[in] cpuUsage @b Integer: Setting to 1 enables high CPU usage. Setting to 0 enables low CPU usage.
#  @param[in] slotNo @b Integer: (optional) Used to specify the slot number to call SetVideoCpuUsage() on.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#     >>SetVideoCpuUsage(1)    # Use as much CPU as is necessary to decode the video stream.
#  @endcode
#  @note
#  @note The default value if the test does not call SetVideoCpuUsage() is <I><B> high CPU usage / high quality </B></I> video decoding.
@ApiFunction
def SetVideoCpuUsage(cpuUsage, slotNo=0):
    """
    Controls the level of CPU used by the client to decode and display the video streamed to the
    StormTest client.  CPU Usage can either be high (1) or low (0).  This has no impact on the
    tests run. It's effect is to make the video playback look less smooth to the human eye.

    Return: None

    cpuUsage: (Integer) 1 enables high CPU usage, 0 enables low CPU usage.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.SetVideoCpuUsage(cpuUsage, slotNo)

## @par Description
#  This function opens a video stream and displays the video in a monitoring window
#  This function should be used INSTEAD of OpenVideoWindow(), eliminating the need for a callback video handler handler
#  @param[in] slotNo @b Integer: (optional) Used to specify the slot number to call ShowVideo() on.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#     >>ShowVideo()
#  @endcode
@ApiFunction
def ShowVideo(slotNo = 0):
    """
    Opens a video stream and displays the video in a monitoring window.  This is preferred over
    OpenVideoWindow() for new scripts as it eliminates the need for a callback video handler
    handler.  Moreover for testing, it can be commented out without needing to restructure
    the code.

    Return: None

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.ShowVideo(slotNo)

## @par Description
#  This function stops streaming video from the Storm Test server which was opened with the ShowVideo() API call and closes the associated video window.
#  This function can only be used on video streams opened with ShowVideo() and INSTEAD of CloseVideoWindow()
#  @param[in] slotNo @b Integer: (optional) Used to specify the slot number to call CloseVideo() on.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#     >>CloseVideo()
#  @endcode
@ApiFunction
def CloseVideo(slotNo = 0):
    """
    Stops streaming video from the Storm Test server which was opened with ShowVideo() and closes
    the associated video window.  It MUST NOT be used if OpenVideoWindow() was used.

    Return: None

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.CloseVideo(slotNo)

## @par Description
#  This function hides an open video window opened with the ShowVideo() API call. The video stream remains open allowing video analysis
#  This function can only be used on video streams opened with the ShowVideo() API call
#  @param[in] slotNumber @b Integer: (optional) Used to specify the slot number to call HideVideo() on.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#     >>HideVideo()
#  @endcode
@ApiFunction
def HideVideo(slotNumber = 0):
    """
    Hides an open video window opened with ShowVideo(). The video stream remains open allowing
    video analysis functions.  It MUST NOT be used on video streams opened with OpenVideoWindow()

    Return: None

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.HideVideo(slotNumber)

##
#  OverWriteAction Enum. Defines the valid values that can be passed as an argument to CaptureImageEx().
#  @param OverWrite : Overwrites an existing file when saving an image with same name
#  @param Error : Returns an error when a file exists with the same name of the image being captured
#  @param NewName : Saves the file with a new name if the name already exists
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#    ret = CaptureImageEx (None, "file.bmp",overwriteAction=OverWriteAction.OverWrite)
#    print(str(ret))
#    >>> [[8, True, <StormTestImageObject instance>, u'file.jpg']]
#    ret = CaptureImageEx (None,  "file.bmp",overwriteAction=OverWriteAction.Error)
#    print(str(ret))
#    >>> [[8, True,<StormTestImageObject instance >,'Error']]
#    ret = CaptureImageEx (None,  "file.bmp",overwriteAction=OverWriteAction.NewName)
#    print(str(ret))
#    >>> [[8, True,<StormTestImageObject instance>, u'file(1).bmp']]
#  @endcode
class OverWriteAction:
    """
    Class to define action on CaptureImageEx.  Valid values are OverWrite, Error, and NewName
    """
    OverWrite,Error,NewName = list(range(3))

## @par Description
#  CompareAlgorithm Enum. Defines the compare algorithm to use in the image comparision functions
#  CompareImageEx(), CompareIconEx(), WaitImageMatch(), WaitImageNoMatch(), WaitIconMatch(), WaitIconNoMatch().
#  Currently only one algorithm is available
#  @note The comparison algorithm is designed for images and not areas of constant color.  If you use the image
#  functions on an area of constant color then the result is likely to be a failed comparison even though they
#  look the same to the human eye - the reason is that using analog capture a region of flat color will have
#  minor variations due to noise and these will be compared as the only variations between the image and they
#  will fail.  Use the compare color functions to compare regions of one color.
#  @param Compare1 : Algorithm 1 is used for the comparison
#  @param Legacy : Not supported. Intention was to allow Legacy comparison with new function but algorithm is not considered suitable.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#    ret = CompareImageEx("refImage.bmp", "testImage.bmp",algorithm=CompareAlgorithm.Compare1)
#  @endcode
class CompareAlgorithm:
    """
    Class to define algorithm to use for image comparison.  Valid values are: Compare1 (the
    algorithm introduced in version 2.0 of StormTest)
    """
    Compare1, Legacy = list(range(2))

## @par Description
#  This function performs detect motion on a video stream
#  @param[in] rect @b Tuple: The rect is a crop area.  In Release 3.1 and later this may be a @ref _regionObject.
#  @param[in] timeout @b Float: Number of seconds to wait for motion to be detected.
#  @param[in] percent @b Integer: The limit for pass/fail. Default 5, so if there is more than 5% difference between frames, the return value is true.
#  @param[in] slotNo @b Integer: (optional) Used to specify the slot number to call DetectMotionEx on.
#  @param[in] returnImage @b Boolean: (optional) If set to False then no StormTestImageObject is returned. If True (the default) then Close() should be called on the returned StormTestImageObject.
#  @return  @b List: A list of lists consisting of slot number,true/false,last image captured as
#                              @ref _stormTestImageObject ,actual percentage, number of captures performed, total time taken, measured SDO execution time.  A single list if
#  the exact slot number is given
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#      # look for motion in top right corner of the screen (an area 104 x 75 pixels starting at 604 from left and 0 from top)
#      # wait for 5 seconds.
#      ret = DetectMotionEx((600,0,104,75),5,percent=5,slotNo = 8)
#      print(str(ret))
#      >>>[8, False, <StormTestImageObject instance>,0.36330969109354783, 42, 5.0009999999999994, 5.120193934365184]
#      ret = DetectMotionEx((600,0,104,75),5,percent=5)
#      print(str(ret))
#      >>>[[8, False, <StormTestImageObject instance>,0.36330969109354783, 42, 5.0009999999999994, 5.120193934365184]]
#  @endcode
@ApiFunction
def DetectMotionEx(rect,timeout,percent = 5,slotNo = 0, returnImage = True):
    """
    Detect motion on a slot - or a subsection of the video on a slot.  It is unimportant as to
    whether the videoFlag of ReserveSlot() is true or false.  However, if false, the function will
    grab images from the server which may increase network traffic.

    Return: List of Lists (if slotNo is 0) or a List.  The contents of the list are:
      [slot Number, Motion Detected (Bool), last image (StormTestImageObject), percentage motion,
      number compares, time taken (Float),  (Double) measured SDO execution time]

    rect: (Tuple) Area of screen to use for motion detection. Tuple is (left, top, width, height)

    timeout: (Float) time in seconds to wait for motion.

    percent: (Integer, optional) degree of difference needed for motion to be considered as motion.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.

    returnImage: (Boolean, optional) If set to False then no StormTestImageObject is returned. If True (the default) then Close() should be called on the returned StormTestImageObject.
    """
    return stormtest_client.stc.DetectMotionEx(rect,timeout,percent,slotNo,returnImage)

## @par Description
#  This function captures an image, crops and saves it if those details are specified
#  @param[in] rect @b Tuple: The rect is a crop area.  In Release 3.1 and later this may be a @ref _regionObject.
#  @param[in] filename @b String: The filename specifies where to save the file and allows %d %t to substitute the date/time.
#                            Extension of filename determines the type save, if none, then .png.
#                            User can specify Python 'None' for filename and then the file is not saved, just captured to memory.
#                            In Release 3.1 and later this may be a @ref _imageObject.
#  @param[in] jpegQuality @b Integer: The jpegQuality specifies the quality of a jpeg image being saved. Default 80, range is 1 - 100.
#  @param[in] overwriteAction @b OverWriteAction: overwriteAction allows user to control behavior on file conflict (overwrite, error, newname).
#                             Default OverWriteAction.NewName.
#  @param[in] slotNo @b Integer: (optional) Used to specify the slot number to call CompareImage on.
#  @param[in] returnImage @b Boolean: (optional) If set to False then no StormTestImageObject is returned. If True (the default) then Close() should be called on the returned StormTestImageObject.
#  @return @b List: If slotNo is 0 or ommitted: A list of lists consisting of slot number,true/false,@ref _stormTestImageObject ,full path of saved file, if any.
#  If slotNo is an explicit number then just a simple list of slot number, true/false etc is returned.
#  @note The true/false refers to whether an image was captured or not, true meaning it was captured without error.
#  @note If ReserveSlot is called with VideoFlag False, the capture is performed on the server and the saved file is always
#  JPEG format.  This has always been the case with StormTest and is not new behavior.  It may be fixed in
#  a future release so you should use .JPG if videoFlag was false.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#    ret = CaptureImageEx (None, "file.bmp")
#    print(str(ret))
#      >>>[[8, True, <StormTestImageObject instance>, u'file.jpg']]
#  @endcode
#  @note This function ignores the effect of SetVideoOffset when the connected server is an HD server. It accounts for the offset when the 
#  connected server is Standard Definition with the captured image being offset as per SetVideoOffset
@ApiFunction
def CaptureImageEx (rect, filename, jpegQuality=80, overwriteAction=OverWriteAction.NewName, slotNo=0, returnImage=True):
    """
    Captures an image, and optionally crops and saves it.  It is unimportant as to whether the
    videoFlag of ReserveSlot() is true or false.  However, if false, the function will capture
    the image from the server which may increase network traffic.  It also limits the format to
    JPEG.

    Return: List of Lists (if slotNo is 0) or a List.  The List contains 4 items: [slot number,
      Status (Bool), the StormTestImageObject, file name saved].  File name will be None if
      no file name was specified as input.  The image object will be None if the capture failed.

    rect: (Tuple) Area of image to crop. Tuple is (left, top, width, height). Use None for no
      cropping.

    filename: (String) Filename to save the file. Use %d %t to substitute the date/time. Extension
      of filename determines the type save, if none, then .png. Use None for filename and the file
      is not saved, just captured to memory.

    jpegQuality: (Integer, optional) The quality of a jpeg image being saved. Ignored unless JPEG
      file is being saved.

    overwriteAction: (OverWriteAction class, optional) controls behavior on file conflict. Ignored
      if not saving to a file.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.

    returnImage: (Boolean, optional) If set to False then no StormTestImageObject is returned. If True (the default) then Close() should be called on the returned StormTestImageObject.
    """
    resultList =  stormtest_client.stc.CaptureImageEx(rect, filename, jpegQuality, overwriteAction, slotNo, returnImage)
    return resultList

## @par Description
#  This function performs a single compare
#  @param[in] refImage @b String or @ref _stormTestImageObject : file or image from CaptureImageEx().
#  In Release 3.1 and later this may be a @ref _imageObject.
#  @param[in] testImage @b String or @ref _stormTestImageObject : file or image from CaptureImageEx().
#  In Release 3.1 and later this may be a @ref _imageObject.
#  @param[in] percent @b Integer: The limit for pass/fail. Default 98. When the detected similarity is above this value, the comparison succeeds.
#  @param[in] includedAreas @b List: Included areas for comparision, currently only one can be specified.  This is either
#  a simple rectangle OR a list of rectangles (each a list of 4) and ONLY 1 element currently supported.  In Release 3.1
#  and later the rectangel may be a @ref _regionObject.
#  @param[in] excludedAreas @b List: Excluded areas for comparision, NOT currently supported.
#  @param[in] algorithm @b CompareAlgorithm: Comparison algorithm to use, only one allowed
#  @return @b List: true/false, actual percentage match
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#      ret = CompareImageEx(refImage, testImage, percent)
#      print(str(ret))
#      >>>[False, 45.076345304474223]
#      # using a crop area
#      ret = CompareImageEx(refImage, testImage, percent, [0,0,50,50])
#      # using a list of crop areas
#      ret = CompareImageEx(refImage, testImage, percent, [[0,0,50,50]])
#  @endcode
#  @note If a named image or rectangle is used then only the general 'all slot' path will be searched because this
#  function does not take a slot number.
@ApiFunction
def CompareImageEx(refImage, testImage, percent = 98, includedAreas=None, excludedAreas=None, algorithm=CompareAlgorithm.Compare1):
    """
    Compares 2 images.  The images may be files (specified by filename) or StormTestImageObject
    captured via CaptureImageEx().  If the images are not the same size, the testImage is
    scaled to the refImage size prior to comparing.

    Return: List. The 1st item is a Bool indicating whether the comparison succeeded and the
      2nd item is Float and contains the % similarity (in range 0 to 100)

    refImage: (String or StormTestImageObject) The reference image to compare against.

    testImage: (String or StormTestImageObject) The image to compare agianst the reference.

    percent: (Integer, optional) the threshold for 'passing'. A similarity greater than or equal
      results in a True status in the return.

    includedAreas: (List, optional) List of rectangles to include in the comparison specified
      relative to the refImage size.  Currently only 1 rectangle can be specified.  You may
      give a list of 4 integers instead of constructing a list with a single list of 4 integers.

    excludedAreas: (List, optional) List of excluded areas for comparision, in same format as
      includedAreas.  NOT currently supported.

    algorithm: (CompareAlgorithm, optional) comparison algorithm to use.
    """
    return stormtest_client.stc.CompareImageEx(refImage, testImage, percent, includedAreas, excludedAreas, algorithm)

## @par Description
#  This function performs a single compare on an icon at a specified location
#  @param[in] refIcon @b String or @ref _stormTestImageObject : file or image from CaptureImageEx().
#  In Release 3.1 and later this may be a @ref _imageObject.
#  @param[in] testImage @b String or @ref _stormTestImageObject : file or image from CaptureImageEx().
#  In Release 3.1 and later this may be a @ref _imageObject.
#  @param[in] percent @b Integer: The limit for pass/fail. Default 98. When the detected similarity is above this value, the comparison succeeds.
#  @param[in] location @b Tuple: A tuple (x,y) where icon is within the testImage.  In Release 3.1
#  and later this may be a @ref _regionObject (but only the left and top parts are used)
#  @param[in] algorithm @b CompareAlgorithm: Comparison algorithm to use, only one allowed
#  @return @b List: true/false, actual percentage match
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#      ret = CompareIconEx(refIcon, testImage , location=(100,100))
#      print(str(ret))
#      >>>[True, 99.076345304474223]
#  @endcode
#  @note If a named image or rectangle is used then only the general 'all slot' path will be searched because this
#  function does not take a slot number.
@ApiFunction
def CompareIconEx(refIcon, testImage, percent = 98, location=None, algorithm=CompareAlgorithm.Compare1):
    """
    Compares a reference image (a small image referred to as an icon) against a similarly sized
    area of a larger image.  Intended to check on screen icons where you can keep a small
    reference image and check against larger images.

    Return: List. The 1st item is a Bool indicating whether the comparison succeeded and the
      2nd item is Float and contains the % similarity (in range 0 to 100)

    refIcon: (String or StormTestImageObject) The reference image to find in testImage.  It
      must be smaller than the testImage.

    testImage: (String or StormTestImageObject) The image to compare agianst the refIcon.

    percent: (Integer, optional) the threshold for 'passing'. A similarity greater than or equal
      results in a True status in the return.

    location: (Tuple) the location (x,y) where the refIcon is expected in the testImage. It is
      important that the rectangle formed by the location and the size of the refIcon fits
      within the testImage or an error occurs.

    algorithm: (CompareAlgorithm, optional) comparison algorithm to use.
    """
    return stormtest_client.stc.CompareIconEx(refIcon, testImage, percent, location, algorithm)

## @par Description
#  Waits for image compare to pass.
#  @param[in] refImage @b String or @ref _stormTestImageObject : file or image from CaptureImageEx().
#  In Release 3.1 and later this may be a @ref _imageObject.
#  @param[in] percent @b Integer: The limit for pass/fail. Default 98. When the detected similarity is above this value, the comparison succeeds.
#  @param[in] includedAreas @b List: Included areas for comparision, currently only one can be specified.
#  See CompareImageEx for details on format and usage.  In Release 3.1 and later the rectangle may be a @ref _regionObject.
#  @param[in] excludedAreas @b List: Excluded areas for comparision, NOT currently supported.
#  @param[in] algorithm @b CompareAlgorithm: Comparison algorithm to use, only one allowed
#  @param[in] timeToWait @b Integer: Number of Seconds to wait for a pass
#  @param[in] waitGap @b Float: Interval between subsequent comparisons
#  @param[in] slotNo @b Integer: (optional) Used to specify the slot number to call WaitImageMatch on.
#  @param[in] returnImage @b Boolean: (optional) If set to False then no StormTestImageObject is returned. If True (the default) then Close() should be called on the returned StormTestImageObject.
#  @return @b Array: An array of tuples consisting of slot number,true/false,last image captured as
#                              @ref _stormTestImageObject ,actual percentage, number of captures performed, total time taken
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#      ret = WaitImageMatch(testImage, percent, includedAreas, excludedAreas, algorithm, timeToWait, waitGap)
#      print(str(ret))
#      >>>[[8, False, <StormTestImageObject instance>,3.7219811921117305, 5, 4.5529999732971191]]
#  @endcode
#  @note This function ignores the effect of SetVideoOffset when the connected server is an HD server. It accounts for the offset when the 
#  connected server is Standard Definition.
@ApiFunction
def WaitImageMatch(refImage, percent = 98, includedAreas=None, excludedAreas=None, algorithm=CompareAlgorithm.Compare1, timeToWait=5, waitGap=1, slotNo=0, returnImage=True):
    """
    Waits until the specified slot passes the image comparison.  Images are sampled and compared
    until a timeout or an image match.

    Return: List of Lists (if slotNo is 0) or a List.  The list is: [slot number, status (Bool),
      StormTestImageObject, % match, number of captures, total time taken]. The image is the
      last image aquired during searching.

    refImage: (String or StormTestImageObject) The reference image to compare against.

    percent: (Integer, optional) the threshold for 'passing'. A similarity greater than or equal
      results in a True status in the return.

    includedAreas: (List, optional) List of rectangles to include in the comparison specified
      relative to the refImage size.  Currently only 1 rectangle can be specified.  You may
      give a list of 4 integers instead of constructing a list with a single list of 4 integers.

    excludedAreas: (List, optional) List of excluded areas for comparision, in same format as
      includedAreas.  NOT currently supported.

    algorithm: (CompareAlgorithm, optional) comparison algorithm to use.

    timeToWait: (Integer, optional) number of seconds to wait for a match.

    waitGap: (Float, optional) the time in seconds between each sample.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.

    returnImage: (Boolean, optional) If set to False then no StormTestImageObject is returned. If True (the default) then Close() should be called on the returned StormTestImageObject.
    """
    return stormtest_client.stc.WaitImageMatch(refImage, percent, includedAreas, excludedAreas, algorithm, timeToWait, waitGap, slotNo, returnImage)

## @par Description
#  Waits for image compare to fail.
#  @param[in] refImage @b String or @ref _stormTestImageObject : file or image from CaptureImageEx().
#  In Release 3.1 and later this may be a @ref _imageObject.
#  @param[in] percent @b Integer: The limit for pass/fail. Default 98, so if the returned percentage match is below this it is a passing result
#  @param[in] includedAreas @b List: Included areas for comparision, currently only one can be specified.  In Release 3.1 and later
#  the recttangle may be a @ref _regionObject.
#  See CompareImageEx for details on format and usage.
#  @param[in] excludedAreas @b List: Excluded areas for comparision, NOT currently supported.
#  @param[in] algorithm @b CompareAlgorithm: Comparison algorithm to use, only one allowed
#  @param[in] timeToWait @b Integer: Number of Seconds to wait for a pass
#  @param[in] waitGap @b Float: Interval between subsequent comparisons
#  @param[in] slotNo @b Integer: (optional) Used to specify the slot number to call WaitImageNoMatch on.
#  @param[in] returnImage @b Boolean: (optional) If set to False then no StormTestImageObject is returned. If True (the default) then Close() should be called on the returned StormTestImageObject.
#  @return @b Array: An array of tuples consisting of slot number,true/false,last image captured as
#                              @ref _stormTestImageObject ,actual percentage, number of captures performed, total time taken
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#      ret = WaitImageNoMatch(testImage, percent, includedAreas, excludedAreas, algorithm, timeToWait, waitGap)
#      print(str(ret))
#      >>>[[8, False, <StormTestImageObject instance>,99.40149751270468, 10, 10.073000192642212]]
#  @endcode
#  @note This function ignores the effect of SetVideoOffset when the connected server is an HD server. It accounts for the offset when the 
#  connected server is Standard Definition.
@ApiFunction
def WaitImageNoMatch(refImage, percent = 98, includedAreas=None, excludedAreas=None, algorithm=CompareAlgorithm.Compare1, timeToWait=5, waitGap=1, slotNo=0, returnImage=True):
    """
    Waits until the specified slot fails the image comparison.  Images are sampled and compared
    until a timeout or an image match.

    Return: List of Lists (if slotNo is 0) or a List.  The list is: [slot number, status (Bool),
      StormTestImageObject, % match, number of captures, total time taken]. The image is the
      last image aquired during searching.  The status is True if the image does NOT match the
      reference.

    refImage: (String or StormTestImageObject) The reference image to compare against.

    percent: (Integer, optional) the threshold for 'passing'. A similarity greater than or equal
      results in a True status in the return.

    includedAreas: (List, optional) List of rectangles to include in the comparison specified
      relative to the refImage size.  Currently only 1 rectangle can be specified.  You may
      give a list of 4 integers instead of constructing a list with a single list of 4 integers.

    excludedAreas: (List, optional) List of excluded areas for comparision, in same format as
      includedAreas.  NOT currently supported.

    algorithm: (CompareAlgorithm, optional) comparison algorithm to use.

    timeToWait: (Integer, optional) number of seconds to wait for a non match.

    waitGap: (Float, optional) the time in seconds between each sample.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.

    returnImage: (Boolean, optional) If set to False then no StormTestImageObject is returned. If True (the default) then Close() should be called on the returned StormTestImageObject.
    """

    return  stormtest_client.stc.WaitImageNoMatch(refImage, percent, includedAreas, excludedAreas, algorithm, timeToWait, waitGap, slotNo, returnImage)

## @par Description
#  Waits for icon compare of a ref icon against a live stream to pass
#  @param[in] refIcon  @b String or @ref _stormTestImageObject : file or image from CaptureImageEx().
#  In Release 3.1 and later this may be a @ref _imageObject.
#  @param[in] percent @b Integer: The limit for pass/fail. Default 98.  When the detected similarity is above this value, the comparison succeeds.
#  @param[in] location @b Tuple: A tuple (x,y) where icon is within screen area being compared.  In Release 3.1 and later
#  this may be a @ref _regionObject but only the left and top values are used.
#  @param[in] algorithm @b CompareAlgorithm: Comparison algorithm to use, only one allowed
#  @param[in] timeToWait @b Integer: Number of Seconds to wait for a pass
#  @param[in] waitGap @b Float: Interval between subsequent comparisons
#  @param[in] slotNo @b Integer: (optional) Used to specify the slot number to call WaitImageNoMatch on.
#  @param[in] returnImage @b Boolean: (optional) If set to False then no StormTestImageObject is returned. If True (the default) then Close() should be called on the returned StormTestImageObject.
#  @return @b Array: An array of tuples consisting of slot number,true/false,last image captured as
#                              @ref _stormTestImageObject ,actual percentage, number of captures performed, total time taken
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#      ret = WaitIconMatch(refIcon, percent, location, algorithm, timeToWait, waitGap)
#      print(str(ret))
#      >>>[[8, True, <StormTestImageObject instance>, 99.794884604363105, 1, 0.1119999885559082]]
#  @endcode
#  @note This function ignores the effect of SetVideoOffset when the connected server is an HD server. It accounts for the offset when the 
#  connected server is Standard Definition.
@ApiFunction
def WaitIconMatch(refIcon, percent = 98, location=None, algorithm =CompareAlgorithm.Compare1, timeToWait=5, waitGap=1, slotNo=0, returnImage=True):
    """
    Waits until the specified slot passes the icon image comparison.  Images are sampled and
    the icon image compared against a region of the sampled image until a timeout or a match.

    Return: List of Lists (if slotNo is 0) or a List.  The list is: [slot number, status (Bool),
      StormTestImageObject, % match, number of captures, total time taken]. The image is the
      last image aquired during searching.

    refIcon: (String or StormTestImageObject) The reference icon to find in sampled image.
      It must be smaller than the live video from the DUT.

    percent: (Integer, optional) the threshold for 'passing'. A similarity greater than or equal
      results in a True status in the return.

    location: (Tuple) the location (x,y) where the refIcon is expected in the sampled image.
      It is important that the rectangle formed by the location and the size of the refIcon
      fits within the live video or an error occurs.

    algorithm: (CompareAlgorithm, optional) comparison algorithm to use.

    timeToWait: (Integer, optional) number of seconds to wait for a match.

    waitGap: (Float, optional) the time in seconds between each sample.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.

    returnImage: (Boolean, optional) If set to False then no StormTestImageObject is returned. If True (the default) then Close() should be called on the returned StormTestImageObject.
    """
    return stormtest_client.stc.WaitIconMatch(refIcon, percent, location, algorithm, timeToWait, waitGap, slotNo, returnImage)

## @par Description
#  Waits for icon compare of a ref icon against a live stream to fail.
#  @param[in] refIcon  @b String or @ref _stormTestImageObject : file or image from CaptureImageEx().
#  In Release 3.1 and later this may be a @ref _imageObject.
#  @param[in] percent @b Integer: The limit for pass/fail. Default 98, so if the returned percentage match is below this it is a passing result
#  @param[in] location @b Tuple: A tuple (x,y) where icon is within screen area being compared.  In Release 3.1 and later this
#  may be a @ref _regionObject but only the left and top values are used.
#  @param[in] algorithm @b CompareAlgorithm: Comparison algorithm to use, only one allowed
#  @param[in] timeToWait @b Integer: Number of Seconds to wait for a pass
#  @param[in] waitGap @b Float: Interval between subsequent comparisons
#  @param[in] slotNo @b Integer: (optional) Used to specify the slot number to call WaitImageNoMatch on.
#  @param[in] returnImage @b Boolean: (optional) If set to False then no StormTestImageObject is returned. If True (the default) then Close() should be called on the returned StormTestImageObject.
#  @return @b Array: An array of tuples consisting of slot number,true/false,last image captured as
#                              @ref _stormTestImageObject ,actual percentage, number of captures performed, total time taken
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#      ret = WaitIconNoMatch(refIcon, percent, location, algorithm, timeToWait, waitGap)
#      print(str(ret))
#      >>>>[[8, False, <StormTestImageObject instance>,99.756356898506851, 5, 4.5179998874664307]]
#  @endcode
#  @note This function ignores the effect of SetVideoOffset when the connected server is an HD server. It accounts for the offset when the 
#  connected server is Standard Definition.
@ApiFunction
def WaitIconNoMatch(refIcon, percent = 98, location=None, algorithm=CompareAlgorithm.Compare1, timeToWait=5, waitGap=1, slotNo=0, returnImage=True):
    """
    Waits until the specified slot fails the icon image comparison.  Images are sampled and
    the icon image compared against a region of the sampled image until a timeout or a fail.

    Return: List of Lists (if slotNo is 0) or a List.  The list is: [slot number, status (Bool),
      StormTestImageObject, % match, number of captures, total time taken]. The image is the
      last image aquired during searching.  The status is True if the image does NOT match the
      icon.

    refIcon: (String or StormTestImageObject) The reference icon to find in sampled image.
      It must be smaller than the live video from the DUT.

    percent: (Integer, optional) the threshold for 'passing'. A similarity greater than or equal
      results in a True status in the return.

    location: (Tuple) the location (x,y) where the refIcon is expected in the sampled image.
      It is important that the rectangle formed by the location and the size of the refIcon
      fits within the live video or an error occurs.

    algorithm: (CompareAlgorithm, optional) comparison algorithm to use.

    timeToWait: (Integer, optional) number of seconds to wait for a match.

    waitGap: (Float, optional) the time in seconds between each sample.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.

    returnImage: (Boolean, optional) If set to False then no StormTestImageObject is returned. If True (the default) then Close() should be called on the returned StormTestImageObject.
    """
    return stormtest_client.stc.WaitIconNoMatch(refIcon, percent, location, algorithm, timeToWait, waitGap, slotNo, returnImage)

# Deprecated Class
## @par Deprecated
class SaveScreenCap:
    """
    DEPRECATED
    """
    IfResultTrue,IfResultFalse,Never = list(range(3))

# Deprecated Function
@ApiFunction
def CompareImage(refImage, mask, rect, timeout, percent = 98, savescreencap = SaveScreenCap.IfResultFalse, slotNo=0):
    """
    DEPRECATED - use CompareImageEx(), WaitImageMatch(), WaitImageNoMatch() etc
    """
    return stormtest_client.stc.compare_screen(refImage, mask, rect, timeout, percent, savescreencap, slotNo)

# Deprecated Function
@ApiFunction
def CompareImageFiles(ImageOne, ImageTwo, mask = None, rect = None):
    """
    DEPRECATED - use CompareImageEx
    """
    return stormtest_client.stc.CompareImageFiles(ImageOne, ImageTwo, mask, rect)

# Deprecated Function
@ApiFunction
def CompareIcon(refIcon, pos, timeout, percent = 98, savescreencap = SaveScreenCap.IfResultFalse, slotNo=0):
    """
    DEPRECATED - use CompareIconEx(), WaitIconMatch(), WaitIconNoMatch()
    """
    return stormtest_client.stc.compare_icon(refIcon, pos, timeout, percent, savescreencap, slotNo)

# Deprecated Function
@ApiFunction
def CompareColor(imageFile, rect, color):
    """
    DEPRECATED - Use CompareColorEx()
    """
    return stormtest_client.stc.CompareColor(imageFile, rect, color)

## @par Description
#  This function performs a single color compare on an image. It calculates the average color in each RGB component and compares that with the
#  specified reference color.  A tolerance is applied to each value so that if the calculated color is within the tolerance (in either direction)
#  then it is considered a match.  Thereafter a 'flatness' is calculated and a 'peak error' is calculated of tolerance.
#  The 'flatness' is how 'flat' the color is - whether there is much variation across the area of interest.  The rectangle could be,
#  on average gray but have a lot of red and cyan in it which cancel out - the average would be right but the flatness would be very
#  low (100% flat means perfect single true color).
#  The 'peak error' measures how many pixels (as a %) differ from the reference color by more than the given tolerance.  We could get a rectangle where the average color
#  matches and the flatness is high but the color difference for large parts of the rectangle exceeds the tolerance by a small amount.  This would show up as a high peak error even
#  though the flatness could be high.  A high value of flatness and a low value of peak error makes the color comparer very sensitive
#  to variations and is more likely to fail even if, to the human eye, the color matches.  It is recomended that you use the
#  Developer Suite trainer to experiment with the settings - it will save a lot of time and experimentation.
#  A match occurs IF the average color is within the tolerance limits AND the calculated flatness is above or equal to the specified
#  value AND the calculated peak error is below or equal to the specified value.
#  @param[in] image @b String or @ref _stormTestImageObject : file or image from CaptureImageEx().  In Release 3.1 and later this
#  may be a @ref _imageObject.
#  @param[in] color @b Tuple : red green and blue components of a color that is used as the reference for the comparison.
#  In Release 3.1 and later this may be a @ref _colorObject - in this case the tolerances, flatness and peakError parameters are ignored
#  because the @ref _colorObject has its own values for these parameters.
#  @param[in] tolerances @b Tuple : red green and blue component tolerances. The values are numbers and represent how far from the reference color each RGB component may be and still be considered a match.
#  @param[in] flatness @b Double : the degree of flatness required within the region where the color is calculated. 0 - 100 is the valid range
#  @param[in] peakError @b Double : the peak error (see above description) required within the region where the color is calcualted. 0 - 100 is valid range
#  @param[in] includedAreas @b List: Included areas for comparision, currently only one can be specified.
#  See CompareImageEx for details on format and usage.  In Release 3.1 and later the rectangle may be a @ref _regionObject.
#  @param[in] excludedAreas @b List: Excluded areas for comparision, NOT currently supported.
#  @return @b List: true/false, actual color, actual flatness, actual peak error
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#      # validate color at 100x20 pixel rect with top left at (10,10) has a mid gray color (128,128,128) with a
#      # flatness better than 95%, peak error 1% and allow a tolerance of 8 on each component
#      ret = CompareColorEx(testImage, (128,128,128),(8,8,8), 95, 1, includedAreas=[[10,10,100,20]])
#      print(str(ret))
#      >>>[True, (127,129,128), 97, 0]
#  @endcode
#  @note If a named image, color or region is used then only the general 'all slot' path will be searched because this
#  function does not take a slot number.
@ApiFunction
def CompareColorEx(image, color, tolerances=(4,4,4), flatness=98, peakError=0, includedAreas=None, excludedAreas=None):
    """
    Compare a region of an image for a color match.

    Return: List. The elements of the list are [Status, Color, Flatness, Peak Error]
      The Status is True if the color matches.  The Color is a Tuple (R,G,B) and the color found.
      The Flatness is Float and the degree of 'constant-ness' of the color.  Peak Error is a
      Float and represents the % of pixels deviate from the average color.

    image: (String or StormTestImageObject) The reference image to measure color on.

    color: (Tuple) red green and blue components of a color that is to be measured.

    tolerances: (Tuple, optional) red green and blue component tolerances. The values are numbers
      and represent how far from the reference color each RGB component may be and still be
      considered a match.

    flatness: (Float, optional) the degree of flatness required within the region where the color
      is calculated. 0 - 100 is the valid range.

    peakError: (Float, optional) the peak error required within the region where the color is
      calcualted. 0 - 100 is valid range.

    includedAreas: (List, optional) List of rectangles to include in the comparison.
      Currently only 1 rectangle can be specified.  You may give a list of 4 integers instead
      of constructing a list with a single list of 4 integers.

    excludedAreas: (List, optional) List of excluded areas for comparision, in same format as
      includedAreas.  NOT currently supported.
    """

    try:
        return stormtest_client.stc.CompareColorEx(image, color, tolerances, flatness, peakError, includedAreas, excludedAreas)
    except TypeError:
        print("CompareColorEx has one or more parameters of the wrong type:",image, color, tolerances, flatness, peakError, includedAreas, excludedAreas)
        raise

## @par Description
#  Waits for color compare to pass.  It tries multiple times until a pass or the timeout is reached.
#  It calculates the average color in each RGB component and compares that with the
#  specified reference color.  A tolerance is applied to each value so that if the calculated color is within the tolerance (in either direction)
#  then it is considered a match.  Thereafter a 'flatness' is calculated and a 'peak error' is calculated of tolerance.
#  The 'flatness' is how 'flat' the color is - whether there is much variation across the area of interest.  The rectangle could be,
#  on average gray but have a lot of red and cyan in it which cancel out - the average would be right but the flatness would be very
#  low (100% flat means perfect single true color).
#  The 'peak error' measures how many pixels (as a %) are away from the average.  We could get a rectangle where the average color
#  matches and the flatness is high but a small corner is dramatically different color.  This would show up as a high peak error even
#  though the flatness could be high.  A high value of flatness and a low value of peak error makes the color comparer very sensitive
#  to variations and is more likely to fail even if, to the human eye, the color matches.  It is recomended that you use the
#  Developer Suite trainer to experiment with the settings - it will save a lot of time and experimentation.
#  A match occurs IF the average color is within the tolerance limits AND the calculated flatness is above or equal to the specified
#  value AND the calculated peak error is below or equal to the specified value.
#  @param[in] color @b Tuple : red green and blue components of a color that is used as the reference for the comparison.
#  #  In Release 3.1 and later this may be a @ref _colorObject - in this case the tolerances, flatness and peakError parameters are ignored
#  because the @ref _colorObject has its own values for these parameters.
#  @param[in] tolerances @b Tuple : red green and blue component tolerances. The values are numbers and represent how far from the reference color each RGB component may be and still be considered a match.
#  @param[in] flatness @b Double : the degree of flatness required within the region where the color is calculated. 0 - 100 is the valid range
#  @param[in] peakError @b Double : the peak error (see above description) required within the region where the color is calculated. 0 - 100 is valid range
#  @param[in] includedAreas @b List: Included areas for comparision, currently only one can be specified.  In Release 3.1 and later
#  the rectangle may be a @ref _regionObject
#  @param[in] excludedAreas @b List: Excluded areas for comparision, NOT currently supported.
#  @param[in] timeToWait @b Integer: Number of Seconds to wait for a pass
#  @param[in] waitGap @b Float: Interval between subsequent comparisons
#  @param[in] slotNo @b Integer: (optional) Used to specify the slot number to call WaitColorMatch on.
#  @param[in] returnImage @b Boolean: (optional) If set to False then no StormTestImageObject is returned. If True (the default) then Close() should be called on the returned StormTestImageObject.
#  @return @b List: A list of lists consisting of slot number,true/false,last image captured as
#                              @ref _stormTestImageObject, actual color, actual flatness, actual peak error, number of captures performed, total time taken
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#      ret = WaitColorMatch((128,128,128),(8,8,8), 95, 1, includedAreas, excludedAreas, timeToWait, waitGap)
#      print(str(ret))
#      >>>[[8, False, <StormTestImageObject instance>,[129,130,126], 98, 1, 5, 4.5529999732971191]]
#  @endcode
#  @note This function ignores the effect of SetVideoOffset when the connected server is an HD server. It accounts for the offset when the 
#  connected server is Standard Definition.
@ApiFunction
def WaitColorMatch(color, tolerances=(4,4,4), flatness=98, peakError=0, includedAreas=None, excludedAreas=None, timeToWait=5, waitGap=1, slotNo=0, returnImage=True):
    """
    Waits until the specified slot passes the color comparison.  Images are sampled and compared
    until a timeout or a color match.

    Return: List of Lists (if slotNo is 0) or a List.  The list is: [SlotNumber, Status,
      StormTestImageObject, Color, Flatness, PeakError, NumberCaptures, TimeTaken]
      The Status is True if the color matches.  The Color is a Tuple (R,G,B) and the color found.
      The Flatness is Float and the degree of 'constant-ness' of the color.  Peak Error is a
      Float and represents the % of pixels deviate from the average color. TimeTaken is a Float
      and it the total time for the call in seconds.

    color: (Tuple) red green and blue components of a color that is to be measured.

    tolerances: (Tuple, optional) red green and blue component tolerances. The values are numbers
      and represent how far from the reference color each RGB component may be and still be
      considered a match.

    flatness: (Float, optional) the degree of flatness required within the region where the color
      is calculated. 0 - 100 is the valid range.

    peakError: (Float, optional) the peak error required within the region where the color is
      calcualted. 0 - 100 is valid range.

    includedAreas: (List, optional) List of rectangles to include in the comparison.
      Currently only 1 rectangle can be specified.  You may give a list of 4 integers instead
      of constructing a list with a single list of 4 integers.

    excludedAreas: (List, optional) List of excluded areas for comparision, in same format as
      includedAreas.  NOT currently supported.

    timeToWait: (Integer, optional) number of seconds to wait for a match.

    waitGap: (Float, optional) the time in seconds between each sample.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.

    returnImage: (Boolean, optional) If set to False then no StormTestImageObject is returned. If True (the default) then Close() should be called on the returned StormTestImageObject.
    """
    return stormtest_client.stc.WaitColorMatch(color, tolerances, flatness, peakError, includedAreas, excludedAreas, timeToWait, waitGap, slotNo, returnImage)

## @par Description
#  Waits for color compare to fail - that is for an area of the screen to be NOT equal to the color.  It tries multiple times until a
#  color mismatch occurs or the timeout is reached.
#  It calculates the average color in each RGB component and compares that with the
#  specified reference color.  A tolerance is applied to each value so that if the calculated color is within the tolerance (in either direction)
#  then it is considered a match.  Thereafter a 'flatness' is calculated and a 'peak error' is calculated of tolerance.
#  The 'flatness' is how 'flat' the color is - whether there is much variation across the area of interest.  The rectangle could be,
#  on average gray but have a lot of red and cyan in it which cancel out - the average would be right but the flatness would be very
#  low (100% flat means perfect single true color).
#  The 'peak error' measures how many pixels (as a %) are away from the average.  We could get a rectangle where the average color
#  matches and the flatness is high but a small corner is dramatically different color.  This would show up as a high peak error even
#  though the flatness could be high.  A high value of flatness and a low value of peak error makes the color comparer very sensitive
#  to variations and is more likely to fail even if, to the human eye, the color matches.  It is recomended that you use the
#  Developer Suite trainer to experiment with the settings - it will save a lot of time and experimentation.
#  A match occurs IF the average color is within the tolerance limits AND the calculated flatness is above or equal to the specified
#  value AND the calculated peak error is below or equal to the specified value.  This function waits for a match to NOT occur.
#  @param[in] color @b Tuple : red green and blue components of a color that is used as the reference for the comparison.
#  In Release 3.1 and later this may be a @ref _colorObject - in this case the tolerances, flatness and peakError parameters are ignored
#  because the @ref _colorObject has its own values for these parameters.
#  @param[in] tolerances @b Tuple : red green and blue component tolerances. The values are numbers and represent how far from the reference color each RGB component may be and still be considered a match.
#  @param[in] flatness @b Double : the degree of flatness required within the region where the color is calculated. 0 - 100 is the valid range
#  @param[in] peakError @b Double : the peak error (see above description) required within the region where the color is calculated. 0 - 100 is valid range
#  @param[in] includedAreas @b List: Included areas for comparision, currently only one can be specified.
#  See CompareImageEx for details on format and usage.  In Release 3.1 and later the rectangle may be a @ref _regionObject
#  @param[in] excludedAreas @b List: Excluded areas for comparision, NOT currently supported.
#  @param[in] timeToWait @b Integer: Number of Seconds to wait for a pass
#  @param[in] waitGap @b Float: Interval between subsequent comparisons
#  @param[in] slotNo @b Integer: (optional) Used to specify the slot number to call WaitColorNoMatch on.
#  @param[in] returnImage @b Boolean: (optional) If set to False then no StormTestImageObject is returned. If True (the default) then Close() should be called on the returned StormTestImageObject.
#  @return @b Array: An array of tuples consisting of slot number,true/false,last image captured as
#                              @ref _stormTestImageObject,actual color, actual flatness, actual peak error, number of captures performed, total time taken
#  A return value of True means that the color on the screen does NOT equal the specified color - that is the function has successfully
#  detected a change of color from that specified.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#      ret = WaitColorNoMatch((128,128,128),(8,8,8), 95, 1, includedAreas, excludedAreas, timeToWait, waitGap)
#      print(str(ret))
#      >>>[[8, False, <StormTestImageObject instance>,(129,130,126), 98, 1, 5, 4.5529999732971191]]
#  @endcode
#  @note This function ignores the effect of SetVideoOffset when the connected server is an HD server. It accounts for the offset when the 
#  connected server is Standard Definition.
@ApiFunction
def WaitColorNoMatch(color, tolerances=(4,4,4), flatness=98, peakError=0, includedAreas=None, excludedAreas=None, timeToWait=5, waitGap=1, slotNo=0, returnImage=True):
    """
    Waits until the specified slot fails the color comparison.  Images are sampled and compared
    until a timeout or a color match failure.

    Return: List of Lists (if slotNo is 0) or a List.  The list is: [SlotNumber, Status,
      StormTestImageObject, Color, Flatness, PeakError, NumberCaptures, TimeTaken]
      The Status is True if the color does NOT match.  The Color is a Tuple (R,G,B) and the color
      found. The Flatness is Float and the degree of 'constant-ness' of the color.  Peak Error
      is a Float and represents the % of pixels deviate from the average color. TimeTaken is a
      Float and it the total time for the call in seconds.

    color: (Tuple) red green and blue components of a color that is to be measured.

    tolerances: (Tuple, optional) red green and blue component tolerances. The values are numbers
      and represent how far from the reference color each RGB component may be and still be
      considered a match.

    flatness: (Float, optional) the degree of flatness required within the region where the color
      is calculated. 0 - 100 is the valid range.

    peakError: (Float, optional) the peak error required within the region where the color is
      calcualted. 0 - 100 is valid range.

    includedAreas: (List, optional) List of rectangles to include in the comparison.
      Currently only 1 rectangle can be specified.  You may give a list of 4 integers instead
      of constructing a list with a single list of 4 integers.

    excludedAreas: (List, optional) List of excluded areas for comparision, in same format as
      includedAreas.  NOT currently supported.

    timeToWait: (Integer, optional) number of seconds to wait for a failed match.

    waitGap: (Float, optional) the time in seconds between each sample.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.

    returnImage: (Boolean, optional) If set to False then no StormTestImageObject is returned. If True (the default) then Close() should be called on the returned StormTestImageObject.
    """
    return stormtest_client.stc.WaitColorNoMatch(color, tolerances, flatness, peakError, includedAreas, excludedAreas, timeToWait, waitGap, slotNo, returnImage)

# Deprecated Function
@ApiFunction
def ImageDiff (slotNo=0):
    """
    DEPRECATED
    """
    return stormtest_client.stc.ImageDiff(slotNo)

# Deprecated Function
@ApiFunction
def CaptureScreen(prefix='Cap', slotNo=0, ext='jpg', quality=80, rect=None):
    """
    DEPRECATED - Use CaptureImageEx()
    """
    return stormtest_client.stc.capture_screen(prefix, slotNo, ext, quality, rect)

## @par Description
#  This function is designed to allow a test written with reference images captured from one box to be run on a box with
#  different hardware characteristics, but the same software application, i.e. it could be a different model or from a different
#  manufacturer. In this case, the analogue video capture images will most likely be offset relative to the reference box.
#  The SetVideoOffset() function can be then be used by the test writer to tell StormTest what this offset is.  Then StormTest will
#  apply this offset to any image captures (both directly and indirectly that are part of an API call).  All image based operations
#  such as OCR, image comparison, navigate will use the offset image.
#  \n\n The actual values that are passed to the function are the number of pixels on each axis that the live video picture needs
#  to be translated by in order for it to match the reference box
#  \n\n For example, if a screen capture from a box is shifted 7 pixels to the left and 2 pixels down relative to a reference box
#  then its top left hand corner is at (-7,2) relative to the reference. It must therefore have 7 added to the x co-ordinate and 2 subtracted
#  from the y co-ordinate in order to bring it in line with the reference.
#  \n\n So, in this example, the user would call SetVideoOffset((7,-2))
#  @param[in] offset @b Tuple: This is in the form (x,y) where (x,y) is the amount to translate the live video so that it
#  matches the reference box.  In Release 3.1 and later this may be a @ref _regionObject but only the left and top values will be used.
#  @param[in] slotNo @b Integer: (optional) Used to specify the slot number to set an offset. If not used, then the offset will apply to all reserved slots.
#  @param[in] saveToDatabase @ Bool: (optional) If true then the value(s) are saved to the database and automatically used by all scripts on that type of DUT thereafter. Use with caution!
#  @return @e offsetResult @b List: A list of tuples consisting of slot number and the result.  Just a single tuple if explicit slot is used.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>ret=SetVideoOffset((10, -10))
#   >>print(str(ret))
#   >>[[1, True], [5, False]]     # result from slot 1 success and from slot 5 fail
#  @endcode
#  @note This function is deprecated when the connected server is an HD server and has no effect.
@ApiFunction
def SetVideoOffset (offset, slotNo=0, saveToDatabase=False):
    """
    Set an offset for the video on the slot.  All images captured will be offset by this amount
    before image processing.  Allows a test to use images captured on one DUT as reference images
    for tests to be run on another DUT once the offset is known between the DUTs.  This only
    works if the videoFlag of ReserveSlot() was set to True

    Return: List of tuples (if slotNo is 0) or a tuple.  The tuple is: (SlotNumber,Status) where
      the status indicates whether the offset was set or not.

    offset: (Tuple) X,Y co-ordinates of offset to apply to each image captured.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.

    saveToDatabase: (Bool, optional) Flag to indicate whether the StormTest main database
      should be updated with the new values or not.
    """
    return stormtest_client.stc.SetVideoOffset(offset, saveToDatabase, slotNo)

## @par Description
#  This function returns the value of the video offset.
#  @param[in] slotNo @b Integer: (optional) Used to specify the slot number to get an offset.
#  @return @e videoOffset @b List: A list of tuples consisting of slot number and the offset value.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>ret=GetVideoOffset()
#   >>print(str(ret))
#   >>[[1, (10, -10)], [5, (0, 0)]]
#  @endcode
#  @note This function is deprecated when the connected server is an HD server and always returns (0,0).
@ApiFunction
def GetVideoOffset (slotNo=0):
    """
    Get the video offset set by SetVideoOffset.  This only works if the videoFlag of ReserveSlot()
    was set to True.

    Return: List of Lists (if slotNo is 0) or a List.  The list is [SlotNumber, Offset] where
     the offset is a Tuple of (x,y)

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.

    """
    return stormtest_client.stc.GetVideoOffset(slotNo)

## @par Description
#  This function calibrates the current DUT video offset with reference to a reference image
#  It assumes that the DUT is showing the same image as the reference and analyzes the best
#  combination of X & Y offsets and calls SetVideoOffset() internally to set the video offset
#  @param[in] filename @b String: the reference file.  It should be same resolution as the DUT is showing.  In Release 3.1 and later this may be a @ref _imageObject
#  @param[in] maxX @b Integer: (optional) the maximum possible offset in X direction.  The function searches no more than this number of pixels left & right looking for a match
#  @param[in] maxY @b Integer: (optional) the maximum possible offset in Y direction.  The function searches no more than this number of pixels up and down looking for a match
#  @param[in] threshold @b Integer: (optional) the % match that is considered acceptable.  Too low a figure will cause inaccurate
#  offsets, too high figure may prevent any offset being accepted even though there is a valid value.
#  @param[in] saveToDatabase @b Bool (optional) whether the discovered offset is saved to the database
#  @param[in] slotNo @b Integer: (optional) Used to specify the slot number to calibrate. If not used, then the calibration will occur on all reserved slots sequentially.
#  @return @e calibrationArray @b Array: An array of tuples consiting of slot number, status, offset, %error. Just a tuple if
#  explicit slot is used.
#  @subsection _eg1 eg1:
#  @b Example:
#  @code
#   >>ret = CalibrateVideoOffset("guide.png",10,10,95,False,7)
#   >>print(str(ret))
#   >>(7, True,(-4,0),3.412593)
#  @endcode
#  @note this function is deprecated when the connected server is HD
@ApiFunction
def CalibrateVideoOffset(filename,maxX=10,maxY=10,threshold=95,saveToDatabase=False,slotNo=0):
    """
    Calibrates the video offset of the selected slot.  This takes an expected image, assumes the
    slot is showing the same image but with an offset and finds the offset.  This is then used
    for later comparisons in the script.

    Return: List of Tuples (if slotNo is 0) or a Tuple.  The Tuple is: (SlotNumber, Status,
      Offset, % error) The Offset is a Tuple (x,y) of the detected offset. % error indicates the
      degree of success (0% => perfect match).

    filename: (String) Reference image file of expected image on screen.

    maxX: (Integer, optional) Maximum allowed offset in X direction that will be searched for.

    maxY: (Integer, optional) Maximum allowed offset in Y direction that will be searched for.

    threshold: (Integer, optional) Level in % of image match that is considered OK for offset to
      be calibrated.

    saveToDatabase: (Bool, optional) Flag to indicate whether the StormTest main database
      should be updated with the new values or not.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.CalibrateVideoOffset(filename, maxX, maxY, threshold, saveToDatabase, slotNo)

## @par Description
#  This function starts saving the video capture to disk.
#  @param[in] prefix @b String: (optional) Prefix to add to the auto-generated filename.
#  @param[in] slotNo @b Integer: (optional) The slot number to start video logging on.
#  @return see @ref _stdImageReturn
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>ret=StartVideoLog()
#   >>print(str(ret))
#   >>[[1, True, "Vid_Slot1_Timestamp.264"], [9, True, "Vid_Slot9_Timestamp.264"]]
#  @endcode
#  @note If the @e slotNo parameter is omitted the default is to start logging for all slots reserved.
@ApiFunction
def StartVideoLog(prefix='Vid',slotNo=0):
    """
    Start video logging.  This creates a new video file. videoFlag of ReserveSlot() must
    have been true for this to work.

    Return: List List of Lists (if slotNo is 0) or a List.  The list is: [SlotNumber, Status,
      FileName] where Filename is name of .264 file created.

    prefix: (String, optional) prefix to add to filename.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.start_video_log(prefix, slotNo)

## @par Description
#  This function stops saving the video capture to disk.
#  @param[in] slotNo @b Integer: (optional) The slot number to stop video logging on.
#  @return see @ref _stdImageReturn
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>StopVideoLog()
#  @endcode
#  @note If the @e slotNo parameter is omitted the default is to stop logging for all slots reserved.
@ApiFunction
def StopVideoLog(slotNo=0):
    """
    Stop the video logging.  StartVideoLog() must have been successully called.

    Return: None

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.stop_video_log(slotNo)


## @par Description
#  This function enables the rolling record buffer for a slot.  The rolling record buffer
#  is saved by using the SaveRecording call.  It is disabled by DisableRollingRecord which
#  will reclaim disk space used.  The function does some checking for disk space and
#  file creation so may take a few seconds or so to execute.
#  @param[in] maxTime @b Integer: (optional) The max length of the buffer in seconds.  There is a hard
#  coded limit of 10 minutes.  If you need more than 10 minutes we suggest Start/StopVideoLog is a better
#  option.
#  @param[in] location @b String: (optional) The location of a folder to store the temporary files.  If set to 
#  None (the default) then a sub folder of the log folder for the slot will be used.  The location should
#  be on a disk with very fast access due to the amount of data being written.  It need not (and should not)
#  be the same as you intend to save any such buffers.
#  @param[in] slotNo @b Integer: (optional) The slot number to enable the rolling record buffer on. 
#  @return @e Bool.  If slot is zero then a list of lists, each sub list being [slot, bool] where the
#  bool is the status.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>EnableRollingRecord(60,"c:\\temp")
#   >>[[1,True],[7,True]]
#   >>EnableRollingRecord(60, None, 5)
#   >>True
#  @endcode
#  @note Temporary files created will be deleted when the slot is freed (FreeSlot or ReleaseServerConnection)
@ApiFunction
def EnableRollingRecord(maxTime=600, location=None,slotNo=0):
    return stormtest_client.stc.enable_rolling_record(maxTime, location, slotNo)


## @par Description
#  This disables the rolling record buffer for a slot.  The return is True if the rolling record buffer
#  is successfully disabled.  All temporary files created by a prior EnableRollingRecord are deleted.  It is
#  not an error to call DisableRollingRecord on a slot which has no rolling record buffer. The return will be
#  True so this is a safe call at any time.
#  @param[in] slotNo @b Integer: (optional) The slot number to enable the rolling record buffer on. 
#  @return @e Bool.  If slot is zero then a list of lists, each sub list being [slot, bool] where the
#  bool is the status.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>DisableRollingRecord()
#   >>[[1,True],[7,True]]
#   >>DisableRollingRecord(5)
#   >>True
#  @endcode
@ApiFunction
def DisableRollingRecord(slotNo=0):
    return stormtest_client.stc.disable_rolling_record(slotNo)


## @par Description
#  This saves part of the rolling record buffer to disk in the specified file.  It is not an error
#  to call this function with a time larger then the maximum time specified in EnableRollingRecord
#  or a value greater than the amount of video so far captured.  The function will attempt to save
#  the amount requested but report the actual amount saved.
#  @param[in] time @b Integer : the number of seconds of video and audio to save.  
#  @param[in] fileName @b String : the file name to save the video and audio to.  It can be 
#  relative (to the folder specified in SetDirectories/SetProjectDir) or an absolute path.  The
#  extension will be 'corrected' by the API to be .264 (Standard Def systems) or .avi (HD Systems).  You are
#  advised to use a path relative to the log folder.  From release 3.2.5, logfiles will have a hyperlink
#  to the recording so you can easily view then from a browser.  However, for this to work, you must
#  use a path relative to the log folder.  You could, in theory, use an absolute path if you were to 
#  only run the test from a local file.  This cannot work under the daemon as the final resolved path
#  must be in the FTP area of the daemon for hyperlinks to work.  Therefore, if the test is run under
#  the daemon and the path is not relative to the log folder (the fileName is either absolute or starts
#  with ..\ to indicate a parent folder) the hyperlink is not written to the log file but a warning is
#  written instead.
#  @param[in] slotNo @b Integer: (optional) The slot number of the video/audio to save.
#  @return @e Tuple or list of lists.  If slotNo is non zero then a tuple of (status, fullFileName, seconds)
#  is returned. The status is a bool (True if all OK), fullFileName is the full path to the file saved.
#  If slotNo is zero then the return is a list of lists.  The list items are [slotNo, tuple] where tuple
#  is the standard tuple as if slotNo was non zero
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>SaveRecording(10,"myfirsttest.ran",9)
#  >>(True, 8.5, "c:\\mytests\\mytest_20150503_143407_35\\myfirsttest.264")
#  >>SaveRecording(30,"myfirsttest.avi")
#  >>[[5,(True, 30, "c:\\mytests\\mytest_20150503_144510_22\\myfirsttest.avi")],[7,(True, 28, "c:\\mytests\\mytest_20150503_144510_22\\myfirsttest(2).avi")]]
#  @endcode
#  @note Under the daemon, the log folder is mapped by the client daemon and relative paths for the
#  video file are treated in the same manner as for saving images from the StormTestImageObject's Save()
#  method.
@ApiFunction
def SaveRecording(time, fileName, slotNo=0):
    return stormtest_client.stc.save_recording(time, fileName, slotNo)



## @par Description
#  When a test script calls StartVideoLog(), a 'bookmark' is automatically created for every call to a StormTest API function. This allows the person reviewing the logs to quickly
#  jump to the point in the video that a particular API was called. However, there are no bookmarks for non-StormTest functions.\n\n
#  This function allows the test writer to create user-defined bookmarks in the video log.
#  @param None
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>BookmarkVideoLog()
#  @endcode
@ApiFunction
def BookmarkVideoLog():
    """
    Place a bookmark in the log file - the video log player of StormTest Developer Suite can jump
    to user bookmarks.

    Return: None
    """
    # no action needed as the decoriator does the work.
    return None

# Deprecated Function
@ApiFunction
def DetectMotion(rect, timeout, percent = 2, savescreencap = SaveScreenCap.IfResultFalse, slotNo=0):
    """
    DEPRECATED - Use DetectMotionEx()
    """
    return stormtest_client.stc.detect_motion(rect, timeout, percent, savescreencap, slotNo)


## @par Description
#  This function gets the immediate audio level in dBu.
#  @note You cannot call this while running an audio analysis on any channel.
#  @param[in] slotNo @b Integer : (optional) By default, function acts on all reserved slots, unless this parameter is used.
#  @return @e Array: The return type is structured as an array of tuples. Each tuple consists of the slot number, status and the audio level in dBu.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>GetAudioLevel()
#   >>[[1, True, -20], [2, True, -12]]
#  @endcode
@ApiFunction
def GetAudioLevel(slotNo=0):
    """
    Return the instantaneous value of the audio on the slot.  Cannot be used if Audio Analysis
    is running in your script on another slot.

    Return: List of Lists (if slotNo is 0) or a List.  The list is: [SlotNumber, Status, Level]
      where level is audio level (Float) in dBu.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.GetAudioLevel(slotNo)

## @par Description
#  This function detects the presence or absence of audio.
#  @note You cannot call this while running an audio analysis on any channel.
#  @param[in] threshold @b Float: threshold value above which will be deemed as audio presence.
#  @param[in] timeout @b Float : The maximum time in seconds to wait for the audio to exceed the threshold.
#  @param[in] slotNo @b Integer : (optional) By default, function acts on all reserved slots, unless this parameter is used.
#  @return @e Array: The return type is structured as an array of tuples. Each tuple consists of the slot number, the audio detection result (i.e. True/False), the actual audio level and total time taken.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>WaitAudioPresence(-20, 2)
#   >>[[1, True, -8.961853637816823, 0.19401939999999998]]
#   >>WaitAudioPresence(-20, 2, 1)
#   >>[True, -8.961853637816823, 0.19401939999999998]
#  @endcode
@ApiFunction
def WaitAudioPresence(threshold, timeout, slotNo=0):
    """
    Waits for audio to be present on the specified slot.  Audio is continuously sampled
    and measured until the timeout or a level above specified value is detected.

    Return: List of Lists (if slotNo is 0) or a List.  The list is: [SlotNumber,Status,
      Level, TimeTaken] the Level (Float) is the detected Level in dBu and TimeTaken (Float) is
      time to detect audio in seconds.

    threshold: (Float) Level in dBu below which, audio is considered as background noise.

    timeout: (Float) Time in seconds to wait for audio.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.WaitAudioPresence(threshold, timeout, slotNo)

## @par Description
#  This function detects the presence or absence of audio.
#  @note You cannot call this while running an audio analysis on any channel.
#  @param[in] threshold @b Float: threshold value above which will be deemed as audio presence.
#  @param[in] timeout @b Float : The maximum time in seconds to wait for the audio to be below the threshold.
#  @param[in] slotNo @b Integer : (optional) By default, function acts on all reserved slots, unless this parameter is used.
#  @return @e Array: The return type is structured as an array of tuples. Each tuple consists of the slot number, the audio detection result (i.e. True/False),  the actual audio level and total time taken.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>WaitAudioAbsence(-60, 2)
#   >>[[1, False, -8.9549860644472332, 1.9291928999999999]]
#   >>WaitAudioAbsence(-60, 2, 1)
#   >>[False, -8.9549860644472332, 1.9291928999999999]
#  @endcode
@ApiFunction
def WaitAudioAbsence(threshold, timeout, slotNo=0):
    """
    Waits for audio to be absent on the specified slot.  Audio is continuously sampled
    and measured until the timeout or a level below specified value is detected.

    Return: List of Lists (if slotNo is 0) or a List.  The list is: [SlotNumber,Status,
      Level, TimeTaken] the Level (Float) is the detected Level in dBu and TimeTaken (Float) is
      time to detect no audio in seconds.  Status is True if no audio is detected.

    threshold: (Float) Level in dBu below which, audio is considered as 'silent' and thus no
      audio.

    timeout: (Float) Time in seconds to wait for absence of audio.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.WaitAudioAbsence(threshold, timeout, slotNo)


## @par Description
# This function resynchronises the HDMI audio signals.  Occasionally, DUTs can change audio sampling rate
# several times in a few seconds.  This can cause the hardware to lose audio sync.  The symptom is the audio
# levels are incorrectly detected and there is a 'hissing' sound from any speakers.  Should this happen, then
# calling this function will reset the audio channel hardware - there will be a period of several seconds of 
# silence before the audio recovers.  This function is slow in operation - 5 seconds or more is typical and 
# should be used as a last resort.  Many DUTs do not change audio rates and for those DUTs, this function is
# unnecessary.  This function does nothing on SD systems.
# This function requires the server to be at version 3.2.5 or later.
# @param[in]  slotNo @b Integer : (optional) By default, function acts on all reserved slots, unless this parameter is used.
# @return None
# @exception StormTestExceptions is thrown on an error, for example if the server is earlier than release 3.2.5.
# @note You should @b not call this function while running Audio Analysis unless absolutely necessary - it will
# interfere with the results of the analysis.
def ResyncAudio(slotNo=0):
    return stormtest_client.stc.resync_audio(slotNo)


## @par Description
# This function determines whether a resync of the HDMI audio signals may be needed.  If you see strange audio
# levels then you may need to call ResyncAudio function.  The IsAudioResyncNeeded will indicate whether the
# system believes you should call ResyncAudio.  You can call ResyncAudio even if IsAudioResyncNeeded returns False.
# This function always returns False on SD systems and if the server version is less than 3.2.5 (because such servers
# can not perform an audio resync).
# @param[in] slotNo @b Integer : (optional) By default, function acts on all reserved slots, unless this parameter is used.
# @param[in] clearStatusOnRead @b Bool : (optional) By default, the function clears the status after reading.  The intention being
# that if code chooses not to resync audio then a subsequent change to audio will re indicate a change is needed.  However, some
# uses will want the status to be stored in the API and be 'sticky'.  Set clearStatusOnRead to be False for this.  This feature
# was added in release 3.4.1
# @return @e List : if slotNo is 0 then a list of lists, each list being [slotNo, status]. If slotNo is non zero then a
# simple Boolean is returned of the status - True if ResyncAudio should be called.
def IsAudioResyncNeeded(slotNo=0, clearStatusOnRead=True):
    return stormtest_client.stc.is_audio_resync_needed(slotNo, clearStatusOnRead)


# Deprecated Function
## @par Description
# This function sets the audio auto resync on or off for the slot for the duration of the test only.  If you wish to permanently
# set the audio auto resync then call UpdateDutModel with a key called 'AudioAutoResync' and a dictionary as the value as described
# here.  To clear the auto sync from a model, call UpdateDutModel with the value of 'AudioAutoResync' set to None.  Auto audio resync is available in release 3.3.4.
# @param[in] enabled @b Boolean : A value that determines whether the audio auto resync is enabled for the slot or not.
# @param[in] syncParams @b Dictionary : (optional) A set of values controlling how the auto resync decides whether to resync or not.  If the
# value is None then the values set by the model, if any, are used.  If the model has not been customised then hard coded default values are used.
# The full list of keys is:\n
# SampleSize : Number of seconds over which to sample the audio on each channel. Default is 1.0 (type is floating point)\n
# SampleWindow : Number of samples of SampleSize to use in determining whether a resync is to be performed.  Default is 10 (type is integer)\n
# AmplitudeThreshold : Amplitude threshold applied over the window. If the moving average for left and right channels is above this then a resync
# is performed. Default is 200 (type is integer).\n
# AmplitudeDelta : The absolute difference between left and right channels' amplitude above which a resync will be performed. Default is 200 (type is integer).\n
# SpreadThreshold : Threshold in the spread of samples above which a resync is performed.  The 'spread' is loosely described as to how far the audio
# amplitudes are away from 0 during the sample bucket. Default is maximum integer value which means 'not used'. (Type is integer)\n
# SpreadDelta : The absoute difference between left and right spread channels' spread above which a resync will be performed. Default is 400 (type is integer).\n
# EnableAlways : A value indicating whether a resync will always be performed or whether the user must enable it in code. Default is False so that the system
# behaves by default as per previous releases.\n
# @param[in] slotNo @b Integer : (optional) By default, the function acts on all reserved slots, unless this parameter is used.
# @return None
# 
# @note It makes no sense to set the EnableAlways when using this function. It is documented for completeness here rather than in UpdateDutModel.  It makes
# perfect sense to set EnableAlways when setting the parameters for a model so that a given model, in any slot, receives the auto resynce logic.
# @note Enabling auto resync has an impact on IsAudioResyncNeeded because the auto resync means that IsAudioResyncNeeded will always return False.  This does not
# prevent a script calling ResyncAudio.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetAudioAutoResync(False)  # Disables the resync for all reserved slots
#   >>SetAudioAutoResync(True, None, 6)  # Enables the resync for slot 6
#   >>SetAudioAutoResync(True, { "SampleWindow" : 5}) # Enables the resync for all slots and overrides the
#      SampleWindow to be 5 (all other parameters being unchanged)
#  @endcode
#  @subsubsection _eg1 eg2:
#  @b Example:
#  @code
#  >>info = {}
#  >>info["AudioAutoResync"] = { "SampleSize" : 0.75, "SampleWindow" : 10, "EnableAlways" : True, ... }
#  >>ret = UpdateDutModel(789, info)  # set the auto audio resync for model number 789
#  info["AudioAutoResync"] = None
#  >>ret = UpdateDutModel(789, info)  # clear the audio auto resync for model number 789
#  @endcode
@ApiFunction
def SetAudioAutoResync(enabled, syncParams=None, slotNo=0):
    stormtest_client.stc.set_audio_auto_resync(enabled, syncParams, slotNo)

# Deprecated Function
## @par Description
# This function gets the current settings of the audio auto resync.  It is available in release 3.3.4
# @param[in] slotNo @b Integer : (optional) By default, the function retrieves the settings for all reserved slots, unless this parameter is used.
# @return @e List : Each item in the list is another list of [slotNo, syncParams, enabled]. The syncParams are as described under SetAudioAutoResync and
# the enabled is the current enabled state.  The return format is the same whether slotNo on input is 0 or an explicit slot (obviously, if an explicit
# slot is used on input then only the data for that slot is returned by the call)
#
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>GetAudioAutoResync()
#   >>[[1,{SampleSize : 1.0, SampleWindow : 10 ...}, True], [2, {...}, True]]
#   >>GetAudioAutoResync(1)
#   >>[[1,{SampleSize : 1.0, SampleWindow : 10 ...}, True]]
#  @endcode
@ApiFunction
def GetAudioAutoResync(slotNo=0):
    return stormtest_client.stc.get_audio_auto_resync(slotNo)


## @par Description
#  This function sets the format (i.e. the video resolution) for the video. It should be noted that as the video resolution is increased, it may be necessary to increase the maximum bitrate in order to ensure that video quality is not compromised.
#  @param[in] format @b String: see @ref _videoFormat
#  @param[in] slotNo @b Integer: (optional) The slot number to set the resolution on
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetResolution("QCIF",1)  # Sets the resolution to QCIF for slot number 1 only
#   or
#   >>SetResolution("QCIF")    # Sets the resolution to QCIF for all slots
#  @endcode
#  @note If the @e slotNo parameter is omitted the default is to set the resolution for all slots reserved
#  @note It is not possible to set the resolution for HD sources connected to HD servers using Hardware Compression and this API call is ignored.  For such servers the streamed
#  video is at the same resolution as the raw input video.  If GPUCompression has been enabled on an HD server (indicated in GetCapabilities) then this API calls works as for 4K systems.
#  @note For sources connected to the 4K server, you can set the resolution to one of the resolutions listed in @ref _videoFormat.  For optimum CPU performance on the server
#  and lowest bandwidth use, you should use the lowest possible resolution consistent with your needs.  The resolution only affects the log files and the quality of the popup
#  window used to view the DUT video.  It has no effect on the other test api functions such as CaptureImageEx etc.  GPU Compression was added in release 3.3.0 and the server must be
#  at 3.3.0 or later.
@ApiFunction
def SetResolution(format,slotNo=0):
    """
    Set the resolution of the picture to be streamed on a slot.

    Return: None

    format: (String) The picure format: "CIF", "QCIF", "DCIF", "2CIF", "4CIF"

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    if slotNo == 0:
        return stormtest_client.stc.set_encoder_format(format)
    else:
        return stormtest_client.stc.set_encoder_format_on_port(slotNo, format)

## @par Description
#  This function returns the resolution of the encoded video on reserved slots.
#  @param[in] slotNo @b Integer: (optional) Allows the user to get the resolution on just one slot rather than all slots reserved.
#  @return @e slotResolution @b String @b Array: An array of tuples consisting of slot number and resolution. See @ref _videoFormat. If a specific slot number is passed to the function, then the return value will be a string indicating the video resolution on that slot.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Get resolution of all reserved slots
#   >>ret=GetResolution()
#   >>print(str(ret))
#   >>[[1, "QCIF"], [3, "CIF"]]   # Slot 1 is at QCIF resolution, slot 3 is at CIF
#                                 # resolution
#
#   # Get resolution of one specific slot
#   >>ret=GetResolution(3)
#   >>print(str(ret))
#   >>"CIF"                       # Slot 3 is at CIF resolution
#  @endcode
#  @note If the @e slotNo parameter is omitted the resolutions returned are for all slots reserved.
@ApiFunction
def GetResolution(slotNo=0):
    """
    Return the current video resolution of the slot.

    Return: List of Lists (if slotNo is 0) or a String.  When slotNo is 0, the List is [SlotNumber,
      Resolution] and otherwise the return is the Resolution as a string.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.get_resolution(slotNo)


## @par Description
#  VideoColorSpace Enum. Defines the names for color spaces for video systems.  Not all StormTest
#  systems support all values of color space.
#  @param Unknown : The color space is unknown for the input
#  @param RGB : Full Range RGB (0-255 for each of Red, Green and Blue)
#  @param LimitedRGB : Limited range RGB (16-235)
#  @param YUV601 : YUV to BT.601 (Standard Definition color conversion)
#  @param YUV709 : YUV to BT.709 (Normal HD color conversion)
#  @param XVYCC_601 : Extended gamut YUV to BT.601
#  @param XVYCC_709 : Extended gamut YUV to BT.709
#  @param YUV601_FULL : Full range (0-255) YUV to BT.601
#  @param YUV709_FULL : Full range (0-255) YUV to BT.709
class HDMIColorSpace:
    Unknown = -1
    RGB = 0
    LimitedRGB = 1
    YUV601 = 2
    YUV709 = 3
    XVYCC_601 = 4
    XVYCC_709 = 5
    YUV601_FULL = 6
    YUV709_FULL = 7


## @par Description
#  This function returns information about the raw input of the reserved slot(s).  For some servers there may be a 
#  difference between the streamed resolution and the input resolution.  The return here returns information about the
#  raw video and, for HD servers, raw audio input parameters.  The function returns the most recent set of parameters (audio, in particular
#  can change frequently).
#  @param[in] slotNo @b Integer: (optional). The slot number for which values are wanted. Use 0 for all reserved slots.
#  @return @e slotInfo @b Dictionary: A dictionary of keys (each key being a string) and values.  If slotNo is zero then
#  a list of slot number, dictionary is returned.  The keys supported are:\n
#  Width (width in pixels of video)\n
#  Height (height in pixels of video)\n
#  Interlaced (True for interlaced modes, false for progressive)\n
#  FrameRate (number of frames per second.  For interlaced mode, this is the field rate - this matches general marketing material where 1080i50 is 50 Hz but really 25 completer frames/second.)\n
#  HardwareCaptureRate (number of frames per second that the hardware captures images for high speed timer and video quality analysis purposes) This is never above the FrameRate but for some hardware
#  it may be below the frame rate.\n
#  ColorSpace (the color space as VideoColorSpace enumerated type).  Only for 4K systems - Unknown for HD systems.  SD is analog so no color space.\n
#  PixelClock (the pixel clock frequency in Hz).  Only for 4K systems - Unknown for all other systems.\n
#  AudioRawBitDepth (the number of bits per audio sample at the hardware level.  Only for 4K systems, all others systems return None as it is unknown)\n
#  AudioRate (the audio bit rate in Hz)\n
#  AudioBitDepth (the bits per sample for audio that are used in StormTest for all purposes on the server.  For compatibility purposes, the 4K system uses 16 bits even if raw input was 20 or 24 bits)\n
#  AudioChannels (the number of audio channels in the raw audio stream 1 or 2)\n
@ApiFunction
def GetRawInputInfo(slotNo=0):
    return stormtest_client.stc.get_raw_input_info(slotNo)



## @par Description
#  This function sets the maximum bit rate to be used when encoding the video from a particular slot. Note that this function does not set the @e actual bit rate that is used, 
#  it is simply defining a maximum ceiling that the encoder should not cross.
#  @param[in] bitRate @b Integer: This is the bitrate to be used in bits per second, e.g. a value of 512000 would set the bit rate to 512 kbps. For Standard Definition systems
#  a minimum value of 30000 is allowed and for HD systems using hardware compression the minimum is 128000.  For 4K systems and HD systems using GPU compression the minimum
#  is 1/500 of the raw uncompressed bit rate.  So, if you set the resolution to be 720 x 576 and frame rate of 30 then the raw bit rate is 720 x 576 x 30 x 12 (12 bits/pixel always)
#  leading to a raw rate of 149 Mbit/sec so a minimum compressed rate of 300 kbps.  No error is reported on setting an inappropriate rate but GetMaxBitRate() can be used to retrieve
#  the setting.  GPU compression was added in release 3.3.0 and requires the server to be at release 3.3.0 or later.
#  There is no maximum value defined as the encoder will simply not be able to reach the maximum bit rate beyond a certain level.  Standard Definition systems
#  have a usable maximum of 4Mbit/sec and HD systems can use up to 12MBit/sec.
#  @param[in] slotNo @b Integer: (optional) The slot number to set the bitrate on.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetMaxBitRate(512000,1) # Sets the maximum bit rate to 512000bps on slot 1
#     or
#   >>SetMaxBitRate(512000)   # Sets the maximum bit rate to 512000bps on all slots
#  @endcode
#  @note If the @e slotNo parameter is omitted the default is to set the maximum bit rate for all slots reserved.
@ApiFunction
def SetMaxBitRate(bitRate,slotNo=0):
    """
    Set the maximum bit rate to send video from the server to the client.

    Return: None

    bitRate: (Integer) The bit rate in bits/second. Min value is 30000. No maximum but in
      practice, values above 4000000 (4 Mbit/sec) have no effect on actual bit rate.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    if slotNo == 0:
        return stormtest_client.stc.set_bitrate(bitRate)
    else:
        return stormtest_client.stc.set_bitrate_on_port(slotNo, bitRate)

## @par Description
#  This function returns the maximum bit rate that the video encoder can use when encoding the video.
#  @param[in] slotNo @b Integer: (optional) Allows the user to get the maximum bit rate on just one slot rather than all slots reserved.
#  @return @e bitRate @b Integer @b Array: An array of tuples consisting of slot number and maximum encoding bit rate. If a specific slot number is passed to the function, then the return value will be an integer indicating the max bit rate on that slot.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Get maximum bit rate of all reserved slots
#   >>ret = GetMaxBitRate()
#   >>print(str(ret))
#   >>[[1, 512000], [4, 128000]]    # Slot 1 is using a max of 512kbps, slot 4 is using
#                                   # a max of 128kbps
#
#   # Get maximum bit rate of one specific slot
#   >>ret = GetMaxBitRate(4)
#   >>print(str(ret))
#   >>128000                        # Slot 4 is using a max of 128kbps
#  @endcode
#  @note If the @e slotNo parameter is omitted the maximum bit rates for all slots reserved are returned.
@ApiFunction
def GetMaxBitRate(slotNo=0):
    """
    Return the current maximum bit rate.

    Return:  List of Lists (if slotNo is 0) or an Integer.  When slotNo is 0, the List is
     [SlotNumber, BitRate] and otherwise the return is the BitRate as an integer.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.get_bit_rate(slotNo)

## @par Description
#  This function sets the frame rate for the streaming content.
#  @param[in] frameRate @b Integer: The new frame rate. The valid frame rate depends on the server and slot.
#  For Standard Definition, the value is between 1 and 25 for PAL DUTs, 1 and 30 for NTSC DUTs.  For HD systems, the
#  valid range is 1 to 60.  However, the actual frame rate is limited to 30 on HD systems if the source is 1920 x 1080.
#  @param[in] slotNo @b Integer: (optional) The slot number to set the frame rate on.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetFrameRate(25,1)  # Sets the frame rate to 25 on slot 1
#     or
#   >>SetFrameRate(25)    # Sets the frame rate to 25 on all slots
#  @endcode
#  @note If the @e slotNo parameter is omitted the default is to set the frame rate for all slots reserved.
@ApiFunction
def SetFrameRate(frameRate,slotNo=0):
    """
    Set the frame rate of the slot in frames/second.

    Return: None

    frameRate: (Integer) The frame rate in frames/second. 1-25 (PAL), 1-30 (NTSC)

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    if slotNo == 0:
        return stormtest_client.stc.set_framerate(frameRate)
    else:
        return stormtest_client.stc.set_framerate_on_port(slotNo, frameRate)

## @par Description
#  This function returns the frame rate that the video is being encoded with on reserved slots.
#  @param[in] slotNo @b Integer: (optional) Allows the user to get the frame rate on just one slot rather than all slots reserved.
#  @return @e frameRate @b Integer @b Array: An array of tuples consisting of slot number and frame rate. If a specific slot number is passed to the function, then the return value will be an integer indicating the frame rate on that slot.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Get frame rate of all reserved slots
#   >>ret=GetFrameRate()
#   >>print(str(ret))
#   >>[[1, 25], [5, 12], [6, 12]]     # Slot 1 running at 25 fps, slot 5 and 6 at 12 fps
#
#   # Get frame rate of one specific slot
#   >>ret=GetFrameRate(5)
#   >>print(str(ret))
#   >>12                              # Slot 5 is running at 12 fps
#  @endcode
#  @note If the @e slotNo parameter is omitted the frame rates for all slots reserved are returned.
@ApiFunction
def GetFrameRate(slotNo=0):
    """
    Return the current frame rate.

    Return:  List of Lists (if slotNo is 0) or an Integer.  When slotNo is 0, the List is
     [SlotNumber, FrameRate] and otherwise the return is the FrameRate as an integer.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.get_frame_rate(slotNo)

## @par Description
#  VideoStandard Enum. Defines the valid values that can be passed to the SetVideoStandard() function.
#  @param PAL : PAL video standard
#  @param NTSC : NTSC video standard
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetVideoStandard(VideoStandard.NTSC)
#  @endcode
class VideoStandard:
    """
    Defines a video Standard. Values are PAL or NTSC
    """
    PAL,NTSC = list(range(2))

## @par Description
#  This function sets the video standard for the streaming content.
#  @param[in] videoStandard @b VideoStandard: The new video standard.
#  @param[in] slotNo @b Integer: (optional) The slot number to set the video standard on.
#  @return @e Status @b Boolean: True if the call succeeded on all slots, else False.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetVideoStandard(VideoStandard.NTSC)  # Sets the video standard to NTSC on all reserved slots
#   >>True
#     or
#   >>SetVideoStandard(VideoStandard.NTSC,1)  # Sets the video standard to NTSC on slot 1
#   >>True
#  @endcode
#  @note If the @e slotNo parameter is omitted the default is to set the frame rate for all slots reserved.
@ApiFunction
def SetVideoStandard(videoStandard,slotNo=0):
    """
    Set the video standard for a slot.  This is not normally needed as the StormTest server auto
    detects the standard.

    Return: Bool.  Status - if slotNo is 0 then True is returned if all slots succeeded.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    if videoStandard == VideoStandard.PAL:
        return stormtest_client.stc.set_video_standard("PAL",slotNo)
    elif videoStandard == VideoStandard.NTSC:
        return stormtest_client.stc.set_video_standard("NTSC",slotNo)
    elif videoStandard == "PAL-M":
        return stormtest_client.stc.set_video_standard("PAL-M", slotNo)
    elif videoStandard == "Auto":
        return stormtest_client.stc.set_video_standard("Auto", slotNo)
    else:
        return False

## @par Description
#  This function returns the video settings to the default values. These include the frame rate, the resolution and the bit rate.
#  @param[in] slotNo @b Integer: (optional) The slot number to return to original values.
#  @return @e Error indication. If the client fails to communicate with the server (either ConnectToServer has not been called or server has died), then
#  None is returned. If the slot number is invalid or not reserved then 0 is returned. On success, the result is a list of 2 elements, the first element
#  is 1 (always) and the second element is the list of slots for which the parameters were reset (this has 1 element if a single slot is reserved)
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>ret = ResetDefaultParameters()
#   >>print(str(ret))
#   >>[1,[6]]
#  @endcode
#  @note If the @e slotNo parameter is omitted, the parameters of all slots reserved are set to the default values.
@ApiFunction
def ResetDefaultParameters(slotNo=0):
    """
    Reset the video parameters (Resolution, Max Bit Rate and Frame Rate) to the default values
    defined in the database and configured via StormTest Admin Console.

    Return: List. First element is always 1 and second element is list of slots that the call
      succeeded on.  A failure is indicated by a return of None.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.reset_default_parameters(slotNo)

##
#  VideoSignalState Enum. Defines the status of a video signal. This is used when monitoring the video from a DUT to see if the video signal disappears or reappears.
#  @param VidSigLoss : video signal lost
#  @param VidSigGain : video signal regained
class VideoSignalState:
    """
    Class to indicate video state. Values are VID_SIG_LOSS or VID_SIG_GAIN
    """
    VidSigLoss = stormtest_client.SlotState.VID_SIG_LOSS
    VidSigGain = stormtest_client.SlotState.VID_SIG_GAIN

## @par Description
#  This function allows the user to register to be notified if video loss occurs on a slot. The video state is checked every 5 seconds and a callback generated upon a state change.
#  @param[in] callbackFunction @b Function: The callback function that should be called in case video loss occurs.
#  @return @b Bool: true if the callbackFunction has successfully been registered. false if a server does not support this feature.
#  @note   The callback function is defined as follows:
#  @subsubsection _cb1 cb1:
#  @b callbackFunction(slotNo, state)
#  @param[in] slotNo @b Integer: The slot number the video state change occurred on.
#  @param[in] state @b VideoSignalState: The state of the video.
@ApiFunction
def RegisterVideoLossCallback(callbackFunction):
    """
    Set up a callback to be called when the video status changes from no video/video.

    Return: Bool. False if the StormTest server does not support this feature.

    callbackFunction: (Function) function to call when the video signal state changes.  The
      signature of the function is:
        callback(slotNo, state) where slotNo is the slot where the change has occurred and
        state is VideoSignalState enumeration.
    """
    return stormtest_client.stc.register_video_loss_callback(callbackFunction)


## @par Description
#  This class encapsulates a coordinate converter.  It is used to convert points or rectangles
#  between coordinate systems.  Although we define 2 coordinate systems: design space and world space,
#  a coordinate converter represents just one transformation and thus 2 instances are used to
#  fully support the design to world and world to design transformations.  The script can set
#  the transformation on any slot to be a coordinate converter and this converter is either the
#  design to world or world to design.
#  Design space is where the design of the test occurs (eg, using 704 x 576 as full screen for
#  standard definition or 1920 x 1080 as full screen for HD).  World space is the 'real world'
#  and represents the final captured image.  For example running on HD, the real world might
#  be 1280 x 720 as the DUT might not be 1920 x 1080.  The coordinate converter can then be
#  used to scale design rectangles to world rectangles.
#  Of course, there is nothing to stop a script writer from using this class to convert any
#  set of points/rectangles from any cartesian coordinate system to another.
#
#  @param Matrix Tuple: Read Only. A tuple of 6 numbers (float) representing the 3x3 matrix for the
#  transform.  The order is important and represents 3 rows of 2 columns.  The last column is
#  fixed as 0, 0, 1 to make a usable 3x3 matrix for later calculations and is not returned here.
#
#  @param Rotation Float: Read Only. The amount of rotation around the origin, in degrees, represented
#  by the transformation.  Since this is generic mathematics, the rotation is counter
#  clockwise for a normal right-handed coordinate system. However, the normal coordinate
#  system in computer graphics (and thus StormTest) is left handed and so the rotation is
#  clockwise as would look at images and coordinates in Stormtest.  The CoordConverter
#  assumes: rotation, scaling, translation is applied in that order.
#  @note Rotation should be avoided due to performance overhead. It is needed for the HT01 TV Tester
#  due to mechanical constraints but even then users should try to avoid any rotation of the system.
#
#  @param Scaling Tuple: Read Only.  The scaling of the converter in the x and y directions.
#  there are just 2 elements to the tuple.  The CoordConverter
#  assumes: rotation, scaling, translation is applied in that order.
#
#  @param Translation Tuple: Read Only.  This tuple is the translation by the transformation
#  in the x and y directions.  The CoordConverter
#  assumes: rotation, scaling, translation is applied in that order.
#
#  @param DesignSize Tuple or List: The intended design size of this converter. 2 values in the
#  tuple, both must be integers.  Any non integer will be converted to integers if possible.  This value
#  guides the ScreenDefinition in selecting a converter at run time when the design size of a test item
#  does not match the world size.  You can set a converter in a screen definition with the same design
#  and world size and if this matches the test item then it will be used.
#
#  @param WorldSize Tuple or List: The intended world size of this converter. 2 values in the
#  tuple, both must be integers.  Any non integer will be converted to integers if possible.  This value
#  guides the ScreenDefinition in selecting a converter at run time when the design size of a test item
#  does not match the world size.  You can set a converter in a screen definition with the same design
#  and world size and if this matches the test item then it will be used.
#
class CoordConverter(object):
    __handle = None

    ## @par Description
    # The constructor makes a CoordConverter.
    # @param[in] sourceConverter @b None, CoordConverter or List: the source to base this CoordConverter upon.
    # If None then the identity convverter is constructed.  The source object can be another CoordConverter
    # instance, a List/Tuple of 2 items, a List/Tuple of 4 items or a List/Tuple of 6 items.  If
    # 2 items are given then they are interpreted as the translation component (offset). If 4 items are
    # given then they are interpreted as the linear (scale and rotate) component. If 6 items are given
    # they are interpreted as the full 3 x 2 matrix (3 rows of 2 columns).  In all cases, the constructor
    # checks that the final matrix is invertible (all translations are, by definition, invertible).
    # @return @e CoordConverter : The completely constructed CoordConverter object. An exception is thrown
    # if the parameters are invalid
    #  @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>>cc1 = CoordConverter()
    # >>>print(str((cc1.Rotation, cc1.Scaling, cc1.Translation)))
    # >>>0.0 (1.0, 1.0) (0, 0)
    # >>>cc2 = CoordConverter([4,4])
    # >>>print(str((cc2.Rotation, cc2.Scaling, cc2.Translation)))
    # >>>0.0 (1.0, 1.0) (4, 4)
    # >>>cc3 = CoordConverter([2,0,0,2])
    # >>>print(str((cc3.Rotation, cc3.Scaling, cc3.Translation)))
    # >>>0.0 (2.0, 2.0) (0, 0)
    # >>>cc4 = CoordConverter([3,0,0,3,-1,3])
    # >>>print(str((cc4.Rotation, cc4.Scaling, cc4.Translation)))
    # >>>0.0 (3.0, 3.0) (-1, 3)
    # >>>cc5 = CoordConverter(cc4)
    # >>>print(str((cc5.Rotation, cc5.Scaling, cc5.Translation)))
    # >>>0.0 (3.0, 3.0) (-1, 3)
    # @endcode
    def __init__(self, sourceConverter = None):
        self.__handle = Imaging.CoordCreate(sourceConverter)

    def __getattr__(self, attr):
        return Imaging.GetCoordProperty(self.__handle, attr)

    def __setattr__(self, attr, value):
        if attr.startswith("_CoordConverter__"):
            object.__setattr__(self, attr, value)
        else:
            Imaging.SetCoordProperty(self.__handle, attr, value)


    ## @par Description
    # Clears the CoordConverter back to the Indentity transform (output = input for all inputs)
    # @param  None
    # @return @e None
    #  @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>>converter = CoordConverter()
    # >>>converter.Clear()
    # >>>print(str(converter.Matrix))
    # >>> (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)
    # @endcode
    def Clear(self):
        Imaging.CoordClear(self.__handle)

    ## @par Description
    # Set the CoordConverter to use the specified matrix.
    # @param[in] matrix @b Tuple: The matrix is a List/Tuple of 2, 4 or 6 items as described under the constructor.
    # @return @e None
    #  @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>>cc = CoordConverter()
    # >>>cc.SetMatrix([1,2,3,4,5,6])
    # >>>print(str(cc.Matrix))
    # >>>(1.0, 2.0, 3.0, 4.0, 5.0, 6.0)
    # >>>print(str((cc.Rotation, cc.Scaling, cc.Translation)))
    # >>>26.56505 (1.118034, 4.472136) (5, 6)
    # @endcode
    def SetMatrix(self, matrix):
        Imaging.CoordSetMatrix(self.__handle, matrix)

    ## @par Description
    # Set the CoordConverter transform from 2 rectangles. The converter will convert from the source to
    # destination.
    # @param[in] sourceRectangle @b Tuple: The rectangle as a Tuple/List of 4 points (left, top, width, height)
    # of the rectangle.
    # @param[in] destRectangle @b Tuple:  The rectangle as a Tuple/List of 4 points (left, top, width, height)
    # of the rectangle OR as a list of 4 Tuple/List items. Each Tuple/List being a point.  This allows
    # an arbitrary scale/rotate transform.
    # @param[in] designSize @b Tuple: (optional) The DesignSize to be set for the converter.  This is optional and if not
    # specified then the size of the sourceRectangle is assumed to be the DesignSize.
    # @param[in] worldSize @b Tuple: (optional) The WorldSize to be set for the converter.  This is optional and if not
    # specified then the size of the destRectangle is assumed to be the WorldSize.
    # @return @e None
    # @note Strictly speaking only 3 points are needed not 4 to describe the arbitrary rectangle as the
    # rectangle must be a parallelogram.  The implementation checks the 4th point to make sure a parallelogram
    # has been specified.
    # @note If the destRectangle is not 4 items of left, top, width, height then the CoordConverter WorldSize
    # cannot be set - the intended world size MUST be set manually.
    #
    # @exception StormTestExceptions is raised if the CoordConverter cannot find a transform to translate between
    # the specified rectangles.
    #  @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # # Create a coord transform for PAL -> HD where the PAL picture ends up overlapping the HD a bit (and thus would be truncated)
    # >>>cc = CoordConverter()
    # >>>cc.SetFromRectangles([0,0,704,576], [-10,-10, 1930, 1090])
    # >>>print(str((cc.Rotation, cc.Scaling, cc.Translation)))
    # >>>0.0 (2.741477, 1.892361) (-10, -10)
    # >>>print(str(cc.Matrix))
    # >>>(2.741477, 0.0, 0.0, 1.892361, -10.0, -10.0)
    # >>>print(str((cc.WorldSize, cc.DesignSize)))
    # >>>(1930, 1090) (704, 576)
    # @endcode
    def SetFromRectangles(self, sourceRectangle, destRectangle, designSize = None, worldSize = None):
        Imaging.CoordSetFromRectangles(self.__handle, sourceRectangle, destRectangle, designSize, worldSize)

    ## @par Description
    # Update the existing transformation by adding a rotation about the origin.  The direction is
    # mathematically counter clockwise but since the normal coordinate system of StormTest is left
    # handed, the rotation is clockwise as it appears in StormTest.
    # @param[in] degrees @b Float: The rotation in degrees.  Both positive and negative values are allowed.
    # @return @e None
    #  @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>>cc = CoordConverter()
    # >>>print(str(cc.Matrix))
    # >>>(1.0, 0.0, 0.0, 1.0, 0.0, 0.0)
    # >>>cc.Rotate(1.3)
    # >>>print(str(cc.Matrix))
    # >>>(0.9997426, 0.02268733, -0.02268733, 0.9997426, 0.0, 0.0)
    # >>>print(str((cc.Rotation, cc.Scaling, cc.Translation)))
    # >>>1.3 (0.9999999, 0.9999999) (0, 0)
    # @endcode
    def Rotate(self, degrees):
        Imaging.CoordRotate(self.__handle, degrees)

    ## @par Description
    # Update the existing transformation by adding a scaling factor.  The scale factors must be
    # positive and non negative.
    # @param[in] x @b Float: The scale factor in the horizontal direction to be applied.
    # @param[in] y @b Float: The scale factor in the vertical direction to be applied.
    # @return @e None
    #  @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>>cc = CoordConverter()
    # >>>print(str(cc.Matrix))
    # >>>(1.0, 0.0, 0.0, 1.0, 0.0, 0.0)
    # >>>cc.Scale(1.6, 0.8)
    # >>>print(str(cc.Matrix))
    # >>>(1.6, 0.0, 0.0, 0.8, 0.0, 0.0)
    # >>>print(str((cc.Rotation, cc.Scaling, cc.Translation)))
    # >>>0.0 (1.6, 0.8) (0, 0)
    # @endcode
    def Scale(self, x, y):
        Imaging.CoordScale(self.__handle, x, y)

    ## @par Description
    # Update the existing transformation by adding an ofset.  The offset may be negative or
    # positive or zero.
    # @param[in] x @b Float: The offset in the horizontal direction to be applied.
    # @param[in] y @b Float: The offset in the vertical direction to be applied.
    # @return @e None
    #  @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>>cc = CoordConverter()
    # >>>print(str(cc.Matrix))
    # >>>(1.0, 0.0, 0.0, 1.0, 0.0, 0.0)
    # >>>cc.Translate(6.9, -8.4)
    # >>>print(str(cc.Matrix))
    # >>>(1.0, 0.0, 0.0, 1.0, 6.9, -8.4)
    # >>>print(str((cc.Rotation, cc.Scaling, cc.Translation)))
    # >>>0.0 (1.0, 1.0) (7, -8)
    # @endcode
    def Translate(self, x, y):
        Imaging.CoordTranslate(self.__handle, x, y)

    ## @par Description
    # Creates a new CoordConverter that is the inverse transform of this CoordConverter
    # @param None
    # @return @e transform @b CoordConverter: The inverted transform
    #  @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>>cc = CoordConverter()
    # >>>cc.Rotate(1.3)
    # >>>print(str(cc.Matrix))
    # >>>(0.9997426, 0.02268733, -0.02268733, 0.9997426, 0.0, 0.0)
    # >>>inverse = cc.Invert()
    # >>>print(str(inverse.Matrix))
    # >>>(0.9997426, -0.02268733, 0.02268733, 0.9997426, 0.0, 0.0)
    # >>>print(str((inverse.Rotation, inverse.Scaling, inverse.Translation)))
    # >>>-1.3 (1.0, 1.0) (0, 0)
    # @endcode
    def Invert(self):
        inverse = Imaging.CoordInvert(self.__handle)
        pyInvert = CoordConverter()
        pyInvert.__handle = inverse
        return pyInvert

    ## @par Description
    # Converts an item using the transform.
    # @param[in] item @b List: The item to be converted. It may be a Tuple/List of 2 items and is interpreted
    # as a single point.  It may be a List of Tuples/Lists each of which is 2 items in which case it is
    # interpreted as a list of points.  It may be a Tuple/List of 4 items in which case it is interpreted
    # as a rectangle (Left, Top, Width, Height). It may be a List of Tuples/Lists each of which is 4 items
    # in which case it is interpreted as a list of rectangles, each rectangle being Left, Top, Width and Height.
    # @return @e transformedItem @b List: The transformed items. It is a copy of the input (the input is not changed)
    # of a similar format - all input Tuples are converted to Lists on output, however.
    #  @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # # Create a coord transform for PAL -> HD where the PAL picture ends up overlapping the HD a bit (and thus would be truncated)
    # >>>cc = CoordConverter()
    # >>>cc.SetFromRectangles([0,0,704,576], [-10,-10, 1930, 1090])
    # >>>print(str(cc.Convert([8,100])))
    # >>>[12, 179]
    # >>>print(str(cc.Convert([[8,100],[100,100],[8,200],[100,200]])))
    # >>>[[12, 179], [264, 179], [12, 368], [264, 368]]
    # >>>print(str(cc.Convert([8,100,100,100])))
    # >>>[12, 179, 274, 189]
    # >>>print(str(cc.Convert([[8,100,100,100],[600,500,250,120]])))
    # >>>[[12, 179, 274, 189], [1635, 936, 685, 227]]
    # @endcode
    def Convert(self, item):
        return Imaging.CoordConvert(self.__handle, item)

    # Internal function. Deliberately not documented for end users.
    def _Serialize(self):
        return Imaging.CoordSerialize(self.__handle)

    # Internal function. Deliberately not documented for end users.
    def _DeSerialize(self, serialisedString):
        Imaging.CoordDeSerialize(self.__handle, serialisedString)

## @par Description
# Sets the transformation to use between design and world coordinates for the
# specified slot.  
# This function overrides any other transform, including
# SetVideoOffset().  After this call, most functions which were affect by SetVideoOffset now use
# the specified transform.  The value is not saved to the database. To set a transform in the
# database, please see GetDutInstanceInSlot() and UpdateDutModel().
# @param[in] transform @b CoordConverter or List: transform to use. It may be a CoordConverter 
# object OR a List/Tuple that can be passed directly to the constructor of a CoordConverter.  
# Only 1 transform is stored internally as world to design is the inverse of design to world.
# @param[in] slotNo @b Integer: The slot number where the transform is set. If slotNo is zero
# then the transform is applied to all reserved slots.
# @return @e None
# @note The CaptureImageEx is not altered by the transform - this allows you to capture the
# raw image for you own processing even when a severe transform is set.  The older deprecated
# (and no longer documented) functions are also not affected by the transform.
#  @subsubsection _eg1 eg1:
# @b Example:
# @code
# >>>cc = CoordConverter()
# >>>cc.SetFromRectangles([0,0,704,576], [-10,-10, 1930, 1090])
# >>>SetDesignToWorldTransform(cc)
# @endcode
@ApiFunction
def SetDesignToWorldTransform(transform, slotNo=0):
    if isinstance(transform, CoordConverter):
        return stormtest_client.stc.SetDesignToWorldTransform(transform, slotNo)
    else:
        # not a coord converter so make coord converter out of whatever we were given
        cc = CoordConverter(transform)
        return stormtest_client.stc.SetDesignToWorldTransform(cc, slotNo)


## @par Description
# Gets current design to world transform for the specified slot. Such a transform always
# exists - if user has done nothing special then this is the Identity transform which does
# nothing.
# @param[in] slotNo @b Integer: the slot number to retrieve the transform for. If 0 then the
# transforms for all slots are returned
# @return @e CoordConverter: The transform.  If slotNo is 0 then a List of [slot, transform]
# is returned, one for each reserved slots.
# @subsubsection _eg1 eg1:
# @b Example:
# @code
# >>>print(str(GetDesignToWorldTransform(5)))
# >>><stormtest.ClientAPI.CoordConverter object>
# >>>cc = CoordConverter()
# >>>cc.SetFromRectangles([0,0,704,576], [-10,-10, 1930, 1090])
# >>>SetDesignToWorldTransform(cc)
# >>>print(str(GetDesignToWorldTransform()))
# >>>[[5, <stormtest.ClientAPI.CoordConverter object>]]
# @endcode
@ApiFunction
def GetDesignToWorldTransform(slotNo=0):
    return stormtest_client.stc.GetDesignToWorldTransform(slotNo)

## @par Description
# Sets the transformation to use between world and design coordinates for the
# specified slot.  
# This function overrides any other transform, including
# SetVideoOffset().  After this call, most functions which were affect by SetVideoOffset now use
# the specified transform.  The value is not saved to the database. To set a transform in the
# database, please see GetDutInstanceInSlot() and UpdateDutModel().
# @param[in] transform @b CoordConverter or List: transform to use. It may be a CoordConverter 
# object OR a List/Tuple that can be passed directly to the constructor of a CoordConverter.  
# Only 1 transform is stored internally as design to world is the inverse of world to design.
# @param[in] slotNo @b Integer: The slot number where the transform is set. If slotNo is zero
# then the transform is applied to all reserved slots.
# @return @e None
# @note The CaptureImageEx is not altered by the transform - this allows you to capture the
# raw image for you own processing even when a severe transform is set.  The older deprecated
# (and no longer documented) functions are also not affected by the transform.
#  @subsubsection _eg1 eg1:
# @b Example:
# @code
# >>>cc = CoordConverter()
# >>>cc.SetFromRectangles([0,0,704,576], [-10,-10, 1930, 1090])
# >>>SetWorldToDesignTransform(cc)
# @endcode
@ApiFunction
def SetWorldToDesignTransform(transform, slotNo=0):
    if isinstance(transform, CoordConverter):
        return stormtest_client.stc.SetWorldToDesignTransform(transform, slotNo)
    else:
        # not a coord converter so make coord converter out of whatever we were given
        cc = CoordConverter(transform)
        return stormtest_client.stc.SetWorldToDesignTransform(cc, slotNo)


## @par Description
# Gets current world to design transform for the specified slot. Such a transform always
# exists - if user has done nothing special then this is the Identity transform which does
# nothing.
# @param[in] slotNo @b Integer: the slot number to retrieve the transform for. If 0 then the
# transforms for all slots are returned
# @return @e CoordConverter: The transform.  If slotNo is 0 then a List of [slot, transform]
# is returned, one for each reserved slots.
#  @subsubsection _eg1 eg1:
# @b Example:
# @code
# >>>print(str(GetWorldToDesignTransform(5)))
# >>><stormtest.ClientAPI.CoordConverter object>
# >>>cc = CoordConverter()
# >>>cc.SetFromRectangles([0,0,704,576], [-10,-10, 1930, 1090])
# >>>SetDesignToWorldTransform(cc)
# >>>print(str(GetWorldToDesignTransform()))
# >>>[[5, <stormtest.ClientAPI.CoordConverter object>]]
# @endcode
@ApiFunction
def GetWorldToDesignTransform(slotNo=0):
    return stormtest_client.stc.GetWorldToDesignTransform(slotNo)


## @}

## @defgroup Group6 Directory Path API
# The functions in this section are used to configure the directories used by StormTest.\n\n
# The user is recommended to call these function before calling ReserveSlot()
## @{

## @par Description
#  This function sets the project root directory. The directories specified in the SetDirectories() function are relative
#  to the directory passed into this function. If a test does not call this function, the project directory defaults
#  to '.' (i.e. the current working directory). If this is called after ConnectToServer() but before ReserveSlot() there will
#  be some debug output in directory relative to the current working directory and then the rest in the directory specified
#  by SetProjectDir().  This is because ConnectToServer() can generate debug outut.  It is recommended therefore to call this
#  function prior to ConnectToServer(). This is ignored when the test is run under the Client Daemon.
#  @param[in] projRoot @b String: The path to the project root.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetProjectDir(os.path.join("C:\\","my_project_dir"))
#  @endcode
@ApiFunction
def SetProjectDir(projRoot):
    """
    Set the root directory for the script.  By default the current script directory.  All paths
    are relative to this root.  Should be called prior to ConnectToServer()

    Return: None

    projRoot: (String) The path to set - should be an absolute path.
    """
    return stormtest_client.stc.set_project_dir(projRoot)

## @par Description
#  This function sets the location of the logfiles and the reference files relative to the root defined in SetProjectDir(). If SetProjectDir() is not called, then they will be relative to the current working directory (i.e. where the test is run from).
#  If this function is not called by a test, then the reference images must be in the same directory as the test.\n\n
#  Note that the logDir @b must be set before ReserveSlot() is called (as this is when logging commences). Any attempt to change the logDir after ReserveSlot() has been called will be ignored.
#  The refImgDir can be altered at any time and the new value will apply for all subsequent image comparisons.
#  @param[in] logDir @b String: The path to storage location of the log files.  This is ignored when the test is run under the Client Daemon and the log
#  folder is determined by the Client Daemon.
#  @param[in] refImgDir @b String: The path to storage location of the reference images.
#  @param[in] autoCreateSubDir @b String: (optional) DEPRECATED. Should be set to True. A unique directory is always created for log files in releases later than 2.0.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetDirectories( os.path.join("logs","test1"), os.path.join("reference","images") )
#  @endcode
@ApiFunction
def SetDirectories(logDir = None, refImgDir = None, autoCreateSubDir = True):
    """
    Set the location of the log files and reference images.  This path is relative to the
    directory set in SetProjectDir(). May be called at any time BUT logDir will not be
    changed after calling ReserveSlot().

    Return: None

    logDir: (String, optional) Set the path for log files.

    refImgDir: (String, optional) Set the path for reference images

    autoCreateSubDir: (Bool, optional). DEPRECATED.
    """
    return stormtest_client.stc.set_directories(logDir, refImgDir, autoCreateSubDir)

## @par Description
#  This function gets the project root directory. This may have been set previously by a call to SetProjectDir(). This is an optional function.
#  @param None
#  @return @e projPath @b String: The path to the project root.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>ret=GetProjectDir()
#   >>print(str(ret))
#   >>C:\my_project_dir
#  @endcode
@ApiFunction
def GetProjectDir():
    """
    Gets the project root directory.

    Return: String. Path of the root directory.
    """
    return stormtest_client.stc.get_project_dir()

## @par Description
#  This function gets the location of the logfiles and the reference files relative to the root defined in SetProjectDir(). If SetProjectDir() was not called, then they will be relative to the current working directory (i.e. where the test is run from).
#  @param None
#  @return @e dirPath @b List: A list of directory paths. The first path is the output directory where all the log files are stored. The second is the input directory, where the reference images are loaded from.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>dirPaths=GetDirectories()
#   >>print(str(dirPath))
#   >>['logs\\test1', 'reference\\images']
#  @endcode
@ApiFunction
def GetDirectories():
    """
    Get the location of the log files and reference image directories relative to the project
    root directory.

    Return: List.  The elements in the list are: [LogDirectory, ImageDirectory]
    """
    return stormtest_client.stc.get_directories()

## @par Description
#  This function gets the exact full path of the log file directory.  StormTest creates a unique directory for each script run
#  based on date and time.  The root directory of these log file directories can be retrieved by GetDirectories(), however, the
#  exact directory being used cannot be got from that.  This function will provide the exact path.
#  @param None
#  @return @e dirPath @b String: A string with full absolute path of log file directory
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>dirPath=GetLogFileDirectory()
#   >>print(str(dirPath))
#   >>c:\users\some_user\tests\detect_guide_20110621_101534
#  @endcode
#  @note If GetLogFileDirectory() is called before SetDirectories() or ConnectToServer() then the log file directory will not exist
#  but the path returned is correct.  If SetDebugLevel() is called to disable logging, GetLogFileDirectory() will still return a
#  valid path but the path will not exist.
@ApiFunction
def GetLogFileDirectory():
    """
    Get the exact full path of the log file directory. The exact name depends on when the test
    is run as each test creates a unique directory under the general logDirectory path.

    Return: String.  Full path to the folder where the script's log files are stored.
    """
    return stormtest_client.stc.get_log_file_directory()

## @}

## @defgroup Group19 Named Resources API
#  The functions in this section provide access to named resources.  The named resources are an extension
#  to the 3.0 use of resources within a StormTest Navigator.  They allow test scripts to be written in a more
#  robust manner making maintenance and updates easier.
#
#  A resource is a region, image, color, string or screen definition. It is identified by name.  Resources are organised into
#  namespaces - these are analogous to folders on a disk filing system (but since the resource is stored in
#  the database not in a file, the term namespace is more accurate).  Both name and namespace are case sensitive
#  but this may be overriden.
#
#  In release 3.2 model specific resources are supported.  All of the Write/Delete/Read calls were defined with a
#  dutModelId parameter which was marked as 'reserved' in earlier releases.  It is no longer reserved.  The full
#  explanation is supplied only on the Region API calls - all others are analogous and you should read the Region
#  description to understand how the other resources work.
#
#  We define 2 types of resource: a generic and a model specific.  For all resources, it is impossible for a model
#  specific variant to exist without also a generic existing - if you just try to create a model specific then
#  a generic will also be created with the same value.  Likewise, if you delete the generic then all model specific
#  variants are also deleted.  To fully use the power of model specific resources requires that your model names
#  (as defined in Admin Console) are unique across the facility.  If this is not the case then the behavior is undefined -
#  when maintaining resources where a model name is specified that is not unique, you will get an exception.  However,
#  there is nothing to stop you creating a new model with the same name as another and getting confused during lookup
#  of resources.  Internally, all models are stored as a unique database id not by name and that is unique.
#
#  All resources created using versions of StormTest prior to 3.2 are generic and code written for earlier versions
#  will work but operate on the generic version (and in the case of delete, will delete all versions of the resource).
#
#  The example under WriteNamedRegion shows how model specific resources for multiple models are managed.  It is a long
#  example showing all the combinations of use cases.
## @{

## @par Description
#  This function sets the base path for named resources for a slot.  Each slot can have a path for its resources.
#  By default, it is empty which means that resources need to be referenced by the full path.
#  This function sets the base path for a slot and then later code can use a relative name.
#  Setting slotNo = 'all' sets the path for all slots (both reserved and yet to be reserved).  It overrides
#  any prior path with an explicit slot.  A slot does not need to be reserved to use this function.
#  The slot number is always a physical slot.  The path may be a string, or a list/tuple of strings.
#  If a list/tuple of strings then the list/tuple is searched for relative lookups in order until a match is found.
#
#  @param[in] path @b object: A string, tuple or list specifying the path to the resources
#  @param[in] slotNo @b integer: (optional): The slot number to which the path should refer.  The string 'all' may be used to mean
#  all slots.
#  @return @e success @b Bool: True if the path was set successfully
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetResourcePath("projects/my team/new box")   # all slots will use resources in 'projects/my team/new box' namespace.
#  @endcode
@ApiFunction
def SetResourcePath(path, slotNo='all'):
    """
    This function sets the base path for named resources for a slot.  Each slot can have a path for its resources.
    By default, it is empty which means that resources need to be referenced by the full path.
    This function sets the base path for a slot and then later code can use a relative name.
    Setting slotNo = “all” sets the path for all slots (both reserved and yet to be reserved).  It overrides
    any prior path with an explicit slot.  A slot does not need to be reserved to use this function.
    The slot number is always a physical slot.  The path may be a string, or a list/tuple of strings.
    If a list/tuple of strings then the list/tuple is searched for relative lookups in order until a match is found.

    param path object: A string, tuple or list specifying the path to the resources
    param slotNo integer: The slot number to which the path should refer.  The string 'all' may be used to mean
    all slots.
    return True if the path was set successfully
    """
    return stormtest_client.stc.set_resource_path(path, slotNo)

## @par Description
#  Gets the base path for named resources for a slot.  This may be called before reserving a slot.
#  slotNo has same meaning as for SetResourcePath()
#
#  @param[in] slotNo @b integer: (optional) The slot number to which the path should refer.  The string 'all' may be used to mean
#  all slots.
#  @return @e path @b object: The path. A string or tuple matching whatever was passed in for the SetResourcePath.
#
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetResourcePath("projects/my team/new box")
#   >>SetResourcePath(["project/his team/old box", "projects/nowhere/old box"], 5)
#   >>print(GetResourcePath())
#   >>projects/my team/new box
#   >>print(GetResourcePath(5))
#   >>['project/his team/old box', 'projects/nowhere/old box']
#   >>print(GetResourcePath(7))
#   >>None                      # no specific path for slot 7.
#  @endcode
@ApiFunction
def GetResourcePath(slotNo='all'):
    """
    Gets the base path for named resources for a slot.  This may be called before reserving a slot.
    slotNo has same meaning as for SetResourcePath()

    param slotNo integer (optional) The slot number to which the path should refer.  The string 'all' may be used to mean
    all slots.
    """
    return stormtest_client.stc.get_resource_path(slotNo)

## @par Description
#  Sets the case matching for named resource lookup.  By default, the API is case sensitive.
#  Use this function with caseSensitive = False to make the API case insensitive.  The setting
#  applies to all later calls which look up the names.  The whole lookup, including all paths,
#  is performed either in case sensitive or case insensitive manner – not just the name portion.
#
#  @param[in] caseSensitive @b bool: (optional) Set the case sensitive.  If omitted, the functions
#  are case sensitive.
#
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>SetNamedResourceMatchCase(False)
#  @endcode
@ApiFunction
def SetNamedResourceMatchCase(caseSensitive = True):
    """
    Sets the case matching for named resource lookup.  By default, the API is case sensitive.
    Use this function with caseSensitive = False to make the API case insensitive.  The setting
    applies to all later calls which look up the names.  The whole lookup, including all paths,
    is performed either in case sensitive or case insensitive manner – not just the name portion.

    param caseSensitive bool: (optional) Set the case sensitive.  If omitted, the functions
    are case sensitive.

    return None
    """
    return stormtest_client.stc.set_named_resource_match_case(caseSensitive)

## @par Description
#  This function returns the current state of case sensitive match.  Default is true
#  if SetNamedResourceMatchCase() has not been called.
#
#  @param None
#  @return @e caseSensitive @b bool: true if current mode is case sensitive
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>print(GetNamedResourceMatchCase())
#  >>>True
#  @endcode
@ApiFunction
def GetNamedResourceMatchCase():
    """
    This function returns the current state of case sensitive match.  Default is true
    if SetNamedResourceMatchCase() has not been called.

    param None
    return bool: true if current mode is case sensitive
    """
    return stormtest_client.stc.get_named_resource_match_case()

## @par Description
#  This function gets a named region object corresponding to the name item.  The name may be an
#  absolute name (starting with /) or relative name (not starting with /).  An absolute object
#  ignores the path(s) set by SetResourcePath.  A relative object will use the path set by
#  SetResourcePath plus the slot number to resolve the final Region.
#  This returns a lightweight object that does not contain the real region at this point.  A
#  method needs to be called to resolve the final region but this object can be passed to many
#  functions needing a rectangle and the function will use the slot number to find the actual rectangle.
#
#  @param[in] name @b string: The name of a region
#  @return @e object @b NamedRegion - the @ref _regionObject object.
#
#  @note The object tracks changes in the SetResourcePath but also that it caches each resolution of the Region per slot.
#  @note There is no requirement for the named region to actually exist at the time this function is called, however,
#  it must exist at the time of the final use of the named region.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>print(FindNamedRegion("myregion"))
#  >>><stormtest.stormtest_client.NamedRegion object>
#  @endcode
@ApiFunction
def FindNamedRegion(name):
    """
    This function gets a named region object corresponding to the name item.  The name may be an
    absolute name (starting with /) or relative name (not starting with /).  An absolute object
    ignores the path(s) set by SetResourcePath.  A relative object will use the path set by
    SetResourcePath plus the slot number to resolve the final Region.

    param name string: The name of a region

    return object RegionObject - the named region object.
    """
    return stormtest_client.stc.find_named_region(name)

## @par Description
#  This function gets a named color object corresponding to the name item.  The name may be an
#  absolute name (starting with /) or relative name (not starting with /).  An absolute object
#  ignores the path(s) set by SetResourcePath.  A relative object will use the path set by
#  SetResourcePath plus the slot number to resolve the final color.
#  This returns a lightweight object that does not contain the real color at this point.  A
#  method needs to be called to resolve the final color but this object can be passed to many
#  functions needing a color and the function will use the slot number to find the actual color.
#
#  @param[in] name @b string: The name of a color
#  @return @e object @b NamedColor - the @ref _colorObject object.
#
#  @note The object tracks changes in the SetResourcePath but also that it caches each resolution of the color per slot.
#  @note There is no requirement for the named color to actually exist at the time this function is called, however,
#  it must exist at the time of the final use of the named color.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>print(FindNamedColor("my projects/new project/mycolor"))
#  >>><stormtest.stormtest_client.NamedColor object>
#  @endcode
@ApiFunction
def FindNamedColor(name):
    """
    This function gets a named color object corresponding to the name item.  The name may be an
    absolute name (starting with /) or relative name (not starting with /).  An absolute object
    ignores the path(s) set by SetResourcePath.  A relative object will use the path set by
    SetResourcePath plus the slot number to resolve the final color.

    param name string: The name of a color

    return object ColorObject - the named color object.
    """
    return stormtest_client.stc.find_named_color(name)

## @par Description
#  This function gets a named string object corresponding to the name item.  The name may be an
#  absolute name (starting with /) or relative name (not starting with /).  An absolute object
#  ignores the path(s) set by SetResourcePath.  A relative object will use the path set by
#  SetResourcePath plus the slot number to resolve the final string.
#  This returns a lightweight object that does not contain the real string at this point.  A
#  method needs to be called to resolve the final string but this object can be passed to many
#  functions needing a string and the function will use the slot number to find the actual string.
#
#  @param[in] name @b string: The name of a string
#  @return @e object @b NamedString - the @ref _stringObject object.
#
#  @note The object tracks changes in the SetResourcePath but also that it caches each resolution of the string per slot.
#  @note There is no requirement for the named string to actually exist at the time this function is called, however,
#  it must exist at the time of the final use of the named string.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>print(FindNamedString("/my projects/new project/some string"))
#  >>><stormtest.stormtest_client.NamedString object>
#  @endcode
@ApiFunction
def FindNamedString(name):
    """
    This function gets a named string object corresponding to the name item.  The name may be an
    absolute name (starting with /) or relative name (not starting with /).  An absolute object
    ignores the path(s) set by SetResourcePath.  A relative object will use the path set by
    SetResourcePath plus the slot number to resolve the final string.

    param name string: The name of a string

    return object StringObject - the named string object.
    """
    return stormtest_client.stc.find_named_string(name)

## @par Description
#  This function gets a named image object corresponding to the name item.  The name may be an
#  absolute name (starting with /) or relative name (not starting with /).  An absolute object
#  ignores the path(s) set by SetResourcePath.  A relative object will use the path set by
#  SetResourcePath plus the slot number to resolve the final image.
#  This returns a lightweight object that does not contain the real image at this point.  A
#  method needs to be called to resolve the final image but this object can be passed to many
#  functions needing a image and the function will use the slot number to find the actual image.
#
#  @param[in] name @b string: The name of a image
#  @return @e object @b NamedImage - the @ref _imageObject object.
#
#  @note The object tracks changes in the SetResourcePath but also that it caches each resolution of the image per slot.
#  @note There is no requirement for the named image to actually exist at the time this function is called, however,
#  it must exist at the time of the final use of the named image.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>print(FindNamedImage("my projects/new project/my good image"))
#  >>><stormtest.stormtest_client.NamedImage object>
#  @endcode
@ApiFunction
def FindNamedImage(name):
    """
    This function gets a named image object corresponding to the name item.  The name may be an
    absolute name (starting with /) or relative name (not starting with /).  An absolute object
    ignores the path(s) set by SetResourcePath.  A relative object will use the path set by
    SetResourcePath plus the slot number to resolve the final image.

    param name string: The name of a image

    return object NamedImageObject - the named image object.
    """
    return stormtest_client.stc.find_named_image(name)

## @par Description
#  This function gets a named screen definition object corresponding to the name item.  The name may be an
#  absolute name (starting with /) or relative name (not starting with /).  An absolute object
#  ignores the path(s) set by SetResourcePath.  A relative object will use the path set by
#  SetResourcePath plus the slot number to resolve the final image.
#  This returns a lightweight object that does not contain the real screen definition at this point.  A
#  method needs to be called to resolve the final screen definition but this object can be passed to many
#  functions needing a screen definition and the function will use the slot number to find the actual screen definition.
#
#  @param[in] name @b string: The name of a screen definition
#  @return @e object @b NamedScreenDefinition - the _namedSdo object.
#
#  @note The object tracks changes in the SetResourcePath but also that it caches each resolution of the screen definition per slot.
#  @note There is no requirement for the named screen definition to actually exist at the time this function is called, however,
#  it must exist at the time of the final use of the named screen definition.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>print(FindNamedScreenDefinition("my projects/new project/my first sdo"))
#  >>><stormtest.stormtest_client.NamedScreenDefinition object>
#  @endcode
@ApiFunction
def FindNamedScreenDefinition(name):
    """
    This function gets a named screen definition object corresponding to the name item.  
    """
    return stormtest_client.stc.find_named_screen_definition(name)

## @par Description
#  Writes the regionData to the database as regionPath.
#  regionPath is always case sensitive and SetNamedResourceMatchCase is ignored.
#
#  @param[in] regionPath @b string: the full absolute path to the region (may begin with a / but not necessary),
#  path elements separated by /.  Final element is the region name.
#  @param[in] regionData @b tuple: (left, top, width, height) of the region.
#  @param[in] comment @b string: (optional) Free form text of a user defined comment.
#  @param[in] dutModelId @b Integer, String or List : The model for which the data is to be written.  The integer
#  value of 0 means the generic model only will be created/updated.  It can also be an explicit model number, a string
#  representing a single model or a list of strings representing multiple models.
#  @return @e None: An exception is thrown on an error (for example bad parameters, no communication).
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  # this example shows all the possible use cases of the model specific resources.
#  # to simplify the code, we define a variable for the path and ignore the comment field, setting it to None
#  # each time (you can set it to any string you like in practice)
#  >>>regionName = "/my projects/title"
#  # create a generic region:
#  >>>WriteNamedRegion(regionName,[0,0,100,20])
#  # Now create a specific region for a Model with id 999 (looked up from ListDutModels).
#  >>>WriteNamedRegion(regionName,[10,10,100,20], None, 999)
#  # Now create another region for models 'A' and 'B' (neither are id 999)
#  >>>WriteNamedRegion(regionName,[20,20,120,30], None, ['A', 'B'])
#  # Now create another region but for models 'B' and 'C'. After this call we will have
#  # a generic, one for model 999, one for model 'A' and one for models 'B' and 'C' - 4 items in database
#  >>>WriteNamedRegion(regionName,[30,30,100,30], None, ['B', 'C'])
#  # update just model 'C'
#  >>>WriteNamedRegion(regionName,[40,40,100,30], None, 'C')
#  >>>print(str(ReadNamedRegion(regionName)))
#  >>>[[0, (0, 0, 100, 20)]]
#  >>>print(str(ReadNamedRegion(regionName, 999)))
#  >>>[[u'SomeModel', (10, 10, 100, 20)]]
#  >>>print(str(ReadNamedRegion(regionName, 'A')))
#  >>>[[u'A', (20, 20, 120, 30)]]
#  >>>print(str(ReadNamedRegion(regionName, 'B')))
#  >>>[[u'B', (30, 30, 100, 30)]]
#  >>>print(str(ReadNamedRegion(regionName, 'C')))
#  >>>[[u'C', (40, 40, 100, 30)]]
#  >>>WriteNamedRegion(regionName,[9,9,800,10],None, ['A' ,'B', 'C'])
#  >>>print(str(ReadNamedRegion(regionName, 'A')))
#  >>>[[u'A', (9, 9, 800, 10)]]
#  >>>print(str(ReadNamedRegion(regionName, 'B')))
#  >>>[[u'B', (9, 9, 800, 10)]]
#  >>>print(str(ReadNamedRegion(regionName, 'C')))
#  >>>[[u'C', (9, 9, 800, 10)]]
#  >>>print(str(ReadNamedRegion(regionName, 'D')))
#  >>>Traceback (most recent call last):
#  ...
#  StormTestExceptions: ReadNamedRegion: No model specific region exists for model D
#  @endcode
@ApiFunction
def WriteNamedRegion(regionPath, regionData, comment=None, dutModelId=0):
    """
    Writes the regionData to the database as regionPath.
    regionPath is always case sensitive and SetNamedResourceMatchCase is ignored.

    param regionPath string: the full absolute path to the region (may begin with a / but not necessary),
    path elements separated by /.  Final element is the region name.

    param regionData tuple: (left, top, width, height) of the region.

    param comment string: (optional) Free form text of a user defined comment.

    param dutModelId integer: reserved for future use and must be 0.

    return  None: An exception is thrown on an error (for example bad parameters, no communication).
    """
    return stormtest_client.stc.write_named_region(regionPath, regionData, comment, dutModelId)

## @par Description
#  Deletes the named region regionPath.
#
#  @param[in] regionPath @b string: the full absolute path to the region (may begin with a / but not necessary),
#  path elements separated by /.  Final element is the region name.
#  @param[in] dutModelId @b integer, String or List: The model for which the region is to be deleted.  The integer
#  value of 0 means the generic model and all variants will be deleted.  It can also be an explicit model number, a string
#  representing a single model or a list of strings representing multiple models.  It is not an error to delete a region
#  with a model where there is no model specific region for that region - just a waste of CPU cycles and network bandwidth.
#  @return @e None: An exception is thrown on an error (for example bad parameters, no communication).
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  # This example expands the WriteNamedRegion to perform some deletion
#  >>>regionName = "/my projects/title"
#  >>>WriteNamedRegion(regionName,[0,0,100,20])
#  >>>WriteNamedRegion(regionName,[20,20,120,30], None, ['A', 'B'])
#  >>>WriteNamedRegion(regionName,[30,30,100,30], None, ['B', 'C'])
#  >>>print(str(ReadNamedRegion(regionName)))
#  >>>[[0, (0, 0, 100, 20)]]
#  >>>print(str(ReadNamedRegion(regionName, 'A')))
#  >>>[[u'A', (20, 20, 120, 30)]]
#  >>>print(str(ReadNamedRegion(regionName, 'B')))
#  >>>[[u'B', (30, 30, 100, 30)]]
#  >>>print(str(ReadNamedRegion(regionName, 'C')))
#  >>>[[u'C', (30, 30, 100, 30)]]
#  >>>DeleteNamedRegion(regionName, 'C')
#  >>>print(str(ReadNamedRegion(regionName, 'B')))
#  >>>[[u'B', (30, 30, 100, 30)]]
#  >>>print(str(ReadNamedRegion(regionName, 'C')))
#  >>>StormTestExceptions: ReadNamedRegion: No model specific region exists for model C
#  >>>DeleteNamedRegion(regionName)
#  >>>print(str(ReadNamedRegion(regionName, 'B')))
#  >>>StormTestExceptions: ReadNamedRegion: ReadNamedRegion failed: The named entity does not exist
#  @endcode
@ApiFunction
def DeleteNamedRegion(regionPath, dutModelId = 0):
    """
    Deletes the named region regionPath.

    param regionPath string: the full absolute path to the region (may begin with a / but not necessary),
    path elements separated by /.  Final element is the region name.

    param dutModelId integer: reserved for future use and must be 0.

    return None: An exception is thrown on an error (for example bad parameters, no communication).
    """
    return stormtest_client.stc.delete_named_region(regionPath, dutModelId)

## @par Description
#
#  Reads the named region regionPath
#
#  @param[in] regionPath @b string: the full absolute path to the region (may begin with a / but not necessary),
#  path elements separated by /.  Final element is the region name.
#  @param[in] dutModelId @b integer or String: The model to read. If 0 then the generic verion is read. It can also be the
#  model name or an id retrieved from ListDutModels()
#  @return @e List: Each list item of the list has 2 elements, the first is the dutModelId
#  and the second is a tuple of the region (left, top, width, height).  The dutModelId is 0 for the generic region and the 
#  model name for others.  If a dutModelId is supplied as an integer, the return is the model name, not the
#  numeric id.  It was intended at one stage to return all variants
#  in one function but that was changed due to potential network overhead but the format of a list of lists has been retained.
#  An exception is thrown on an error (for example bad parameters, no communication).
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>print(str(ReadNamedRegion(regionName)))
#  >>>[[0, (0, 0, 100, 20)]]
#  >>>print(str(ReadNamedRegion(regionName, 'A')))
#  >>>[[u'A', (20, 20, 120, 30)]]
#  @endcode
@ApiFunction
def ReadNamedRegion(regionPath, dutModelId=0):
    """
    Reads the named region regionPath

    param regionPath string: the full absolute path to the region (may begin with a / but not necessary),
    path elements separated by /.  Final element is the region name.

    param dutModelId integer: reserved for future use and must be 0.

    return e list of lists: each list item of the list has 2 elements, the first is the dutModelId (will always be 0)
    and a tuple of the region (left, top, width, height). In Release 3.1 there will always be just one list item in the
    overall returned list.
    An exception is thrown on an error (for example bad parameters, no communication).
    """
    return stormtest_client.stc.read_named_region(regionPath, dutModelId)

## @par Description
#  Renames the NamedRegion regionPath to newName.  The NamedRegion must exist and the newName must not exist.
#
#  @param[in] regionPath @b string: the full absolute path to the region (may begin with a / but not necessary),
#  path elements separated by /.  Final element is the region name.
#
#  @param[in] newName @b string: just the name portion and cannot include path components.
#
#  @return @e None
#  @exception StormTestExceptions is thrown on an error (for example bad parameters, no communication).
#  @note This cannot be used to move regions, just to change the name.  All model specific versions are renamed
#  so this function does not need a dutModelId parameter.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>RenameNamedRegion("myproject/region","title")
#  @endcode
@ApiFunction
def RenameNamedRegion(regionPath, newName):
    """
    Renames the NamedRegion regionPath to newName.  The NamedRegion must exist and the newName must not exist.

    param regionPath string: the full absolute path to the region (may begin with a / but not necessary),
    path elements separated by /.  Final element is the region name.

    param newName string: just the name portion and cannot include path components.

    return None.  An exception is thrown on an error (for example bad parameters, no communication).
    """
    return stormtest_client.stc.rename_named_region(regionPath, newName)

## @par Description
#  Writes the imageData to the database as imagePath.
#  imagePath is always case sensitive and SetNamedResourceMatchCase is ignored.
#
#  @param[in] imagePath @b string: the full absolute path to the image (may begin with a / but not necessary),
#  path elements separated by /.  Final element is the image name.
#  @param[in] imageData @b tuple: (binary data, width, height) of the image. The binary data is of a form that can
#   be read/written to a file and is understood to be an image (eg a PNG file).
#  @param[in] comment @b string: (optional) Free form text of a user defined comment.
#  @param[in] dutModelId @b Integer, String or List : The model for which the data is to be written.  The integer
#  value of 0 means the generic model only will be created/updated.  It can also be an explicit model number, a string
#  representing a single model or a list of strings representing multiple models.
#  @return @e None: An exception is thrown on an error (for example bad parameters, no communication).
#  @note see WriteNamedRegion for an exhaustive example.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>fp = open('c:\\users\\me\\sample.png', 'rb')
#  >>>image = fp.read()
#  >>>fp.close()
#  # we know this image is 100x60 but you could use Pillow to find it.  The size is for guidance only because in most
#  # uses of the image, the system will check the image size.
#  >>>WriteNamedImage('myprojects/logoicon',(image, 100,60))
#  @endcode
@ApiFunction
def WriteNamedImage(imagePath, imageData, comment=None, dutModelId=0):
    """
    Writes the imageData to the database as imagePath.
    imagePath is always case sensitive and SetNamedResourceMatchCase is ignored.

    param imagePath string: the full absolute path to the image (may begin with a / but not necessary),
    path elements separated by /.  Final element is the image name.

    param imageData tuple: (binary data, width, height) of the image. The binary data is of a form that can
    be read/written to a file and is understood to be an image (eg a PNG file).

    param comment string: (optional) Free form text of a user defined comment.

    param dutModelId integer: reserved for future use and must be 0.

    return  None: An exception is thrown on an error (for example bad parameters, no communication).
    """
    return stormtest_client.stc.write_named_image(imagePath, imageData, comment, dutModelId)

## @par Description
#  Deletes the named image imagePath.
#
#  @param[in] imagePath @b string: the full absolute path to the image (may begin with a / but not necessary),
#  path elements separated by /.  Final element is the image name.
#  @param[in] dutModelId @b integer, String or List: The model for which the image is to be deleted.  The integer
#  value of 0 means the generic model and all variants will be deleted.  It can also be an explicit model number, a string
#  representing a single model or a list of strings representing multiple models.  It is not an error to delete an image
#  with a model where there is no model specific image for that image - just a waste of CPU cycles and network bandwidth.
#  @return @e None: An exception is thrown on an error (for example bad parameters, no communication).
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>DeleteNamedImage('myprojects/logoicon')
#  @endcode
@ApiFunction
def DeleteNamedImage(imagePath, dutModelId = 0):
    """
    Deletes the named image imagePath.

    param imagePath string: the full absolute path to the image (may begin with a / but not necessary),
    path elements separated by /.  Final element is the image name.

    param dutModelId integer: reserved for future use and must be 0.

    return None: An exception is thrown on an error (for example bad parameters, no communication).
    """
    return stormtest_client.stc.delete_named_image(imagePath, dutModelId)

## @par Description
#
#  Reads the named image imagePath
#
#  @param[in] imagePath @b string: the full absolute path to the image (may begin with a / but not necessary),
#  path elements separated by /.  Final element is the image name.
#  @param[in] dutModelId @b integer or String: The model to read. If 0 then the generic verion is read. It can also be the
#  model name or an id retrieved from ListDutModels()
#
#  @return @e List: Each list item of the list has 2 elements, the first is the dutModelId and the second
#  a tuple of the image (binary data, width, height).  The binary data can be saved direct to a file.  The dutModelId is 
#  0 for the generic image and the 
#  model name for others.  If a dutModelId is supplied as an integer, the return is the model name, not the
#  numeric id.  It was intended at one stage to return all variants
#  in one function but that was changed due to potential network overhead but the format of a list of lists has been retained.
#  An exception is thrown on an error (for example bad parameters, no communication).
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>result = ReadNamedImage('myprojects/logoicon')
#  >>>print(str(result))
#  >>>[[0, ('\x89PNG...', 100, 60)]]
#  >>>fp = open('c:\\users\\me\\res.png','wb')
#  >>>fp.write(result[0][1][0])
#  >>>fp.close()
#  @endcode
@ApiFunction
def ReadNamedImage(imagePath, dutModelId=0):
    """
    Reads the named image imagePath

    param imagePath string: the full absolute path to the image (may begin with a / but not necessary),
    path elements separated by /.  Final element is the image name.

    param dutModelId integer: reserved for future use and must be 0.

    return e list of lists: each list item of the list has 2 elements, the first is the dutModelId (will always be 0)
    and a tuple of the image (binary data, width, height). In Release 3.1 there will always be just one list item in the
    overall returned list.  The binary data can be saved direct to a file.
    An exception is thrown on an error (for example bad parameters, no communication).
    """
    return stormtest_client.stc.read_named_image(imagePath, dutModelId)

## @par Description
#  Renames the Named image imagePath to newName.  The Named image must exist and the newName must not exist.
#
#  @param[in] imagePath @b string: the full absolute path to the image (may begin with a / but not necessary),
#  path elements separated by /.  Final element is the image name.
#
#  @param[in] newName @b string: just the name portion and cannot include path components.
#
#  @return @e None.  An exception is thrown on an error (for example bad parameters, no communication).
#  @note This cannot be used to move images, just to change the name.  All model specific versions are renamed
#  so this function does not need a dutModelId parameter.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>RenameNamedImage("myproject/image","icon")
#  @endcode
@ApiFunction
def RenameNamedImage(imagePath, newName):
    """
    Renames the Named image imagePath to newName.  The Named image must exist and the newName must not exist.

    param imagePath string: the full absolute path to the image (may begin with a / but not necessary),
    path elements separated by /.  Final element is the image name.

    param newName string: just the name portion and cannot include path components.

    return None.  An exception is thrown on an error (for example bad parameters, no communication).
    """
    return stormtest_client.stc.rename_named_image(imagePath, newName)

## @par Description
#  Writes the stringData to the database as stringPath.
#  stringPath is always case sensitive and SetNamedResourceMatchCase is ignored.
#
#  @param[in] stringPath @b string: the full absolute path to the string (may begin with a / but not necessary),
#  path elements separated by /.  Final element is the string name.
#  @param[in] stringData @b string: the string.
#  @param[in] comment @b string: (optional) Free form text of a user defined comment.
#  @param[in] dutModelId @b integer, String or List : The model for which the data is to be written.  The integer
#  value of 0 means the generic model only will be created/updated.  It can also be an explicit model number, a string
#  representing a single model or a list of strings representing multiple models.
#
#  @return @e None: An exception is thrown on an error (for example bad parameters, no communication).
#  @note see WriteNamedRegion for an exhaustive example.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>WriteNamedString('myprojects/titletext',"My Cool DUT")
#  @endcode
@ApiFunction
def WriteNamedString(stringPath, stringData, comment=None, dutModelId=0):
    """
    Writes the stringData to the database as stringPath.
    stringPath is always case sensitive and SetNamedResourceMatchCase is ignored.

    param stringPath string: the full absolute path to the string (may begin with a / but not necessary),
    path elements separated by /.  Final element is the string name.

    param stringData string: the string

    param comment string: (optional) Free form text of a user defined comment.

    param dutModelId integer: reserved for future use and must be 0.

    return  None: An exception is thrown on an error (for example bad parameters, no communication).
    """
    return stormtest_client.stc.write_named_string(stringPath, stringData, comment, dutModelId)

## @par Description
#  Deletes the named string stringPath.
#
#  @param[in] stringPath @b string: the full absolute path to the string (may begin with a / but not necessary),
#  path elements separated by /.  Final element is the string name.
#  @param[in] dutModelId @b integer, String or List: The model for which the string is to be deleted.  The integer
#  value of 0 means the generic model and all variants will be deleted.  It can also be an explicit model number, a string
#  representing a single model or a list of strings representing multiple models.  It is not an error to delete a string
#  with a model where there is no model specific string for that string - just a waste of CPU cycles and network bandwidth.
#  @return @e None: An exception is thrown on an error (for example bad parameters, no communication).
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>DeleteNamedString('myprojects/titletext')
#  @endcode
@ApiFunction
def DeleteNamedString(stringPath, dutModelId = 0):
    """
    Deletes the named string stringPath.

    param stringPath string: the full absolute path to the string (may begin with a / but not necessary),
    path elements separated by /.  Final element is the string name.

    param dutModelId integer: reserved for future use and must be 0.

    return None: An exception is thrown on an error (for example bad parameters, no communication).
    """
    return stormtest_client.stc.delete_named_string(stringPath, dutModelId)

## @par Description
#
#  Reads the named string stringPath
#
#  @param[in] stringPath @b string: the full absolute path to the string (may begin with a / but not necessary),
#  path elements separated by /.  Final element is the string name.
#  @param[in] dutModelId @b integer or String: The model to read. If 0 then the generic verion is read. It can also be the
#  model name or an id retrieved from ListDutModels()
#  @return @e List: Each list item of the list has 2 elements, the first is the dutModelId and the second is the string.
#  The dutModelId is 0 for the generic string and the model name for others.  If a dutModelId is supplied as an integer,
#  the return is the model name, not the numeric id.  It was intended at one stage to return all variants
#  in one function but that was changed due to potential network overhead but the format of a list of lists has been retained.
#  An exception is thrown on an error (for example bad parameters, no communication).
#  @subsubsection _eg1 eg1:
#  @b Example
#  @code
#  >>>print(str(ReadNamedString('myprojects/titletext')))
#  >>>[[0,'My Cool DUT']]
# @endcode
@ApiFunction
def ReadNamedString(stringPath, dutModelId=0):
    """
    Reads the named string stringPath

    param stringPath string: the full absolute path to the string (may begin with a / but not necessary),
    path elements separated by /.  Final element is the string name.

    param dutModelId integer: reserved for future use and must be 0.

    return e list of lists: each list item of the list has 2 elements, the first is the dutModelId (will always be 0)
    and the second is the string.  In Release 3.1 there will always be just one list item in the
    overall returned list.
    An exception is thrown on an error (for example bad parameters, no communication).
    """
    return stormtest_client.stc.read_named_string(stringPath, dutModelId)

## @par Description
#  Renames the Named string stringPath to newName.  The Named string must exist and the newName must not exist.
#
#  @param[in] stringPath @b string: the full absolute path to the string (may begin with a / but not necessary),
#  path elements separated by /.  Final element is the string name.
#
#  @param[in] newName @b string: just the name portion and cannot include path components.
#
#  @return @e None.  An exception is thrown on an error (for example bad parameters, no communication).
#  @note This cannot be used to move strings, just to change the name.  All model specific versions are renamed
#  so this function does not need a dutModelId parameter.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>RenameNamedString('myprojects/titletext'.'no text')
#  @endcode
@ApiFunction
def RenameNamedString(stringPath, newName):
    """
    Renames the Named string stringPath to newName.  The Named string must exist and the newName must not exist.

    param stringPath string: the full absolute path to the string (may begin with a / but not necessary),
    path elements separated by /.  Final element is the string name.

    param newName string: just the name portion and cannot include path components.

    return None.  An exception is thrown on an error (for example bad parameters, no communication).
    """
    return stormtest_client.stc.rename_named_string(stringPath, newName)

## @par Description
#  Writes the colorData to the database as colorPath.
#  colorPath is always case sensitive and SetNamedResourceMatchCase is ignored.
#
#  @param[in] colorPath @b string: the full absolute path to the color (may begin with a / but not necessary),
#  path elements separated by /.  Final element is the color name.
#  @param[in] colorData @b tuple: (color tuple, tolerance tuple, flatness, peak error) of the color.
#  @param[in] comment @b string: (optional) Free form text of a user defined comment.
#  @param[in] dutModelId @b integer, String or List : The model for which the data is to be written.  The integer
#  value of 0 means the generic model only will be created/updated.  It can also be an explicit model number, a string
#  representing a single model or a list of strings representing multiple models.
#  @return @e None: An exception is thrown on an error (for example bad parameters, no communication).
#  @note see WriteNamedRegion for an exhaustive example.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>WriteNamedColor('myprojects/hilight color',((255,0,0),(10,10,10),98.3,1.5))
#  @endcode
@ApiFunction
def WriteNamedColor(colorPath, colorData, comment=None, dutModelId=0):
    """
    Writes the colorData to the database as colorPath.
    colorPath is always case sensitive and SetNamedResourceMatchCase is ignored.

    param colorPath string: the full absolute path to the color (may begin with a / but not necessary),
    path elements separated by /.  Final element is the color name.
    param colorData tuple: (color tuple, tolerance tuple, flatness, peak error) of the color.
    param comment string: (optional) Free form text of a user defined comment.
    param dutModelId integer: reserved for future use and must be 0.

    return  None: An exception is thrown on an error (for example bad parameters, no communication).
    """
    return stormtest_client.stc.write_named_color(colorPath, colorData, comment, dutModelId)

## @par Description
#  Deletes the named color colorPath.
#
#  @param[in] colorPath @b string: the full absolute path to the color (may begin with a / but not necessary),
#  path elements separated by /.  Final element is the color name.
#  @param[in] dutModelId @b integer, String or List: The model for which the color is to be deleted.  The integer
#  value of 0 means the generic model and all variants will be deleted.  It can also be an explicit model number, a string
#  representing a single model or a list of strings representing multiple models.  It is not an error to delete a color
#  with a model where there is no model specific color for that color - just a waste of CPU cycles and network bandwidth.
#  @return @e None: An exception is thrown on an error (for example bad parameters, no communication).
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>DeleteNamedColor('myprojects/hilight color')
#  @endcode
@ApiFunction
def DeleteNamedColor(colorPath, dutModelId = 0):
    """
    Deletes the named color colorPath.

    param colorPath string: the full absolute path to the color (may begin with a / but not necessary),
    path elements separated by /.  Final element is the color name.

    param dutModelId integer: reserved for future use and must be 0.

    return None: An exception is thrown on an error (for example bad parameters, no communication).
    """
    return stormtest_client.stc.delete_named_color(colorPath, dutModelId)

## @par Description
#
#  Reads the named color colorPath
#
#  @param[in] colorPath @b string: the full absolute path to the color (may begin with a / but not necessary),
#  path elements separated by /.  Final element is the color name.
#  @param[in] dutModelId @b integer or String: The model to read. If 0 then the generic verion is read. It can also be the
#  model name or an id retrieved from ListDutModels()
#  @return @e List: Each list item of the list has 2 elements, the first is the dutModelId and the second a tuple of the color
#  (color tuple, tolerance tuple, flatness, peak error).  The dutModelId is 0 for the generic string and the model name for others.  If a dutModelId is supplied as an integer,
#  the return is the model name, not the numeric id.  It was intended at one stage to return all variants
#  in one function but that was changed due to potential network overhead but the format of a list of lists has been retained.
#  An exception is thrown on an error (for example bad parameters, no communication).
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>print(str(ReadNamedColor('myprojects/hilight color')))
#  >>>[[0,((255,0,0),(10,10,10),98.3,1.5)]]
#  @endcode
@ApiFunction
def ReadNamedColor(colorPath, dutModelId=0):
    """
    Reads the named color colorPath

    param colorPath string: the full absolute path to the color (may begin with a / but not necessary),
    path elements separated by /.  Final element is the color name.

    param dutModelId integer: reserved for future use and must be 0.

    return e list of lists: each list item of the list has 2 elements, the first is the dutModelId (will always be 0)
    and a tuple of the color (color tuple, tolerance tuple, flatness, peak error). In Release 3.1 there will always be just one list item in the
    overall returned list.
    An exception is thrown on an error (for example bad parameters, no communication).
    """
    return stormtest_client.stc.read_named_color(colorPath, dutModelId)

## @par Description
#  Renames the Named color colorPath to newName.  The Named color must exist and the newName must not exist.
#
#  @param[in] colorPath @b string: the full absolute path to the color (may begin with a / but not necessary),
#  path elements separated by /.  Final element is the color name.
#
#  @param[in] newName @b string: just the name portion and cannot include path components.
#
#  @return @e None.  An exception is thrown on an error (for example bad parameters, no communication).
#  @note This cannot be used to move colors, just to change the name.  All model specific versions are renamed
#  so this function does not need a dutModelId parameter.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>RenameNamedColor('myprojects/hilight color', 'lolite')
#  @endcode
@ApiFunction
def RenameNamedColor(colorPath, newName):
    """
    Renames the Named color colorPath to newName.  The Named color must exist and the newName must not exist.

    param colorPath string: the full absolute path to the color (may begin with a / but not necessary),
    path elements separated by /.  Final element is the color name.

    param newName string: just the name portion and cannot include path components.

    return None.  An exception is thrown on an error (for example bad parameters, no communication).
    """
    return stormtest_client.stc.rename_named_color(colorPath, newName)

## @par Description
#  Writes the screenDefinition to the data base as screenPath.
#  screenPath is always case sensitive and SetNamedResourceMatchCase is ignored.
#  There is no requirement for the screenPath to end in the same name as the embedded name of the screenDefinition.  
#  Likewise the comment is not related to the embedded comment property.
#
#  @param[in] screenPath @b string: the full absolute path to the screen definition (may begin with a / but not necessary),
#  path elements separated by /.  Final element is the screen definition name in the database.
#  @param[in] screenDefinition @b ScreenDefinition: the ScreenDefinition object.
#  @param[in] comment @b string: (optional) Free form text of a user defined comment.
#  @param[in] dutModelId @b integer, String or List : The model for which the data is to be written.  The integer
#  value of 0 means the generic model only will be created/updated.  It can also be an explicit model number, a string
#  representing a single model or a list of strings representing multiple models.
#  @return @e None: An exception is thrown on an error (for example bad parameters, no communication).
#  @note see WriteNamedRegion for an exhaustive example.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>sdo = ScreenDefinition()
#  >>>WriteNamedScreenDefinition('myprojects/empty sdo',sdo)
#  @endcode
@ApiFunction
def WriteNamedScreenDefinition(screenPath, screenDefinition, comment=None, dutModelId=0):
    """
    Writes a screen definition object as a named item.  
    There is no requirement for the screenPath to end in the same name as the embedded name of the screenDef.  
    Likewise the comment is not related to the embedded comment property.  
    The screenPath is the full absolute path
    """
    if screenDefinition is None or not isinstance(screenDefinition, ScreenDefinition):
        raise StormTestExceptions("Invalid object passed for screen Definition in WriteNamedScreenDefinition")

    screenDefinition.ToNamedResource(screenPath, comment, dutModelId)

## @par Description
#  Deletes the named screen definition screenPath.
#
#  @param[in] screenPath @b string: the full absolute path to the screen definition (may begin with a / but not necessary),
#  path elements separated by /.  Final element is the screen definition name in the database.
#  @param[in] dutModelId @b integer, String or List: The model for which the screen definition is to be deleted.  The integer
#  value of 0 means the generic model and all variants will be deleted.  It can also be an explicit model number, a string
#  representing a single model or a list of strings representing multiple models.  It is not an error to delete a screen definition
#  with a model where there is no model specific screen definition for that screen definition - just a waste of CPU cycles and network bandwidth.
#  @return @e None: An exception is thrown on an error (for example bad parameters, no communication).
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>DeleteNamedScreenDefinition('myprojects/empty sdo')
#  @endcode
@ApiFunction
def DeleteNamedScreenDefinition(screenPath, dutModelId = 0):
    """
    Deletes the screen definition screenPath.
    """
    stormtest_client.stc.delete_named_screen_definition(screenPath, dutModelId)
 
## @par Description
#  Reads the named screen definition screenPath
#
#  @param[in] screenPath @b string: the full absolute path to the screen definition (may begin with a / but not necessary),
#  path elements separated by /.  Final element is the screen definition name.
#  @param[in] dutModelId @b integer or String: The model to read. If 0 then the generic verion is read. It can also be the
#  model name or an id retrieved from ListDutModels()
#  @return @e List: Each list item of the list has 2 elements, the first is the dutModelId and the second the screen definition.
#  The dutModelId is 0 for the generic string and the model name for others.  If a dutModelId is supplied as an integer,
#  the return is the model name, not the numeric id.  It was intended at one stage to return all variants
#  in one function but that was changed due to potential network overhead but the format of a list of lists has been retained.
#  An exception is thrown on an error (for example bad parameters, no communication).
#  @subsubsection _eg1 eg1:
#  @b Example
#  @code
#  >>>print(str(ReadNamedScreenDefinition('myprojects/empty sdo')))
#  >>>[[0,<stormtest.ClientAPI.ScreenDefinition object>]]
#  @endocde
@ApiFunction
def ReadNamedScreenDefinition(screenPath, dutModelId=0):
    """
    Reads the screen definition screenPath 
    """
    return stormtest_client.stc.read_named_screen_definition(screenPath, dutModelId)
        
        
    
    
## @par Description
#  Renames the Named Screen Definition screenPath to newName.  The Named screen definition must exist and the newName must not exist.
#
#  @param[in] screenPath @b string: the full absolute path to the screen definition (may begin with a / but not necessary),
#  path elements separated by /.  Final element is the screen definition name.
#
#  @param[in] newName @b string: just the name portion and cannot include path components.
#
#  @return @e None.  An exception is thrown on an error (for example bad parameters, no communication).
#  @note This cannot be used to move screen definitions, just to change the name.  All model specific versions are renamed
#  so this function does not need a dutModelId parameter.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>RenameNamedScreenDefinition('myprojects/empty sdo', 'another sdo')
#  @endcode
@ApiFunction
def RenameNamedScreenDefinition(screenPath, newName):
    """
    Renames the screen definition to newName.  The screen definition must exist and the newName must not exist.
    """
    return stormtest_client.stc.rename_named_screen_definition(screenPath, newName)

## @par Description
#
#  Creates an empty folder for storing named resources.  This is for completeness and allows scripts
#  to create folders and entities separately, possibly from an external database.  It is not
#  necessary to create all intermediate paths – this function will create intermediate folders as needed.
#
#  @param[in] folderPath @b string: the full absolute path (may begin with a / but not necessary),
#  path elements separated by /.
#
#  @return @e None.  An exception is thrown on an error (for example bad parameters, no communication).
#  @subsubsection _eg1 eg1:
# @b Example:
# @code
# >>>CreateNamedFolder('/my projects/backup')
# @endcode
@ApiFunction
def CreateNamedFolder(folderPath):
    """
    Creates an empty folder for storing named resources.  This is for completeness and allows scripts
    to create folders and entities separately, possibly from an external database.  It is not
    necessary to create all intermediate paths – this function will create intermediate folders as needed.

    param folderPath string: the full absolute path (may begin with a / but not necessary),
    path elements separated by /.

    return None.  An exception is thrown on an error (for example bad parameters, no communication).
    """
    return stormtest_client.stc.create_named_folder(folderPath)

## @par Description
#
#  Deletes a folder and all contents (including sub folders).
#
#  @param[in] folderPath @b string: the full absolute path (may begin with a / but not necessary),
#  path elements separated by /.
#
#  @return @e None.  An exception is thrown on an error (for example bad parameters, no communication).
#  @note This is a very dangerous function to use.  You can delete everything by using the empty string
#  and there is no undelete option.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>DeleteNamedFolder('/my folder/my project/temp')
#  @endcode
@ApiFunction
def DeleteNamedFolder(folderPath):
    """
    Deletes a folder and all contents (including sub folders).

    param folderPath string: the full absolute path (may begin with a / but not necessary),
    path elements separated by /.

    return None.  An exception is thrown on an error (for example bad parameters, no communication).
    """
    return stormtest_client.stc.delete_named_folder(folderPath)

## @par Description
#
#  Renames the Named folder folderPath to newName.  The Named folder must exist and the newName must not exist.
#
#  @param[in] folderPath @b string: the full absolute path (may begin with a / but not necessary),
#  path elements separated by /.
#
#  @param[in] newName @b string: just the name portion and cannot include path components.
#
#  @return @e None.  An exception is thrown on an error (for example bad parameters, no communication).
#  @note This cannot be used to move folder, just to change the name.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>RenameNamedFolder('/my projects/backup','old backup')
#  @endcode
@ApiFunction
def RenameNamedFolder(folderPath, newName):
    """
    Renames the Named folder folderPath to newName.  The Named folder must exist and the newName must not exist.

    param folderPath string: the full absolute path (may begin with a / but not necessary),
    path elements separated by /.

    param newName string: just the name portion and cannot include path components.

    return None.  An exception is thrown on an error (for example bad parameters, no communication).
    """
    return stormtest_client.stc.rename_named_folder(folderPath, newName)

## @par Description
#  Returns a list of Resources, recursing as necessary.
#
#  @param[in] path @b string: the full absolute path (may begin with a / but not necessary),
#  path elements separated by /.  Can be empty for the root.
#  @param[in] whatToList @b integer:  made up of bit wise OR to limit the type of data to return.
#  The values are: 1 => namespaces, 2 => regions, 4 => colors, 8 => images,  16 => Screen Definition Objects,
#  32 => strings.  So setting whatToList = 63 will return everything
#  (0 returns nothing), 1 would return just name spaces.
#  @param[in] recurseLevel @b string: determines how many levels to recurse through namespaces.  0 is just one level down from path.
#  @param[in] dutModelId @b integer, String or List: The models to include in the return list.  The integer
#  value of 0 means the generic model only will be returned.  It can also be an explicit model number, a string
#  representing a single model or a list of strings representing multiple models.  It can also be the empty list [] meaning
#  all possible models.  It is not an error to include a model here which has no variants in the folder.
#
#  @return @e List: Each item in the list is a named resource.  The named resource is a list of 8 elements.  These are
#  [path relative to input path, type of resource as whatToList, comment, dutModelId, creation date, creating user, modification date, modifying user].  The dates are epoch seconds (
#  seconds since 1/1/1970 00:00:00 UTC).  the dutModelId is 0 for the generic and a string for all model specific resources.  The order within the list is not guaranteed
#  and is simply the fastest way to retrieve from the database.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  # from the WriteNamedRegion example
#  >>>print(str(ListNamedResources('/my projects', recurseLevel = 0, dutModelId='A')))
#  >>>[[u'title', 2, u'', u'A', 1406040427, u'me', 1406040988, u'me']]
#  >>>print(str(ListNamedResources('/my projects', recurseLevel = 0, dutModelId=[])))
#  >>>[[u'title', 2, u'', 0, 1406034434, u'me', 1406040987, u'me'], [u'title', 2, u'', u'SomeModel', 1406034533, u'me', 1406040987, u'me'], 
#  [u'title', 2, u'', u'A', 1406040427, u'me', 1406040988, u'me'], [u'title', 2, u'', u'B', 1406040988, u'me', 1406040988, u'me'], 
#  [u'title', 2, u'', u'C', 1406040988, u'me', 1406040988, u'me']]
#  @endcode
@ApiFunction
def ListNamedResources(path, whatToList = 63, recurseLevel = 0, dutModelId=0):
    """
    Returns a list of Resources, recursing as necessary.

    param path  string: the full absolute path (may begin with a / but not necessary),
    path elements separated by /.  Can be empty for the root.

    param whatToList integer:  made up of bit wise OR to limit the type of data to return.
    The values are: 1 => namespaces, 2 => regions, 4 => colors, 8 => images, 16 => Screen Definition Objects,
    32 => strings.  So setting whatToList = 63 will return everything
    (0 returns nothing), 1 would return just name spaces.

    param recurseLevel string: determines how many levels to recurse through namespaces.  0 is just one level down from path.

    param dutModelId integer: reserved for future use and must be 0.

    return list: Each item in the list is a named resource.  The named resource is a list of 8 elements.  These are
    [path relative to input path, type of resource as whatToList, comment, dutModelId, creation date, creating user, modification date, modifying user].  The dates are epoch seconds.
    """
    return stormtest_client.stc.list_named_resources(path, whatToList, recurseLevel, dutModelId)
## @}

## @defgroup Group20 MetaData API
#  Some objects in the system allow the addition of metadata.  This was introduced in StormTest version 3.2.  Each item of
#  metadata is a name, value pair where both are strings.  Some of the metadata is interpreted by StormTest but most of it is not.
#  To avoid confusion, all metadata items that have meaning to StormTest have names starting with an underscore '_'.
#  Users should not create or modify items beginning with the underscore.  This will avoid unexpected StormTest behavior.
#  All names not beginning with an underscore are for the end user.
#  It should be noted that adding meta data to items may prevent some of them being deleted until the meta data has been removed.
## @{


## @par Description
#  MetaDataType Enum. Defines the types of objects for which meta data can be assigned.  The
#  MetaDataType is passed in to the function calls to identify the object type for which meta data
#  is being read or written.
#  @param NamedRegion : A named region resource
#  @param NamedString : A named string resource
#  @param NamedColor : A named color resource
#  @param NamedImage : A named image resource
#  @param NamedScreenDef : A named screen definition resource
#  @param Namespace : A named folder (namespace)
#  @param Schedule : A schedule
#  @param Dut : A DUT instance
#  @param DutModel : A DUT model
#  @param Server : A server
#  @param Slot : A slot within the server
class MetaDataType:
    NamedRegion = "NamedRegion"
    NamedString = "NamedString"
    NamedColor = "NamedColor"
    NamedImage = "NamedImage"
    NamedScreenDef = "NamedScreenDef"
    Namespace = "Namespace"
    Schedule = "Schedule"
    Dut = "Dut"
    DutModel = "DutModel"
    Server = "Server"
    Slot = "Slot"


## @par Description
#  Adds meta data to an object.  Meta data is a keyword = value pair of strings.
#  Only a sub set of objects can support meta data.
#  @param[in] objType @b String or Integer: the type of object. It must be one of the MetaDataType enumeration.
#  To support adding meta data to model specific resources, the objType can also have a suffix of 
#  ".modelname" where modelname is the case sensitive name of a model
#  @param[in] objInstance @b String: the instance of the object. For the named resources, this is the
#  full path.  For other items it is the id, either as a string or as an integer
#  @param[in] metaName @b String: the name of meta data to add.  Users should not use names beginning with
#  an underscore ( _ ) - these are reserved for StormTest system meta data.
#  @param[in] metaValue @b String: the value of meta data to add.
#  @param[in] allowUpdate @b String: (optional). If the meta data already exists and this flag is true then
#  the existing meta data is updated.  If this flag is False and the meta data exists then this function fails
#  @return @e None 
#  On error an exception is thrown
#  @note The API checks that the specified item exists before adding the meta data.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  # add "Stable Build" = "0" to dut model 3750. Meaning known only to user code
#  >>>AddMetaData(MetaDataType.DutModel,3750,"Stable Build","0")    
#  # adds "Stable Build" = "0" to a named region /Tests/MyRegion but only to the version for 'MyModel'
#  >>>AddMetaData(MetaDataType.NamedRegion + ".MyModel","/Tests/MyRegion","Stable Build","0")    
#  @endcode
@ApiFunction
def AddMetaData(objType, objInstance, metaName, metaValue, allowUpdate=True):
    stormtest_client.stc.add_meta_data(objType, str(objInstance), metaName, metaValue, allowUpdate)

## @par Description
#  Removes meta data to an object.  Meta data is a keyword = value pair of strings.
#  Only a sub set of objects can support meta data.
#  @param[in] objType @b String or Integer: the type of object. It must be one of the MetaDataType enumeration.
#  To support adding meta data to model specific resources, the objType can also have a suffix of 
#  ".modelname" where modelname is the case sensitive name of a model
#  @param[in] objInstance @b String: the instance of the object. For the named resources, this is the
#  full path.  For other items it is the id, either as a string or as an integer
#  @param[in] metaName @b String: the name of meta data to remove. Use the empty string ("") to remove all
#  user meta data. Use "_" to remove all system meta data - this is unwise in general but is provided for
#  advanced users.
#  @return @e None
#  On error an exception is thrown.
#  @note The API checks that the specified item exists before removing the meta data.  Removing non exsitent meta data is NOT an error - it is always
#  safe to call RemoveMetaData() with metaName as empty so long as the objType and objInstance exist.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  # remove "Stable Build" from dut model 3750.
#  >>>RemoveMetaData(MetaDataType.DutModel,3750,"Stable Build","0")    
#  # remove all user meta data from the named region /Tests/MyRegion and model "MyModel". System meta data is not affected
#  >>>RemoveMetaData(MetaDataType.NamedRegion + ".MyModel","/Tests/MyRegion","")    
#  @endcode
@ApiFunction
def RemoveMetaData(objType, objInstance, metaName):
    stormtest_client.stc.remove_meta_data(objType, str(objInstance), metaName)


## @par Description
#  Read meta data on an object.  Meta data is a keyword = value pair of strings.
#  Only a sub set of objects can support meta data.
#  @param[in] objType @b String or Integer: the type of object. It must be one of the MetaDataType enumeration.
#  To support adding meta data to model specific resources, the objType can also have a suffix of 
#  ".modelname" where modelname is the case sensitive name of a model
#  @param[in] objInstance @b String: the instance of the object. For the named resources, this is the
#  full path.  For other items it is the id, either as a string or as an integer
#  @param[in] metaName @b String: the name of meta data to read. Use the empty string ("") to read all
#  meta data, including system meta data.
#  @return @e List: Each item in the list is a pair of strings: the meta data name and the meta data value.  This is true
#  even when an explicit item is requested.  If no meta data exists then an empty list is returned.
#  On error an exception is thrown.
#  @note The API checks that the specified item exists before reading the meta data.  Reading non exsitent meta data is NOT an error - it is always
#  safe to call ReadMetaData() with metaName as empty so long as the objType and objInstance exist.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>ReadMetaData(MetaDataType.DutModel,3750)
#  >>>[["Stable Build","0"],["Key1","value1"]]
#  @endcode
@ApiFunction
def ReadMetaData(objType, objInstance, metaName):
    return stormtest_client.stc.read_meta_data(objType, str(objInstance), metaName)

## @}

## @defgroup Group7 Debug output API
# This section is used to configure the level of output from the StormTest client and where that output is sent to.
## @{

from . import DebugLog

# Deprecated Class
## @par Deprecated
class OutputTo:
    """
    DEPRECATED
    """
    Console     = DebugLog.LOG_TO_CONSOLE
    SerialLog   = DebugLog.LOG_TO_SERIAL
    File        = DebugLog.LOG_TO_FILE

## @par
#  DebugLevel Enum. Introduced in release 2.8.  Defines the valid values for the
#  SetDebugLevel and WriteDebugLine functions.  When used in SetDebugLevel, it
#  defines which level of information is put into the log file.  All levels are
#  cumulative in that the less severe include the more severe so setting the
#  level to INFO, includes ERROR and WARNING messages as well.  When used in
#  WriteDebugLine(), the DebugLevel indicates the severity of the message.
#  @param NONE : When used in SetDebugLevel() indicates no tracing be shown.  Should not be
#  used in WriteDebugLine() but if used will force the line to appear whenever a log file is
#  created.
#  @param ERROR : Error messages - typically issues which have stopped StormTest API completing a task
#  @param WARNING : Warning messages - typically issues which should be fixed but allowed StormTest API to complete its task
#  @param INFO : Information messages - routine information about actions in StormTest API
#  @param VERBOSE : Verbose messages which are intended only to help debug problems in the StormTest API.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetDebugLevel(1, DebugLevel.INFO)     # set debug output to be INFO
#   >>WriteDebugLine("my debug line", DebugLevel.ERROR) # write the comment 'my debug line' as an error message
#  @endcode
class DebugLevel:
    """
    Names for the debug level
    """
    NONE        = 1
    ERROR       = 2
    WARNING     = 3
    INFO        = 4
    VERBOSE     = 5

## @par Description
#  This function sets the verbosity of the output from a script. The default is to print out error, warning and info messages.
#  @param[in] trace @b Integer: Turn on/off function entry/exit trace, see note <SUP>1</SUP>.
#  @param[in] level @b Integer: Sets the verbosity level, see note <SUP>2</SUP>. In Release 2.8 and later, an enumeration from
#  DebugLevel can also be used.
#  @param[in] serialLog @b Integer: (optional) Turn on/off serial logging in the main log file, see note <SUP>3</SUP>.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetDebugLevel(1,4)
#   # Error, warning, information and trace messages turned on
#  @endcode
#  @note
#  -# The variable @e trace can be set to 0 or 1 for OFF or ON
#  -# The variable @e level can be set to the following values:
#  \n\n @b 1: Prints out no messages.
#  \n\n @b 2: Prints out error messages.
#  \n\n @b 3: Prints out error and warning messages.
#  \n\n @b 4: Prints out error, warning and information messages.
#  \n\n @b 5: Prints out error, warning, info and verbose messages.
#  -# The variable @e serialLog can be set to 0 or 1 for OFF or ON. The default is 1 (i.e. ON).
#  @note Calling SetDebugLevel(0, 0) will prevent any log file from being created.
def SetDebugLevel(trace,level, serialLog=1):
    """
    Set the debug level.  This should be one of the first calls made, before even setting the
    directories.

    Return: None

    trace: (Integer) Use a value of 1 for enabling the function entry/exit trace messages

    level: (Integer) Set the level of debug information. 1 = No messages, 2 = Error, 3 = Warning
      4 = Information, 5 = Verbose detailed information.

    serialLog: (Integer) Turn on/off serial logging in the main log file. Default to 1 (on) when the serial is enabled. 0 - off, 1 - on
    """
    stormtest_client.stc.set_debug_log_level(trace,level, serialLog)


## @par Description
#  This function sets the size of pages of the HTML log file.  For a long running test, the log file may grow so large that
#  it cannot be loaded into a browser or the StormTest Developer Suite.  From Release 3.3.0 onwards, the HTML log file
#  is broken into pages (with links between them) to solve this problem.  The default size of each page is 20MB.  However, you
#  can control this size by using SetLogPageSize() as the first function in your script.  A small page size will make loading of
#  each page much faster and the browser/log viewer more responsive.  However, review of the overall test log will require more
#  clicks and automated log scanning tools would need changing.  Set the pageSize to None to disable paging totally and restore
#  the pre 3.3.0 behavior for large log files (so they are suitable for automated tools but not for loading into a browser)
#  This funtion will throw an exception if called after the log file starts.
#  @param[in] pageSize @b Integer : Size, in bytes of each page of the generated HTML log file.  This value is approximate as the code
#  must write HTML closing tags after the size limit is reached.  Also, it will not break a line of log across files.  Use pageSize = None
#  to disable paging.  The API imposes no maximum value on pageSize and a minimum of 30000 - if you set a value below this an exception is raised because
#  such a low value is likely to lead to a file per line of log output.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetLogPageSize(5000000)       # set 5MB pages
#   >>SetLogPageSize(None)          # no paging at all
#  @endcode
def SetLogPageSize(pageSize):
    """
    Set page size of HTML log file.  Must be first function called in your script.
    Size is in bytes, None to disable paging.

    Return: None (raises exception on error)
    """
    stormtest_client.stc.set_log_page_size(pageSize)

# Deprecated Function
@ApiFunction
def SetDebugOut(location):
    """
    DEPRECATED
    """
    out = 0
    if location != None:
        # If the result is iterable (more than one location)
        if hasattr(location,'__iter__'):
            for l in location:  out = out | l
        else:
            out = location

    stormtest_client.stc.set_debug_log_location(out,"")

## @par Description
#  This function writes a comment to the log
#  @param[in] commentToLog @b String: The comment to be written to the log
#  @param[in] debugLevel @b DebugLevel: The level to use for the comment.  If omitted, the comment
#  is always put into the log file.  This parameter requires release 2.8 and later.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>WriteDebugLine("This is a comment")
#   # Writes the debug messages to the to the log file
#  @endcode
@ApiFunction
def WriteDebugLine(commentToLog, debugLevel = None):
    """
    Write a comment to the debug log file.  The CommentToLog writes a message to the serial
    log but THIS function writes to the general log file.

    Return: None

    commentToLog: (String) the comment to write.

    debugLevel: (DebugLevel enum) the level to write. Omit (or None) for always write to log.
    """
    stormtest_client.stc.WriteDebugLine(commentToLog, debugLevel)


## @par Description
#  This function sets the thumbnail size in the HTML log file.  All images saved as thumbnails
#  after this call will use these values.  This function may be called at any time - however it
#  should NOT be called at the very start of the script if the next line is SetDebugLevel(0,0) to
#  turn off logging.  This function is available in release 3.4
#  @param[in] scaleFacotr @b float: The amount to scale the raw image by for the thumbnail.  The value
#  must be less than 1 (you can't make a thumbnail bigger than the raw image).
#  @param[in] minSize @b Tuple: A tuple or list of 2 integers specifying the minimum dimensions in
#  the horizontal and vertical dimensions respectively.  Whatever the scale factor, the thumbnail will
#  be no smaller than the minSize.
#  @return @e None
#  @exception StormTestExceptions is thrown if the parameters are invalid.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetHtmlThumbnailSize(0.25, (80,60))
#   # Thumbnails are 25% (1/4) of raw size but no smaller than 80 x 60
#  @endcode
#  @note The default system scale is 0.125 and (32,24) for the minimum size.
@ApiFunction
def SetHtmlThumbnailSize(scaleFactor, minSize):
    stormtest_client.stc.set_html_thumbnail_size(scaleFactor, minSize)
    

## @par Description
#  This function returns the current scale factor and minimum size of the thumbnails that will be written
#  to the HTML log file.  This function may be called at any time.  This function is available in release 3.4
#  @param None
#  @return @e Tuple: A tuple of scale factor, minimum size as described by SetHtmlThumbnailSize
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>GetHtmlThumbnailSize()
#   >>(0.125, (32, 24))
#  @endcode
@ApiFunction
def GetHtmlThumbnailSize():
    return stormtest_client.stc.get_html_thumbnail_size()


## @}

## @defgroup Group21 Screen Definition Object API
# This section contains the functions and classes that allow a script to use Screen Definition Objects.  This was introduced in version 3.2
# of StormTest.  It is a higher level of control than the underlying Image compare, color compare, OCR string, audio detection and motion detection.
#
# The easiest way to create Screen Definition Objects is by using the graphical StormTest Developer Suite Tool.  However, they can be created in 
# code in Python.
#
## @{


## @par Description
#  This enumeration controls the return of images in the ScreenDefintion and all sub objects.
#  @param Never : Never return an image
#  @param Always : Always return an image
#  @param OnSuccess : Return an image of success only
#  @param OnFail : Return an image on Fail only
#  @param Inherit : Use the parent's setting.  This cannot be applied to a top level ScreenDefinition
class ReturnScreen:
    Never = 0
    Always = 1
    OnSuccess = 2
    OnFail = 4
    Inherit = 128

    
## @par Description
#  OCRStringCorrection Enum. Defines the valid values for OCR string correction.  It uses a fixed algorithm
#  for common mistakes (eg 5 and S, 1 and I, 0 and O).  It does not guarantee total conversion (for instance
#  if you request AllNumbers and one character is M, it has no idea of a close number so leaves it alone)
#  @param NoCorrection : No correction - the string is unchanged.
#  @param AllCharacters : Convert the string to characters where possible
#  @param AllNumbers : Convert the string to numbers where possible
class OCRStringCorrection:
    """
    OCRStringCorrection, converting common OCR character/number errors
    """
    NoCorrection = 'None'
    AllCharacters = 'AllCharacters'
    AllNumbers = 'AllNumbers'

## @par Description
#  This object encapsulates the OCR processing.  All properties have default values unless explicitly set by the
#  script after construction.
#  @param Name String : The name of the region - this is a human readable name.
#  @param Comment String : A general comment.  It is not used by StormTest and is provided for the user.
#  @param DesignSize Tuple : This is a List of 2 float values representing the width and height of the coordinate system used 
#  when designing the object.  Given this information it is possible to combine objects designed at different times by 
#  different people at different resolutions and reuse the components.  It effectively makes the embedded coordinates 
#  proportional coordinates.
#  @param Parent ScreenDefinition : The parent ScreenDefinition.  It will be set on all objects returned from the StormTest API and should
#  be set on objects passed into the StormTest API (but the API is tolerant of users who forget to set the Parent or choose 
#  not to set it).
#
#  @param Rect Tuple: The rectangle to use - a tuple / List of left, top, width, height as used elsewhere in the API.
#  It can also be a NamedRegion object.
#
#  @param Verify Boolean : A bool to indicate whether the region is for verification purposes (True) or just reading (False).
#
#  @param PassOnNoMatch Boolean: A bool, defaulting to False, which allows the reversal of the condition - that is, the 'pass'
#  status is when the OCR of the region does NOT match the ExpectedText.  This property is ignored if Verify is False.
#
#  @param ExpectedText String or List : This is the expected text.  It can be a simple string, or a list of strings.
#  Each string can also be a NamedString object.  If a list of strings, then each one is tested when attempting to
#  verify the region.  The text can contain * and ? as wildcards.  When ExpectedText is supplied and Verify is false,
#  the rules are used to find the best match.  Best match is defined as closest Levenshtein distance.  In this case,
#  ExpectedTest should be a list of more than 1 item. Since it makes no sense to read a region and supply 1 expected text,
#  (the answer would be that text), if you do supply just one item, it is ignored and the text from the captured image
#  is returned.  On the other hand to supply 10 items and have the function return the closest makes a lot of sense.
#
#  @note There is a change of behaviour in release 3.3.4 - On earlier releases, if 1 item was specified for ExpectedText AND Verify
#  was False then the ExpectedText was always returned.  This, although logical, confused users so in release 3.3.4 the behaviour has
#  changed as described above.
#
#  @param MaxDistance  Integer: This is the maximum allowed Levenshtein distance as currently used in WaitOCRMatch when verification.
#
#  @param AutoCorrect OCRStringCorrection : This is the auto correction algorithm to apply immediately after OCR capture as described in WaitOCRMatch.
#
#  @param Languages List : A list of languages to use for the OCR region - the format is the same as OCRSetLanguage API
#  and overrides the global setting.  It can be None to mean use the global default.
#
#  @param ImageFilters List : A list of image filters to apply - the format is the same as OCRSetImageFiltering and
#  overrides the global setting.  It can be None to mean use the global default.
#
#  @param LegacyInvert Boolean : Whether to apply the legacy invert filter.  This can be used with the ImageFilters
#  but not recommended.  This overrides the OCRSetDefaultImageProcessing global setting.  It can be None
#  to mean use the global default.
#
#  @param ReturnScreenImage ReturnScreen : An enumerated type to indicate whether the return should include the cropped area
#  of the screen used for the OCR.  It is an enumeration of type ReturnScreen.  The default is Inherit which means
#  the image return will be controlled by the enclosing ScreenDefinition
#
#  @param ResultText String : The returned text of the OCR, corrected by the auto correct and, if Verify is false,
#  the closest value from the dictionary, if it is supplied.  Will be None if no OCR was performed.  The combination
#  of RawText, ResultText, Verify and ExpectedText can be summarized by the table below
#  @htmlonly
#  <TABLE ALIGN="center" BORDER=1 CELLSPACING=0 CELLPADDING=5>
#  <TR ALIGN="left" VALIGN="middle">
#    <TH>Verify</TH>
#    <TH>ExpectedText</TH>
#    <TH>Actual Screen</TH>
#    <TH>VerifyStatus</TH>
#    <TH>RawText</TH>
#    <TH>ResultText</TH>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>True</td><td>"Options"</td><td>"Options"</td><td>True</td><td>"Options"</td><td>"Options"</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <td>True</td><td>"Options"</td><td>"Opts"</td><td>False</td><td>"Opts"</td><td>"Opts"</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <td>False</td><td>"Options"</td><td>"Options"</td><td>True</td><td>"Options"</td><td>"Options"</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <td>False</td><td>"Options"</td><td>"Settings"</td><td>True</td><td>"Settings"</td><td>"Options"</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <td>False</td><td>"Options"</td><td>""</td><td>True</td><td>""</td><td>"Options"</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <td>False</td><td>["Options",""]</td><td>""</td><td>True</td><td>""</td><td>""</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <td>False</td><td>["Options",""]</td><td>"Settings"</td><td>True</td><td>"Settings"</td><td>"Options"</td>
#  </TR>
#  </Table>
#  @endhtmlonly
#  @latexonly
#  \begin{center}
#  \begin{tabular}{ | l | r | }
#  \hline
#  Verify & ExpectedText & Actual Screen & VerifyStatus & RawText & ResultText \\ \hline\hline
#  True & "Options" & "Options" & True & "Options" & "Options" \\
#  True & "Options" & "Opts" & False & "Opts" & "Opts" \\
#  False & "Options" & "Options" & True & "Options" & "Options" \\
#  False & "Options" & "Settings" & True & "Settings" & "Options" \\
#  False & "Options" & "" & True & "" & "Options" \\
#  False & ["Options",""] & "" & True & "" & "" \\
#  \hline
#  \end{tabular}
#  \end{center}
#  @endlatexonly
#
#  @param RawText String: The raw text from the underlying OCR engine before correction or dictionary lookup.
#  Will be None if no OCR was performed.
#
#  @param VerifyStatus Boolean : The output of the verification process.  It will be True if this object' verification criteria passed, 
#  else False.  If Verify is False then it is True as nothing can fail.
#
#  @param Image StormTestImageObject : This is a StormTestImageObject holding the image of the region used for OCR.
#  It can be None.  The table below summarises when this property is not None
#  @htmlonly
#  <TABLE ALIGN="center" BORDER=1 CELLSPACING=0 CELLPADDING=5>
#  <TR ALIGN="left" VALIGN="middle">
#    <TH>ReturnScreenImage value</TH>
#    <TH>Condition for Image to be not None</TH>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>Always</td><td>Always</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>Never</td><td>Never</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>OnSuccess</td><td>VerifyStatus is True</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>OnFail</td><td>VerifyStatus is False</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>Inherit</td><td>Depends on enclosing ScreenDefinition. If no such parent, then as per OnFail</td>
#  </TR>
#  </Table>
#  @endhtmlonly
#
#  @latexonly
#  \begin{center}
#  \begin{tabular}{ | l | r | }
#  \hline
#  ReturnScreenImage value & Condition for Image to be not None \\ \hline\hline
#  Always & Always \\
#  Never & Never \\
#  OnSuccess & VerifyStatus is True \\
#  OnFail & VerifyStatus is False \\
#  Inherit & Depends on enclosing ScreenDefinition. If no such parent, then as per OnFail \\
#  \hline
#  \end{tabular}
#  \end{center}
#  @endlatexonly
#
#  @param OCRStatistics List : A list of the OCR statistics as normally returned by OCRSlot.  Empty list if no OCR was performed.
class OCRRegion(object):
    __handle = None
    __cache = {}
    __closed = False

    def __getattr__(self, attr):
        self.__checkObject()
        return Sdo.GetObjectProperty(self.__handle, self.__cache, attr)

    def __setattr__(self, attr, value):
        if attr == "__handle":
            self.__handle = value
        elif attr.startswith("_OCRRegion__"):
            object.__setattr__(self, attr, value)
        else:
            self.__checkObject()
            Sdo.SetObjectProperty("OCRRegion", self.__cache, attr, value)

    def __checkObject(self):
        """
        Check the object's state.  A sanity check.
        """
        if self.__closed:
            raise StormTestExceptions("you can't access a OCRRegion object after calling Close() on it")
        elif self.__handle is None:
            self.__handle = Sdo.OcrRegionCreate()
        # else we are OK so do nothing

    def __resetObject(self, handle):
        """
        Reinitializes with a new object
        """
        Sdo.OcrClose(self.__handle, self.__cache)
        self.__handle = handle
        self.__cache = {}
        self.__closed = False

    ## @par Description
    # The constructor makes an OCRRegion object.  The empty constructor OCRRegion() makes a region to OCR the whole screen but has
    # no expected text so you would need to set that separately.  All parameters to the constructor are optional
    # @param[in] expectedText @b String or List: Sets the ExpectedText property of the constructed region
    # @param[in] name @b String : Sets the Name property of the constructed region
    # @param[in] rect @b Tuple, List or NamedRegion : Sets the Rect property of the constructed region
    # @param[in] verify @b Boolean : Sets the Verify property of the constructed region
    # @param[in] maxDistance @b Integer : Sets the MaxDistance property of the constructed region
    # @param[in] autoCorrect @b OCRStringCorrection : Sets the AutoCorrect property of the constructed region
    # @return @b OCRRegion : The constructed OCRRegion object
    #  @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>region = OCRRegion("Options", "Region to Test for Options", (100,20,80,25), autoCorrect = OCRStringCorrection.AllCharacters)
    # @endcode
    def __init__(self, expectedText=None, name='', rect=None, verify=True, maxDistance=0, autoCorrect = OCRStringCorrection.NoCorrection):
        """
        Ctor to set all defaults of the OCRRegion object
        """
        self.__handle = None
        self.__cache = {}
        self.__closed = False
        self.Name = name
        self.Rect = rect
        self.Verify = verify
        self.ExpectedText = expectedText
        self.MaxDistance = maxDistance
        self.AutoCorrect = autoCorrect
        self.Languages = None
        self.LegacyInvert = None

    ## @par Description
    # The OCRRegion has a finalizer as a last resort clean up when the object goes out of scope.
    # Normally the OCRRegion is part of a ScreenDefinition - in that case, you don't need to take
    # any precautions over OCRRegion clean up - the owning ScreenDefinition manages it.  If you
    # create 'orphaned' OCRRegions, see the Close() method.
    # @param None
    # @return @e None
    def __del__(self):
        # finalizer
        self.Close()

    def __dir__(self):
        return Sdo.OcrDir(list(OCRRegion.__dict__.keys()))

    ## @par Description
    # Cleans up the OCRRegion releasing any internal images.  Do NOT call this if the OCRRegion
    # is owned by a ScreenDefinition - the ScreenDefinition will manage the lifetime and cleanup
    # of all owned objects.
    # However, if you create an orphaned OCRRegion (either directly or by removing it from the
    # ScreenDefinition) then you should call Close() when finished with the object.
    # @param None
    # @return @e None
    #  @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # # This is somewhat contrived example which loads a ScreenDefinition from a file
    # # executes it to get a result and then 'orphans' the OCR region (assuming it
    # # is the first region in the screen definition
    # >>>sdo = ScreenDefinition()
    # >>>sdo.Load("file.stscreen")
    # >>>result = WaitScreenDefMatch(sdo, slotNo=4)[0]
    # >>>r = result.Regions[0]
    # >>>result.Regions = []    # now the result sdo has no regions but r is an OCRRegion and 'orphaned'
    # # do stuff with r
    # # this frees the potentially large image in r. Without Close() you would wait for Python to garbage collect it.
    # >>>r.Close()
    # @endcode
    def Close(self):
        Sdo.OcrClose(self.__handle, self.__cache)

        """
        Important to set C# handle to None after closing so as
        to avoid the situation where neither Python nor C# can garbage collect their own
        objects because Python is holding a reference to the C# object.
        """
        self.__handle = None
        self.__cache = {}
        self.__closed = True

    ## @par Description
    #  This clones an OCRRegion returning an exact copy.
    #  @param None
    #  @return @e OCRRegion: the cloned regions.  The original region is unmodified.
    #  @subsubsection _eg1 eg1:
    #  @b Example:
    #  @code
    #  >>>r1 = OCRRegion("Option", rect=(0,0,100,10))
    #  >>>r2 = r1.Clone()
    #  >>>print(r2.ExpectedText)
    #  >>>'Option'
    #  @endcode
    def Clone(self):
        """
        This method returns an exact copy of the OCRRegion object.
        """
        self.__checkObject()
        return Sdo.OcrClone(self, self.__handle)

## @par Description
#  This represents an image comparison test.  Although it can be used in full image mode, it is recommended to use icon mode because that is more efficient.
#  The reference image or icon has to be stored within the ImageRegion unless a named resource is used.  All properties have default values unless explicitly set by the
#  script after construction.
#  @param Name String : The name of the region - this is a human readable name.
#  @param Comment  String : A general comment.  It is not used by StormTest and is provided for the user.
#  @param DesignSize  Tuple: This is a List of 2 float values representing the width and height of the coordinate system used 
#  when designing the object.  Given this information it is possible to combine objects designed at different times by 
#  different people at different resolutions and reuse the components.  It effectively makes the embedded coordinates 
#  proportional coordinates.
#  @param Parent  ScreenDefinition: The parent ScreenDefinition.  It will be set on all objects returned from the StormTest API and should
#  be set on objects passed into the StormTest API (but the API is tolerant of users who forget to set the Parent or choose 
#  not to set it).
#
#  @param Rect Tuple : The rectangle to use - a tuple / List of left, top, width, height as used elsewhere in the API.  The width
#  and height are ignored in icon mode but must be set correctly in non icon mode.  It is recommended that they are set to
#  match the icon size in icon mode to aid user code documentation and debugging.
#  It can also be a @ref _namedRegion object.
#
#  @param Verify Boolean: A bool to indicate whether the region is for verification purposes (True) or just reading (False).
#
#  @param PassOnNoMatch Boolean: A bool, defaulting to False, which allows the reversal of the condition - that is, the 'pass'
#  status is when the image/icon of the region does NOT match the captured screen.  This property is ignored if Verify is False.
#
#  @param ReturnScreenImage ReturnScreen: An enumerated type to indicate whether the return should include the cropped area
#  of the screen used for the image comparison.  It is an enumeration of type ReturnScreen.  The default is Inherit which means
#  the image return will be controlled by the enclosing ScreenDefinition
#
#  @param IconMode  Boolean: A bool, defaulting to True which is true to indicate that the ReferenceImage is an icon.  In this case th eposition of the icon
#  is specified by the Rect and the size of the icon is the size of the ReferenceImage.
#
#  @param ReferenceImage StormTestImageObject or NamedImage : This is the reference image used in the image comparison
#  test.  If IconMode is True, this image is assumed to be a part of the screen locatied at the top corner of the
#  Rect property.  If Iconmode is False then the image is assumed eo be the same size as the captured screen
#  and Rect specifies an area such that the image in the captured screen is matched against the equivalent area in the ReferenceImage.
#
#  @param Threshold Integer: The threshold that the similarity between the captured image and the reference image must equal or
#  exceed in order to be considered a 'matching image'.  This is ignored if Verify is False.  Default value is 90.
#
#  @param VerifyStatus Boolean: The output of the verification process.  It will be True if this object' verification criteria passed, 
#  else False.  If Verify is False then it is True as nothing can fail.
#
#  @param Image StormTestImageObject: This is a StormTestImageObject holding the image of the region used for image comparison.
#  It can be None.  The table below summarises when this property is not None
#  @htmlonly
#  <TABLE ALIGN="center" BORDER=1 CELLSPACING=0 CELLPADDING=5>
#  <TR ALIGN="left" VALIGN="middle">
#    <TH>ReturnScreenImage value</TH>
#    <TH>Condition for Image to be not None</TH>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>Always</td><td>Always</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>Never</td><td>Never</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>OnSuccess</td><td>VerifyStatus is True</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>OnFail</td><td>VerifyStatus is False</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>Inherit</td><td>Depends on enclosing ScreenDefinition. If no such parent, then as per OnFail</td>
#  </TR>
#  </Table>
#  @endhtmlonly
#
#  @latexonly
#  \begin{center}
#  \begin{tabular}{ | l | r | }
#  \hline
#  ReturnScreenImage value & Condition for Image to be not None \\ \hline\hline
#  Always & Always \\
#  Never & Never \\
#  OnSuccess & VerifyStatus is True \\
#  OnFail & VerifyStatus is False \\
#  Inherit & Depends on enclosing ScreenDefinition. If no such parent, then as per OnFail \\
#  \hline
#  \end{tabular}
#  \end{center}
#  @endlatexonly
#
#  @param ActualMatch Float:. After processing this is the actual amount of match between the captured image and the reference
#  image as a percentage between 0 and 100.  It will be None if the image comparison has not been performed.
class ImageRegion(object):
    __handle = None
    __cache = {}
    __closed = False

    def __getattr__(self, attr):
        self.__checkObject()
        return Sdo.GetObjectProperty(self.__handle, self.__cache, attr)

    def __setattr__(self, attr, value):
        if attr == "__handle":
            self.__handle = value
        elif attr.startswith("_ImageRegion__"):
            object.__setattr__(self, attr, value)
        else:
            self.__checkObject()
            Sdo.SetObjectProperty("ImageRegion", self.__cache, attr, value)

    def __checkObject(self):
        """
        Check the object's state.  A sanity check.
        """
        if self.__closed:
            raise StormTestExceptions("you can't access a ImageRegion object after calling Close() on it")
        elif self.__handle is None:
            self.__handle = Sdo.ImageRegionCreate()
        # else we are OK so do nothing

    def __resetObject(self, handle):
        """
        Reinitializes with a new object
        """
        Sdo.ImageClose(self.__handle, self.__cache)
        self.__handle = handle
        self.__cache = {}
        self.__closed = False

    ## @par Description
    # The constructor makes an ImageRegion object.  The empty constructor ImageRegion() makes a region to compare the whole screen but has
    # no reference image so you would need to set that separately.  All parameters to the constructor are optional
    # @param[in] name @b String : Sets the Name property of the constructed region
    # @param[in] threshold @b Integer : Sets the threshold of the image comparison
    # @param[in] rect @b Tuple, List or NamedRegion : Sets the Rect property of the constructed region
    # @param[in] verify @b Boolean : Sets the Verify property of the constructed region
    # @return @e ImageRegion : The constructed ImageRegion object
    #  @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>region = ImageRegion("Logo region", 97, (100,20,80,25))
    # @endcode
    def __init__(self, name='', threshold=90, rect=None, verify=True):
        self.__handle = None
        self.__cache = {}
        self.__closed = False
        self.Name = name
        self.Rect = rect
        self.Verify = verify
        self.Threshold = threshold

    ## @par Description
    # The ImageRegion has a finalizer as a last resort clean up when the object goes out of scope.
    # Normally the ImageRegion is part of a ScreenDefinition - in that case, you don't need to take
    # any precautions over ImageRegion clean up - the owning ScreenDefinition manages it.  If you
    # create 'orphaned' ImageRegions, see the Close() method.
    # @param None
    # @return @e None
    def __del__(self):
        # finalizer
        self.Close()

    def __dir__(self):
        return Sdo.ImageDir(list(ImageRegion.__dict__.keys()))

    ## @par Description
    # Cleans up the ImageRegion releasing any internal images.  Do NOT call this if the ImageRegion
    # is owned by a ScreenDefinition - the ScreenDefinition will manage the lifetime and cleanup
    # of all owned objects.
    # However, if you create an orphaned ImageRegion (either directly or by removing it from the
    # ScreenDefinition) then you should call Close() when finished with the object.
    # @param None
    # @return @e None
    #  @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # # This is somewhat contrived example which loads a ScreenDefinition from a file
    # # executes it to get a result and then 'orphans' the ImageRegion (assuming it
    # # is the first region in the screen definition
    # >>>sdo = ScreenDefinition()
    # >>>sdo.Load("file.stscreen")
    # >>>result = WaitScreenDefMatch(sdo, slotNo=4)[0]
    # >>>r = result.Regions[0]
    # >>>result.Regions = []    # now the result sdo has no regions but r is an ImageRegion and 'orphaned'
    # # do stuff with r
    # # this frees the potentially large image in r. Without Close() you would wait for Python to garbage collect it.
    # >>>r.Close()
    # @endcode
    def Close(self):
        Sdo.ImageClose(self.__handle, self.__cache)

        """
        Important to set C# handle to None after closing so as
        to avoid the situation where neither Python nor C# can garbage collect their own
        objects because Python is holding a reference to the C# object.
        """
        self.__handle = None
        self.__cache = {}
        self.__closed = True


    ##  @par Description
    #  This clones an ImageRegion returning an exact copy.
    #  @param None
    #  @return @e ImageRegion: the cloned regions.  The original region is unmodified.
    #  @subsubsection _eg1 eg1:
    #  @b Example:
    #  @code
    #  >>>r1 = ImageRegion(rect=(0,0,100,10))
    #  >>>r2 = r1.Clone()
    #  >>>print(str(r2.Rect))
    #  >>>(0, 0, 100, 10)
    #  @endcode
    def Clone(self):
        """
        This method returns an exact copy of the ImageRegion object.
        """
        self.__checkObject()
        return Sdo.ImageClone(self, self.__handle)

    ##  @par Description
    #  Sets the reference image of the region.  This is more flexible in terms of input parameters
    #  than just setting the ReferenceImage directly and is the preferred method to set the image
    #  because it copies the image.
    #  @param[in] imgToSet @b String, StormTestImageObject, NamedImage or Pillow Image : The image to
    #  use as the reference.  With the exception of a NamedImage, the imgToSet is converted to a
    #  StormTestImageObject and stored as the ReferenceImage.  A copy is made if the imgToSet is
    #  already a StormTestImageObject.  This means the script can use, reuse or dispose of the
    #  imgToSet object after calling this function.
    #  @return @e None
    #  @subsubsection _eg1 eg1:
    #  @b Example:
    #  @code
    #  >>>i = ImageObject()
    #  >>>i.SetImage("c:\\myfiles\\sd.png")
    #  @endcode
    def SetImage(self, imgToSet):
        if isinstance(imgToSet, stormtest_client.NamedImage):
            self.ReferenceImage = imgToSet
        elif isinstance(imgToSet, stormtest_client.Imaging.StormTestImageObject):
            self.ReferenceImage = imgToSet.Clone()
        elif isinstance(imgToSet, str):
            self.ReferenceImage = stormtest_client.Imaging.ImageFromFile(imgToSet)
        else:
            try:
                self.ReferenceImage = stormtest_client.Imaging.StormTestImageObject(imgToSet)
            except:
                raise StormTestExceptions("Invalid Image supplied to ImageRegion.SetImage()")

## @par Description
#  This represents a color comparison test.
#  @param Name  String: The name of the region - this is a human readable name.
#  @param Comment String : A general comment.  It is not used by StormTest and is provided for the user.
#  @param DesignSize  Tuple: This is a List of 2 float values representing the width and height of the coordinate system used 
#  when designing the object.  Given this information it is possible to combine objects designed at different times by 
#  different people at different resolutions and reuse the components.  It effectively makes the embedded coordinates 
#  proportional coordinates.
#  @param Parent ScreenDefinition : The parent ScreenDefinition.  It will be set on all objects returned from the StormTest API and should
#  be set on objects passed into the StormTest API (but the API is tolerant of users who forget to set the Parent or choose 
#  not to set it).
#
#  @param Rect  Tuple: The rectangle to use - a tuple / List of left, top, width, height as used elsewhere in the API.
#  It can also be a @ref _namedRegion object.
#
#  @param Verify Boolean: A bool to indicate whether the region is for verification purposes (True) or just reading (False).
#
#  @param PassOnNoMatch Boolean: A bool, defaulting to False, which allows the reversal of the condition - that is, the 'pass'
#  status is when the color of the region does NOT match the color of the captured screen.  This property is ignored if Verify is False.
#
#  @param ReturnScreenImage ReturnScreen: An enumerated type to indicate whether the return should include the cropped area
#  of the screen used for the color comparison.  It is an enumeration of type ReturnScreen.  The default is Inherit which means
#  the image return will be controlled by the enclosing ScreenDefinition
#
#  @param ReferenceColor List, Tuple or NamedColor : The reference color as a Red, Green, Blue list (all integers). This is ignored
#  if Verify is False.  Default is (0,0,0) (Black).  This is the same as the color parameter of CompareColorEx() function.
#
#  @param Tolerance List : The tolerance on the color when comparing.  It is a list of 3 integers.  This is ignored if the 
#  ReferenceColor is a NamedColor object or if Verify is False.  This is the same as the tolerances parameter of CompareColorEx() function.
#  Default value (4,4,4)
#
#  @param Flatness Float : The required flatness of the color.  This is ignored if the ReferenceColor is a NamedColor or if Verify
#  is False.  This is the same as the flatness parameter of the CompareColorEx function.  Default value 98.
#
#  @param PeakError Float : The required peak error of the color.  This is ignored if the ReferenceColor is a NamedColor or if Verify
#  is False.  This is the same as the peakError parameter of the CompareColorEx function.  Default value 0.
#
#  @param VerifyStatus Boolean: The output of the verification process.  It will be True if this object's verification criteria passed, 
#  else False.  If Verify is False then it is True as nothing can fail.
#
#  @param Image StormTestImageObject: This is a StormTestImageObject holding the image of the region used for color comparison.
#  It can be None.  The table below summarises when this property is not None
#  @htmlonly
#  <TABLE ALIGN="center" BORDER=1 CELLSPACING=0 CELLPADDING=5>
#  <TR ALIGN="left" VALIGN="middle">
#    <TH>ReturnScreenImage value</TH>
#    <TH>Condition for Image to be not None</TH>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>Always</td><td>Always</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>Never</td><td>Never</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>OnSuccess</td><td>VerifyStatus is True</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>OnFail</td><td>VerifyStatus is False</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>Inherit</td><td>Depends on enclosing ScreenDefinition. If no such parent, then as per OnFail</td>
#  </TR>
#  </Table>
#  @endhtmlonly
#
#  @latexonly
#  \begin{center}
#  \begin{tabular}{ | l | r | }
#  \hline
#  ReturnScreenImage value & Condition for Image to be not None \\ \hline\hline
#  Always & Always \\
#  Never & Never \\
#  OnSuccess & VerifyStatus is True \\
#  OnFail & VerifyStatus is False \\
#  Inherit & Depends on enclosing ScreenDefinition. If no such parent, then as per OnFail \\
#  \hline
#  \end{tabular}
#  \end{center}
#  @endlatexonly
#
#  @param ActualColor Tuple : The detected color as a typle of 3 integers.  It will be None if no color comparison has occurred.
#
#  @param ActualFlatness Float : The detected flatness.  It will be None if no color comparison has occurred.
#
#  @param ActualPeakError Float : The detected peak error.  It will be None if no color comparison has occurred.
class ColorRegion(object):
    __handle = None
    __cache = {}
    __closed = False

    def __getattr__(self, attr):
        self.__checkObject()
        return Sdo.GetObjectProperty(self.__handle, self.__cache, attr)

    def __setattr__(self, attr, value):
        if attr == "__handle":
            self.__handle = value
        elif attr.startswith("_ColorRegion__"):
            object.__setattr__(self, attr, value)
        else:
            self.__checkObject()
            Sdo.SetObjectProperty("ColorRegion", self.__cache, attr, value)


    def __checkObject(self):
        """
        Check the object's state.  A sanity check.
        """
        if self.__closed:
            raise StormTestExceptions("you can't access a ColorRegion object after calling Close() on it")
        elif self.__handle is None:
            self.__handle = Sdo.ColorRegionCreate()
        # else we are OK so do nothing

    def __resetObject(self, handle):
        """
        Reinitializes with a new object
        """
        Sdo.ColorClose(self.__handle, self.__cache)
        self.__handle = handle
        self.__cache = {}
        self.__closed = False


    ## @par Description
    # The constructor makes a ColorRegion object.  The empty constructor ColorRegion() makes a region to compare the whole screen to
    # black.  All parameters to the constructor are optional
    # @param[in] name @b String : Sets the Name property of the constructed region
    # @param[in] rect @b Tuple, List or NamedRegion : Sets the Rect property of the constructed region
    # @param[in] verify @b Boolean : Sets the Verify property of the constructed region
    # @param[in] referenceColor @b List, Tuple or NamedColor : Sets the ReferenceColor property of the constructed region
    # @param[in] tolerance @b List : Sets the Tolerance property of the constructed region
    # @param[in] flatness @b Float : Sets the Flatness property of the constructed region
    # @param[in] peakError @b Float : Sets the PeakError property of the constructed region
    # @return @e ColorRegion : The constructed ColorRegion object
    #  @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>region = ColorRegion("highlight area", (100,20,80,25), (255,255,0))
    # @endcode
    def __init__(self, name='', rect=None, verify=True, referenceColor=(0,0,0), tolerance=(4,4,4), flatness=98, peakError=0):
        """
        Ctor to set all defaults of the ColorRegion object
        """
        self.__handle = None
        self.__cache = {}
        self__closed = False
        self.Name = name
        self.Rect = rect
        self.Verify = verify
        self.Tolerance = tolerance
        self.Flatness = flatness
        self.PeakError = peakError
        self.ReferenceColor = referenceColor

    ## @par Description
    # The ColorRegion has a finalizer as a last resort clean up when the object goes out of scope.
    # Normally the ColorRegion is part of a ScreenDefinition - in that case, you don't need to take
    # any precautions over ColorRegion clean up - the owning ScreenDefinition manages it.  If you
    # create 'orphaned' ColorRegions, see the Close() method.
    # @param None
    # @return @e None
    def __del__(self):
        # finalizer
        self.Close()

    def __dir__(self):
        return Sdo.ColorDir(list(ColorRegion.__dict__.keys()))

    ## @par Description
    # Cleans up the ColorRegion releasing any internal images.  Do NOT call this if the ColorRegion
    # is owned by a ScreenDefinition - the ScreenDefinition will manage the lifetime and cleanup
    # of all owned objects.
    # However, if you create an orphaned ColorRegion (either directly or by removing it from the
    # ScreenDefinition) then you should call Close() when finished with the object.
    # @param None
    # @return @e None
    #  @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # # This is somewhat contrived example which loads a ScreenDefinition from a file
    # # executes it to get a result and then 'orphans' the ColorRegion (assuming it
    # # is the first region in the screen definition
    # >>>sdo = ScreenDefinition()
    # >>>sdo.Load("file.stscreen")
    # >>>result = WaitScreenDefMatch(sdo, slotNo=4)[0]
    # >>>r = result.Regions[0]
    # >>>result.Regions = []    # now the result sdo has no regions but r is an ColorRegion and 'orphaned'
    # # do stuff with r
    # # this frees the potentially large image in r. Without Close() you would wait for Python to garbage collect it.
    # >>>r.Close()
    # @endcode
    def Close(self):
        Sdo.ColorClose(self.__handle, self.__cache)

        """
        Important to set C# handle to None after closing so as
        to avoid the situation where neither Python nor C# can garbage collect their own
        objects because Python is holding a reference to the C# object.
        """
        self.__handle = None
        self.__cache = {}
        self.__closed = True


    ##  @par Description
    #  This clones an ColorRegion returning an exact copy.
    #  @param None
    #  @return @e ColorRegion: the cloned regions.  The original region is unmodified.
    #  @subsubsection _eg1 eg1:
    #  @b Example:
    #  @code
    #  >>>r1 = ColorRegion(rect=(0,0,100,10))
    #  >>>r2 = r1.Clone()
    #  >>>print(str(r2.Rect))
    #  >>>(0, 0, 100, 10)
    #  @endcode
    def Clone(self):
        """
        This method returns an exact copy of the ColorRegion object.
        """
        self.__checkObject()
        return Sdo.ColorClone(self, self.__handle)


## @par Description
#  This represents a detect motion test.  
#  This needs the ability to grab multiple images so can only be used as part of a Screen Definition object that has a slot specified for capturing.  
#  It is highly recommended that it is the last used test whether that be for verification or simply reading the motion in a region.  Otherwise it
#  will delay other non motion detection regions.
#  @param Name String : The name of the region - this is a human readable name.
#  @param Comment String : A general comment.  It is not used by StormTest and is provided for the user.
#  @param DesignSize Tuple : This is a List of 2 float values representing the width and height of the coordinate system used 
#  when designing the object.  Given this information it is possible to combine objects designed at different times by 
#  different people at different resolutions and reuse the components.  It effectively makes the embedded coordinates 
#  proportional coordinates.
#  @param Parent ScreenDefinition: The parent ScreenDefinition.  It will be set on all objects returned from the StormTest API and should
#  be set on objects passed into the StormTest API (but the API is tolerant of users who forget to set the Parent or choose 
#  not to set it).
#
#  @param Rect Tuple : The rectangle to use - a tuple / List of left, top, width, height as used elsewhere in the API.
#  It can also be a @ref _namedRegion object.
#
#  @param Verify Boolean : A bool to indicate whether the region is for verification purposes (True) or just reading (False).
#
#  @param PassOnNoMatch Boolean : A bool, defaulting to False, which allows the reversal of the condition - that is, the 'pass'
#  status is when there is no motion in the region.  This property is ignored if Verify is False.
#
#  @param ReturnScreenImage ReturnScreen: An enumerated type to indicate whether the return should include the cropped area
#  of the screen used for the motion detection.  It is an enumeration of type ReturnScreen.  The default is Inherit which means
#  the image return will be controlled by the enclosing ScreenDefinition
#
#  @param MotionThreshold Integer : The degree of motion that constitutes motion.  It ranges from 0 to 100.  Default is 5.
#
#  @param Timeout Float : The maximum time in seconds to wait for motion to occur.  Where the PassOnNoMatch is False then
#  this is the time to wait to confirm that there is a static picture.  If Verify is False, then this is the time
#  to monitor the motion and the maximum motion in this time is returned.  The default value is None and user code
#  must set a timeout.
#
#  @param VerifyStatus Boolean : The output of the verification process.  It will be True if this object's verification criteria passed, 
#  else False.  If Verify is False then it is True as nothing can fail.
#
#  @param Image StormTestImageObject: This is a StormTestImageObject holding the image of the region used for motion detection.  It will be the
#  image or portion of the image that was last used for motion detection (not the first in the sequence).
#  It can be None.  The table below summarises when this property is not None
#  @htmlonly
#  <TABLE ALIGN="center" BORDER=1 CELLSPACING=0 CELLPADDING=5>
#  <TR ALIGN="left" VALIGN="middle">
#    <TH>ReturnScreenImage value</TH>
#    <TH>Condition for Image to be not None</TH>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>Always</td><td>Always</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>Never</td><td>Never</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>OnSuccess</td><td>VerifyStatus is True</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>OnFail</td><td>VerifyStatus is False</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>Inherit</td><td>Depends on enclosing ScreenDefinition. If no such parent, then as per OnFail</td>
#  </TR>
#  </Table>
#  @endhtmlonly
#
#  @latexonly
#  \begin{center}
#  \begin{tabular}{ | l | r | }
#  \hline
#  ReturnScreenImage value & Condition for Image to be not None \\ \hline\hline
#  Always & Always \\
#  Never & Never \\
#  OnSuccess & VerifyStatus is True \\
#  OnFail & VerifyStatus is False \\
#  Inherit & Depends on enclosing ScreenDefinition. If no such parent, then as per OnFail \\
#  \hline
#  \end{tabular}
#  \end{center}
#  @endlatexonly
#
#  @param ActualMotion Float : The degree of motion detected (range is 0 to 100).  It will be None if no motion detection took
#  place. If Verify is True and VerifyStatus is True then this is the motion that caused the verification to
#  pass.\n\n
#  The motion detection works by first grabbing an image and calculating the average and standard deviation
#  of the red, green and blue colors.  It then captures additional images, calculates the same metrics and
#  if any differ by more than the threshold then this is the 'motion' returned.  The cycle of image grab and
#  calculation continues until either a value greater than or equal to the threshold is detected or the timeout
#  is reached.  The most recent tested value is returned.  In the case of motion not exceeding the threshold 
#  this is the difference between the first image and the image at the timeout - even if intermediate images
#  had more motion.\n\n
#  When Verify is false or PassOnNoMatch is true the exact same algorithm is applied as above: the detection stops when 
#  the same conditions are satisfied.  Then the logic involved in Verify and PassOnNoMatch is applied to determine the
#  pass or fail status of the region.\n\n
#  A consequence of the algorithm used is that it is optimised for what a human perceives as moving video. There
#  are two known cases where this may cause confusion.  If the video is simply noise then the average and 
#  standard deviations don't change over time.  So StormTest will not report motion.  To a human there is no
#  live video - to an engineer there are definitely changes in the video signal.  Another case is where the
#  device shows a slow moving screen saver of the type that moves a logo around the screen.  The average and 
#  standard deviations won't change as the actual image has the same pixels but just in a different location.
#  StormTest won't report motion.  A human would not consider this to be live video but again an engineer would
#  ignore the content and consider the image as moving.
#  @param ImagesCompared Integer : The number of images compared during execution of the motion region.  It will be None if no
#  motion took place.  In all other cases it is the actual number of images, that were processed.  A value of 1 means that the
#  first image after the initial reference image produced motion.
class MotionRegion(object):
    __handle = None
    __cache = {}
    __closed = False

    def __getattr__(self, attr):
        self.__checkObject()
        return Sdo.GetObjectProperty(self.__handle, self.__cache, attr)

    def __setattr__(self, attr, value):
        if attr == "__handle":
            self.__handle = value
        elif attr.startswith("_MotionRegion__"):
            object.__setattr__(self, attr, value)
        else:
            self.__checkObject()
            Sdo.SetObjectProperty("MotionRegion", self.__cache, attr, value)

    def __checkObject(self):
        """
        Check the object's state.  A sanity check.
        """
        if self.__closed:
            raise StormTestExceptions("you can't access a MotionRegion object after calling Close() on it")
        elif self.__handle is None:
            self.__handle = Sdo.MotionRegionCreate()
        # else we are OK so do nothing

    def __resetObject(self, handle):
        """
        Reinitializes with a new object
        """
        Sdo.MotionClose(self.__handle, self.__cache)
        self.__handle = handle
        self.__cache = {}
        self.__closed = False

    ## @par Description
    # The constructor makes a MotionRegion object.  The empty constructor NotionRegion() makes a region to detect motion on
    # the whole screen with a threshold of 5.
    # @param[in] name @b String : Sets the Name property of the constructed region
    # @param[in] rect @b Tuple, List or NamedRegion : Sets the Rect property of the constructed region
    # @param[in] verify @b Boolean : Sets the Verify property of the constructed region
    # @param[in] motionThreshold @b Integer : Sets the MotionThreshold property of the constructed region
    # @param[in] timeout @b Float : Sets the Timeout property of the constructed region
    # @return @e MotionRegion : The constructed MotionRegion object
    #  @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>region = MotionRegion("highlight area", (100,20,80,25))
    # @endcode
    def __init__(self, name='', rect=None, verify=True, motionThreshold=5, timeout=None):
        """
        Ctor to set all defaults of the MotionRegion object
        """
        self.__handle = None
        self.__cache = {}
        self.__closed = False
        self.Name = name
        self.Rect = rect
        self.Verify = verify
        self.MotionThreshold = motionThreshold
        self.Timeout = timeout

    ## @par Description
    # The MotionRegion has a finalizer as a last resort clean up when the object goes out of scope.
    # Normally the MotionRegion is part of a ScreenDefinition - in that case, you don't need to take
    # any precautions over MotionRegion clean up - the owning ScreenDefinition manages it.  If you
    # create 'orphaned' MotionRegions, see the Close() method.
    # @param None
    # @return @e None
    def __del__(self):
        # finalizer
        self.Close()

    def __dir__(self):
        return Sdo.MotionDir(list(MotionRegion.__dict__.keys()))

    ## @par Description
    # Cleans up the MotionRegion releasing any internal images.  Do NOT call this if the MotionRegion
    # is owned by a ScreenDefinition - the ScreenDefinition will manage the lifetime and cleanup
    # of all owned objects.
    # However, if you create an orphaned MotionRegion (either directly or by removing it from the
    # ScreenDefinition) then you should call Close() when finished with the object.
    # @param None
    # @return @e None
    #  @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # # This is somewhat contrived example which loads a ScreenDefinition from a file
    # # executes it to get a result and then 'orphans' the MotionRegion (assuming it
    # # is the first region in the screen definition
    # >>>sdo = ScreenDefinition()
    # >>>sdo.Load("file.stscreen")
    # >>>result = WaitScreenDefMatch(sdo, slotNo=4)[0]
    # >>>r = result.Regions[0]
    # >>>result.Regions = []    # now the result sdo has no regions but r is an MotionRegion and 'orphaned'
    # # do stuff with r
    # # this frees the potentially large image in r. Without Close() you would wait for Python to garbage collect it.
    # >>>r.Close()
    # @endcode
    def Close(self):
        Sdo.MotionClose(self.__handle, self.__cache)

        """
        Important to set C# handle to None after closing so as
        to avoid the situation where neither Python nor C# can garbage collect their own
        objects because Python is holding a reference to the C# object.
        """
        self.__handle = None
        self.__cache = {}
        self.__closed = True


    ##  @par Description
    #  This clones a MotionRegion returning an exact copy.
    #  @param None
    #  @return @e MotionRegion: the cloned regions.  The original region is unmodified.
    #  @subsubsection _eg1 eg1:
    #  @b Example:
    #  @code
    #  >>>r1 = MotionRegion(rect=(0,0,100,10))
    #  >>>r2 = r1.Clone()
    #  >>>print(str(r2.Rect))
    #  >>>(0, 0, 100, 10)
    #  @endcode
    def Clone(self):
        """
        This method returns an exact copy of the MotionRegion object.
        """
        self.__checkObject()
        return Sdo.MotionClone(self, self.__handle)


## @par Description
#  This represents an audio test.    It permits a screen to be verified to include or exclude audio.  There is no 'region'
#  of audio but for consistency, the AudioRegion keeps the naming and properties conventions of the other regions.
#  @param Name String : The name of the region - this is a human readable name.
#  @param Comment String: A general comment.  It is not used by StormTest and is provided for the user.
#  @param DesignSize Tuple: This has no significance for audio.
#  @param Parent ScreenDefinition: The parent ScreenDefinition.  It will be set on all objects returned from the StormTest API and should
#  be set on objects passed into the StormTest API (but the API is tolerant of users who forget to set the Parent or choose 
#  not to set it).
#
#  @param Verify Boolean: A bool to indicate whether the region is for verification purposes (True) or just reading (False).
#
#  @param PassOnNoMatch Boolean: A bool, defaulting to False, which allows the reversal of the condition - that is, the 'pass'
#  status is when there is no audio in the region.  This property is ignored if Verify is False.
#
#  @param ReturnScreenImage ReturnScreen: An enumerated type to indicate whether the return should include the full screen at the end
#  of audio detection.  It is an enumeration of type ReturnScreen.  The default is Inherit which means
#  the image return will be controlled by the enclosing ScreenDefinition
#
#  @param AudioThreshold Integer : The audio level in dBu, above which the audio is considered 'present'.  There is no default
#  so user code must set a value.
#
#  @param Timeout Float : The maximum time in seconds to wait for audio to exceed the threshold.  Where the PassOnNoMatch is False then
#  this is the time to wait for audio to drop below the threshold.  If Verify is False, then this is ignored and a simple measurement
#  of the level occurs.  The default value is None and user code must set a timeout.
#
#  @param Channel AudioChannel : For HD systems, this specifies the left or right audio channel.  Ignored for Standard Definition
#  systems 
#
#  @param VerifyStatus Boolean: The output of the verification process.  It will be True if this object's verification criteria passed, 
#  else False.  If Verify is False then it is True as nothing can fail.
#
#  @param Image StormTestImageObject: This is a StormTestImageObject holding the image of the region used for motion detection.  It will be the
#  image that was visible at the end of the audio detection.
#  It can be None.  The table below summarises when this property is not None
#  @htmlonly
#  <TABLE ALIGN="center" BORDER=1 CELLSPACING=0 CELLPADDING=5>
#  <TR ALIGN="left" VALIGN="middle">
#    <TH>ReturnScreenImage value</TH>
#    <TH>Condition for Image to be not None</TH>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>Always</td><td>Always</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>Never</td><td>Never</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>OnSuccess</td><td>VerifyStatus is True</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>OnFail</td><td>VerifyStatus is False</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>Inherit</td><td>Depends on enclosing ScreenDefinition. If no such parent, then as per OnFail</td>
#  </TR>
#  </Table>
#  @endhtmlonly
#
#  @latexonly
#  \begin{center}
#  \begin{tabular}{ | l | r | }
#  \hline
#  ReturnScreenImage value & Condition for Image to be not None \\ \hline\hline
#  Always & Always \\
#  Never & Never \\
#  OnSuccess & VerifyStatus is True \\
#  OnFail & VerifyStatus is False \\
#  Inherit & Depends on enclosing ScreenDefinition. If no such parent, then as per OnFail \\
#  \hline
#  \end{tabular}
#  \end{center}
#  @endlatexonly
#
#  @param ActualAudio Float : The actual audio level in dBu.  It will be None if no audio measurement took place.  If Verify is True
#  and VerifyStatus is True then this is the audio level that caused the verification to pass.  This is independent of the value of
#  PassOnNoMatch - the value is the valute that triggered the verification to be True.  If the verification failed then this is the
#  closest value to the passing threshold.
class AudioRegion(object):
    __handle = None
    __cache = {}
    __closed = False

    def __getattr__(self, attr):
        self.__checkObject()
        return Sdo.GetObjectProperty(self.__handle, self.__cache, attr)

    def __setattr__(self, attr, value):
        if attr == "__handle":
            self.__handle = value
        elif attr.startswith("_AudioRegion__"):
            object.__setattr__(self, attr, value)
        else:
            self.__checkObject()
            Sdo.SetObjectProperty("AudioRegion", self.__cache, attr, value)

    def __checkObject(self):
        """
        Check the object's state.  A sanity check.
        """
        if self.__closed:
            raise StormTestExceptions("you can't access a AudioRegion object after calling Close() on it")
        elif self.__handle is None:
            self.__handle = Sdo.AudioRegionCreate()
        # else we are OK so do nothing

    def __resetObject(self, handle):
        """
        Reinitializes with a new object
        """
        Sdo.AudioClose(self.__handle, self.__cache)
        self.__handle = handle
        self.__cache = {}
        self.__closed = False

    ## @par Description
    # The constructor makes an AudioRegion object.  The empty constructor AudioRegion() makes an object to detect audio on
    # the left channel.
    # @param[in] name @b String : Sets the Name property of the constructed region
    # @param[in] verify @b Boolean : Sets the Verify property of the constructed region
    # @param[in] audioThreshold @b Integer : Sets the AudioThreshold property of the constructed region
    # @param[in] timeout @b Float : Sets the Timeout property of the constructed region
    # @param[in] channel @b Integer : Sets the Channel property of the constructed region
    # @return @e AudioRegion : The AudioRegion object
    #  @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>region = AudioRegion("epg screen", audioThreshold=-20)
    # @endcode
    def __init__(self, name='', verify=True, audioThreshold=None, timeout=None, channel='Left'):
        """
        Ctor to set all defaults of the AudioRegion object
        """
        self.__handle = None
        self.__cache = {}
        self.__closed = False
        self.Name = name
        self.Verify = verify
        self.AudioThreshold = audioThreshold
        self.Timeout = timeout
        self.Channel = channel

    ## @par Description
    # The AudioRegion has a finalizer as a last resort clean up when the object goes out of scope.
    # Normally the AudioRegion is part of a ScreenDefinition - in that case, you don't need to take
    # any precautions over AudioRegion clean up - the owning ScreenDefinition manages it.  If you
    # create 'orphaned' AudioRegions, see the Close() method.
    # @param None
    # @return @e None
    def __del__(self):
        # finalizer
        self.Close()

    def __dir__(self):
        return Sdo.AudioDir(list(AudioRegion.__dict__.keys()))


    ## @par Description
    # Cleans up the AudioRegion releasing any internal images.  Do NOT call this if the AudioRegion
    # is owned by a ScreenDefinition - the ScreenDefinition will manage the lifetime and cleanup
    # of all owned objects.
    # However, if you create an orphaned AudioRegion (either directly or by removing it from the
    # ScreenDefinition) then you should call Close() when finished with the object.
    # @param None
    # @return @e None
    #  @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # # This is somewhat contrived example which loads a ScreenDefinition from a file
    # # executes it to get a result and then 'orphans' the AudioRegion (assuming it
    # # is the first region in the screen definition
    # >>>sdo = ScreenDefinition()
    # >>>sdo.Load("file.stscreen")
    # >>>result = WaitScreenDefMatch(sdo, slotNo=4)[0]
    # >>>r = result.Regions[0]
    # >>>result.Regions = []    # now the result sdo has no regions but r is an AudioRegion and 'orphaned'
    # # do stuff with r
    # # this frees the potentially large image in r. Without Close() you would wait for Python to garbage collect it.
    # >>>r.Close()
    # @endcode
    def Close(self):
        Sdo.AudioClose(self.__handle, self.__cache)

        """
        Important to set C# handle to None after closing so as
        to avoid the situation where neither Python nor C# can garbage collect their own
        objects because Python is holding a reference to the C# object.
        """
        self.__handle = None
        self.__cache = {}
        self.__closed = True

    ##  @par Description
    #  This clones an AudioRegion returning an exact copy.
    #  @param None
    #  @return @e AudioRegion: the cloned regions.  The original region is unmodified.
    #  @subsubsection _eg1 eg1:
    #  @b Example:
    #  @code
    #  >>>r1 = AudioRegion(audioThreshold = -57)
    #  >>>r2 = r1.Clone()
    #  >>>print(str(r2.AudioThreshold))
    #  >>>-57.00001
    #  @endcode
    def Clone(self):
        """
        This method returns an exact copy of the AudioRegion object.
        """
        self.__checkObject()
        return Sdo.AudioClone(self, self.__handle)

## @par Description
#  This represents a color object, combining the RGB elements, tolerances, flatness and peak error into one object
#  This is available in release 3.4 and is only supported in a CustomRegion
#  @param RGB List : A List of 3 integers representing Red, Green, Blue color components
#  @param Tolerances List : A List of 3 integers representing the tolerance on red, green and blue components
#  @param Flatness Float : The flatness of the color in the range 0 to 100
#  @param PeakError Float : The peak error of the color in the range 0 to 100
class Color(object):
    def __init__(self, color=[0,0,0], tolerances=[4,4,4], flatness=98, peakError = 0):
        self.RGB = color
        self.Tolerances = tolerances
        self.Flatness = flatness
        self.PeakError = peakError

## @par Description
# This represents a rectangle matrix object.  This is n x m sub rectangles, each of which is treated as a separate
# rectangle.  This is available in release 3.4 and is only supported in a CustomRegion
# @param Bounds List : A list of 4 integers representing the bounding rectangle of the matrix.  This allows a border
# to be defined outside of the rectangle matrix.  The integers are the same as for any Rectangle in the API.
# @param Rows Integer : The number of rows in the matrix.  It must be greater than 0.
# @param Columns Integer : The number of columns in the matrix.  It must be greater than 0.
# @param HorizontalGap Float : The gap between columns.
# @param VerticalGap Float : The gap between rows.
# @Note The horizontal and vertical gaps are defined as floating point to allow calculation of rectangles to floating
# point accuracy - most algorithms will then need to round to the nearest pixel but the flexibility has been designed
# in now to allow fractional pixel processing.
class RectangleMatrix(object):
    def __init__(self, bounds=[0,0,0,0], rows = 1, columns = 1, horizontalGap = 0, verticalGap = 0):
        self.Bounds = bounds
        self.Rows = rows
        self.Columns = columns
        self.HorizontalGap = horizontalGap
        self.VerticalGap = verticalGap


## @par Description
#  This represents a Custom Algorithm test.  It permits a screen to be verified with a custom algorithm.  You can create a custom
#  algorithm but there is no guarantee that when executed the algorithm is installed on the system so the user must take that
#  into account when checking ScreenDefinition results.  This is only available in release 3.4
#  @param Descriptor AlgorithmDescriptor : The algorithm that will be executed by this CustomRegion.
#  @param Name String : The name of the region - this is a human readable name and nothing to do with the algorithm name
#  @param Comment String: A general comment.  It is not used by StormTest and is provided for the user.
#  @param DesignSize Tuple : This is a List of 2 float values representing the width and height of the coordinate system used 
#  when designing the object.  Given this information it is possible to combine objects designed at different times by 
#  different people at different resolutions and reuse the components.  It effectively makes the embedded coordinates 
#  proportional coordinates.
#  @param Parent ScreenDefinition: The parent ScreenDefinition.  It will be set on all objects returned from the StormTest API and should
#  be set on objects passed into the StormTest API (but the API is tolerant of users who forget to set the Parent or choose 
#  not to set it).
#
#  @param Verify Boolean: A bool to indicate whether the region is for verification purposes (True) or just reading (False).
#
#  @param PassOnNoMatch Boolean: A bool, defaulting to False, which allows the reversal of the condition - that is, the 'pass'
#  status is when the custom algorithm cannot verify the region.  This property is ignored if Verify is False.
#
#  @param ReturnScreenImage ReturnScreen: An enumerated type to indicate whether the return should include the full screen at the end
#  of the custom algorithm.  It is an enumeration of type ReturnScreen.  The default is Inherit which means
#  the image return will be controlled by the enclosing ScreenDefinition
#
#  @param CustomInput object : The algorithm may define input parameters.  These can be discovered at run time (via dir()) but should
#  also be documented by the algorithm writer.  See the example of the constructor to use the custom input properties.
#
#  @param VerifyStatus Boolean: The output of the verification process.  It will be True if this object's verification criteria passed, 
#  else False.  If Verify is False then it is True as nothing can fail.
#
#  @param Image StormTestImageObject: This is a StormTestImageObject holding the image of the region used for the custom algorithm. The exact
#  meaning of this is determined by the custom algorithm
#  It can be None.  The table below summarises when this property is not None
#  @htmlonly
#  <TABLE ALIGN="center" BORDER=1 CELLSPACING=0 CELLPADDING=5>
#  <TR ALIGN="left" VALIGN="middle">
#    <TH>ReturnScreenImage value</TH>
#    <TH>Condition for Image to be not None</TH>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>Always</td><td>Always</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>Never</td><td>Never</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>OnSuccess</td><td>VerifyStatus is True</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>OnFail</td><td>VerifyStatus is False</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>Inherit</td><td>Depends on enclosing ScreenDefinition. If no such parent, then as per OnFail</td>
#  </TR>
#  </Table>
#  @endhtmlonly
#
#  @latexonly
#  \begin{center}
#  \begin{tabular}{ | l | r | }
#  \hline
#  ReturnScreenImage value & Condition for Image to be not None \\ \hline\hline
#  Always & Always \\
#  Never & Never \\
#  OnSuccess & VerifyStatus is True \\
#  OnFail & VerifyStatus is False \\
#  Inherit & Depends on enclosing ScreenDefinition. If no such parent, then as per OnFail \\
#  \hline
#  \end{tabular}
#  \end{center}
#  @endlatexonly
#
#  @param CustomOutput object : The algorithm may define output parameters.  These can be discovered at run time (via dir()) but should
#  also be documented by the algorithm writer.  See the example of the constructor to use the custom input properties.
#
class CustomRegion(object):
    __handle = None
    __cache = {}
    __closed = False

    def __getattr__(self, attr):
        self.__checkObject()
        return Sdo.GetObjectProperty(self.__handle, self.__cache, attr)

    def __setattr__(self, attr, value):
        if attr == "__handle":
            self.__handle = value
        elif attr.startswith("_CustomRegion__"):
            object.__setattr__(self, attr, value)
        else:
            self.__checkObject()
            Sdo.SetObjectProperty("CustomRegion", self.__cache, attr, value)

    def __checkObject(self):
        """
        Check the object's state.  A sanity check.
        """
        if self.__closed:
            raise StormTestExceptions("you can't access a CustomRegion object after calling Close() on it")
        elif self.__handle is None:
            self.__handle = Sdo.CustomRegionCreate()
        # else we are OK so do nothing

    def __resetObject(self, handle):
        """
        Reinitializes with a new object
        """
        tempAscii = self.__cache["__asciiNames"]
        tempInput = self.__cache["__inputPropertyNames"]
        tempOutput = self.__cache["__outputPropertyNames"]
        Sdo.CustomRegionClose(self.__handle, self.__cache)
        self.__handle = handle
        self.__cache = {}
        self.__cache["__asciiNames"] = tempAscii
        self.__cache["__inputPropertyNames"] = tempInput
        self.__cache["__outputPropertyNames"] = tempOutput
        self.__closed = False


    ## @par Description
    # The constructor makes a CustomRegion object.
    # @param[in] descriptor @b AlgorithmDescripor : The type of algorithm to use in the custom region
    # @param[in] name @b String : Sets the Name property of the constructed region
    # @param[in] verify @b Boolean : Sets the Verify property of the constructed region
    # @return @e CustomRegion : The CustomRegion object
    #  @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>algorithms = ScreenDefinition.GetExtensionAlgorithms()
    # >>region = CustomRegion(algorithms[0], "epg screen")      # This is not totally useful as we don't know what algorithm will be used.
    # >>region.EpgText = "EPG OK"                               # The EpgText is a custom input property (hopefully)
    # >>region.EpgSize = [500,60]                               # Also EpgSize ia a custom input property
    # ...
    # >>print(str(region.ActualSize))                           # ActualSize ia a custom output property
    # >>[]
    # @endcode
    def __init__(self, descriptor, name='', verify=True):
        """
        Ctor to set all defaults of the CustomRegion object
        """
        self.__handle = None
        self.__cache = {}
        self.__closed = False
        self.Descriptor = descriptor
        self.Name = name
        self.Verify = verify
        Sdo.CustomRegionSetDescriptor(self.__handle, self.__cache, descriptor)

    ## @par Description
    # The CustomRegion has a finalizer as a last resort clean up when the object goes out of scope.
    # Normally the CustomRegion is part of a ScreenDefinition - in that case, you don't need to take
    # any precautions over CustomRegion clean up - the owning ScreenDefinition manages it.  If you
    # create 'orphaned' CustomRegions, see the Close() method.
    # @param None
    # @return @e None
    def __del__(self):
        # finalizer
        self.Close()

    def __dir__(self):
        return Sdo.CustomRegionDir(list(CustomRegion.__dict__.keys()), self.__cache)


    ## @par Description
    # Cleans up the CustomRegion releasing any internal images.  Do NOT call this if the CustomRegion
    # is owned by a ScreenDefinition - the ScreenDefinition will manage the lifetime and cleanup
    # of all owned objects.
    # However, if you create an orphaned CustomRegion (either directly or by removing it from the
    # ScreenDefinition) then you should call Close() when finished with the object.
    # @param None
    # @return @e None
    #  @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # # This is somewhat contrived example which loads a ScreenDefinition from a file
    # # executes it to get a result and then 'orphans' the CustomRegion (assuming it
    # # is the first region in the screen definition
    # >>>sdo = ScreenDefinition()
    # >>>sdo.Load("file.stscreen")
    # >>>result = WaitScreenDefMatch(sdo, slotNo=4)[0]
    # >>>r = result.Regions[0]
    # >>>result.Regions = []    # now the result sdo has no regions but r is an CustomRegion and 'orphaned'
    # # do stuff with r
    # # this frees the potentially large image in r. Without Close() you would wait for Python to garbage collect it.
    # >>>r.Close()
    # @endcode
    def Close(self):
        Sdo.CustomRegionClose(self.__handle, self.__cache)

        """
        Important to set C# handle to None after closing so as
        to avoid the situation where neither Python nor C# can garbage collect their own
        objects because Python is holding a reference to the C# object.
        """
        self.__handle = None
        self.__cache = {}
        self.__closed = True

    ##  @par Description
    #  This clones a CustomRegion returning an exact copy.
    #  @param None
    #  @return @e CustomRegion: the cloned region.  The original region is unmodified.
    #  @subsubsection _eg1 eg1:
    #  @b Example:
    #  @code
    #  >>>r1 = CustomRegion(descriptor, "a named item")
    #  >>>r2 = r1.Clone()
    #  >>>print(r2.Name)
    #  >>>a named item
    #  @endcode
    def Clone(self):
        """
        This method returns an exact copy of the CustomRegion object.
        """
        self.__checkObject()
        return Sdo.CustomRegionClone(self, self.__handle)



## @par Description
#  The object defines an Sdo Extension algorithm description.  It is NOT the algorithm itself but describes the
#  algorithm in enough detail for a script writer to know if they wish to use the algorithm (if returned from 
#  the system) as well as being able to define an algorithm to use (if it is desired to create a region using a
#  specific algorithm).  This object is available in Release 3.4
class AlgorithmDescriptor(object):

    ## @par Description
    #  The constructor makes an AlgorithmDescriptor.  Use this when you know in advance which algorithm
    #  to use.  The constructor will check the algorithm is on the system and raise an exception if it cannot
    #  find the algorithm requested.  If more than 1 algorithm matches the request an exception is raised.
    #  Omitting a parameter from the constructor sets that parameter to 'any' when searching for algorithms.
    #  @param[in] id @b String : The id of the algorithm.  If you want precise control over the algorithm selected, 
    #  you should set the id to the intended value.
    #  @param[in] name @b String : The name of the algorithm.  This can change between versions and is an unreliable
    #  search criterion.
    #  @param[in] vendor @b String : The vendor of the algorithm.  This is not always specified and is an unreliable
    #  search criterion.
    #  @param[in] version @b String : The version of the algorihm.  This can be used with the id to precisely select
    #  an algorithm.  There is no check for "later version" because the format of the version is unknown to StormTest.
    # @return @e AlgorithmDescriptor : The AlgorithmDescriptor object
    #  @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>>algorithm = AlgorithmDescriptor("12453B27-4736-4EAA-BC92-655DE7716871")
    # >>>algorithm = AlgorithmDescriptor(name = "my algorithm", version = "V 1.0")
    # @endcode
    def __init__(self, id = None, name = None, vendor = None, version = None):

        ## @par Description
        # The name of the algorithm.  This is provided by the algorithm writer and may not be unique
        self.Name = name

        ## @par Description
        # The name of the supplier of the algorithm.  This is optional, if not supplied by the algorithm writer
        # then this will be None
        self.Vendor = vendor

        ## @par Description
        # A unique ID for the algorithm. This is guaranteed to be unique with the facility and if the algorithm
        # writer follows the guidelines then it will be unique across all facilities.
        self.Id = id

        ## @par Description
        # The version of the algorithm. The format and meaning of this is determined by the algorithm writer
        # and is not related to the version of the StormTest Client
        self.Version = version

        ## @par Description
        # A list of aliases of algorithms which are the same as this one and can be used instead of this.  The intended
        # use of this is to allow the algorithm writer to upgrade an algorithm with new features but still have existing 
        # ScreenDefinitions designed for older versions to use the newer version without editing and without having to
        # keep all old extension binaries in place.  If id 'X' appears in the alias list for id 'Y' it means that algorithm
        # 'Y' can also implement all features of algorithm 'X'.  It is likely that algorithm 'X' is no longer on the system.
        # Aliases can be emtpy (and often will be)
        self.Aliases = []
    

## @par Description
#  The object defines the screen.  It is a collection of sub objects which define areas of a 
#  screen and tests to perform.  The tests can involve verification of simply read and return values. A
#  test can in fact be another screen definitino object to construct a hierarchical screen definition.  During execution,
#  all the tests with verification state (Verify property is True) are tested and if all the validation criteria are met 
#  then the read criteria are read.  With the exception of a fatal system type error, a read operation cannot fail.  
#  Where float is specified, an integer can be used.  Where a list is specified, a tuple may be used instead.
#  @param Name String : The name of the screen definition - this is a human readable name.
#  @param Comment String: A general comment.  It is not used by StormTest and is provided for the user.
#  @param DesignSize Tuple: This is a List of 2 float values representing the width and height of the coordinate system used 
#  when designing the screen definition.  Given this information it is possible to combine objects designed at different times by 
#  different people at different resolutions and reuse the components.  It effectively makes the embedded coordinates 
#  proportional coordinates.
#  @param Parent ScreenDefinition: The parent ScreenDefinition.  It is None on the top level screen definition.  It will be set on all 
#  screen defintion sub objects returned from the StormTest API and should be set on objects passed into the StormTest 
#  API (but the API is tolerant of users who forget to set the Parent or choose not to set it).
#
#  @param ReturnScreenImage ReturnScreen: An enumerated type to indicate whether the return should include the full screen 
#  used for the evalutation.  It is an enumeration of type ReturnScreen.  The default is OnFail which means
#  the image will be returned only on a failure.
#
#  @param ModelList List : Read Only.  When the screen definition is loaded from a NamedScreenDefinition then the list of models that the NamedScreenDefinition
#  supported is listed here.  It will be empty for generic NamedScreenDefinition.  This property is for informational purposes.
#
#  @param Regions List : List of regions owned by the screen definition.  The default is empty.  You can add/remove items or replace the list entirely.
#  You should not share a list between screen definitions because this confuses the clean up code.  When the screen definition is executed the types and
#  values of the Regions property are checked - until that moment, you may be able to put erroneous items in the Regions list.
#  
#  @param CoordConverters List : List of CoordConverter objects to perform coordinate conversions.  Each object specifies how to convert
#  coordinates from one size to another.  If any sub objects have a design size different from the captured video size then coordinate transformation
#  must occur.  Default is an empty list. See discussion on how this works @ref _coordtransforms
#  
#  @param VerifyStatus Boolean: The output of the verification process.  It will be True if all of this screen defintions object's verification criteria passed, 
#  else False.
#
#  @param RealTimeTaken Double: A measurement of the real time taken to execute the screen definition object. The value returned is in seconds.   
#
#  @param Image StormTestImageObject: This is a StormTestImageObject holding the image of the region used for evalutation.  If a MotionRegion or
#  an AudioRegion is contained in the screen definition then it will be the last image used for motion detection or audio detection -
#  not the image used for the image, color or OCR tests.  It can be None.  The table below summarises when this property is not None
#  @htmlonly
#  <TABLE ALIGN="center" BORDER=1 CELLSPACING=0 CELLPADDING=5>
#  <TR ALIGN="left" VALIGN="middle">
#    <TH>ReturnScreenImage value</TH>
#    <TH>Condition for Image to be not None</TH>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>Always</td><td>Always</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>Never</td><td>Never</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>OnSuccess</td><td>VerifyStatus is True</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>OnFail</td><td>VerifyStatus is False</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <TD>Inherit</td><td>Depends on enclosing ScreenDefinition. If no such parent, then as per OnFail</td>
#  </TR>
#  </Table>
#  @endhtmlonly
#
#  @latexonly
#  \begin{center}
#  \begin{tabular}{ | l | r | }
#  \hline
#  ReturnScreenImage value & Condition for Image to be not None \\ \hline\hline
#  Always & Always \\
#  Never & Never \\
#  OnSuccess & VerifyStatus is True \\
#  OnFail & VerifyStatus is False \\
#  Inherit & Depends on enclosing ScreenDefinition. If no such parent, then as per OnFail \\
#  \hline
#  \end{tabular}
#  \end{center}
#  @endlatexonly
#
#  @param Errors List : A list of strings holding the errors encountered udring evaluation of the screen definition.
#  These are errors such as a failure to capture an image, invalid parameters detected on the server etc.  They <b>do not</b>
#  include a normal failure to verify a region.  The Errors will be None if no errors are found (the usual condition), else a list
#  of strings (usually only 1 string as the first serious error stops evaluation).  When screen definitions are nested, the outermost
#  screen definition includes all the inner errors as a master list of errors.
class ScreenDefinition(object):
    __handle = None
    __cache = {}
    __closed = False

    def __getattr__(self, attr):
        self.__checkObject()
        return Sdo.GetObjectProperty(self.__handle, self.__cache, attr)

    def __setattr__(self, attr, value):
        if attr == "__handle":
            self.__handle = value
        elif attr.startswith("_ScreenDefinition__"):
            object.__setattr__(self, attr, value)
        else:
            self.__checkObject()
            Sdo.SetObjectProperty("ScreenDef", self.__cache, attr, value)

    ## @par Description
    # The Screen Definition has a finalizer to clean up when the object goes out of scope.  However,
    # you should call Close() when finished with the screen definition.  The finalizer simply calls Close().
    # @param None
    # @return @e None
    def __del__(self):
        # finalizer.  This can not be guaranteed to run if there are circular references.
        self.Close()

    def __dir__(self):
        return Sdo.SdoDir(list(ScreenDefinition.__dict__.keys()))

    def __checkObject(self):
        """
        Check the object's state.  A sanity check.
        """
        if self.__closed:
            raise StormTestExceptions("you can't access a ScreenDefinition object after calling Close() on it")
        elif self.__handle is None:
            self.__handle = Sdo.SdoCreate()

    def __resetObject(self, handle):
        """
        Reinitializes with a new object
        """
        Sdo.SdoClose(self.__handle, self.__cache)
        self.__handle = handle
        self.__cache = {}
        self.__closed = False

    ## @par Description
    # The constructor makes an emtpy screen definition object, ready for you to add regions.
    # @param None
    # @return @e ScreenDefinition : The constructed empty screen definition
    #  @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>>sdo = ScreenDefinition()
    # >>>print(str(len(sdo.Regions)))
    # >>>0
    # @endcode
    def __init__(self):
        """
        Object constructor
        """
        self.__cache = {}
        self.__handle = None
        self.__closed = False

    def __deserialize(self, serializedData):
        Sdo.SdoDeSerialize(self, self.__handle, self.__cache, serializedData)

    ## @par Description
    # This cleans up the screen definition, calling Close() on all the regions. It also disposes of the Image in the
    # screen definition.  After calling Close() any other access to the screen definition, a sub object or an image
    # (even if a reference is held elsewhere) is likely to cause an exception.  This is the key reason why you must not
    # share Regions between screen definitions - the Close() will close the shared list.  If you wish to share data, use the
    # Clone() method on the regions.
    # @param None
    # @return @e None
    #  @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>>sdo = ScreenDefinition()
    # >>>sdo.Close()
    # @endcode
    def Close(self):
        """
        This method cleans up the object, including all sub objects saving memory.  
        The finalizer (sometimes called a destructor) will do the same thing but the timing of the finalizer is not deterministic.  
        """
        Sdo.SdoClose(self.__handle, self.__cache)

        """
        Important to set C# handle to None after closing so as
        to avoid the situation where neither Python nor C# can garbage collect their own
        objects because Python is holding a reference to the C# object.
        """
        self.__handle = None
        self.__cache = {}
        self.__closed = True

    ##  @par Description
    #  Saves the screen definition to a file on the local file system.  If there is an error during save (privilege, disk full etc) then
    #  an exception is thrown.
    #  @param[in] filename @b String : The filename to save to, including extension.  You can use any extension but if you wish to edit
    #  it within StormTest Developer Suite, you @b must use .stscreen as the extension.  The filename can be absolute or relative.  If it
    #  is relative then it is saved relative to the 'images' directory as set by the SetDirectories() and SetProjectDir() functions.  The format
    #  of the file is JSON text with images stored as base64 encoded such that if the base64 is decoded and saved as binary to a file then Windows
    #  can read the file correctly.
    #  @return @e None
    #  @subsubsection _eg1 eg1:
    #  @b Example:
    #  @code
    #  >>>sdo = ScreenDefinition()
    #  >>>sdo.Save("mysdo.stscreen")
    #  >>>sdo.Save("c:\\users\\me\\mysdo.stscreen")
    #  @endcode
    def Save(self, filename):
        """
        Saves the object to a file on the file system.
        If there is an error during save (privilege, disk full etc) then an exception is thrown.  
        The filename can be absolute or relative.  If relative then it is relative to the ‘images’ directory as set by the SetDirectories() and SetProjectDir() functions.
        """
        self.__checkObject()
        Sdo.SdoSave(self, self.__handle, filename)

    ## @par Description
    #  Serializes the screen definition to a string.  The format is the same as Save(). You could use Serialize and then choose how/when to save
    #  the screen definition using normal python code.
    #  @param None
    #  @return @e string : The serialized data
    #  @subsubsection _eg1 eg1:
    #  @b Example:
    #  @code
    #  >>>sdo = ScreenDefintion()
    #  >>>s = sdo.Serialize()
    #  @endcode
    def Serialize(self):
        """
        Converts the object to a JSON string (same as Save() would but without saving to the file system).
        """
        self.__checkObject()
        return Sdo.SdoSerialize(self, self.__handle)

    ## @par Description
    #  De-Serializes a string into the screen definition.  It reverses Serialize()
    #  @param[in] jsonData @b String : the serialized data (from Serialize or other source)
    #  @return @e None
    #  @subsubsection _eg1 eg1:
    #  @b Example:
    #  @code
    #  >>>sdo = ScreenDefintion()
    #  >>>s = sdo.Serialize()
    #  >>>sdo2 = ScreenDefintion()
    #  >>>sdo2.DeSerialize(s)
    #  @endcode
    def DeSerialize(self, jsonData):
        Sdo.SdoDeSerialize(self, self.__handle, self.__cache, jsonData)

    ## @par Description
    #  Loads the screen definiton from the specified filename, destroying all the contents of the pre existing screen definition object.  If there
    #  is an error loading the file, then and exception si thrown and the object is in an indeterminate state (Close() will work to clean it up).  It should
    #  be noted that even on a non-existent file, the user @b cannot assume the object was unchanged and can still be used.
    #  @param[in] filename @b String : The file name to load the screen definition from.  It can be absolute or relative and if relative then it is relative to
    #  the 'images' directory as set by the SetDirectories() and SetProjectDir() functions.
    #  @return @e None
    #  @subsubsection _eg1 eg1:
    #  @b Example:
    #  @code
    #  >>>sdo = ScreenDefintion()
    #  >>>sdo.Load("mysdo.stscreen")
    #  @endcode
    def Load(self, filename):
        """
        Loads the specified filename and populates the ScreenDefiniton object with the content of the file, destroying everything already in the object.
        If there is an error during loading (privilege, file not exist etc) then an exception is thrown and the object is in an indeterminate state.  
        In particular, even on a non-existent file, the user cannot assume the object is unchanged and can be used.  
        The filename can be absolute or relative.  
        If relative then it is relative to the ‘images’ directory as set by the SetDirectories() and SetProjectDir() functions.
        """
        Sdo.SdoLoad(self, self.__handle, self.__cache, filename)


    ##  @par Description
    #  This clones a ScreenDefiniton object returning an exact copy.  All sub regions are also cloned.  This is a
    #  'deep copy'.
    #  @param None
    #  @return @e ScreenDefinition: the cloned screen definition.  The original screen definition is unmodified.
    #  @subsubsection _eg1 eg1:
    #  @b Example:
    #  @code
    #  >>>sdo = ScreenDefinition()
    #  >>>sdo.Regions.append(ImageRegion())
    #  >>>print(str(len(sdo.Regions)))
    #  >>>1
    #  >>>sdo2 = sdo.Clone()
    #  >>>sdo.Regions.append(OCRRegion())
    #  >>>print(str((len(sdo.Regions), len(sdo2.Regions))))
    #  >>>(2, 1)
    #  @endcode
    def Clone(self):
        """
        This method returns an exact deep copy of the object.  All images are duplicated.  NamedRegions etc are also copied.  
        It is fully recursive so if called on a ScreenDefinition object all sub objects are also cloned via their Clone() method.
        """
        self.__checkObject()
        return Sdo.SdoClone(self, self.__handle)

    ## @par Description
    #  This is the same as WriteNamedScreenDefinition but provides an instance method (in fact the WriteNamedScreenDefinition is
    #  implemented as a call to ToNamedResource).
    #  path is always case sensitive and SetNamedResourceMatchCase is ignored.
    #  There is no requirement for the path to end in the same name as the embedded name of the screenDefinition.
    #  Likewise the comment is not related to the embedded comment property.
    #
    #  @param[in] path @b String: the full absolute path to the screen definition (may begin with a / but not necessary),
    #  path elements separated by /.  Final element is the screen definition name in the database.
    #  @param[in] comment @b String: (optional) Free form text of a user defined comment.
    #  @param[in] dutModelId @b Integer, String or List : The model for which the data is to be written.  The integer
    #  value of 0 means the generic model only will be created/updated.  It can also be an explicit model number, a string
    #  representing a single model or a list of strings representing multiple models.
    #  @return @e None : An exception is thrown on an error (for example bad parameters, no communication).
    #  @subsubsection _eg1 eg1:
    #  @b Example:
    #  @code
    #  >>>sdo = ScreenDefinition()
    #  >>>sdo.ToNamedResource('myprojects/empty sdo')
    #  @endcode
    def ToNamedResource(self, path, comment=None, dutModelId=0):
        """
        This is a synonym for WriteScreenDefinition(path, screenDef, comment, dutModelId=0) and provides an instance method for convenience. 
        """
        self.__checkObject()
        data = Sdo.SdoSerialize(self, self.__handle)
        stormtest_client.stc.write_named_screen_definition(path, data, comment, dutModelId)


    ## @par Description
    #  Executes the verification stages of the screen definiton  until they pass, then executes the read stages.
    #  On a failure, a wait of waitGap occurs between retries and if the time taken exceeds timeToWait then the call returns.
    #  @param[in] timeToWait @b Float : Optional. The maximum time to wait in seconds for the VerifyStatus of the screen definition to become true.  Default is 5 seconds.
    #  @param[in] waitGap @b Float : Optional. The time between successive attempts at verification in seconds. This is the time to wait after a failure before trying again.
    #  @param[in] slotNo @b Integer : Optional.  The slot to use for the evaluation of the screen definition object.  If slotNo is non zero then all reserved slots are used.
    #  @return @e List : If slotNo is non zero then the returned list is [screen definition, time waited,  number of captures made].  If slotNo is zero then the return is a
    #  list of lists, each sub list being [slotNo, [screen definition, time waited, number of captures made]]
    #  @note that in all cases the execution time may exceed timeToWait. For example the 4th test at time 4.5 seconds fails so the code waits 1 second, tries again at 5.5 seconds and passes.
    #  @note If the screenDef includes a motion detection region with a long timeout then the overall timeToWait may need to be adjusted upwards if failures are anticipated and retries are desired.
    #  The returned screenDefinition is a @b copy of the input with output fields filled in.  The original input screen not altered in any way and can thus be reused in many API calls.
    #  @subsubsection _eg1 eg1:
    #  @b Example:
    #  @code
    #  >>>sdo.WaitMatch(4, 0.1)
    #  >>>[[5,[<ClientAPI.ScreenDefinition object>, 1.2388, 4]]]
    #  >>>sdo.WaitMatch(slotNo=5)
    #  >>>[<ClientAPI.ScreenDefinition object>, 1.2388, 6]
    #  @endcode
    def WaitMatch(self, timeToWait=5, waitGap=1, slotNo=0):
        """
        This is the same as calling WaitScreenDefMatch() with the current object as the screen definition object.  
        It returns a copy of this object and does not modify the source object.
        """
        self.__checkObject()
        return Sdo.SdoWaitMatch(self, self.__handle, timeToWait, waitGap, slotNo)


    ## @par Description
    #  Executes the verification stages of the screen definiton  until one of them fails.  This means the screen on the DUT no longer matches
    #  the screen definition object.  On a pass, a wait of waitGap occurs between retries and if the time taken exceeds timeToWait then the call returns.  Whenever
    #  the verification stages pass, the read stages are executed.  This can result in unnecessary reads so the user should ise this function with screen definitions
    #  whcih have either no read regsions or fast to execute read regions (such as ColorRegion and ImageRegion).  OCRRegions with Verify as False should be avoided because
    #  they take time and use up OCR license characters.  The purpose of the function is to wait until the DUT screen changes away from a known state where you don't care
    #  what happens next so long as something happens.
    #  @param[in] timeToWait @b Float : Optional. The maximum time to wait in seconds for the VerifyStatus of the screen definition to become false.  Default is 5 seconds.
    #  @param[in] waitGap @b Float : Optional. The time between successive attempts at non verification in seconds. This is the time to wait after a success before trying again.
    #  @param[in] slotNo @b Integer : Optional.  The slot to use for the evaluation of the screen definition object.  If slotNo is non zero then all reserved slots are used.
    #  @return @e List : If slotNo is non zero then the returned list is [screen definition, time waited,  number of captures made].  If slotNo is zero then the return is a
    #  list of lists, each sub list being [slotNo, [screen definition, time waited, number of captures made]]
    #  @note that in all cases the execution time may exceed timeToWait. For example the 4th test at time 4.5 seconds passes so the code waits 1 second, tries again at 5.5 seconds and fails.
    #  @note If the screenDef includes a motion detection region with a long timeout then the overall timeToWait may need to be adjusted upwards if successes are anticipated and retries are desired.
    #  The returned screenDefinition is a @b copy of the input with output fields filled in.  The original input screen not altered in any way and can thus be reused in many API calls.
    #  @subsubsection _eg1 eg1:
    #  @b Example:
    #  @code
    #  >>>sdo.WaitNoMatch(4, 0.1)
    #  >>>[[5,[<ClientAPI.ScreenDefinition object>, 1.2388, 4]]]
    #  >>>sdo.WaitNoMatch(slotNo=5)
    #  >>>[<ClientAPI.ScreenDefinition object>, 1.2388, 6]
    #  @endcode
    def WaitNoMatch(self, timeToWait=5, waitGap=1, slotNo=0):
        """
        This is the same as calling WaitScreenDefNoMatch() with the current object as the screen definition object.
        It returns a copy of this object and does not modify the source object.
        """
        self.__checkObject()
        return Sdo.SdoWaitNoMatch(self, self.__handle, timeToWait, waitGap, slotNo)


    ##  @par Description
    #  The runs a single evaluation of the screen definition on a slot or an image (depending on the parameter supplied).
    #  @param[in] whatToMatch @b Pillow Image, StormTestImageObject, NamedImage or String: The image to use for matching.  If this is 0 (the integer value 0)
    #  then this is functionally equivalent to calling WaitMatch(0, 0, slotNo) but with a simplified return value.  If whatToMatch
    #  is a valid image then an evaluation occurs using that image.  In this case, MotionRegions and AudioRegions in the screen
    #  definition will result in a StormTestExceptions being raised as it is impossible to detect motion or audio in a single image.
    #  If whatToMatch is a string then it is assumed to be a file and an image will be loaded using the same semantics as the 
    #  StormTestImageObject.FromFile() method. This option is available on Release 3.3.3 and later.
    #  @param[in] slotNo @b Integer : The slot number to use for evaluation when whatToMatch is 0.  If whatToMatch is an image (or string) then
    #  the slotNo is used to determine how resources are resolved.  If slotNo is 0 then generic resources are used, otherwise resources
    #  for the specific model in the specified slot are used.  There is no requirement here that the specified slot is reserved when using
    #  this method on an image (however some slot must be reserved for the server to accept the request).
    #  @return @e ScreenDefinition or List : If whatToMatch is 0 and slotNo is non zero then a single ScreenDefinition is returned. If
    #  whatToMatch is 0 and slotNo is 0 then a List is returned.  Each item in the list is a list of [slotNo, ScreenDefinition] where slotNo
    #  is the reserved slot.  If whatToMatch is an image then the retuen is a ScreenDefinition.  In all cases the returned ScreenDefinition is
    #  a copy and the original screen definition is unchanged.
    #  @subsubsection _eg1 eg1:
    #  @b Example:
    #  @code
    #  >>>sdo = ScreenDefinition()
    #  >>>print(str(sdo.Match(0, 0)))
    #  >>>[[4, <ClientAPI.ScreenDefinition object>], [5, <ClientAPI.ScreenDefinition object>]]
    #  >>>print(str(sdo.Match(0, 4)))
    #  >>><ClientAPI.ScreenDefinition object>
    #  >>>im = Image.open("c:\\users\\me\\myimg.png")
    #  >>>print(str(sdo.Match(im)))        # use generic lookup of resources
    #  >>><ClientAPI.ScreenDefinition object>
    #  >>>print(str(sdo.Match(im, 7)))     # use resources for dut model in slot 7
    #  >>><ClientAPI.ScreenDefinition object>
    #  >>>print(str(sdo.Match("c:\\users\\me\\myimg.png")))  # read a file and use generic lookup of resources
    #  >>><ClientAPI.ScreenDefinition object>
    #  @endcode
    def Match(self, whatToMatch=0, slotNo=0):
        """
        if whatToMatch is an integer, the behavior and return is identical to calling MatchScreenDef(self, whatToMatch).  
        If whatToMatch is an image (Pillow, StormTestObject, string) then the behavior  and return is identical to calling MatchScreenDefImage(self, whatToMatch).
        In every case the returned screen definition is a copy of this object.
        """
        self.__checkObject()
        matchImageFromFile = False
        if isinstance(whatToMatch, str):
            matchImageFromFile = True
            whatToMatch = stormtest_client.Imaging.StormTestImageObject.FromFile(whatToMatch)
        result = None
        try:
            result = Sdo.SdoMatch(self, self.__handle, whatToMatch, slotNo)
        finally:
            if matchImageFromFile:
                whatToMatch.Close()
        return result

    ## @par Description
    #  Evaluates the screen definition over one or more arbitrary frames captured from the high speed timer.  The screen definition
    #  cannot contain a MotionRegion or an AudioRegion and a StormTestExceptions exception is raised if it does.
    #  @param[in] frameIndex @b Integer or List : The frame of frames to test.  It can be a single integer for a single
    #  frame test or a list of integers.  If a list then multiple tests are performed.  Frame indexes are zero based.
    #  @param[in] slotNo @b Integer : Optional. The slot number.  There must have been a prior execution of the high speed timer on this slot
    #  with frames captured.
    #  @return @e ScreenDefinition or List : see example code for the combinations of return types and input parameters.
    #  @note There is no requirement for any particular order of frames with specifying a list: [6, 10, 56] is as valid as [99, 3, 78].
    #  @subsubsection _eg1 eg1:
    #  @b Example:
    #  @code
    #  >>>ReserveVideoTimer()
    #  >>>EnableCaptureZapFrames()
    #  >>>TriggerHighSpeedTimer()
    #  >>>WaitSec(5)
    #  >>>StopHighSpeedTimer()
    #  # now we can work on the zap frames
    #  >>>sdo = ScreenDefinition()
    #  >>>sdo.Load("c:\\users\\me\\mysdo.stscreen")
    #  >>>print(str(sdo.TestRawZapFrames(5, slotNo=1)))
    #  >>><ClientAPI.ScreenDefinition object>
    #  >>>print(str(sdo.TestRawZapFrames([6,7,8], slotNo=1)))
    #  >>>[(6, <ClientAPI.ScreenDefinition object>), (7, <ClientAPI.ScreenDefinition object>),(8, <ClientAPI.ScreenDefinition object>)]
    #  >>>print(str(sdo.TestRawZapFrames(5)))
    #  >>>[[1,<ClientAPI.ScreenDefinition object>]]
    #  >>>print(str(sdo.TestRawZapFrames([6,7,8])))
    #  >>>[[1, [(6, <ClientAPI.ScreenDefinition object>), (7, <ClientAPI.ScreenDefinition object>),(8, <ClientAPI.ScreenDefinition object>)]]]
    #  @endcode
    def TestRawZapFrames(self, frameIndex, slotNo=0):
        self.__checkObject()
        return Sdo.SdoTestRawZapFrames(self, self.__handle, frameIndex, slotNo)

    ## @par Description
    #  Evaluates the screen definition over a range of contiguous previously captured frames from the high speed timer looking for
    #  a match of the screen definition (VerifyStatus returned as True).  A MotionRegion may be used in the screen definition - it will only
    #  examine frames up to the last specified in the range.
    #  AudioRegion is not supported as no audio is captured by the high speed timer.
    #  @param[in] startIndex @b Integer : Zero based start frame to scan for screen definition match.
    #  @param[in] maxFrames @b Integer : The maximum number of frames to scan for a match.
    #  @param[in] slotNo @b Integer : Optional.  The slot number.  There must have been a prior execution of the high speed timer on this slot
    #  with frames captured. If omitted or 0 then the scan occurs on all reserved slots.
    #  @param[in] algorithm @b String : Allows an alternative algorithm to be used, it can be "default" or "binarysearch" (introduced in release 3.5.5).
    #  @return @e Tuple : If slotNo is non zero then a tuple of ScreenDefinition that matched and index where a match was found.  If slotNo is zero
    #  then a List of slot, tuples.  If no match is found then the matched frame is None instead of an Integer.
    #  @note The "default" algorithm searches for an SDO match in the captured frames IN SEQUENCE so it will find the first point at which an SDO matches,
    #  whereas the "binarysearch" algorithm keeps bisecting the search area until the frame at which the SDO match occurs is found.
    #  This assumes that the SDO transitions from not matching to matching at one point only in the captured images, otherwise it won't work.
    #  In these cases, "binarysearch" can provide a significant improvement in the execution time of FindRawZapMatch, particularly if the SDO has an OCR test.
    #  @note With the "default" algorithm, the operation of the motion region can be confusing regarding the return value from FindRawZapMatch.  If you specify a timeout on the
    #  motion region of, for example, 10 seconds then FindRawZapMatch starts at startIndex and looks for motion within 10 seconds of that point.  If
    #  motion is found in the 10 seconds then startIndex will be returned.  If no motion is found then FindRawZapMatch starts at startIndex + 1 and 
    #  searches for 10 seconds.  If motion is found then startIndex + 1 is returned.  If no motion is found then the process is repeated until startIndex +
    #  maxFrames is reached.   If you wish to measure @b when motion starts after a static picture then you should set the timeout on the motion region to
    #  be large, verify that startIndex is returned from FindRawZapMatch and examine the ImagesCompared property of the returned MotionRegion - this will
    #  tell you how many images were needed to find motion and thus how long before motion started.  The ImagesCompared property is new in release 3.2.6
    #  With the "binarysearch" algorithm, a motion region within the SDO will be altered - its timeout is set to zero so that it will only test 2 frames at a time.
    #  This is necessary to allow "binarysearch" to test at different points in the sequence of captured images.
    #  @subsubsection _eg1 eg1:
    #  @b Example:
    #  @code
    #  >>>ReserveVideoTimer()
    #  >>>EnableCaptureZapFrames()
    #  >>>TriggerHighSpeedTimer()
    #  >>>WaitSec(5)
    #  >>>StopHighSpeedTimer()
    #  # now we can work on the zap frames
    #  >>>sdo = ScreenDefinition()
    #  >>>sdo.Load("c:\\users\\me\\mysdo.stscreen")
    #  >>>print(str(sdo.FindRawZapMatch(0, 25, slotNo=6)))
    #  >>>(<ClientAPI.ScreenDefinition object>, 12)
    #  >>>print(str(sdo.FindRawZapMatch(25, 100)))
    #  >>>[[6, (<ClientAPI.ScreenDefinition object>, None)]]
    #  @endcode
    def FindRawZapMatch(self, startIndex, maxFrames, slotNo=0, algorithm='default'):
        self.__checkObject()
        return Sdo.FindRawZapMatch(self, self.__handle, startIndex, maxFrames, slotNo, algorithm)

    ## @par Description
    #  Evaluates the screen definition over a range of contiguous previously captured frames from the high speed timer looking for
    #  a NON match of the screen definition (VerifyStatus returned as False).  A MotionRegion may be used in the screen definition - it will only
    #  examine frames up to the last specified in the range.
    #  AudioRegion is not supported as no audio is captured by the high speed timer.
    #  @param[in] startIndex @b Integer : Zero based start frame to scan for screen definition non match.
    #  @param[in] maxFrames @b Integer : The maximum number of frames to scan for a non match.
    #  @param[in] slotNo @b Integer : Optional.  The slot number.  There must have been a prior execution of the high speed timer on this slot
    #  with frames captured. If omitted or 0 then the scan occurs on all reserved slots.
    #  @param[in] algorithm @b String : Allows an alternative algorithm to be used, it can be "default" or "binarysearch" (introduced in release 3.5.5).
    #  @return @e Tuple : If slotNo is non zero then a tuple of ScreenDefinition that failed to match and index where the match was not found.  If slotNo is zero
    #  then a List of slot, tuples.  If all frames match then the matched frame is None instead of an Integer.
    #  @note See FindRawZapMatch documentation for notes on "default" and "binarysearch" algorithms - those apply equally to FindRawZapNoMatch.
    #  @subsubsection _eg1 eg1:
    #  @b Example:
    #  @code
    #  >>>ReserveVideoTimer()
    #  >>>EnableCaptureZapFrames()
    #  >>>TriggerHighSpeedTimer()
    #  >>>WaitSec(5)
    #  >>>StopHighSpeedTimer()
    #  # now we can work on the zap frames
    #  >>>sdo = ScreenDefinition()
    #  >>>sdo.Load("c:\\users\\me\\mysdo.stscreen")
    #  >>>print(str(sdo.FindRawZapNoMatch(0, 25, slotNo=6)))
    #  >>>(<ClientAPI.ScreenDefinition object>, 12)
    #  >>>print(str(sdo.FindRawZapNoMatch(25, 100)))
    #  >>>[[6, (<ClientAPI.ScreenDefinition object>, None)]]
    #  @endcode
    def FindRawZapNoMatch(self, startIndex, maxFrames, slotNo=0, algorithm='default'):
        self.__checkObject()
        return Sdo.FindRawZapNoMatch(self, self.__handle, startIndex, maxFrames, slotNo, algorithm)

    ## @par Description
    #  Gets the list of Sdo Extension Algorithms installed on the config server being used by the Script.  This is a live read of the
    #  list of algorithms - if an administrator is adding or removing algorithms while a script is running, this will be reflected in
    #  the result of this method.  Getting the list can also be time consuming, requiring a round trip on the network so script writers
    #  are advised to cache the result in a variable unless live updates are needed.
    #  This method is available in Release 3.4
    #  @param None
    #  @return @e List : Each item in the list is an AlgorithmDescriptor describing one SdoExtension algorithm.  If no extensions
    #  are installed then the result is an empty list.
    #  @subsection _eg1 eg1:
    #  @b Example:
    #  @code
    #  >>>print(str(ScreenDefinition.GetExtensionAlgorithms()))
    #  >>>[<ClientAPI.AlgorithmDescriptor object>, <ClientAPI.AlgorithmDescriptor object>]
    #  >>>algorithms = ScreenDefinition.GetExtensionAlgorithms() 
    #  >>>print(str((algorithms[0].Id, algorithms[0].Name, algorithms[0].Version)))
    #  >>>("12453B27-4736-4EAA-BC92-655DE7716871", "My Algorithm", "V1.0")
    #  @endcode
    @staticmethod
    def GetExtensionAlgorithms():
        return Sdo.GetExtensionAlgorithms()

## @par Description
#  Evaluates the screenDef.  It is implemented as a call to ScreenDefinition.WaitMatch.
#  
#  WaitScreenDefMatch(sdo, waitTime, waitGap, slotNo) is identical to sdo.WaitMatch(waitTime, waitGap, slotNo)
#  including the return values and types.
#  @param[in] screenDef @b ScreenDefinition : The screen definition object to evaluate
#  @param[in] timeToWait @b Float : Optional. The maximum time to wait in seconds for the VerifyStatus of the screen definition to become true.  Default is 5 seconds.
#  @param[in] waitGap @b Float : Optional. The time between successive attempts at verification in seconds. This is the time to wait after a failure before trying again.
#  @param[in] slotNo @b Integer : Optional.  The slot to use for the evaluation of the screen definition object.  If slotNo is non zero then all reserved slots are used.
#  @return @e List : If slotNo is non zero then the returned list is [screen definition, time waited,  number of captures made].  If slotNo is zero then the return is a 
#  list of lists, each sub list being [slotNo, screen definition, time waited, number of captures made]
#  @bExample:
#  @code
#  >>>WaitScreenDefMatch(sdo, 4, 0.1)
#  >>>[[5, <ClientAPI.ScreenDefinition object>, 1.2388, 4]]
#  >>>WaitScreenDefMatch(sdo, slotNo=5)
#  >>>[<ClientAPI.ScreenDefinition object>, 1.2388, 6]
#  @endcode
@ApiFunction
def WaitScreenDefMatch(screenDef, timeToWait=5, waitGap=1, slotNo=0):
    return screenDef.WaitMatch(timeToWait, waitGap, slotNo)

## @par Description
#  Evaluates the screenDef.  It is implemented as a call to ScreenDefinition.WaitNoMatch.
#  
#  WaitScreenDefNoMatch(sdo, waitTime, waitGap, slotNo) is identical to sdo.WaitNoMatch(waitTime, waitGap, slotNo)
#  including the return values and types.
#  @param[in] screenDef @b ScreenDefinition : The screen definition object to evaluate
#  @param[in] timeToWait @b Float : Optional. The maximum time to wait in seconds for the VerifyStatus of the screen definition to become false.  Default is 5 seconds.
#  @param[in] waitGap @b Float : Optional. The time between successive attempts at non verification in seconds. This is the time to wait after a success before trying again.
#  @param[in] slotNo @b Integer : Optional.  The slot to use for the evaluation of the screen definition object.  If slotNo is non zero then all reserved slots are used.
#  @return @e List : If slotNo is non zero then the returned list is [screen definition, time waited,  number of captures made].  If slotNo is zero then the return is a 
#  list of lists, each sub list being [slotNo, screen definition, time waited, number of captures made]
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>WaitScreenDefNoMatch(sdo, 4, 0.1)
#  >>>[[5, <ClientAPI.ScreenDefinition object>, 1.2388, 4]]
#  >>>WaitScreenDefNoMatch(sdo, slotNo=5)
#  >>>[<ClientAPI.ScreenDefinition object>, 1.2388, 6]
#  @endcode
@ApiFunction
def WaitScreenDefNoMatch(screenDef, timeToWait=5, waitGap=1, slotNo=0):
    return screenDef.WaitNoMatch(timeToWait, waitGap, slotNo)

## @par Description
#  Captures an image from the slot and executes the verification stage of screenDef once.
#  It is implemented as a call to ScreenDefinition.Match.
#
#  ScreenDefMatch(sdo, slotNo) is identical to sdo.Match(0, slotNo) including the return values and types.
#  @param[in] screenDef @b ScreenDefinition : The screen definition object to evaluate
#  @param[in] slotNo @b Integer : Optional. The slot number to use for evaluation.
#  @return @e ScreenDefinition or List : If slotNo is non zero then a single ScreenDefinition is returned, otherwise a List is returned.
#  Each item in the list is a list of [slotNo, ScreenDefinition] where slotNo is the reserved slot.  In all cases the returned ScreenDefinition is
#  a copy and the original screen definition is unchanged.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>sdo = ScreenDefinition()
#  >>>print(str(ScreenDefMatch(4)))
#  >>><ClientAPI.ScreenDefinition object>
#  >>>print(str(ScreenDefMatch()))
#  >>>[[4, <ClientAPI.ScreenDefinition object>], [5, <ClientAPI.ScreenDefinition object>]]
#  @endcode
@ApiFunction
def ScreenDefMatch(screenDef, slotNo=0):
    return screenDef.Match(0, slotNo)


## @par Description
#  Executes the verification stages of screenDef on the image and if that passes, executes the read stages.  
#  The image may be a StormTestImageObject, Pillow image, NamedImage or String.
#  The screenDef cannot include any MotionRegions or AudioRegions as they cannot be evaluated on an image.
#  A StormTestExceptions exception is thrown if either of those region types are present.
#  It is implemented as a call to ScreenDefinition.Match.
# 
#  ScreenDefMatchImage(sdo, im, slotNo) is identical to sdo.Match(im, slotNo) including the return values and types.
#  @param[in] screenDef @b ScreenDefinition : The screen definition object to evaluate
#  @param[in] image @b Pillow Image, StormTestImageObject, NamedImage or String : The image to use for matching. If a string is used
#  then it is assumed to be a file and will be loaded using the same semantics as the StormTestImageObject.FromFile() 
#  method. This option is available on Release 3.3.3 and later.
#  @param[in] slotNo @b Integer : The slotNo is used to determine how resources are resolved.  If slotNo is 0 then generic 
#  resources are used, otherwise resources for the specific model in the specified slot are used.  There is no requirement here 
#  that the specified slot is reserved when using this method on an image (however some slot must be reserved for the server to 
#  accept the request).
#  @return @e ScreenDefinition : The processed ScreenDefinition as a copy and the original screen definition is unchanged.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>sdo = ScreenDefinition()
#  >>>im = Image.open("c:\\users\\me\\myimg.png")
#  >>>print(str(ScreenDefMatchImage(sdo, im)))          # use generic lookup of resources
#  >>><ClientAPI.ScreenDefinition object>
#  >>>print(str(ScreenDefMatchImage(sdo, im, 7)))       # use resources for dut model in slot 7
#  >>><ClientAPI.ScreenDefinition object>
#  >>>print(str(ScreenDefMatchImage(sdo, "c:\\users\\me\\myimg.png")))
#  >>><ClientAPI.ScreenDefintion object>
#  @endcode
@ApiFunction
def ScreenDefMatchImage(screenDef, image, slotNo=0):
    if isinstance(image, int):
        raise StormTestExceptions("Non image passed to ScreenDefMatchImage")
    return screenDef.Match(image, slotNo)


## @par Description
#  Evaluates the screen definition over one or more arbitrary frames captured from the high speed timer.  The screen definition
#  cannot contain a MotionRegion or an AudioRegion and a StormTestExceptions exception is raised if it does.
#  
#  It is implemented as a call to ScreenDefinition.TestRawZapFrames.
#
#  TestRawZapFrames(sdo, frameIndex, slotNo) is identical to sdo.TestRawZapFrames(frameIndex, slotNo)  including the return values and types.
#  @param[in] screenDef @b ScreenDefinition : The screen definition object to evaluate
#  @param[in] frameIndex @b Integer or List : The frame of frames to test.  It can be a single integer for a single
#  frame test or a list of integers.  If a list then multiple tests are performed.  Frame indexes are zero based.
#  @param[in] slotNo @b Integer : Optional. The slot number.  There must have been a prior execution of the high speed timer on this slot
#  with frames captured.
#  @return @e ScreenDefinition or List : see example code for the combinations of return types and input parameters.
#  @note There is no requirement for any particular order of frames with specifying a list: [6, 10, 56] is as valid as [99, 3, 78].
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>ReserveVideoTimer()
#  >>>EnableCaptureZapFrames()
#  >>>TriggerHighSpeedTimer()
#  >>>WaitSec(5)
#  >>>StopHighSpeedTimer()
#  # now we can work on the zap frames
#  >>>sdo = ScreenDefinition()
#  >>>sdo.Load("c:\\users\\me\\mysdo.stscreen")
#  >>>print(str(TestRawZapFrames(sdo, 5, slotNo=1)))
#  >>><ClientAPI.ScreenDefinition object>
#  >>>print(str(TestRawZapFrames(sdo, [6,7,8], slotNo=1)))
#  >>>[(6, <ClientAPI.ScreenDefinition object>), (7, <ClientAPI.ScreenDefinition object>),(8, <ClientAPI.ScreenDefinition object>)]
#  >>>print(str(TestRawZapFrames(sdo, 5)))
#  >>>[[1,<ClientAPI.ScreenDefinition object>]]
#  >>>print(str(TestRawZapFrames(sdo, [6,7,8])))
#  >>>[[1, [(6, <ClientAPI.ScreenDefinition object>), (7, <ClientAPI.ScreenDefinition object>),(8, <ClientAPI.ScreenDefinition object>)]]]
#  @endcode
@ApiFunction
def TestRawZapFrames(screenDef, frameIndex, slotNo=0):
    return screenDef.TestRawZapFrames(frameIndex, slotNo)

## @par Description
#  Evaluates the screen definition over a range of contiguous previously captured frames from the high speed timer looking for
#  a match of the screen definition (VerifyStatus returned as True).  A MotionRegion may be used in the screen definition - it will only
#  examine frames up to the last specified in the range.
# 
#  It is implemented as a call to ScreenDefinition.FindRawZapMatch.
#  
#  FindRawZapMatch(sdo, startIndex, maxFrames, slotNo, algorithm) is identical to sdo.FindRawZapMatch(startIndex, maxFrames, slotNo, algorithm)  including the return values and types.
#  @param[in] screenDef @b ScreenDefinition : The screen definition object to evaluate
#  @param[in] startIndex @b Integer : Zero based start frame to scan for screen definition match.  
#  @param[in] maxFrames @b Integer : The maximum number of frames to scan for a match.
#  @param[in] slotNo @b Integer : Optional.  The slot number.  There must have been a prior execution of the high speed timer on this slot
#  with frames captured. If omitted or 0 then the scan occurs on all reserved slots.
#  @param[in] algorithm @b String : Allows an alternative algorithm to be used, it can be "default" or "binarysearch" (introduced in release 3.5.5).
#  @return @e Tuple : If slotNo is non zero then a tuple of ScreenDefinition that matched and index where a match was found.  If slotNo is zero
#  then a List of slot, tuples.  If no match is found then the matched frame is None instead of an Integer.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>ReserveVideoTimer()
#  >>>EnableCaptureZapFrames()
#  >>>TriggerHighSpeedTimer()
#  >>>WaitSec(5)
#  >>>StopHighSpeedTimer()
#  # now we can work on the zap frames
#  >>>sdo = ScreenDefinition()
#  >>>sdo.Load("c:\\users\\me\\mysdo.stscreen")
#  >>>print(str(FindRawZapMatch(sdo, 0, 25, slotNo=6)))
#  >>>(<ClientAPI.ScreenDefinition object>, 12)
#  >>>print(str(FindRawZapMatch(sdo, 25, 100)))
#  >>>[[6, (<ClientAPI.ScreenDefinition object>, None)]]
#  @endcode
@ApiFunction
def FindRawZapMatch(screenDef, startIndex, maxFrames, slotNo=0, algorithm='default'):
    return screenDef.FindRawZapMatch(startIndex, maxFrames, slotNo, algorithm)

## @par Description
#  Evaluates the screen definition over a range of contiguous previously captured frames from the high speed timer looking for
#  a NON match of the screen definition (VerifyStatus returned as False).  A MotionRegion may be used in the screen definition - it will only
#  examine frames up to the last specified in the range.
#
#  It is implemented as a call to ScreenDefinition.FindRawZapNoMatch.
#  
#  FindRawZapNoMatch(sdo, startIndex, maxFrames, slotNo, algorithm) is identical to sdo.FindRawZapNoMatch(startIndex, maxFrames, slotNo, algorithm)  including the return values and types.
#  @param[in] screenDef @b ScreenDefinition : The screen definition object to evaluate
#  @param[in] startIndex @b Integer : Zero based start frame to scan for screen definition non match.  
#  @param[in] maxFrames @b Integer : The maximum number of frames to scan for a non match.
#  @param[in] slotNo @b Integer : Optional.  The slot number.  There must have been a prior execution of the high speed timer on this slot
#  with frames captured. If omitted or 0 then the scan occurs on all reserved slots.
#  @param[in] algorithm @b String : Allows an alternative algorithm to be used, it can be "default" or "binarysearch" (introduced in release 3.5.5).
#  @return @e Tuple : If slotNo is non zero then a tuple of ScreenDefinition that failed to match and index where the match was not found.  If slotNo is zero
#  then a List of slot, tuples.  If all frames match then the matched frame is None instead of an Integer.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>ReserveVideoTimer()
#  >>>EnableCaptureZapFrames()
#  >>>TriggerHighSpeedTimer()
#  >>>WaitSec(5)
#  >>>StopHighSpeedTimer()
#  # now we can work on the zap frames
#  >>>sdo = ScreenDefinition()
#  >>>sdo.Load("c:\\users\\me\\mysdo.stscreen")
#  >>>print(str(FindRawZapNoMatch(sdo, 0, 25, slotNo=6)))
#  >>>(<ClientAPI.ScreenDefinition object>, 12)
#  >>>print(str(FindRawZapNoMatch(sdo, 25, 100)))
#  >>>[[6, (<ClientAPI.ScreenDefinition object>, None)]]
#  @endcode
@ApiFunction
def FindRawZapNoMatch(screenDef, startIndex, maxFrames, slotNo=0, algorithm='default'):
    return screenDef.FindRawZapNoMatch(startIndex, maxFrames, slotNo, algorithm)

## @}
    
## @defgroup Group8 Optical Character Recognition API
# This section contains the functions that allow a script to use the optical character recognition abilities of StormTest.\n\n
# StormTest allows a test script to perform OCR on the live stream or on an image file. As OCR works best on high resolution images, the
# OCRSlot() function always operates on images at the native input resolution (704x576 for PAL, 704 x 480 for NTSC
# and the detected HD resolution in HD).\n\n
# You can now use the Tesseract 3 or 4 OCR engines by setting filters.  The API remains compatible
# with earlier versions and this imposes a slight amount of complexity on the script writer.  From day 1, the default image processing set by
# OCRSetDefaultImageProcessing() has been 'sticky' - it persists across reserve / free slot and is used by OCRSlot().  Also, for good legacy reasons
# the default after power on of the server is to Invert the image (most electonic images were light on dark compared to paper which is black on white) and
# this has been retained.  However, that legacy Invert is not compatible with the Tesseract engines (they can't do the ABBYY inversion algorithm) so it has
# to be explicitly removed.  Please read the sections on OCRSetDefaultImageProcessing and OCRSetImageFiltering.
# Since StormTest version 3.5.2, Tesseract 3 or 4 can be set as the default OCR engine on the server instead of ABBYY.
# With this setup, the legacy Invert is no longer turned on by default and if selected it will not cause an error with a Tesseract engine, it will be ignored.
# With a Tesseract engine as default, ABBYY OCR can still be chosen by setting an OCR engine filter on each API request.
## @{

## @par Description
#  ProcessImage Enum. Defines the valid values for OCR image pre-processing.
#  @param Invert : Invert the image.
#  @param Greyscale : Convert the image to greyscale.  DEPRECATED, do not use. Use the OCR Filters.  Retained for legacy applications.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>print(str(OCRSetDefaultImageProcessing(ProcessImage.Invert)))
#   >>True
#  @endcode
class ProcessImage:
    """
    Type of image processing to perform.  Only Invert is supported, Greyscale is retained for legacy applications only.
    """
    Invert,Greyscale = list(range(2))

   

## @par Description
#  This function returns the strings found when OCR has been performed on a capture from a live stream. @b Important: When OCR is performed on the live stream, the resolution used is @e always @b 4CIF for Standard Definition servers.
#  This means you must use a 704x576 reference image when calculating what co-ordinates to use for your rectangle.  For HD, the resolution is automatically selected based on the input to the server.
#  @param[in] rect @b List: Restricts the OCR to the part of the screen bounded by the rectangular co-ordinates supplied. If no bounding rectangle is required, use <I>None</I> here. See note <SUP>1</SUP> for more information.
#  In Release 3.1 and later this may be a @ref _regionObject or a ScreenDefinition Object.  If a ScreenDefinition Object is used then
#  the return parameters change.  
#  @param[in] slotNo @b Integer: (optional) The slot number to capture strings on.
#  @return @e ocrResult @b List: Contains the OCR statistics and list of strings found. See note <SUP>2</SUP> for more information.
#  If the OCR fails for some reason then None is returned instead of a List.  If a ScreenDefinition Object is used as the first parameter
#  then the string return is replaced by the original ScreenDefinition Object from which the results can be simply read.  The returned
#  ScreenDefinition object is NOT the same as the input object.
#  @note The ScreenDefinition object may only contain OCRRegions.  It @b cannot contain other types of region.  To use ScreenDefinitions in version 3.2, 
#  it is recommended to use the dedicated Screen Definition API and NOT OCRSlot even when just OCRRegion objects are contained within the ScreenDefinition.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Perform OCR on all reserved slots
#   >>ret = OCRSlot(None)
#   >>print(str(ret))
#   >>(0, 0, 39, 11,                              # Statistics
#   >> [[2,'This is a string from slot 2'],       # Slot 2 result
#   >>  [4,'This is the string from slot 4']])    # Slot 4 result
#
#   # The above strings are returned from the two slots which are reserved
#   # The statistics indicate the combined totals for both slots
#
#   # Perform OCR on just one slot
#   >>ret = OCRSlot(None, 4)
#   >>[0, 0, 30, 7, 'This is the string from slot 4']
#  @endcode
#  @note If the @e slotNo parameter is omitted, the OCR is performed on all reserved slots.
#  -# When defining the rectangular area you need to specify the top left hand corner and the width and height of the box, i.e. (x, y, w, h). Remember that the frame of reference is the native screen size not the streaming size (Standard Definition allows downscaling of the streaming video).
#  -# The statistics returned are:
#     -# Total number of suspicious symbols.
#     -# Total number of unrecognised symbols.
#     -# Total number of all symbols.
#     -# The total number of all words found.
#     -# A list of strings found per slot.
#  -# If the OCR fails to perform any OCR then None is returned.
#  @note This function ignores the effect of SetVideoOffset when the connected server is an HD server. It accounts for the offset when the
#  connected server is Standard Definition.
@ApiFunction
def OCRSlot(rect=None, slotNo=0):
    """
    Perform OCR on the video in a slot.

    Return: List.  The list is (SuspiciousSymbolsCount, UnrecognizedSymbolsCount,
      AllSymbolsCount, WordCount, TextFound).  The TextFound is str type if SlotNo
      was not zero, otherwise it is a List of Lists.  Each List is [SlotNo, StringFound].

    rect: (List, optional)  The region to use for OCR in format of [left,top,width,height]

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.ocr_slot(rect,slotNo)

## @par Description
#  This function Waits until the specified slot passes the OCR comparison with the OCRed string found when OCR has been performed on a capture from a live stream.
#  @b Important: When OCR is performed on the live stream, the resolution used is @e always @b 4CIF for standard definition Servers.
#  This means you must use a 704x576 reference image when calculating what co-ordinates to use for your rectangle.  For HD, the resolution is automatically selected based on the input to the server.
#  @param[in] text @b String : Expected Text for comparison.  In Release 3.1 and later this may be a NamedString.
#  @param[in] rect @b List: Restricts the OCR to the part of the screen bounded by the rectangular co-ordinates supplied. If no bounding rectangle is required, use <I>None</I> here. See note <SUP>1</SUP> for more information.
#  In Release 3.1 and later this may be a NamedRegion.
#  @param[in] timeToWait @b Integer: Number of Seconds to wait for a pass
#  @param[in] waitGap @b Float: Interval between subsequent comparisons
#  @param[in] slotNo @b Integer: (optional) The slot number to capture strings on.
#  @param[in] maxDistance @b Integer: (optional) The maximum allowed Levenshtein distance between the expected text and the OCRed text. Wikipedia can give more details.
#  @param[in] autoCorrect @b OCRStringCorrection: (optional) The type of auto correction to be performed on input string.  This is done before the distance is calculated
#  @return @e resultList @b List: Contains two lists. The Result List is a list of slot numbers and result for each of the reserved slots. The OCR Result List is of the same format as the return values of the OCRSlot function.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Wait for 'TV Guide', waiting no more than 3 seconds
#   >>ret=WaitOCRMatch("TV Guide",[40,20,100,25],timeToWait=3)
#   >>print(str(ret))
#   >>[[[11, False]], [0, 0, 0, 0, [[11, '']]]]
#   >>ret=WaitOCRMatch("TV Guide",[40,20,100,25],timeToWait=3, slotNo=11)
#   >>print(str(ret))
#   >>[[[11, False]], [0, 0, 0, 0, '']]
#  @endcode
#  @note
#  -# If the @e slotNo parameter is omitted, the OCR is performed on all reserved slots.
#     -# @e resultList in the return value is a list of the results of all reserved slots
#  -# When defining the rectangular area you need to specify the top left hand corner and the width and height of the box, i.e. (x, y, w, h). Remember that the frame of reference is the native screen size not the streaming size (Standard Definition allows downscaling of the streaming video).
#  -# The statistics returned are:
#     -# Total number of suspicious symbols.
#     -# Total number of unrecognised symbols.
#     -# Total number of all symbols.
#     -# The total number of all words found.
#     -# A list of strings found per slot.
#  -# If the OCR fails to perform any OCR then None is returned.
#  @note This function ignores the effect of SetVideoOffset when the connected server is an HD server. It accounts for the offset when the
#  connected server is Standard Definition.
#  @note Where autoCorrect is specified, the returned string is @e always the value prior to auto correction being applied so that you can see the raw string.
@ApiFunction
def WaitOCRMatch(text, rect=None, timeToWait=5, waitGap=1, slotNo=0, maxDistance=0, autoCorrect=OCRStringCorrection.NoCorrection):
    """
    Waits until the specified slot passes the OCR comparison.  The OCRed TextFound string is compared
    until a timeout or a positive match.

    Return: List.  The list is (Status, OCRResult). The Status (True / False) is the overall
      status of the execution of the function. The OCR Result is of the same format as the return value of
      the function OCRSlot() if OCR is successful, otherwise it is none.

    text: (str) Expected Text for comparison

    rect: (List, optional)  The region to use for OCR in format of [left,top,width,height]

    timeToWait: (Integer, optional) number of seconds to wait for a match.

    waitGap: (Float, optional) the time in seconds between each OCR.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.

    maxDistance: (Integer, optional) If the Levenshtein distance between the expected text and the OCRed text is less than or equal to the Max distance, then the function passes. Otherwise fails.

    autoCorrect: (OCRStringCorrection, options) the type of auto correction to be performed on input string
    """
    return stormtest_client.stc.WaitOCRMatch(text, rect, timeToWait, waitGap, slotNo, True, maxDistance, autoCorrect)

## @par Description
#  This function Waits until the specified slot fails the OCR comparison with the OCRed string found when OCR has been performed on a capture from a live stream.
#  @b Important: When OCR is performed on the live stream, the resolution used is @e always @b 4CIF for standard definition Servers.
#  This means you must use a 704x576 reference image when calculating what co-ordinates to use for your rectangle.  For HD, the resolution is automatically selected based on the input to the server.
#  @param[in] text @b String : Expected Text for comparison.  In Release 3.1 and later this may be a NamedString.
#  @param[in] rect @b List: Restricts the OCR to the part of the screen bounded by the rectangular co-ordinates supplied. If no bounding rectangle is required, use <I>None</I> here. See note <SUP>1</SUP> for more information.
#  In Release 3.1 and later this may be a NamedRegion.
#  @param[in] timeToWait @b Integer: Number of Seconds to wait for a fail
#  @param[in] waitGap @b Float: Interval between subsequent comparisons
#  @param[in] slotNo @b Integer: (optional) The slot number to capture strings on.
#  @param[in] maxDistance @b Integer: (optional) The maximum allowed Levenshtein distance between the expected text and the OCRed text.  Wikipedia can give more details.
#  @param[in] autoCorrect @b OCRStringCorrection: (optional) The type of auto correction to be performed on input string.  This is done before the distance is calculated
#  @return @e resultList @b List: Contains two lists. The Result List is a list of slot numbers and result for each of the reserved slots. The OCR Result List is of the same format as the return values of the OCRSlot function.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Wait for 'TV Guide', waiting no more than 3 seconds
#   >>ret=WaitOCRNoMatch("TV Guide",[40,20,100,25],timeToWait=3)
#   >>print(str(ret))
#   >>[[[11, True]], [0, 0, 0, 0, [[11, '']]]]
#   >>ret=WaitOCRNoMatch("TV Guide",[40,20,100,25],timeToWait=3, slotNo=11)
#   >>print(str(ret))
#   >>[[[11, True]], [0, 0, 0, 0, '']]
#  @endcode
#  @note
#  -# If the @e slotNo parameter is omitted, the OCR is performed on all reserved slots.
#     -# @e resultList in the return value is a list of the results of all reserved slots
#  -# When defining the rectangular area you need to specify the top left hand corner and the width and height of the box, i.e. (x, y, w, h). Remember that the frame of reference is the native screen size not the streaming size (Standard Definition allows downscaling of the streaming video).
#  -# The statistics returned are:
#     -# Total number of suspicious symbols.
#     -# Total number of unrecognised symbols.
#     -# Total number of all symbols.
#     -# The total number of all words found.
#     -# A list of strings found per slot.
#  -# When the OCR fails then None is returned.
#  @note This function ignores the effect of SetVideoOffset when the connected server is an HD server. It accounts for the offset when the
#  connected server is Standard Definition.
#  @note Where autoCorrect is specified, the returned string is @e always the value prior to auto correction being applied so that you can see the raw string.
@ApiFunction
def WaitOCRNoMatch(text, rect=None, timeToWait=5, waitGap=1, slotNo=0, maxDistance=0, autoCorrect=OCRStringCorrection.NoCorrection):
    """
    Waits until the specified slot fails the OCR comparison. The OCRed TextFound string is compared
    until a timeout or a negative match.

    Return: List.  The list is (Status, OCRResult). The Status (True / False) is the overall
      status of the execution of the function. The OCR Result is of the same format as the return value of
      the function OCRSlot() if OCR is successful, otherwise it is none.

    text: (str) Expected Text for comparison

    rect: (List, optional)  The region to use for OCR in format of [left,top,width,height]

    timeToWait: (Integer, optional) number of seconds to wait for a match.

    waitGap: (Float, optional) the time in seconds between each OCR.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.

    maxDistance: (Integer, optional) If the Levenshtein distance between the expected text and the OCRed text is less than or equal to the Max distance, then the function passes. Otherwise fails.

    autoCorrect: (OCRStringCorrection, options) the type of auto correction to be performed on input string
    """
    return stormtest_client.stc.WaitOCRMatch(text, rect, timeToWait, waitGap, slotNo, False, maxDistance, autoCorrect)

## @par Description
#  This function returns the strings found when OCR has been performed on an image file.  The default call will use the very old
#  invert filter (for legacy reasons).  This is different from the GUI which does not use the legacy invert.  To achieve the same results as
#  the GUI (or to simply not use the legacy invert), set the process to be an empty list, i.e. call OCRFile(rect, file, process=[]).  If you
#  use the Tesseract3 or Tesseract4 filters in the filters parameter then you @b MUST also set the process = []
#  Note: From StormTest version 3.5.2, if a Tesseract engine is set up as the default OCR on the server then legacy invert is simply ignored.
#  Previously supported behaviour is to allow OCRFile to be called without reserving a slot - this is now deprecated and will only work if ABBYY OCR is available.
#  @param[in] rect @b List: Restricts the OCR to the part of the screen bounded by the rectangular co-ordinates supplied. If no bounding rectangle is required, use <I>None</I> here. See note <SUP>1</SUP> for more information.
#  In Release 3.1 and later this may be a @ref _regionObject.
#  Passing a ScreenDefinition object as rect was previously supported - this is now deprecated and will only work if ABBYY OCR is available.
#  @param[in] fileName @b String or StormTestImageObject: The local filename to perform OCR on.  This may also be the image
#  returned from CaptureImageEx or similar function which produces a StormTestImageObject object.  Types of image file supported are: BMP, JPEG, PNG and TIFF. The function
#  can read GIF files but note that StormTest cannot save files as GIF.  In Release 3.1 and later this may be a @ref _imageObject.
#  @param[in] languages @b List: (optional) May be one language or a list of languages. Each language is a string of three characters from the ISO639-3 code list. For a list of supported languages, please see @ref _supportedLangs. Defaults to 'eng' - English.
#  @param[in] process @b ProcessImage: (optional) List of pre-processing options to be applied to the image before OCR is carried out. See note <SUP>2</SUP> for more information. Defaults to (ProcessImage.Invert)
#  @param[in] filters @b List: (optional) List of filters as per OCRSetImageFiltering()
#  @return @e ocrResult @b List: Contains the OCR statistics and a string containing all characters found. See note <SUP>3</SUP> for more information.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Perform OCR on a bitmap file
#   >>ret=OCRFile((70,70,300,300),"myOCRImage.bmp")
#   >>print(str(ret))
#   >>[0,0,15,4,'This is the string found in the bitmap']
#  @endcode
#  @note
#  -# When defining the rectangular area you need to specify the top left hand corner and the width and height of the box, i.e. (x, y, w, h).
#  -# The user may choose what pre-processing should be done to the image before it is sent to the OCR engine. The user may choose no pre-processing, one method or a combination of methods. Available method is:
#     -# Invert image (ProcessImage.Invert)
#  -# The statistics returned are:
#     -# Total number of suspicious symbols.
#     -# Total number of unrecognised symbols.
#     -# Total number of all symbols.
#     -# The total number of all words found.
#     -# A string containing all the characters found in the bitmap
#  -# If a named image or rectangle is used then only the general 'all slot' path will be searched because this
#  function does not take a slot number.
@ApiFunction
def OCRFile(rect, fileName, languages=None, process=None, filters=None):
    """
    Perform OCR on a file

    Return: List. The list is (SuspiciousSymbolsCount, UnrecognizedSymbolsCount,
      AllSymbolsCount, WordCount, TextFound)

    rect: (Tuple)  The region to use for OCR in format of (left,top,width,height). This may also be RegionObject object.
    Passing a ScreenDefinition object as rect was previously supported - this is now deprecated and will only work if ABBYY OCR is available.

    fileName: (String) Filename of file to use for OCR

    languages: (List, optional) List of language strings, each in ISO639-3 format.

    process: (ProcessImage, optional) Legacy processing method.

    filters: (List, optional) List of strings specifying the image processing to perform prior
      to performing OCR in an attempt to improve OCR.
    """

    return stormtest_client.stc.ocr_file(rect,fileName,languages,process,filters)

## @par Description
#  This function returns the strings found when OCR has been performed on an image.  The default call will use the very old
#  invert filter (for legacy reasons).  This is different from the GUI which does not use the legacy invert.  To achieve the same results as
#  the GUI (or to simply not use the legacy invert), set the process to be an empty list, i.e. call OCRImage(image, rect, process=[]). If you
#  use the Tesseract3 or Tesseract4 filters in the filters parameter then you @b MUST also set the process = []
#  Note: From StormTest version 3.5.2, if a Tesseract engine is set up as the default OCR on the server then legacy invert is simply ignored.
#  @param[in] image @b StormTestImageObject or Pillow Image: The image to perform OCR on.  It can be a @ref _imageObject.
#  @param[in] rect @b List: Restricts the OCR to the part of the screen bounded by the rectangular co-ordinates supplied. If no bounding rectangle is required, use <I>None</I> here. See note <SUP>1</SUP> for more information.
#  This may be a @ref _regionObject object.
#  Passing a ScreenDefinition object as rect was previously supported - this is now deprecated and will only work if ABBYY OCR is available.
#  @param[in] languages @b List: (optional) May be one language or a list of languages. Each language is a string of three characters from the ISO639-3 code list. For a list of supported languages, please see @ref _supportedLangs. Defaults to 'eng' - English.
#  @param[in] process @b ProcessImage: (optional) List of pre-processing options to be applied to the image before OCR is carried out. See note <SUP>2</SUP> for more information. Defaults to (ProcessImage.Invert)
#  @param[in] filters @b List: (optional) List of filters as per OCRSetImageFiltering()
#  @return @e ocrResult @b List: Contains the OCR statistics and a string containing all characters found. See note <SUP>3</SUP> for more information.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Perform OCR on an image
#   >>ret=OCRImage(img, (70,70,300,300))
#   >>print(str(ret))
#   >>[0,0,15,4,'This is the string found in the bitmap']
#  @endcode
#  @note
#  -# When defining the rectangular area you need to specify the top left hand corner and the width and height of the box, i.e. (x, y, w, h).
#  -# The user may choose what pre-processing should be done to the image before it is sent to the OCR engine. The user may choose no pre-processing, one method or a combination of methods. Available method is:
#     -# Invert image (ProcessImage.Invert)
#  -# The statistics returned are:
#     -# Total number of suspicious symbols.
#     -# Total number of unrecognised symbols.
#     -# Total number of all symbols.
#     -# The total number of all words found.
#     -# A string containing all the characters found in the bitmap
#  -# If a named image or rectangle is used then only the general 'all slot' path will be searched because this
#  function does not take a slot number.
#  -# If a ScreenDefinition object is used, the languages, process and filters parameters, if not None, override the values in the ScreenDefinition object.  A copy of 
#  the ScreenDefinition object is returned instead of the string (eg [0,0,15,4,<ScreenDefinitionObject>])
@ApiFunction
def OCRImage(image, rect, languages=None, process=None, filters=None):
    """
    This function returns the strings found when OCR has been performed on an image.

    param image StormTestImageObject or Pillow image: The image to perform OCR on.  It can be a @ref _imageObject.

    param rect List: Restricts the OCR to the part of the screen bounded by the rectangular co-ordinates supplied.
    If no bounding rectangle is required, use None here. This may also be RegionObject object.
    Passing a ScreenDefinition object as rect was previously supported - this is now deprecated and will only work if ABBYY OCR is available.

    param languages List: (optional) May be one language or a list of languages. Each language is a string of three characters from the ISO639-3 code list.  Defaults to 'eng' - English.

    param process ProcessImage: (optional) List of pre-processing options to be applied to the image before OCR is carried out.. Defaults to (ProcessImage.Invert)

    param filters List: (optional) List of filters as per OCRSetImageFiltering()

    return ocrResult List: Contains the OCR statistics and a string containing all characters found.
    """
    if not isinstance(image, Imaging.StormTestImageObject):
        try:
            image = Imaging.StormTestImageObject(image)
        except:
            if not isinstance(image, stormtest_client.NamedImage):
                raise StormTestExceptions("Invalid Image supplied to OCRImage()")


    return stormtest_client.stc.ocr_file(rect, image, languages, process, filters)

## @par Description
#  This function returns an integer denoting the number of characters remaining on the OCR license for this period (i.e. until the end of the month)
#  \n\n By default, the OCR license details for the currently connected StormTest server are returned. However, if no server is connected, or if the details
#  for a different server are required, the server name can be passed as a parameter.\n\n This Function does not require a client license to be called.
#  @param[in] server @b String: (optional) Specify the StormTest server to get the remaining OCR characters from. If the server does not use the standard port, then the server name must include the port number (i.e. 'server:port')
#  @return @e remChars @b Integer: The number of remaining characters.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>ret = OCRGetRemainingChars()
#   >>print(str(ret))
#   >>9939020
#  @endcode
@ApiFunction
def OCRGetRemainingChars(server=None):
    """
    Return number of OCR characters for the current licensing period.

    Return: Integer. Number of characters remaining.
    """
    return stormtest_client.stc.ocr_get_remaining_chars(server)

## @par Description
#  This function is used to set the default language dictionaries that are used by the OCR engine when it comes across suspicious characters in a word. The default setting for this is english - @e 'eng'. It is still possible to OCR other languages based on the latin character set without changing the default language.
#  \n\n However, it is very important to set the default language correctly if you wish to OCR text that is rendered in non-latin alphabets.
#  The user may set the OCR language to be a list of languages. The language is specified by using the @b ISO639-3 encoding for that language.
#  For a list of supported languages, please see @ref _supportedLangs
#  \n\n Please note that the language(s) set by a call to this function apply to all OCR operations carried out by the OCR engine on the specified slot. The language is stored on the server and will be used by later scripts unless OCRSetLanguage
#  is called by the script.  This function has no effect on the language used by OCRFile()
#  @param[in] languages @b List: May be one language or a list of languages. Each language is a string of three characters from the ISO639-3 code list.
#  @param[in] slotNo @b Integer: (optional) Apply the language change to OCRs performed on just one of the reserved slots
#  @return @e result @b Bool: True if the call was successful. False otherwise. If the language code used is not supported or invalid, then a StormTestException will be raised.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Tell the OCR engine to use the German dictionary.
#   >>result = OCRSetLanguage('deu')
#   >>print(str(result))
#   >>True
#
#   # Tell the OCR engine to use the Spanish, Portugese and French dictionaries.
#   >>result = OCRSetLanguage(('spa','por','fra'))
#   >>print(str(result))
#   >>True
#
#   # Tell the OCR engine to use an invalid dictionary - this will raise an exception
#   >>result = OCRSetLanguage('abc')
#    Exception in user code:
#    StormTestExceptions: Invalid language: [abc]
#  @endcode
@ApiFunction
def OCRSetLanguage(languages = 'eng', slotNo = 0):
    """
    Set the OCR language to use for later OCRs. This improves recognition by using a dictionary
    to resolve ambiguities during OCR.

    Return: Bool. True if language is supported

    languages: (List or String, optional) Either a single ISO639-3 language string or a list of
      such strings.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    if languages == None:
        return False
    else:
        # If the result is not iterable (only one language)
        if isinstance(languages, str):
            temp_list = [languages]
        else:
            temp_list = languages

        for l in temp_list:
            if l not in list(stormtest_client.supported_langs.keys()):
                raise StormTestExceptions("Invalid language: ["+str(l)+"]")

        return stormtest_client.stc.OCRSetLanguage(temp_list,slotNo)

## @par Description
#  Get the default language dictionary used by the StormTest OCR engine for the reserved slots
#  @param[in] slotNo @b Integer: (optional) Get the default language dictionary for just one of the reserved slots
#  @return @e result @b List: A list of lists consisting of slot number and a list of strings representing the language dictionaries in use. A single list will be returned if the exact slot number is given.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Get dictionary, 2 slots reserved
#   >>result = OCRGetLanguage()
#   >>print(str(result))
#   >>[ [4, ['ces', 'dan', 'nld', 'deu']],
#   >>  [6, ['ces', 'dan', 'nld', 'deu']]]
#
#   # Get dictionary, specify slot
#   >>result = OCRGetLanguage(4)
#   >>print(str(result))
#   >>[4, ['ces', 'dan', 'nld', 'deu']]
#  @endcode
@ApiFunction
def OCRGetLanguage(slotNo=0):
    """
    Get the current default language for a slot.

    Return: List of Lists (if slotNo is zero) or a single List. List is: [SlotNumber, Languages]
      where languages is a list of ISO639-3 strings.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.OCRGetLanguage(slotNo)

## @par Description
#  This function sets the default image pre-processing that will be applied to all images for the specifed slot before sending them to the OCR engine.
#  From 3.0, only the Invert option is supported.  This Invert is for legacy applications.  New applications should disable this
#  Invert and use OCRSetFilters().  However, since 1.0 of StormTest, the default has been to apply this Invert and to avoid
#  breaking scripts, this behaviour is retained.  If the default of Invert is in place then you cannot use Tesseract3 or Tesseract4 filters to use a Tesseract
#  OCR engine - you @b MUST disable the Invert explicitly in order to use a Tesseract engine.
#  Note: From StormTest version 3.5.2, if a Tesseract engine is set up as the default OCR on the server then legacy invert is simply ignored.
#  @param[in] process @b ProcessImage: List of pre-processing options to be applied to the image before OCR is carried out. See note <SUP>1</SUP> for more information.
#  @param[in] slotNo @b Integer: (optional) Apply the image pre-processing to OCRs performed on just one of the reserved slots
#  @return @e result @b Bool: True if the call was successful. False if there was an error in the parameter.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Tell the OCR engine to do no pre-processing of images by default.
#   >>result = OCRSetDefaultImageProcessing(None)
#   >>print(str(result))
#   >>True
#
#   # Tell the OCR engine to invert the colors using legacy method by default.
#   >>result = OCRSetDefaultImageProcessing(ProcessImage.Invert)
#   >>print(str(result))
#   >>True
#
#  @endcode
#  @note
#  -# The user may choose what pre-processing should be done to the image before it is sent to the OCR engine. The user may choose no pre-processing, one method or a combination of methods. Available method is:
#     -# Invert image (ProcessImage.Invert)
#
@ApiFunction
def OCRSetDefaultImageProcessing(process = None, slotNo = 0):
    """
    Sets default image pre-processing that will be applied to all images for the specifed slot before
    sending them to the OCR engine.
    Use None, ProcessImage.Invert or ProcessImage.Greyscale.
    """
    invert = 0
    greyscale = 0
    if process != None:
        # If the result is iterable (more than one location)
        if hasattr(process,'__iter__'):
            for p in process:
                if p == ProcessImage.Invert: invert = 1
                elif p == ProcessImage.Greyscale: greyscale = 1
                else: raise StormTestExceptions("Invalid option: ["+str(p)+"]")
        else:
            if process == ProcessImage.Invert: invert = 1
            elif process == ProcessImage.Greyscale: greyscale = 1
            else: raise StormTestExceptions("Invalid option: ["+str(p)+"]")
    return stormtest_client.stc.OCRSetDefaultImageProcessing(invert,greyscale,slotNo)

## @par Description
#  This function gets the default image pre-processing that will be applied to all images before sending them to the OCR engine.
#  @param[in] slotNo @b Integer: (optional) Get the default image pre-processing for just one of the reserved slots
#  @return @e result @b Tuple or Integer: If zero or more than one pre-processing methods that will be applied then this is a tuple of each method that
#  will be applied before each OCR.  If only one method will be applied, then just that value as an integer is returned.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>result = OCRGetDefaultImageProcessing()
#   >>print(str(result))
#   >>[ [4, 0],    # (ProcessImage.Invert)
#       [5, 0],    # (ProcessImage.Invert)
#       [6, ()]]   # No image pre-processing
#  @endcode
@ApiFunction
def OCRGetDefaultImageProcessing(slotNo=0):
    """
    Gets the default image pre-processing that will be applied to all
    images before sending them to the OCR engine.
    """
    return stormtest_client.stc.OCRGetDefaultImageProcessing(slotNo)

## @par Description
#  This function sets the default image filtering that will be applied to all images before sending them to the OCR engine.  This function
#  has no effect on the image processing applied to images used by OCRFile() and OCRImage().  If you use this function to set the filters
#  to use the Tesseract3 or Tesseract4 engines then you @b MUST also use OCRSetDefaultImageProcessing() to remove the legacy invert filter.
#  Note: From StormTest version 3.5.2, if a Tesseract engine is set up as the default OCR on the server then legacy invert is simply ignored.
#  @param[in] filterList @b list of string arrays: List of filtering options to be applied to the image before OCR is carried out. See note <SUP>1</SUP> for more information.
#  @param[in] slotNo @b Integer: (optional) Apply the image pre-processing to OCRs performed on just one of the reserved slots
#  @return @e result @b Bool: True if the call was successful. False if there was an error in the parameter.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Tell the OCR engine to do no filtering of images by default.
#   >>result = OCRSetImageFiltering(None)
#   >>print(str(result))
#   >>True
#
#   # Tell the OCR engine to blur the images on a 3x3 processing block and convert to grayscale
#   >>result = OCRSetImageFiltering([("Blur","Gaussian3x3"),("Color","Gray")])
#   >>print(str(result))
#   >>True
#
#  @endcode
#  @note
#  -# The user may choose what pre-processing should be done to the image for the specified slot before it is sent to the OCR engine.
#  The user may choose no pre-processing, one method or a combination of methods. Each method is a tuple of 2 items,
#  the first is a class of filtering and the second is a precise algorithm within the class to use.Available methods are:
#     -# ("Blur", "Gaussian3x3") - blur the image using a Gaussian blur algorithm on a 3x3 pixel matrix
#     -# ("Blur", "Gaussian5x5") - blur the image using a Gaussian blur algorithm on a 5x5 pixel matrix (blurs more than 3x3)
#     -# ("Sharpen", "Sharpen3x3") - sharpen the image using a 3x3 pixel matrix
#     -# ("Sharpen", "Sharpen5x5") - sharpen the image using a 5x5 pixel matrix (sharper than the 3x3)
#     -# ("Contrast", "Contrast1") - Increase the contrast a bit
#     -# ("Contrast", "Contrast2") - Increase the contrast a bit more
#     -# ("Contrast", "Contrast3") - Increase the contrast quite a bit
#     -# ("Contrast", "Contrast4") - Increase the contrast by quite a lot
#     -# ("Contrast", "Contrast5") - Increase the contrast by a lot
#     -# ("Invert", "Invert") - Invert all colors
#     -# ("Color", "Red") - keep just the red component of the color
#     -# ("Color", "Green") - keep just the green component of the color
#     -# ("Color", "Blue") - keep just the blue component of the color
#     -# ("Color", "RedGreen") - keep the red and green components of the color
#     -# ("Color", "RedBlue") - keep the red and blue components of the color
#     -# ("Color", "BlueGreen") - keep the blue and green components of the color
#     -# ("Color", "RedGray") - keep the red component and then make the image gray
#     -# ("Color", "GreenGray") - keep the green component and them make the image gray
#     -# ("Color", "BlueGray") - keep the blue component and then make the image gray
#     -# ("Color", "RedGreenGray") - keep the red and green components and then make the image gray
#     -# ("Color", "RedBlueGray") - keep the red and blue components and then make the image gray
#     -# ("Color", "BlueGreenGray") - keep the blue and green components and then make the image gray
#     -# ("Color", "Gray") - convert to gray
#     -# ("Color", "Monochrome") - convert to black and white
#     -# ("Engine", "Tesseract3") - Request to use Tesseract 3.x engine for OCR.  Available in Release 3.4.2.  Only Available on HD/4K systems.
#     -# ("Engine", "Tesseract4") - Request to use Tesseract 4.x engine for OCR.  Available in Release 3.5.2.  Only Available on HD/4K systems.
#     -# ("Engine", "ABBYY") - Request to use ABBYY engine for OCR.  Available in Release 3.5.2. Only useful if default OCR has been set to a Tesseract engine on the server
#     -# ("Hint", "SingleLine") - Hint to the engine that image is single line of text. Only use with Tesseract3 or Tesseract4
#     -# ("Hint", "SingleWord") - Hint to the engine that image is single word. Only use with Tesseract3 or Tesseract4
#     -# ("Hint", "SingleCharacter") - Hint to the engine that image is single character. Only use with Tesseract3 or Tesseract4
#     -# ("Tesseract4Arg", "[user defined]") - Argument to pass to tesseract 4 command-line. Can be used multiple times. Only works with filter Engine:Tesseract4
#
@ApiFunction
def OCRSetImageFiltering(filterList, slotNo = 0):
    """
    Set the list of filters to apply before performing OCR on a slot.

    Return: Bool. True if filters stored successfully.

    filterList: (List) List of filters. Each filter is a Tuple of 2 strings, the first being
      the filter class and the second being the detailed filter.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.OCRSetImageFiltering(filterList,slotNo)

## @par Description
#  This function gets the default image filtering that will be applied to all images before sending them to the OCR engine.
#  @param[in] slotNo @b Integer: (optional) Get the default image filtering for just one of the reserved slots
#  @return @e result @b List: List of the filtering methods that will be applied by default before each OCR
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>result = OCRGetImageFiltering()
#   >>print(str(result))
#   >>[ [4, [["Sharpen","Sharpen5x5"]],    # (Sharpen image using a 5x5 area)
#       [5, [["Blur","Gaussian3x3"]],      # (Blur image using a Gaussian 3x3 area)
#       [6, []],                           # No image filtering
#       [7, [["Color","RedGray"],["Sharpen","Sharpen3x3)]] # (Drop Blue and green components thus keeping Red, convert to gray scale, then sharpen on a 3x3 area)
#  @endcode
@ApiFunction
def OCRGetImageFiltering(slotNo=0):
    """
    Get the list of filters to apply on a slot prior to OCR.

    Return: List of Lists (if slotNo is 0) or a List.  The contents of the list are: [SlotNumber,
      List of filters] Each filter is a Tuple of (Filter Class, Detailed Filter)

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.OCRGetImageFiltering(slotNo)

## @par Description
#  This is a utility function that can be used in conjunction with OCRSlot() and OCRFile(). It allows a test to compare an
#  expected string with the actual string returned by the OCR function and to get a Pass even when the strings do not match exactly.\n\n
#  Given that the results from OCR are not always 100% accurate depending on the quality of the incoming image, this function allows a test writer
#  to tune the string comparison in a similar way that image comparisons are tuned.
#  @param[in] string1 @b String: A string
#  @param[in] string2 @b String: Another string
#  @param[in] percent @b Integer: How closely the two strings must match for a pass. Range is from 0-100, where 100 means the strings match exactly.
#  @return @e compareResult @b Bool: True for a match, False otherwise
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Perform OCR on all reserved slots
#   >>ret = OCRSlot(None)
#   >>for slot,txt in ret[4]:
#   >>    if CompareStrings("Expected text",txt,85) == False:
#   >>        WriteDebugLine("OCR comparison failed")
#   >>    else:
#   >>        WriteDebugLine("OCR comparison passed")
#  @endcode
@ApiFunction
def CompareStrings(string1, string2, percent=90):
    """
    Compare strings using fuzzy matching.

    Return: Bool. True if the strings match by specified similarity.

    string1: (String) A string to compare.

    string2: (String) string to compare to string1

    percent: (Integer, optional) How closely the string should match. 0-100 where 100 is a perfect
      match.
    """
    return stormtest_client.ApproxStringCompare(string1, string2, percent)

## @par Description
#  This is a utility function that can be used to compute the Levenshtein distance between two strings.
#  It is used in conjunction with OCRSlot() and OCRFile() to allow for less than perfect OCR string matching
#  @param[in] string1 @b String: A string
#  @param[in] string2 @b String: Another string
#  @return @e distance @b Integer: Levenshtein distance between the two strings.  Wikipedia can give more details.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>print(str(ComputeStringsDistance("TV Guide", "Guide")))
#  >>>3
#  @endcode
@ApiFunction
def ComputeStringsDistance(string1, string2):
    """
    Compute the Levenshtein distance between two strings.

    Return: Integer. The Levenshtein distance.

    string1: (String) A string to compare.

    string2: (String) string to compare to string1

    """
    return stormtest_client.computeLevenshteinDistance(string1, string2)

## @par Description
# This is a utility function that automatically correct a given string.
# Two methods are defined:
# 1, correct a given string to all characters, so all similar looking numbers are converted
#    to their character counterparts
# 2, correct a given string to all numbers, so all similar looking characters are converted
#    to their number counterparts
#  @param[in] string1 @b String: A string
#  @param[in] type @b OCRStringCorrection: AutoCorrection type
#  @return @e correctedString @b String: The automatically corrected string
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>print(str(StringsAutoCorrection("0ptions", OCRStringCorrection.AllCharacters)))
#  >>>Options
#  >>>print(str(StringsAutoCorrection("56SIO96AH", OCRStringCorrection.AllNumbers)))
#  >>>5651096AH
#  @endcode
@ApiFunction
def StringsAutoCorrection(string1, type=OCRStringCorrection.NoCorrection):
    """
    Automatically correct a given string..

    Return: String. The automatically corrected string.

    string1: (String) A string.

    type: (OCRStringCorrection)

    """
    if type == 'None' or type == 'AllCharacters' or type == 'AllNumbers':
        return stormtest_client.stringAutoCorrection(string1, type)
    else:
        return None

## @}

##  @defgroup Group9 High Speed Video Timing API
# These commands control the high speed video timer API.
#
# The high speed video timer allows a StormTest user to accurately measure the amount of time that a device under test takes to
# zap from one channel to another. StormTest uses a patented method to detect the change in video which indicates that a channel
# zap has occurred and can detect this to an accuracy of one frame (i.e. 40ms).
# Since the zap measurement is resource intensive, and would be adversely affected if too many simultaneous measurements were happening,
# the zap time measurement is treated as a reservable resource.
# The client is therefore required to reserve the resource before using it and release it once the measurement is complete.  Note that
# the high speed timer cannot be reserved at the same time as running a reference stream video analysis on the slot.  You can run high speed timer
# at the same time as VQA analysis (subject to memory constraints).
#
# The memory constraints are discussed under @ref Group16
#
##  @{

## @par Description
#  This function reserves a video timer resource for the specified slot.  The slot must have been previously reserved via
#  ReserveSlot().  There is a limit to the number of video timers that can be reserved at any one time (4 video timers per 16 slot rack for SD servers, no limit for HD servers), 
#  so the script writer must deal with the case where the function call returns a fail.  Also, a high speed timer cannot be reserved while a reference stream Video analysis
#  is running on the slot.  You can reserve a high speed timer at the same time as VQA analysis (subject to memory constraints).
#  @param[in] slotNo @b Integer: (optional) The slot number on which to reserve a video timer.
#  @return @b Bool: True if the video timer on the slot has been reserved, false otherwise.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>print(str(ReserveVideoTimer()))
#  >>>True
#  @endcode
@ApiFunction
def ReserveVideoTimer(slotNo=0):
    """
    Reserve a high speed video timer for the slot.

    Return: Bool. True if successful.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.reserve_video_timer(slotNo)

## @par Description
#  This function frees a previously reserved video timer on the specified slot.
#  @param[in] slotNo @b Integer: (optional) The slot number on which to free a video timer.
#  @return @b Bool: True if the video timer has been freed, else False.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  >>>print(str(FreeVideoTimer()))
#  >>>True
#  @endcode
@ApiFunction
def FreeVideoTimer(slotNo=0):
    """
    Free a high speeed timer that has previously been reserved.

    Return: Bool. True if successfully feeed.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.free_video_timer(slotNo)

## @par Description
#  This function starts the Zap Time measurement.  The slot must have had a
#  video timer previously reserved via a call to ReserveVideoTimer() - this is because
#  it is not possible to simultaneously run Zap time measurements on all slots of
#  a 16 slot SD rack (HD systems do NOT have this limitation) - to ensure the Zap measurement can run when desired, the measurement resource
#  must previously have been reserved - if necessary, the client can wait
#  in a loop until it is able to reserver the video timer.
#  @param[in] irKey @b String: The ir key stroke which initiates the zap time measurement - the zap
#  time is measured from the end of this keystroke.  In Release 3.1 and later this may be a @ref _stringObject.
#  @param[in] keyCount @b Integer: (optional) The number of irKey's to ignore before starting the measurement.
#  For example, setting irKey = '1' and keyCount = '1' would allow the client to
#  send the ir command '101' and have zap time start on the second '1' instead of
#  the first.  keyCount is only of use when you need to send multiple instances of irKey prior to starting the
#  zap measurement as in the example above where the measurement should start @b with the second '1' key.
#  @param[in] rect @b List: (optional) The area of the video to examine when determining zap time. This is based on the
#  standardised coordinates of a 704 x 576 screen, irrespective of current video.  In Release 3.1 and later this may be a @ref _regionObject.
#  streaming format. The default of None means all of the screen
#  @param[in] colorCount @b Integer: (optional) The threshold for determining ZAP.  When the color count falls
#  below this value, the zap is considered to have started and when it rises
#  above this value, the zap is considered to have ended.
#  @param[in] timeout @b Number: (optional) A timeout to wait for the zap to complete.  A zap consists of 2 phases, the first
#  phase waits for the color count to drop below the threshold and phase 2 waits for the color count to rise again.  This timeout
#  parameter is divided equally between the 2 phases.  So, the default value of 20 allocates 10 seconds to wait for phase 1 and
#  10 seconds to wait for phase 2.  If either time is exceeded, the call returns.  So, if the DUT fails to start the zap process
#  within timeout/2 seconds, the call stops and returns immediately. Phase 1 starts starts from the end of the irKey occurrence.  
#  There is also an overall timeout on the function from StartZapMeasurement() of 2 minutes for SD systems - to save on server
#  resources. From release 3.2.5, HD systems have no limitation.  So from calling StartZapMeasurement() to completion of Zap there is a maximum
#  time limit of 2 minutes on SD systems, even if the StartZapMeasurement() timeout is set higher.    From version
#  3.3.1 onwards, the timeout is measured in frame time not real time (so a timeout of 2 seconds with 50 fps will capture
#  and process 100 frames).  There is a safety feature such that if no frames are being processed, no more than 1 minute
#  will elapse before the 'real' timeout kicks in.
#  @param[in] slotNo @b Integer: (optional) The slot number on which to start the zap measurement
#  @param[in] triggerSlot @b Integer: (optional) The slot number which acts as the trigger for the zap.  This can be used
#  if the script reserves 2 slots.  In this case the trigger is monitored on the triggerSlot, @b not the slotNo but the
#  zap timing and any associated images are acquired on slotNo.  This is most useful when the zap timing is being used just
#  as a simple means to capture all raw frames. TriggerHighSpeedTimer would be prefferred for use in that case.  The default
#  value of 0 means trigger and acquire on the same slot.  This is the default behaviour and emulates the behavior prior to
#  release 2.8.3.  triggerSlot is available only on release 2.8.3 and later.
#  @return @b List: A list of tuples.  Each tuple is one slot and is (slotNo,Bool) where the bool is True if successfully primed.
#
#  @subsubsection _eg1 eg1:
#  @b Example
#  @code
#   >>if ReserveVideoTimer():
#   >>    PressDigits(101, slot)
#   >>    zapstatus = ST.StartZapMeasurement("Channel+",0,(0,0,704,300), timeout=5.0)
#   >>    WaitSec(1)
#   >>    # Do channel + and wait 5 seconds
#   >>    PressButton("Channel+")
#   >>    WaitSec(5)
#   >>    # get the zap times and validate them
#   >>    zaptimes = ST.GetZapTimes()
#  @endcode
@ApiFunction
def StartZapMeasurement(irKey, keyCount=0, rect=None, colorCount=1000, timeout=20, slotNo=0, triggerSlot=None):
    """
    Start the Zap Measurement.  This primes the process to watch for an IR key which will start
    full timing measurement. ReserveVideoTimer() must have previously been called.  This is an
    asynchronous call - it returns and the script then issues the PressButton() key to start
    the DUT change and zap monitoring.

    Return: List of tuples (always).  Each tuple is one slot and is (slotNo,Bool) where the
    bool is True if successfully primed.

    irKey: (String) The IR button press that will start the zap measurement.

    keyCount: (Integer, optional) The number of times that irKey can be sent before the zap
      measurement starts. eg: you want to start after sending keys 303 so you set irKey to 3
      and keyCount to 1 - so that StormTest ignores one of the '3' keys.

    rect: (Tuple, optional) Rectangle of the screen to monitor for the zap time. The area should
      be a plain constant color as that is how StormTest detects the channel transisiton.

    colorCount: (Integer, optional) The number of colors in the rectangle that is expected during
      a channel zap.  For good quality DUTs this should be low, for poorer quality DUTs, this may
      need to be higher.

    timeout: (Integer, optional) Maximum number of seconds to wait from the IR keystroke to the
      end of zap.  If zap has not occurred by this time, it is considered a failure.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.

    triggerSlot: (Integer, optional) The slot number which acts as the trigger for the zap.  This can be used
     if the script reserves 2 slots.

    """
    return stormtest_client.stc.start_zap_measurement(irKey, keyCount, rect, colorCount, timeout, slotNo, triggerSlot)

## @par Descripton
# This function allows you to use the high speed timer for purposes other than measuring zap times.
# It sets up a trigger point and can be used instead of the StartZapMeasurement().  The timer is triggered
# and runs until the timeout or until stopped.  This is only useful if the frame capture is also enabled
# using EnableCaptureZapFrames().  Then you can use GetRawZapFrame() to perform later analysis of the
# sequence.  This could be used, for example, to capture 50 frames after pressing the 'TV_Guide' button
# and analyzing each frame to determine when the screen showed some text or a color in a particular place.
# GetZapTimes() has no meaning in this case.
# @param[in] irKey @b String: (optional) The ir key stroke which initiates the timer. If omitted or set to None
# then the timer starts immediately.  Timing starts from the end of the key stroke.
# @param[in] keyCount @b Integer: (optional) The number of irKey's to ignore before starting the measurement.
# For example, setting irKey = '1' and keyCount = '1' would allow the client to
# send the ir command '101' and have time start on the second '1' instead of
# the first. Ignored if irKey is None. Default 0.
# @param[in] timeout @b Number: (optional) The total time in seconds to run the timer. The time starts from the
# irKey occurrence or immediately if irKey is None.  There is also an overall timeout
# on the function from TriggerHighSpeedTimer() of 2 minutes on SD systems - to save on server
# resources.  From release 3.2.5 onwards, HD systems have no limit as all slots can be used simultaneously.  From version
# 3.3.1 onwards, the timeout is measured in frame time not real time (so a timeout of 2 seconds with 50 fps will capture
# and process 100 frames).  There is a safety feature such that if no frames are being processed, no more than 1 minute
# will elapse before the 'real' timeout kicks in.
# @param[in] slotNo @b Integer: (optional) The slot number on which to start the timer.
# @param[in] triggerSlot @b Integer: (optional) The slot number which acts as the trigger for the timer.  This can be used
# if the script reserves 2 slots and irKey is not None.  In this case the trigger is monitored on the triggerSlot, @b not the slotNo but the
# the associated images are acquired on slotNo.  This could be used, for instance when DUTs access some shared data
# and you wish to find the timing on slotNo from some event on the DUT in triggerSlot. triggerSlot is available only on
# release 2.8.3 and later.  A value of 0 means the trigger and acquiring slot are the same slot.  This is the default and emulates
# the behavior prior to release 2.8.3.  If IrKey is None then triggerSlot is ignored.
# @return @b List: A List of tuples constaining slot number and boolean status. The boolean status will be true if the slot has successfully started the timer
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>if ReserveVideoTimer():
#   >>    EnableCaptureZapFrames(100,0,2)
#   >>    TriggerHighSpeedTimer("1",1)
#   >>    PressDigits(101)
#   >>    WaitSec(5)
#   >>    StopHighSpeedTimer()
#   >>    if GetCountImagesSaved(0)[0][1]>=11:
#   >>      (slot,image) = GetRawZapFrame(10)[0] # return 11th captured frame which is (11 * 3) * 40mS after the 2nd '1' key at 25 fps
#   >>      image.Save("frame11.png") # save it to disk.
#  @endcode
#  @note The server captures images to memory and saves them asynchronously to disk so you need to call
#  GetCountImagesSaved() before attempting to retrieve an image.
@ApiFunction
def TriggerHighSpeedTimer(irKey=None, keyCount=0, timeout=20, slotNo=0, triggerSlot=None):
    """
    This starts the high spped timer (and full frame image capture) for purposes other than zap
    time measurement.  ReserveVideoTimer() must have previously been called.

    Return: List of tuples of (slot number, status) where status is a bool indicating success.

    irKey: (String, optioanl) The IR button press that will start the zap measurement.  If omitted
      the timer starts immediately

    keyCount: (Integer, optional) The number of times that irKey can be sent before the timer
      starts. eg: you want to start after sending keys 303 so you set irKey to 3
      and keyCount to 1 - so that StormTest ignores one of the '3' keys.

    timeout: (Integer, optional) Maximum number of seconds to wait from the IR keystroke before
      automatically stopping.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.

    triggerSlot: (Integer, optional) The slot number which acts as the trigger for timer.  This can be used
      if the script reserves 2 slots and irKey is not None.  It is ignored if irKey is none.
    """
    return stormtest_client.stc.trigger_high_speed_timer(irKey, keyCount, timeout, slotNo, triggerSlot)

## @par Description
# Stops the high speed timer.  It is intended to be used with TriggerHighSpeedTimer() but could be
# used with StartZapMeasurement() - but not usually needed.
# @param[in] slotNo @b Integer: (optional) The slot number on which to stop the timer.
# @return @e status @b List: List of tuples.  Each tuple is (slot, status) where the status is True if the slot has successfully stopped the timer
#  @subsubsection _eg1 eg1:
# @b Example:
# @code
# >>>print(str(StopHighSpeedTimer()))
# >>>[(12, True)]
# >>>print(str(StopHighSpeedTimer(12)))
# >>>[(12, True)]
# @endcode
@ApiFunction
def StopHighSpeedTimer(slotNo=0):
    """
    Stop the high speed timer.

    Return: List of tuples, each tuple is (slot, status) Status is True if timer successfully stopped.  Will be false if the timer stops due to a
      timeout or other natural reason.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.stop_high_speed_timer(slotNo)

## @par Description
# This function returns the zap times if the zap has completed.
# @param[in] slotNo @b Integer: (optional) The slot number on which to get the results.
# @param[in] wait @b Integer: (optional) The time in seconds to wait for completion.
# @return @b List: Contains the Zap times, array of tuples, the 1st element is the slot number,
# the second is a bool indicating whether the zap was successful
# third is time (in seconds) to start of zap, fourth is time (in seconds) to
# end of zap. If zap is still in progress, then 3rd and 4th values are 0.
# If a timeout occurred, the 2nd parameter is False and the 3rd and 4th will
# reflect either the correct time or the timeout (depending upon whether the
# timeout occurred waiting for the zap start or zap end).
@ApiFunction
def GetZapTimes(slotNo=0, wait=0):
    """
    Get the zap times after a zap measurement has completed.

    Return: List of Tuples. Each Tuple is (SlotNumber, Status, StartTime, EndTime) The Status
      is True is zap completed, False if zap failed with a timeout. StartTime is the time in
      seconds between IR key and start of channel change. EndTime is time between IR key and
      completion of channel change.  If zap is still in progress StartTime and EndTime are both 0.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.

    wait: (Integer, optional) Number of seconds to wait for zap time to complete.  This can be
      used to hold up the script until the zap has finished.
    """
    return stormtest_client.stc.get_zap_times(wait, slotNo)

## @par Description
# This function returns the raw measurements performed - this can be quite a
# lot as 25 measurements (30 on NTSC systems) are performed every second.
# @param[in] slotNo @b Integer: (optional) The slot number on which to get the
# results.
# @return @b List: The return is a list of tuples, 1st is frame number relative to the irKey,
# second is the number of YUV colors in the rectangle of interest.
@ApiFunction
def GetRawZapMeasurements(slotNo=0):
    """
    Returns the raw measurements performed during zap testing.  There are 25 (PAL) or 30 (NTSC)
      measurements per second.

    Return: List of Tuples.  Each tuple is (FrameNumber, YUVColors) where FrameNumber is relative
      to the IR key and the count is number of colors in the rectangle of the image.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.get_raw_zap_measurements(slotNo)

## @par Description
# This function enables the zap timer code to capture the raw video frames during the measurement.
# These can be used for later analysis.  They are captured on the server and can be retrieved using
# the GetRawZapFrame() function.  They frames are overwritten by the next zap measurement on the
# same slot.  So you can free the zap timer but so long as you do not free the Slot then you can
# still get the frames.
# @param[in] maxFrames @b Integer: (optional) The max number of frames to capture. Default is 100.
# @param[in] startFrame @b Integer: (optional) The frame to use as the first captured frame. Frame 0 is the
# first frame after the Zap starts.  You can choose to ignore some frames by setting the value to be greater
# than zero.  Less than zero is an error.  Default is 0.
# @param[in] skipCount @b Integer: (optional) The number of frames to skip between captures. A value of 0 will
# capture each frame, but a value of 1 will skip 1 frame between each and thus effectively capture at 1/2 the
# real frame rate (12.5 fps on a 25 fps PAL system).  Useful to extend the elapsed time period of captured frames if
# it is not necessary to capture each one.  Default 0.
# @param[in] slotNo @b Integer: (optional) The slot number on which to capture the frames. The zap timer must be
# reserved on the slot prior to calling this value.
# @return @b List: The return is a list of tuples, 1st is slot number, 2nd is true/false
@ApiFunction
def EnableCaptureZapFrames(maxFrames=100, startFrame=0, skipCount=0, slotNo=0):
    """
    Enable the capture of individual frames during High Speed timer use.  They can be later
    retrieved with GetRawZapFrame()

    Return: List of Tuples.  Each Tuple is (SlotNumber, Status) Status is true if successfully
      enabled capture.

    maxFrames: (Integer, optional)  The maximum number of frames to capture.

    startFrame: (Integer, optional) The frame to start capture at relative to the High Speed timer
      trigger point. Frame numbers start at 0.

    skipCount: (Integer, optional) The number of frames to skip beteen each capture. 0 means
      capture all frames, 1 means every other frame.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.vta_capture_yuv_sequence(slotNo, maxFrames, startFrame, skipCount)

## @par Description
#  This function returns the number of images actually saved if EnableCaptureZapFrames() is enabled
#  This will be zero if the system is still saving them after the run has ended (there can be a delay).
#  It must be called before calling FreeVideoTimer()
#  @param[in] slotNo @b Integer: (optional) The slot number for which the information is wanted.
#  @return @b List: The return is a list of tuples, 1st is slot number, 2nd is number of images.
#  @note The High Speed Timer captures images coming from the hardware.  For HD systems, it is possible
#  for the Device Under Test to stop producing data on the HDMI link (eg when going into power save).  This
#  fact cannot be determined instantaneously so there is a delay of up to 10 seconds before the low level
#  hardware concludes that there is no video from the hardware.  This means that capturing frames as the
#  DUT goes into power save will likely report fewer frames than you expect.
@ApiFunction
def GetCountImagesSaved(slotNo=0):
    """
    Return the number of images capture after a high speed timer run.

    Return: List of Tuples. Each Tuple is (SlotNumber, Number of Images) If this function is
      called immediately after stopping the high speed timer, the returned number can be less
      than expected as the server has to do some processing after the timer has stopped.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.get_count_zap_images_saved(slotNo)

## @par Description
# This function returns the number of frames for which info has been recorded during a high speed timer run.
# This feature must be enabled by setting a registry key on each slave server.
# It must be called before calling FreeVideoTimer() which deletes the results of a high speed timer run.
# @param[in] slotNo @b Integer: (optional) The slot number for which the information is wanted.
# @return @b List: The return is a list of tuples, 1st is slot number, 2nd is number of frames for which info is saved.
@ApiFunction
def GetCountFrameInfo(slotNo=0):
    """
    Return the number of frames for which info has been saved after a high speed timer run.

    Return: List of Tuples. Each Tuple is (SlotNumber, Number of frames for which info is saved).

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.get_count_frame_info(slotNo)

## @par Description
# This function returns the raw video frame from a zap capture. It is an error to call this if the capture
# was not enabled prior to starting the zap.
# @param[in] frameIndex @b Integer: The frame to retrieve. The 1st captured frame is frame 0.  Note that if you
# specified a non zero skip in EnableCaptureZapFrames(), this is ignored in numbering the frame to be returned. Frame 1
# will be the second frame captured - not necessarily the 2nd frame after the trigger point. The application code will
# need to do its own timing calculations.
# @param[in] slotNo @b Integer: (optional) The slot number on which to get the frame.
# @return @b List: The retrun is a list of tuples, 1st is slot number, 2nd is the frame as a StormTestImageObject.
# @note The server captures images to memory and saves them asynchronously to disk so you need to call
# GetCountImagesSaved() and, if necessary, wait for the images to be saved, before attempting to
# retrieve an image.
@ApiFunction
def GetRawZapFrame(frameIndex, slotNo=0):
    """
    Get a raw image captured during a high speed timer run.

    Return: List of Tuples. Each Tuple is (SlotNumber, StormTestImageObject). The image object can
      be manipulated and/or saved locally to the client machine.

    frameIndex: (Integer) The frame number to retrieve, zero based. Must be less than the number
      returned by GetCountImagesSaved()

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.get_raw_zap_frame(frameIndex, slotNo)

## @par Description
# This function returns info about a frame received during a high speed timer run.
# This feature must be enabled by setting a registry key on each slave server.
# It must be called before calling FreeVideoTimer() which deletes the results of a high speed timer run.
# @param[in] frameInfoIndex @b Integer: The frame to retrieve info about.
# The 1st frame received after the trigger has index 0.
# Note that this is not the same index as used in GetRawZapFrame which only refers to captured frames.
# @param[in] slotNo @b Integer: (optional) The slot number for which the information is wanted.
# @return @b List: The return is a list of tuples, each Tuple is (SlotNumber, {dict with frame info}).
# See example below.
# dataSize is the number of bytes required to store the frame's image.
# emulated indicates that the image did not come from the capture card but was generated due to the absence of video.
# timestamp is the time assigned to the frame when captured whereas elapsedTime is the time since the HST trigger.
# If frameIndex is None then the frame's image was not saved, only info about it. If frameIndex is an integer
# then the frame's image has been saved and can be retrieved using GetRawZapFrame(frameIndex).
# yuvColors is a count of colours in the rect set up when using StartZapMeasurement().
# If StartZapMeasurement() was not used to start the high-speed timer then yuvColors is None.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>#The following example shows the info retrieved from GetFrameInfo() and formatted using json.dumps().
#   >>#While json formats it nicely, note that it converts tuples to lists and None to null
#   >>print(json.dumps(GetFrameInfo(33),indent=2))
#   [
#     [
#       4,
#       {
#         "dataSize": 1382400,
#         "width": 1280,
#         "height": 720,
#         "frameRate": 60,
#         "interlaced": false,
#         "emulated": true,
#         "timestamp": 33656.6400339,
#         "elapsedTime": 0.566,
#         "frameInfoIndex": 33,
#         "frameIndex": null,
#         "yuvColors": 1
#       }
#     ]
#   ]
#  @endcode
@ApiFunction
def GetFrameInfo(frameInfoIndex, slotNo=0):
    """
    Return info about a frame received during a high speed timer run.

    Return: List of Tuples. Each Tuple is (SlotNumber, {dict with frame info}). If an error occurred then the dict is
      replaced with None

    frameInfoIndex: (Integer) The frame number to retrieve info about, zero based. Must be less than the number
      returned by GetCountFrameInfoSaved(). Note this is NOT the same index as used in GetRawZapFrame().

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.get_frame_info(frameInfoIndex, slotNo)

## @par Description
# This function returns info about a frame captured during a high speed timer run with EnableCaptureZapFrames().
# This feature must be enabled by setting a registry key on each slave server.
# It must be called before calling FreeVideoTimer() which deletes the results of a high speed timer run.
# @param[in] frameIndex @b Integer: The frame to retrieve info about.
# The 1st captured frame is frame 0.  Note that if you specified a non zero skip in EnableCaptureZapFrames(),
# this is ignored in numbering the frame to be returned.
# Frame 1 will be the second frame captured - not necessarily the 2nd frame after the trigger point.
# Note that this is the same index as used in GetRawZapFrame.
# @param[in] slotNo @b Integer: (optional) The slot number for which the information is wanted.
# @return @b List: The return is a list of tuples, each Tuple is (SlotNumber, {dict with frame info}).
# See example below.
# Note the format of the returned dictionary is identical to that returned by GetFrameInfo().
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>#The following example shows the info retrieved from GetCapturedFrameInfo() and formatted using json.dumps().
#   >>#While json formats it nicely, note that it converts tuples to lists and None to null
#   >>print(json.dumps(GetCapturedFrameInfo(3),indent=2))
#   [
#     [
#       4,
#       {
#         "dataSize": 1382400,
#         "width": 1280,
#         "height": 720,
#         "frameRate": 60,
#         "interlaced": false,
#         "emulated": true,
#         "timestamp": 3356.3390022,
#         "elapsedTime": 0.733,
#         "frameInfoIndex": 30,
#         "frameIndex": 3,
#         "yuvColors": 5632
#       }
#     ]
#   ]
#  @endcode
@ApiFunction
def GetCapturedFrameInfo(frameIndex, slotNo=0):
    """
    Return info about a frame captured during a high speed timer run.

    Return: List of Tuples. Each Tuple is (SlotNumber, {dict with frame info}). If an error occurred then the dict is
      replaced with None

    frameIndex: (Integer) The frame number to retrieve info about, zero based. Must be less than the number
      returned by GetCountImagesSaved(). This is the same index as used in GetRawZapFrame().

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.get_captured_frame_info(frameIndex, slotNo)

## @par Description
# This function returns info about frames captured during a high speed timer run, with one entry for each set of
# identical formats. ie. If the format of the captured image does not change it will return one entry,
# if for example the resolution or framerate changes once then two entries are returned, and so on.
# This feature must be enabled by setting a registry key on each slave server.
# It must be called before calling FreeVideoTimer() which deletes the results of a high speed timer run.
# Any change to the fields 'width', 'height', 'frameRate', 'interlaced' or 'emulated' will result in
# a new entry in the list of frame formats returned by this function.
# The fields 'first' and 'last' contain a dictionary of values for the first and last frame in each frame format's set.
# eg. formatInfo['first']['frameInfoIndex'] gives the frame info index at which the format started
# and formatInfo['last']['frameInfoIndex'] gives the frame info index at which it ended.
# The fields 'firstSavedFrameIndex' and 'countSavedFrames' give details of any captured frames in each format.
# If there are no captured frames then 'firstSavedFrameIndex' will be None, if there are captured frames then
# 'firstSavedFrameIndex' specifies the first of these using the same index as used by GetRawZapFrame() and
# GetCapturedFrameInfo(), and 'firstSavedFrameIndex' and 'countSavedFrames' can be passed as the arguments
# startIndex and maxFrames in FindRawZapMatch() to find a match to an SDO within only captured frames of one format.
# @param[in] slotNo @b Integer: (optional) The slot number for which the information is wanted.
# @return @b List: The return is a list of tuples, each Tuple is (SlotNumber, [{formatInfo}, ...]).
# See example below.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>#The following example shows the info retrieved from GetFrameInfoChanges() and formatted using json.dumps().
#   >>#While json formats it nicely, note that it converts tuples to lists and None to null
#   >>print(json.dumps(GetFrameInfoChanges(),indent=2))
#  [
#    [
#      4,
#      [
#        {
#          "dataSize": 1382400,
#          "width": 1280,
#          "height": 720,
#          "frameRate": 60,
#          "interlaced": false,
#          "emulated": false,
#          "first": {
#            "timestamp": 33653.7214697,
#            "elapsedTime": 0.016,
#            "frameInfoIndex": 0,
#            "frameIndex": 0,
#            "yuvColors": 2
#          },
#          "last": {
#            "timestamp": 33654.2780587,
#            "elapsedTime": 0.55,
#            "frameInfoIndex": 32,
#            "frameIndex": null,
#            "yuvColors": 1
#          },
#          "firstSavedFrameIndex": 0,
#          "countSavedFrames": 4
#        },
#        {
#          "dataSize": 1382400,
#          "width": 1280,
#          "height": 720,
#          "frameRate": 60,
#          "interlaced": false,
#          "emulated": true,
#          "first": {
#            "timestamp": 33656.6400339,
#            "elapsedTime": 0.566,
#            "frameInfoIndex": 33,
#            "frameIndex": null,
#            "yuvColors": 1
#          },
#          "last": {
#            "timestamp": 33666.8621816,
#            "elapsedTime": 13.116,
#            "frameInfoIndex": 786,
#            "frameIndex": null,
#            "yuvColors": 1
#          },
#          "firstSavedFrameIndex": 4,
#          "countSavedFrames": 74
#        }
#      ]
#    ]
#  ]
#  @endcode
@ApiFunction
def GetFrameInfoChanges(slotNo=0):
    """
    Return info about frames received during a high speed timer run.

    Return: List of Tuples. Each Tuple is (SlotNumber, [{formatInfo}, ...]).

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.get_frame_info_changes(slotNo)

## @par Description
# This function allows you to apply a mask on the video stream with a given color.
# @param[in] rgb @b Tuple: (optional) The RGB color to use to mask the video. The default mask is pure black i.e. RGB(0,0,0)
# @param[in] rect @b List: (optional) The area of the video to mask. The width must be multiple of 16. The height must be multiple of 8. The default rect is (0,0,32,32)
# @param[in] irKey @b String: (optional) The ir key stroke which triggers the mask
# @param[in] keyCount @b Integer: (optional) The number of irKey's to ignore before starting the mask.
# For example, setting irKey = '1' and keyCount = '1' would allow the client to send the ir command '101' and have time start on the second '1' instead of
# the first. Ignored if irKey is None. Default 0.
# @param[in] autoStop @b Boolean: (optional) If set to True, the mask will only be applied to the current frame. Otherwise, the mask
# will be applied until StopOsdMask is called. The default is True, i.e. the mask will be automatically stopped.
# @param[in] slotNo @b Integer: (optional) The slot number on which to apply the mask.
# @return @b List: Each element is a list of slot number, status. The status is true if the slot has successfully applied the mask.  The return
# is always a list even if the slot number is explicitly given.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>#the following example shows how TriggerOsdMask can be used with zap timing APIs, though it can be used independently as well.
#   >>if ReserveVideoTimer():
#   >>    EnableCaptureZapFrames(100,0,2)
#   >>    TriggerOsdMask((20,255,255), (16,16,48,48), "1", 1, True) # set a blue-ish color mask on the video upon the same trigger for the high speed timer
#   >>    TriggerHighSpeedTimer("1",1)
#   >>    PressDigits(101)
#   >>    WaitSec(5)
#   >>    StopHighSpeedTimer()
#   >>    (slot,image) = GetRawZapFrame(10)[0] # return 11th captured frame which is (11 * 3) * 40mS after the 2nd '1' key at 25 fps
#   >>    image.Save("frame11.png") # save it to disk.
#  @endcode
@ApiFunction
def TriggerOsdMask(rgb=(0,0,0), rect=(0,0,32,32), irKey=None, keyCount=0, autoStop=True, slotNo=0):
    """
    Apply a rectangle of color over the streamed video.  Note that this is NOT captured by the
    HighSpeed timer frames becuase it is applied later in the processing chain.

    Return: List of Tuples. Each Tuple is (SlotNumber, Status) Status is true if the mask is
      successfully applied.

    rgb: (Tuple, optional) The RGB color to use to add to the video.

    rect: (Tuple, optional) The area of the video to mask. The width must be multiple of 16. The
      height must be multiple of 8.  The tuple is (left, top, width, height)

    irKey: (String, optional) The ir key stroke which triggers the mask to be applied. If None then
      it is added immediately.

    keyCount: (Integer, optional) The number of times that irKey can be sent before the OSD
      is applied . eg: you want to start after sending keys 303 so you set irKey to 3
      and keyCount to 1 - so that StormTest ignores one of the '3' keys.

    autoStop: (Bool, optional) If set to True, the mask will only be applied to the frame.
      Otherwise, the mask will be applied until StopOsdMask is called.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.trigger_osd_mask(rgb, rect, irKey, keyCount, autoStop, slotNo)

## @par Description
# Stops the OSD mask.  It is intended to be used with TriggerOsdMask when its autoStop parameter is set to False
# @param[in] slotNo @b Integer: (optional) The slot number on which to stop the OSD mask.
# @return @b List: Each element is a list of slot number, status. The status is true if the slot has successfully stopped the OSD mask.  The return
# is always a list even if the slot number is explicitly given.
@ApiFunction
def StopOsdMask(slotNo=0):
    """
    Remove the OSD mask.

    Return: List of Tuples. Each Tuple is (SlotNumber, Status)

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """

    return stormtest_client.stc.stop_osd_mask(slotNo)

## @par Description
# This function allows you to display a string on the video.
# @param[in] osdStr @b String: The string to display
# @param[in] x @b Integer: x coordinate of the display position. x must be multiple of 8
# @param[in] y @b Integer: y coordinate of the display position. y must be multiple of 4
# @param[in] irKey @b String: (optional) The ir key stroke which triggers the OSD string
# @param[in] keyCount @b Integer: (optional) The number of irKey's to ignore before starting the OSD string.
# For example, setting irKey = '1' and keyCount = '1' would allow the client to send the ir command '101' and have time start on the second '1' instead of
# the first. Ignored if irKey is None. Default 0.
# @param[in] autoStop @b Boolean: (optional) If set to True, the OSD string will only be applied to the current frame. Otherwise, the string
# will be displayed until StopOsdString is called. The default is True, i.e. the OSD string will be automatically cleared
# @param[in] slotNo @b Integer: (optional) The slot number on which to display the OSD string.
# @return @b Bool: true if the slot has successfully displayed the OSD string
#  @subsubsection _eg1 eg1:
#  @b Example
#  @code
#   >>#the following example shows how TriggerOsdString can be used with zap timing APIs, though it can be used independently as well.
#   >>if ReserveVideoTimer():
#   >>    EnableCaptureZapFrames(100,0,2)
#   >>    TriggerOsdString("Press 101 Done", 16,16, "1", 1, True)
#   >>    TriggerHighSpeedTimer("1",1)
#   >>    PressDigits(101)
#   >>    WaitSec(5)
#   >>    StopHighSpeedTimer()
#   >>    (slot,image) = GetRawZapFrame(10)[0] # return 11th captured frame which is (11 * 3) * 40mS after the 2nd '1' key at 25 fps
#   >>    image.Save("frame11.png") # save it to disk.
#  @endcode
@ApiFunction
def TriggerOsdString(osdStr, x = 0, y = 0, irKey=None, keyCount=0, autoStop=True, slotNo=0):
    """
    Apply a string of text over the streamed video.  Note that this is NOT captured by the
    HighSpeed timer frames becuase it is applied later in the processing chain.

    Return: Bool. True if successfully setup.

    osdStr: (String) The string to display

    x: (Integer, optional) x coordinate of the display position. x must be multiple of 8.

    y: (Integer, optional) y coordinate of the display position. y must be multiple of 4.

    irKey: (String, optional) The ir key stroke which triggers the string to be applied. If None
      then it is added immediately.

    keyCount: (Integer, optional) The number of times that irKey can be sent before the OSD
      string is applied . eg: you want to start after sending keys 303 so you set irKey to 3
      and keyCount to 1 - so that StormTest ignores one of the '3' keys.

    autoStop: (Bool, optional) If set to True, the string will only be applied to one frame.
      Otherwise, the string will be applied until StopOsdString is called.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.trigger_osd_string(osdStr, x, y, irKey, keyCount, autoStop, slotNo)

## @par Description
# Stops the OSD string.  It is intended to be used with TriggerOsdString when its autoStop parameter is set to False
# @param[in] slotNo @b Integer: (optional) The slot number on which to stop the OSD string.
# @return @b List of Lists.  One List per slot reserved. The List per slot is [slot number, Bool] where the 
# Bool is true if the slot has successfully stopped the OSD string
@ApiFunction
def StopOsdString(slotNo=0):
    """
    Remove the OSD string.

    Return: List of Lists.  One List per slot reserved. The List per slot is [slot number, Bool] where the 
             Bool is true if the slot has successfully stopped the OSD string

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.stop_osd_string(slotNo)

## @}

##  @defgroup Group10 Feed Select API
# These commands allow a test script to dynamically select the feed to a DUT in a particular slot.
#
# Note that dynamic feed select is an optional feature on a StormTest rack and is not installed by default.
##  @{

## @par Description
#  This function is used to select an input feed for a slot. Note that the feeds to slots in a StormTest rack are generally
#  arranged in groups. The normal configuration is that slots are grouped into groups of four. This means that switching the
#  feed on one slot in a group will switch the feed for all slots in the group.\n\n
#  For this reason, the SelectInputFeed() function will only suceed if all slots in a group are reserved by the test script.
#  If the tester wishes to over-ride this behaviour then he should use the @b force parameter to force a switch.
#  @param[in] feed @b Integer: Only 1 and 2 are valid values.
#  @param[in] force @b Bool: (optional) If set to True, then force the feed switch even if all slots in a group are not reserved by the test.
#  @param[in] persistent @b Bool: (optional) If set to False, then the feed to all slots reserved by the test will reset back to the default value when the test ends. If True, the setting will persist across multiple test runs.
#  @return @b Integer/List: Returns 0 if the rack does not support this functionality. Otherwise returns a list of tuples, with one for each slot and a True/False result
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >># Functionality not supported
#   >>print(str(SelectInputFeed(1)))
#   >>0
#
#   >># Slots 1,2,3 and 4 are reserved
#   >>print(str(SelectInputFeed(1)))
#   >>[[1,True], [2,True], [3,True], [4,True]]
#
#   >># Slots 1,2 and 3 are reserved
#   >>print(str(SelectInputFeed(1)))
#   >>[[1,False], [2,False], [3,False]] # Fails because one of the group is not reserved
#
#   >># Force the switch
#   >>print(str(SelectInputFeed(1,True)))
#   >>[[1,True], [2,True], [3,True]]
#  @endcode
@ApiFunction
def SelectInputFeed(feed, force = False, persistent = False):
    """
    Select the input RF feed to the slot. This requires the StormTest server to have the feed
    select option installed.  The function acts on all slots reserved by the script.

    Return: List of Lists.  Each List is [SlotNumber, Status] The number of slots in the list
      depends on the feed select hardware configuration.

    feed: (Integer) The feed to select (1 or 2)

    force: (Bool, optional) Set to true to force the feed select even if some of the slots that
      will be affected are not reserved by the script.  This can disrupt other scripts.

    persistent: (Bool, optional).  If True, the feed selection will be remain when the script ends.
      Otherwise the feed will revert to the default value as soon as the script ends.
    """
    return stormtest_client.stc.SelectInputFeed(feed, force, persistent)

## @par Description
#  This function returns the currently selected input feed for each reserved slot
#  @param None
#  @return  @e feedStatus @b List: A list of lists. For each slot, the slot number and the feed number is returned.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >># Slots 1-6 are reserved
#   >># Force all slots to feed 1
#   >>print(str(SelectInputFeed(1,force = True)))
#   >>[[1,True], [2,True], [3,True], [4,True], [5,True], [6,True]]
#   >>
#   >># Select feed 2, but don't force if all slots in a group are not reserved
#   >>print(str(SelectInputFeed(2)))
#   >>[[1,True], [2,True], [3,True], [4,True], [5,False], [6,False]]
#   >>
#   >># Now slots 1-4 will be on feed 2 and slots 5-6 on feed 1
#   >>print(str(GetInputFeed()))
#   >>[[1,2], [2,2], [3,2], [4,2], [6,1], [6,1]]
#  @endcode
@ApiFunction
def GetInputFeed():
    """
    Get the current feed for each reserved slot. This requires the StormTest server to have the
    feed select option installed.

    Return: List of Lists.  Each List is [SlotNumber, FeedSelected]
    """
    return stormtest_client.stc.GetInputFeed()

## @}

##  @defgroup Group11 Audio/Video Switch API
# These commands allow a test script to dynamically select the audio and video source that is captured by StormTest.
#
# Note that dymamic audio/video switching is an optional feature on a StormTest rack that requires extra hardware and it is not installed by default.
##  @{

## @par Description
#  AudioChannel Enum. Defines the valid values for audio channel.
#  @param Left : Left audio channel
#  @param Right : Right audio channel
class AudioChannel:
    """
    Audio channel for AV switch.  Values are Left and Right
    """
    Left = 'Left'
    Right = 'Right'

## @par Description
#  This function sets the video and audio input to StormTest. This function is only valid for StormTest racks that have been equipped with an audio/video switch device that allows the test script to select which of the
#  a/v inputs to use.
#  @param[in] videoSource @b string : The video source to use.
#  @param[in] audioSource @b string : The audio source to use.
#  @param[in] audioChannel @b AudioChannel : The audio channel to use. StormTest only support mono audio, so the test can use this to switch between left and right audio channels.
#  @param[in] slotNo @b Integer: (optional) The slot number to set the AV input on
#  @return @b List: First entry indicates if the call suceeded. The second entry is a message. Third entry is a list of slots the command was enacted on.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>ret = SetAVInput("cvbs1", "analog1", AudioChannel.Left, 1)  # Set AV input for slot 1
#   >>print(str(ret))
#   >>[1, 'OK', [1]]
#   or
#   >>ret = SetAVInput("cvbs1", "analog1", AudioChannel.Left)   # Sets AV input for all reserved slots
#   >>print(str(ret))
#   >>[1, 'OK', [1, 2]]
#
#   >># Using the command when no AV switch is configured
#   >>ret = SetAVInput("cvbs1", "analog1", AudioChannel.Left)
#   >>print(str(ret))
#   >>[0, 'No AV Switch Available', [1, 2]]
#  @endcode
#  @note If the @e slotNo parameter is omitted the default is to set AV input for all slots reserved
@ApiFunction
def SetAVInput(videoSource, audioSource, audioChannel, slotNo = 0):
    """
    Set the AV switch input.  The selected source will be routed from the DUT to StormTest and is
    used for the audio / video analysis and capture.  This requires the StormTest server to have
    the optional AV switch on selected slot.

    Return: List. List is [StatusCode, Message, ListOfSlots]. A status code of 1 means the call
      succeeded.

    videoSource: (String) The video source to use.

    audioSource: (String) The audio source to use.

    audioChannel: (AudioChannel) The audio channel to use.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.set_av_input(videoSource, audioSource, audioChannel, slotNo)

## @par Description
#  This function returns the AV input
#  @param[in] slotNo @b Integer: (optional) Allows the user to get the AV input on just one slot rather than all slots reserved.
#  @return @b Array: An array of array consisting of slot number and AV input. 0 is returned if there is no AV switch configured in the rack.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Get AV inputs of all reserved slots
#   >>ret=GetAVInput()
#   >>print(str(ret))
#   >>[ [1, ['cvbs1', 'analog', 'Left']],
#   >>  [3, ['cvbs1', 'analog', 'Left']] ]
#
#   # Get AV input of one specific slot
#   >>ret=GetAVInput(3)
#   >>print(str(ret))
#   >>['cvbs1', 'analog', 'Left']
#  @endcode
#  @note If the @e slotNo parameter is omitted the AV inputs returned are for all slots reserved.
@ApiFunction
def GetAVInput(slotNo = 0):
    """
    Return the current status of the audio video switch inputs.  These are the sources routed from
    the DUT into StormTest. This requires the StormTest server to have the optional AV switch on
    selected slot.

    Return: List of Lists (if slotNo is 0) or a List.  The contents of the list are: [SlotNumber,
      [VideoSource, AudioSource, AudioChannel]] - the sources as strings. If SlotNo is not zero
      then just the list of sources is returne.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.get_av_input(slotNo)

## @par Description
#  This function returns the available video inputs that can be passed to the SetAVInput() function.
#  @param[in] slotNo @b Integer: (optional) Allows the user to get the available video inputs on just one slot rather than all slots reserved.
#  @return @b Array: An array of tuples consisting of slot number and available video inputs. 0 is returned if there is no AV switch configured in the rack.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Get available video inputs of all reserved slots
#   >>ret=GetCapsVideoInput()
#   >>print(str(ret))
#   >>[[1, ['cvbs1', 'cvbs2', 'cvbs3', 'cvbs4', 'svideo', 'ypbpr', 'hdmi', 'dvi', 'vga', 'vrf1', 'vrf2']],
#   >>[3, ['cvbs1', 'cvbs2', 'cvbs3', 'cvbs4', 'svideo', 'ypbpr', 'hdmi', 'dvi', 'vga', 'vrf1', 'vrf2']]]
#
#   # Get available video inputs of one specific slot
#   >>ret=GetCapsVideoInput(3)
#   >>print(str(ret))
#   >>['analog1', 'analog2', 'analog3', 'analog4', 'analog5', 'hdmi', 'optical', 'coax', 'arf1', 'arf2']
#  @endcode
#  @note If the @e slotNo parameter is omitted the available video inputs returned are for all slots reserved.
@ApiFunction
def GetCapsVideoInput(slotNo = 0):
    """
    Get the capabilites of the AV switch video input - the list of available sources that can be
    routed from the DUT into StormTest.  This requires the StormTest server to have the optional
    AV switch on selected slot.

    Return: List of Lists (if slotNo is 0) or a List.  The contents of the list are: [SlotNumber,
      [List of Sources]] Each source is a string. If slotNo is not zero then just the list of
      sources is returned.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.get_caps_video_input(slotNo)

## @par Description
#  This function returns the available audio inputs for a given video input
#  @param[in] slotNo @b Integer: (optional) Allows the user to get the available audio inputs on just one slot rather than all slots reserved.
#  @param[in] videoSource @b String: The video source for which the audio capabilies are wanted.
#  @return @b Array: An array of tuples consisting of slot number and available audio inputs. 0 is returned if there is no AV switch configured in the rack.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Get available audio inputs of all reserved slots
#   >>ret=GetCapsAudioInput(VideoSource.Scart1CVBS)
#   >>print(str(ret))
#   >>[[1, ['analog1', 'analog2', 'analog3', 'analog4', 'analog5', 'hdmi', 'optical','coax', 'arf1', 'arf2']],
#   >>[3, ['analog1', 'analog2', 'analog3', 'analog4', 'analog5', 'hdmi', 'optical','coax', 'arf1', 'arf2']]]
#
#   # Get available audio inputs of one specific slot
#   >>ret=GetCapsAudioInput('cvbs1', 3)
#   >>print(str(ret))
#   >>['analog1', 'analog2', 'analog3', 'analog4', 'analog5', 'hdmi', 'optical', 'coax', 'arf1', 'arf2']
#  @endcode
#  @note If the @e slotNo parameter is omitted the available audio inputs returned are for all slots reserved.
@ApiFunction
def GetCapsAudioInput(videoSource, slotNo = 0):
    """
    Get the capabilites of the AV switch audio input - the list of available sources that can be
    routed from the DUT into StormTest.  Since the audio source may depend on the video source,
    you specify which video source you are interesed in.  This requires the StormTest server to
    have the optional AV switch on selected slot.

    Return: List of Lists (if slotNo is 0) or a List.  The contents of the list are: [SlotNumber,
      [List of Sources]] Each source is a string. If slotNo is not zero then just the list of
      sources is returned.

    videoSource: (String) The video source for which the associated audio source is required.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.get_caps_audio_input(videoSource, slotNo)

## @par Description
#  This function returns the available RF formats for a given tuner on a particular av switch
#  @param[in] tunerNum @b Integer: Specifies the tuner to query in the avswitch. This value can be 1 or 2.
#  @param[in] slotNo @b Integer: (optional) Allows the user to get the available RF formats on just one slot rather than all slots reserved.
#  @return @b Array: An array of tuples consisting of slot number and available RFformats. 0 is returned if there is no AV switch configured in the rack.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Get available rf formats from tuner 1 of all reserved slots
#   >>ret=GetRfFormats(1)
#   >>print(str(ret))
#   >>[[1, ['pal_secam_i', 'ntsc', 'pal_secam_bg', 'pal_secam_dk', 'pal_secam_l', 'pal_secam_lp']]]
#
#   # Get available rf formats from tuner 1 of one specific slot
#   >>ret=GetRfFormats(1, 1)
#   >>print(str(ret))
#   >> ['pal_secam_i', 'ntsc', 'pal_secam_bg', 'pal_secam_dk', 'pal_secam_l', 'pal_secam_lp']
#  @endcode
#  @note If the @e slotNo parameter is omitted the available RF formats returned are for all slots reserved.
@ApiFunction
def GetRfFormats(tunerNum,slotNo = 0):
    """
    Get the capabilites of the AV switch RF input - the list of available formats supported by the
    RF tuner on the AV switch.  This requires the StormTest server to have the optional AV switch
    on selected slot.

    Return: List of Lists (if slotNo is 0) or a List.  The contents of the list are: [SlotNumber,
      [List of Formats]] Each format is a string. If slotNo is not zero then just the list of
      formats is returned.

    tunerNum: (Integer) RF tuner number of interest. The first tuner is tunerNum = 1.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.get_rf_formats(tunerNum,slotNo)

## @par Description
#  This function returns the RF tuner configuration for a given tuner on a particular av switch
#  @param[in] tunerNum @b Integer: Specifies the tuner to query in the avswitch. This value can be 1 or 2.
#  @param[in] slotNo @b Integer: (optional) Allows the user to get the RF tuner configuration on just one slot rather than all slots reserved.
#  @return @b Array: An array of tuples consisting of slot number and a tuple of frequency in kHz and format. 0 is returned if there is no AV switch configured in the rack.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Get available RF configuration from tuner 1 of all reserved slots
#   >>ret=GetRfTunerConfiguration(1)
#   >>print(str(ret))
#   >>[[1, ['602000', 'ntsc']]]
#
#   # Get available RF configuration from tuner 1 from one specific slot
#   >>ret=GetRfTunerConfiguration(1, 1)
#   >>print(str(ret))
#   >> ['602000', 'ntsc']
#  @endcode
#  @note If the @e slotNo parameter is omitted the available RF formats returned are for all slots reserved.
@ApiFunction
def GetRfTunerConfiguration(tunerNum,slotNo = 0):
    """
    Get the RF tuner configuration. This requires the StormTest server to have the optional AV
    switch on selected slot.

    Return: List of Lists (if slotNo is 0) or a List.  The contents of the list are: [SlotNumber,
      [Frequency, Format]] Each element is a string. The frequency is in kHz.  If slotNo is not
      zero then just the list of [Frequency, Format] is returned.

    tunerNum: (Integer) RF tuner number of interest. The first tuner is tunerNum = 1.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.get_rf_tuner_configuration(tunerNum,slotNo)

## @par Description
#  This function configures the specified RF tuner on a particular av switch
#  @param[in] tunerNum @b Integer: Specifies the tuner to configure in the avswitch. This value can be 1 or 2.
#  @param[in] format @b String: A valid rf tuner format
#  @param[in] frequency @b Integer: A frequency in the supported frequency range in kHz
#  @param[in] slotNo @b Integer: (optional) Allows the user to configure the RF tuner on just one slot rather than all slots reserved.
#  @return @b Array: First entry indicates if the call suceeded. The second entry is a message. Third entry is a list of slots the command was enacted on.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Configure RF tuner 1 for all reserved slots
#   >>ret=ConfigureRfTuner(1,"pal_secam_i",602000)
#   >>print(str(ret))
#   >>[1, 'OK', [1,2]]
#
#   # Configure RF tuner 1 for of one specific slot
#   >>ret=ConfigureRfTuner(1,"pal_secam_i",602000,1)
#   >>print(str(ret))
#   >>[1, 'OK', [1]]
#  @endcode
#  @note If the @e slotNo parameter is omitted the available RF formats returned are for all slots reserved.
@ApiFunction
def ConfigureRfTuner(tunerNum,format,frequency,slotNo = 0):
    """
    Configure the RF tuner for an AV switch. This requires the StormTest server to have the
    optional AV switch on selected slot.

    Return: List. The contents of the List are: [StatusCode, Message, List of Slots] The status
      code is 1 on success.

    tunerNum: (Integer) RF tuner number of interest. The first tuner is tunerNum = 1.

    format: (String) The RF format to configure.

    frequency: (Integer) The frequency to tune to, in kHz.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.configure_rf_tuner(tunerNum,format,frequency,slotNo)

## @par Description
#  This function configures the HD down converter  on a particular av switch
#  @param[in] format @b String: A valid HD format, which can be "pal" or "ntsc"
#  @param[in] slotNo @b Integer: (optional) Allows the user to configure the HD down converter on just one slot rather than all slots reserved.
#  @return @b Array: First entry indicates if the call suceeded. The second entry is a message. Third entry is a list of slots the command was enacted on.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Get available rf formats from tuner 1 of all reserved slots
#   >>ret=ConfigureHdDownConverter("pal")
#   >>print(str(ret))
#   >>[1, 'OK', [1,2]]
#
#   # Get available audio inputs of one specific slot
#   >>ret=ConfigureHdDownConverter("pal",1)
#   >>print(str(ret))
#   >>[1, 'OK', [1]]
#  @endcode
#  @note If the @e slotNo parameter is omitted the available RF formats returned are for all slots reserved.
@ApiFunction
def ConfigureHdDownConverter(format,slotNo = 0):
    """
    Configure the HD down converter for an AV switch. This requires the StormTest server to have
    the optional AV switch on selected slot.

    Return: List. The contents of the List are: [StatusCode, Message, List of Slots] The status
      code is 1 on success.

    format: (String) The format to configure. "pal" or "ntsc".

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.configure_hd_down_converter(format)

## @}

##  @defgroup Group12 Telephone Line Simulator API
# These commands allow a test script to control a Telephone Line Simulator (TLS) device.
#
# Note that the telephone line simulator is an optional extra on StormTest racks and is not available by default.
##  @{

## @par Description
#  OffHookMode Enum. Defines the valid values for off-hook mode.
#  @param Silence : Present no tone when off-hook
#  @param DialTone : Present dial tone when off-hook
#  @param AudioNoise : Present audio noise when off-hook
class OffHookMode:
    """
    Class to define the possible off hook modes for the telephone line simulator. Options
    are Silence, DialTone or AudioNoise.
    """
    Silence = 'Silence'
    DialTone = 'DialTone'
    AudioNoise = 'AudioNoise'

## @par Description
#  TLSStatus Enum. Defines the status of a telephone line simulator port.
#  @param OnHook : On-hook
#  @param OffHook : Off-hook
class TLSStatus:
    """
    Class to define the possible off hook status values for the telephone line simulator.
    Options OnHook, OffHook.
    """
    OnHook = 'OnHook'
    OffHook = 'OffHook'

## @par Description
#  This function sets the off-hook mode for a port on the telephone line simulator device.
#  @param[in] offHookMode @b OffHookMode: the mode of the off hook simulation
#  @param[in] slotNo @b Integer: (optional) The slot number to set OffHookMode on
#  @return @b List: First entry indicates if the call suceeded. The second entry is a message. Third entry is a list of slots the command was enacted on.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetTLSOffHookMode(OffHookMode.DialTone, 1)  # Set to present dial tone for slot 1
#   or
#   >>SetTLSOffHookMode(OffHookMode.DialTone)   # Set to present dial tone for all reserved slots
#  @endcode
#  @note If the @e slotNo parameter is omitted the default is to operate on all slots reserved
@ApiFunction
def SetTLSOffHookMode(offHookMode, slotNo = 0):
    """
    Set the off-hook mode for a slot on the telephone line simulator.  This requires the StormTest
    server to have the optional telephone line simulator installed.

    Return: List. Contents of list are [StatusCode, Message, List of Slots] Status code is 1 if
      mode was set successfully.

    offHookMode: (OffHookMode) Behavior for the simulator when the phone line goes 'off hook'.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.set_tls_off_hook_mode(offHookMode, slotNo)

## @par Description
#  This function returns the off-hook mode that the TLS ports are configured with.
#  @param[in] slotNo @b Integer: (optional) Allows the user to get the off-hook mode on just one slot rather than all slots reserved.
#  @return @b Array: An array of arrays consisting of slot number and the off-hook mode.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Get the off-hook mode of all reserved slots
#   >>ret=GetTLSOffHookMode()
#   >>print(str(ret))
#   >>[[1, 'DialTone'], [3, 'DialTone']]
#
#   # Get the off-hook mode of one specific slot
#   >>ret=GetTLSOffHookMode(3)
#   >>print(str(ret))
#   >>DialTone
#  @endcode
#  @note If the @e slotNo parameter is omitted the default is to operate on all slots reserved.
@ApiFunction
def GetTLSOffHookMode(slotNo = 0):
    """
    Get the off-hook mode for a slot on the telephone line simulator.  This requires the
    StormTest server to have the optional telephone line simulator installed.

    Return: List of Lists (if slotNo is 0) or a OffHookMode. Contents of list are [SlotNumber,
      OffHookMode]

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.get_tls_off_hook_mode(slotNo)

## @par Description
#  This function returns the TLS status
#  @param[in] slotNo @b Integer: (optional) Allows the user to get the TLS status on just one slot rather than all slots reserved.
#  @return @b Array: An array of arrays consisting of slot number and the TLS status.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Get the TLS status of all reserved slots
#   >>ret=RetrieveTLSStatus()
#   >>print(str(ret))
#   >>[[1, 'OffHook'], [3, 'OnHook']]
#
#   # Get the TLS status of one specific slot
#   >>ret=RetrieveTLSStatus(3)
#   >>print(str(ret))
#   >>OnHook
#  @endcode
#  @note If the @e slotNo parameter is omitted the default is to operate on all slots reserved.
@ApiFunction
def RetrieveTLSStatus(slotNo = 0):
    """
    Get the off-hook status for a slot on the telephone line simulator.  This requires the
    StormTest server to have the optional telephone line simulator installed.

    Return: List of Lists (if slotNo is 0) or a TLSStatus. Contents of list are [SlotNumber,
      TLSStatus]

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.retrieve_tls_status(slotNo)

## @par Description
#  This function returns the DTMF numbers received since the last off-hook transition.
#  @param[in] slotNo @b Integer: (optional) Allows the user to get the last DTMF dialed on just one slot rather than all slots reserved.
#  @return @b Array: An array of arrays consisting of slot number and the last DTMF dialed.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Get the last DTMF dialed of all reserved slots
#   >>ret=RetrieveTLSLastDialed()
#   >>print(str(ret))
#   >>[[1, "12345#"], [3, "323232"]]
#
#   # Get the last DTMF dialed of one specific slot
#   >>ret=RetrieveTLSLastDialed(3)
#   >>print(str(ret))
#   >>"323232"
#  @endcode
#  @note If the @e slotNo parameter is omitted the default is to operate on all slots reserved.
@ApiFunction
def RetrieveTLSLastDialed(slotNo = 0):
    """
    Get the last number dialed for a slot on the telephone line simulator.  This requires the
    StormTest server to have the optional telephone line simulator installed.

    Return: List of Lists (if slotNo is 0) or a String. Contents of list are [SlotNumber,
      DialedNumber] The Dialed number is a string containing all the DTMF tones detected
      since the last off-hook transition or the most recent call to ClearTLSLastDialed()
      whichever occurred most recently.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.retrieve_tls_last_dialed(slotNo)

## @par Description
#  This function clears the DTMF numbers received since the last off-hook transition.
#  @param[in] slotNo @b Integer: (optional) Allows the user to clear the last DTMF dialed on just one slot rather than all slots reserved.
#  @return @b None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Clear the last DTMF dialed of all reserved slots
#   >>ClearTLSLastDialed()
#
#   # Clear the last DTMF dialed of one specific slot
#   >>ClearTLSLastDialed(3)
#  @endcode
#  @note If the @e slotNo parameter is omitted the default is to operate on all slots reserved.
@ApiFunction
def ClearTLSLastDialed(slotNo = 0):
    """
    Clear the last number dialed for a slot on the telephone line simulator.  This requires the
    StormTest server to have the optional telephone line simulator installed.

    Return: None

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.clear_tls_last_dialed(slotNo)

## @}

## @defgroup Group13 Licensing API
# This section contains the functions that allow a user to check the StormTest licensing status.
# StormTest requires a number of licenses to be fully functional. Every StormTest server must have a valid
# StormTest server license. Similarly, every StormTest Client must have a valid client license.
# Note that a client can be a running test script or the StormTest remote control application. Basically any process
# that attempts to reserve a slot on a StormTest server will require a client license.
#
# Client licenses are served out from a pool and one license is consumed every time a new user connects to a StormTest
# server by calling ConnectToServer(). A new user is defined as a username\@hostname. This means that one user can run as many
# tests as they want on one PC and they will use only one client license. However, they will need another client license
# to run tests on a different PC with the same username.
# In addition, in order to use the OCR functionality, at least one StormTest server in the test facility must have an OCR
# license. The OCR engine is licensed for a certain number of characters per month. This level can be adjusted according
# to an individual customers demand.
## @{

## @par Description
#  This function returns a multi-line string containing details on the following
#  - Server host id
#  - Total number of server licenses
#  - Number of server licenses available
#  - List of server license users
#  - Total number of client licenses
#  - Number of client licenses available
#  - List of client license users
#  By default, the license details are retrieved via the currently connected StormTest server. However, if no server is connected,
#  or if a server name is passed as a parameter, the details will be retrieved via this server.
#  @param[in] server @b String: (optional) Specify the StormTest server to get the license details from. If the server does not use the standard port, then the server name must include the port number (i.e. 'server:port')
#  @return @e licDetails @b String: The StormTest license details.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>ret = StormTestLicenseDetails()
#   >>print(str(ret))
#   >>License Status for server server1 :
#   >>-----------------------------------------------------------
#   >>Server host id: "00xxyyzzaabb"
#   >>
#   >>-----------------------------------------------------------
#   >>Number of StormTest Server licenses:     5
#   >>Available StormTest Server licenses:     4
#   >>
#   >>StormTest Server Users:
#   >>    Administrator@server1
#   >>
#   >>-----------------------------------------------------------
#   >>Number of StormTest Client licenses:     5
#   >>Available StormTest Client licenses:     5
#   >>
#   >>StormTest Client Users:
#   >>    None
#   >>-----------------------------------------------------------
#  @endcode
@ApiFunction
def StormTestLicenseDetails(server=None):
    """
    Get details of StormTest license is a user friendly format.

    Return: String.  Details of server and client license usage.

    server: (String, optional) The server to query. This may include the port number as well
      as the host name.  If omitted the ConnectToServer() must have been called to establish
      the server to query.
    """
    return stormtest_client.stc.license_details(server)

## @par Description
#  This function returns a colon separated string of details relating to the installations OCR license.
#  Each StormTest installation is licensed to allow up to a set maximum number of characters or pages to be OCRed each period (normally a period is a month).
#  Details are given here of the number of units remaining in the current period that can be OCRed. Once the number drops to zero, OCR functionality will not be available again until a new period begins or an increased allowance is purchased.
#  \n\n By default, the OCR license details for the currently connected StormTest server are returned. However, if no server is connected, or if the details
#  for a different server are required, the server name can be passed as a parameter.\n\n This Function does not require a client license to be called.
#  @param[in] server @b String: (optional) Specify the StormTest server to get OCR license details from. If the server does not use the standard port, then the server name must include the port number (i.e. 'server:port')
#  @return @e licDetails @b String: The license details for the OCR engine.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>ret = OCRLicenseDetails()
#   >>print(str(ret))
#   >>Available characters per month 10000000: Remaining characters 9925335
#  @endcode
@ApiFunction
def OCRLicenseDetails(server=None):
    """
    Get details of OCR license.

    Return: String. Human readable information of OCR license details.

    server: (String, optional) The StormTest server for which the OCR license details are wanted.
      This may include the port number as well as the host name.  If omitted the ConnectToServer()
      must have been called to establish the server to query.
    """
    return stormtest_client.stc.ocr_licensing_details(server)

## @}

##  @defgroup Group14 StormTest Database access API
# These functions allow the user to access the StormTest database, retrieving and setting the fields relating to the devices under test.
#
# <b> NOTE: All these functions require the SetMasterConfigurationServer() call to have been made prior to their use.  Failure to do this will result in a Stormtest exception being raised.</b>
##  @{

## @par Description
#  This function sets the machine address of the master StormTest configuration server. Optionally
#  the port used for the configuration server can be specified also. The configuration server must be set
#  if the user wishes to submit jobs for remote execution on any StormTest server in the facility or to access the StormTest database.
#  @note If used, then SetMasterConfigurationServer must be called before ConnectToServer().
#  @param[in] serverAddress @b String: The address of the server
#  @param[in] cfgPort @b String: (optional) The port to use for the configuration server - unless the server set up is unusual, don't specify this and leave
#  the default as 8001.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#    >>SetMasterConfigurationServer("master_server")
#  @endcode
@ApiFunction
def SetMasterConfigurationServer(serverAddress, cfgPort="8001"):
    """
    Set the master configuration server for the database query functions.  This should be
    used early in the script.  Must be used before ConnectToServer()

    Return: None

    serverAddress: (String) The host name or IP address of the configuration server.

    cfgPort: (String, optional) The port used by the configuration server.
    """
    return stormtest_client.stc.set_master_configuration_server(serverAddress, cfgPort)

################################################################################################################
# NOTE: All these functions require the SetMasterConfigurationServer call to have been made prior to           #
#       their use.  Failure to do this will result in a Stormtest exception being raised.                      #
################################################################################################################

## @par Description
#  This function is used to create an entry in the database for a device under test (DUT) i.e. a DUT.
#  @param[in] slotId @b Integer : unique facility wide slotId
#  @param[in] name @b String : name to give to the DUT (can be "" but not @e None)
#  @param[in] description @b String : description to give to the DUT (can be "" but not @e None)
#  @param[in] serialNumber @b String : unique serial number of DUT - must be unique within a modelName / modelType
#  @param[in] modelName @b String : name of the DUT model within the facility (must already exist in database)
#  @param[in] modelType @b String : name of the type of the DUT model within the facility (must already exist in database)
#  @param[in] hwVersionMajor @b String : Major hw version of the DUT as a string (need not already exist - see fCreateHwVersionIfNeeded)
#  @param[in] hwVersionMinor @b String : Minor hw version of the DUT as a string (need not already exist - see fCreateHwVersionIfNeeded)
#  @param[in] fCreateHwVersionIfNeeded @b Bool : (optional) If false, creation of dut instance will fail unless model,type and hw versions
#           already exist.  If true then if either major or minor hw versions do not exist a new model/type with the specified
#           hw versions will be created (all other attributes of the model/type will be cloned).  It is a requirement that
#           at least one model with valid hw versions is created manually in the database before doing this.
#  @return @e idOfDut @b String: The id of the newly created dut.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#    >>CreateDutInstanceInSlot(99945, "my dut","A new dut", "899a", "DutType","1","34")
#  @endcode

@ApiFunction
def CreateDutInstanceInSlot(slotId, name, description, serialNumber, modelName, modelType, hwVersionMajor, hwVersionMinor, fCreateHwVersionIfNeeded=True):
    """
    Create a DUT instance (ie a DUT) in a slot within the database.

    Return: Id of newly created dut as as string.

    slotId: (Integer) unique facility wide slotId where the DUT is located - not a slot number.

    name: (String) name to give to the DUT.

    description: (String) description to give to the DUT.

    serialNumber: (String) unique (within modelName / modelType) serial number of DUT.

    modelName: (String) name of the DUT model within the facility.

    modelType: (String) name of the type of the DUT model within the facility.

    hwVersionMajor: (String) Major hw version of the DUT as a string.

    hwVersionMinor: (String) Minor hw version of the DUT as a string.

    fCreateHwVersionIfNeeded: (Bool, optional) If false, creation of DUT instance will fail unless
      model,type and hw versions already exist.  If true then if either major or minor hw versions
      do not exist a new model/type with the specified versions will be created.
    """
    return stormtest_client.stc.create_dut_instance(slotId, name, description, serialNumber, modelName, modelType, hwVersionMajor, hwVersionMinor, fCreateHwVersionIfNeeded)

## @par Description
# This function is used to update a DUT entry in the database
# @param[in] dutId @b Integer : unique facility wide DUT id to be updated
# @param[in] name @b String : name to be given. None for no change
# @param[in] description @b String : description for the DUT. None for no change
# @param[in] serial_number @b String : serial number for the DUT. None for no change
# @param[in] ipaddress @b String : ip address of the DUT. None for no change
# @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#    >>UpdateDutInstance(45, "my dut")
#  @endcode
@ApiFunction
def UpdateDutInstance(dutId, name=None, description=None, serial_number=None, ipaddress=None):
    """
    Update a DUT instance that is in the database.

    Return: None.

    dutId: (Integer) unique facility wide DUT id to be updated.

    name: (String, optional) name to be given. Omit to leave unchanged.

    description: (String, optional) description for the DUT. Omit to leave unchanged.

    serial_number: (String, optional) serial number for the DUT. Omit to leave unchanged.

    ipaddress: (String, optional) ip address of the DUT. Omit to leave unchanged.
    """
    return stormtest_client.stc.update_dut_instance(dutId, name, description, serial_number, ipaddress)

## @par Description
# This function is used to update a DUT entry in the database
# @param[in] server @b String : server name where DUT is.
# @param[in] slotNo @b Integer : slot no within the server.
# @param[in] name @b String : name to be given. None for no change
# @param[in] description @b String : description for the DUT. None for no change
# @param[in] serial_number @b String : serial number for the DUT. None for no change
# @param[in] ipaddress @b String : ip address of the DUT. None for no change
# @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#    >>UpdateDutInstanceInSlot("server", 1, "my dut",ipaddress="192.168.1.16")
#  @endcode
@ApiFunction
def UpdateDutInstanceInSlot(server, slotNo, name=None, description=None, serial_number=None, ipaddress=None):
    """
    Update DUT instance in a slot.

    Return: None.

    server: (String) server name where DUT is.

    slotNo: (Integer) slot no within the server.

    name: (String, optional) name to be given. Omit to leave unchanged.

    description: (String, optional) description for the DUT. Omit to leave unchanged.

    serial_number: (String, optional) serial number for the DUT. Omit to leave unchanged.

    ipaddress: (String, optional) ip address of the DUT. Omit to leave unchanged.
    """
    return stormtest_client.stc.update_dut_instance_in_slot(server, slotNo, name, description, serial_number, ipaddress)

## @par Description
#  This function gets information about the DUT in the specified slot.
#  @param[in] slotNo @b Integer : (optional) The slot number in the rack that the DUT is located in.
#  @param[in] fields @b List : (optional) List of fields to return. If omitted then all fields bar ipaddress and modelId are returned (as per 1.4 version).
#  valid fields names are: name, description, modelName, modelType, hwVersionMajor, hwVersionMinor, serialNumber, ipaddress, modelId
#  @return @b Array : If @e slotNo is 0 then return is an array of tuples else just one tuple is returned.
#
#  contents are (slotNumber, slotId, name, description, serialNumber, modelName, modelType, hwVersionMajor, hwVersionMinor) as per
#  CreateDutInstanceInSlot() function parameter definition. If fields is given then the subset specified is returned. in the order listed in fields
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#    >>GetDutInstanceInSlot(1, ["ipaddress", "name"])
#    >>["127.0.0.1", "My DUT"]
#  @endcode
@ApiFunction
def GetDutInstanceInSlot(slotNo=0, fields = None):
    """
    Get information about a DUT in specifed slot (must be reserved to script)

    Return: List of Tuples (if slotNo is 0) or a Tuple.  The Tuple contains: (slotNumber, slotId,
      name, description, serialNumber, modelName, modelType, hwVersionMajor, hwVersionMinor,
      ipaddress)

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.

    fields: (List, optional) The fields to return. If omitted all fields are returned EXCEPT
      ipaddress (for compatibility with 1.4 and earlier). If fields is specified it is a list
      of strings to return and the return is tuple in order specified under Return even if
      order of fields is different.
    """
    return stormtest_client.stc.get_dut_instance(slotNo, fields)

## @par Description
#  This function gets information about the DUT of the specified DUT id.
#  @param[in] dutId @b Integer : The DUT id.
#  @return @b Dictionary : Dictionary of fields->values.  None on an error.  Contents vary by version but so far the list is:
#  slotid (NULL on DUT not in a slot), dutid, name, description, serialnumber, ipaddress, modelname,
#  modeldescription, manufacturer, manfmodelname, hwversion, minorhwversion, modeltype, modeltypedescription,
#  network
@ApiFunction
def GetDutDetails(dutId):
    """
    Get details about a DUT by id.

    Return: Dictionary. The dictionary is keyed by field name and value is the value. None is
      returned on error. fields vary by software version.

    dutId: (Integer) DUT id.
    """
    return stormtest_client.stc.get_dut_details(dutId)

## @par Description
#  This function gets information for the device in the slot. The collections and components and the supported status must be added manually outside of this API.
#  @param[in] componentName @b String : Name of a component to search for (case sensitive). Use empty string for all components.
#  @param[in] slotNo @b Integer : (optional) By default, data for all reserved slots is returned, unless this parameter is used.
#  @return @b Array : The return value is an array of tuples (if @e slotNo=0) or a single tuple (if @e slotNo!=0).
#  Each tuple is (slotNo, array of components). Each component is an array: [ componentName, Description, version, collectionName, collectionDescription, status ]
@ApiFunction
def GetSoftwareComponentsSupported(componentName, slotNo=0):
    """
    Get software components supported in the database for the reserved slot. This call is
    designed for Decision Line use and the components are entered by Decision Line
    specified methods.

    Return: List of Tuples (if slotNo is 0) or Tuple.  The contents of the Tuple is (slotNumber,
      List of components). The list of components is [componentName, description, version,
      collectionName, collectionDescription, status]

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.get_sw_components_supported(componentName, slotNo)

## @par Description
#  This function adds a specific software component to the device in the slot.
#  @param[in] componentName @b String : Name of component to add (must already exist in the database).
#  @param[in] collectionName @b String : Name of collection where the component is (must already exist in database).
#  @param[in] version @b String : Version of component (need not exist if fCreateVersionIfNeeded is True).
#  @param[in] description @b String : Description of component (may be empty, in which case the value of a newly created component is taken from database of an existing component).
#  @param[in] SlotNo @b Integer : (optional) By default, function acts on all reserved slots, unless this parameter is used.
#  @param[in] fCreateVersionIfNeeded @b Bool : (optional) Flag to create the version if it is not in database. When this is false the call will fail if version is not in database.
#  @return @b Tuple : A list containing (status, slot list)
@ApiFunction
def AddSwComponentToDut(componentName, collectionName, version, description, SlotNo=0, fCreateVersionIfNeeded=True):
    """
    Add software component to DUT in a slot.  This is intended for Decision Line use.

    Return: List. Contents are (status, slot list)

    componentName: (String) Name of component to add.

    collectionName: (String) Name of collection where the component is.

    version: (String) Version of component.

    description: (String) Description of component.

    slotNo: (Integer, optional) By default, function acts on all reserved slots, unless this
      parameter is used. It does not make a lot of sense to use 0 if >1 slot is reserved unless
      you want all DUTs to have the same components.

    fCreateHwVersionIfNeeded: (Bool, optional) Flag to create the component with the version if
      the version is not in database. When this is false the call will fail if the version is
      not in database.
    """
    return stormtest_client.stc.add_sw_to_dut(componentName, collectionName, version, description, SlotNo, fCreateVersionIfNeeded)

## @par Description
#  This function returns a list of components of the actual DUT in the slot (not those that are supported, but those applied to it).
#  @param[in] componentName @b String : Name of component to return. Use "" for all components.
#  @param[in] collectionName @b String : Collection to use to filter components. Use "" for all collections.
#  @param[in] slotNo @b Integer : (optional) By default, function acts on all reserved slots, unless this parameter is used.
#  @return @b Array : An array of tuples (if @e slotNo=0) or a single tuple (if @e slotNo!=0).
#   Each tuple is (slotNo, array of components). Each component is [ componentName, version, description, collectionName]
@ApiFunction
def GetSwComponentFromDut(componentName, collectionName, slotNo=0):
    """
    Get list of components of the DUT in the slot.

    Return: List of Tuples (if slotNo is 0) or a Tuple. The tuple is (slotNo, List of Components)
      The list of components is [componentName, version, description, collectionName]

    componentName: (String) Name of component to get information for.

    collectionName: (String) Name of collection where the component is.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.get_sw_on_dut(componentName, collectionName, slotNo)

## @par Description
#  This function returns a list of all smartcards in the faciltiy. Just the numbers are returned.
#  @param None
#  @return @b Array : An array smartcard IDs.
@ApiFunction
def GetAllSmartcards():
    """
    Get all smartcards in the facility.  Just the serial numbers are returned.

    Return: List. List of strings of serial numbers of all smart cards. This assumes that
      smartcards in facility have unique numbers across all models and types.
    """
    return stormtest_client.stc.get_all_smartcards()

## @par Description
#  This function sets the smartcard number for the DUT in the slot.
#  @param[in] smartcardNumber @b String : Unique card number (as a string). Must be unique facility wide.
#  @param[in] slotNo @b Integer : (optional) By default, function acts on all reserved slots, unless this parameter is used.
#  @param[in] fCreateIfNeeded @b Bool : (optional) If true and smartcard does not exist, it will be created.
#  @return @b Tuple : A tuple containing (status, slot list)
@ApiFunction
def SetSmartcardNumber(smartcardNumber, slotNo=0, fCreateIfNeeded=True):
    """
    Set the smartcard number for the DUT in the slot. It transfers logically the smartcard
    from wherever it is to the DUT. This is designed for Decision Line use where all
    smartcards have a unique number in the facility.

    Return: Tuple of (status, SlotList)

    smartcardNumber: (String) Unique serial number of a smartcard.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots. 0 can
      only be used if a single slot is reserved by the script.

    fCreateIfNeeded: (Integer, optional) If ture and the smartcard does not exist, it will be
      created. Else, an error is returned.
    """
    return stormtest_client.stc.set_smartcard_number(smartcardNumber, slotNo, fCreateIfNeeded)

## @par Description
#  This function gets the smartcard number for the DUT in the slot.
#  @param[in] slotNo @b Integer : (optional) By default, function acts on all reserved slots, unless this parameter is used.
#  @return @b Array : An array of tuples (if @e slotNo=0) or a single tuple (if @e slotNo!=0). Each tuple contains (slotNo, smartcardNumber).
@ApiFunction
def GetSmartcardNumber(slotNo=0):
    """
    Get the smartcard for the DUT in the slot.

    Return: List of Tuples (if slotNo is 0) or a single Tuple. The Tuple is (slotNo,
      smartcardNumber)

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.get_smartcard_number(slotNo)

## @par Description
#  This function sets the smartcard attribute for the smartcard for the DUT in the slot.
#  @param[in] attributeName @b String : Name of attribute to set.
#  @param[in] attributeValue @b String : Value of attribute to set.
#  @param[in] slotNo @b Integer : (optional) By default, function acts on all reserved slots, unless this parameter is used.
#  @return @b Tuple : A tuple containing (status, slot list)
@ApiFunction
def SetSmartcardAttribute(attributeName, attributeValue, slotNo=0):
    """
    Set the attribute on the smartcard of the DUT in the slot.

    Return: Tuple. The tuple is (status, slot list)

    attributeName: (String) Name of attribute to set.

    attributeValue: (String) Value of attribute to set.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.set_smartcard_attribute(attributeName, attributeValue, slotNo)

## @par Description
#  This function gets the smartcard attribute for the DUT in the slot.
#  @param[in] attributeName @b String : Name of attribute to get.
#  @param[in] slotNo @b Integer : (optional) By default, function acts on all reserved slots, unless this parameter is used.
#  @return @b Array : An array of tuples (if @e slotNo=0) or a single tuple (if @e slotNo!=0). Each tuple contains (slotNo, attributeValue).
@ApiFunction
def GetSmartcardAttribute(attributeName, slotNo=0):
    """
    Get attribute value of smartcard of a DUT in a slot.

    Return: List of Tuples (if slotNo is 0) or a Tuple. The tuple is (slotNumber, attributeValue)

    attributeName: (String) Name of attribute to get.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.get_smartcard_attribute(attributeName, slotNo)

## @par Description
#  This function gets the list of components of a specified name and type.
#  @param[in] componentName @b String : (optional) Name of component to search for, "" for all components. You can use the '*' wildcard.
#  @param[in] componentType @b String : (optional) Type name of component to search for, "" for all component types. You can use the '*' wildcard.
#  @param[in] slotNo @b Integer : (optional) By default, function acts on all reserved slots, unless this parameter is used.
#  @return @b Array : An array of tuples (if @e slotNo=0) or a single tuple (if @e slotNo!=0). Each tuple is (slotNo, array of components).
#  Each component is [ componentName, componentType, description, manufacturer, chipset, parameters]. For many components, the manufacturer, chipset and parameters will be empty strings.
@ApiFunction
def GetHwComponents(componentName = "", componentType = "", slotNo=0):
    """
    Get a list of the hardware components of a DUT in a slot.

    Return: List of Tuples (if slotNo is 0) or a Tuple. Contents of Tuple are: (slotNo,
      List of Components).  The list of Components is: [componentName, componentType, description,
      manufacturer, chipset, parameters].

    componentName: (String, optional) Name of component to filter the return list by. If omitted,
      all component names are returned.

    componentType: (String, optional) Type fo component to filter the return list by. If omitted,
      all component types are returned.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.get_hardware_component_list(componentName, componentType, slotNo)

## @par Description
#  This function finds a list of models which have the specified hardware components.
#  @param[in] componentName @b String : Name of component to search for. You can use the '*' wildcard.
#  @param[in] componentType @b String : (optional) Type name of component to search for, "" for all component types. You can use the '*' wildcard.
#  @param[in] componentCount @b Integer : (optional) The minimum number of components that the model must support.
#  @return @b Array : An array of tuples, one per model that matches the criteria.
#   Each tuple is [ modelName, Manufacturer, HwVersion] and is thus suitable for passing to ReserveDut() function call (ignoring the serial number / smartcard values)
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >># This will find all models with 4 or more hardware components of type AVOut.
#   >>ret = FindModelsByHardware("","AVOut",4)
#  @endcode
@ApiFunction
def FindModelsByHardware(componentName, componentType="", componentCount=1):
    """
    Return list of models which have the specified hardware components.

    Return: List of Tuples. Each tuple is: (modelName, manufacturer, hwVersion).

    componentName: (String) name of component that the model(s) must have. Use '*' for all.

    componentType: (String, optional) type of component to qualify the componentName. Use '*' for
      all.

    componentCount: (Integer, optional) The minimum number of components that the model must
      support.
    """
    return stormtest_client.stc.find_models_by_hardware(componentName, componentType, componentCount)

## @par Description
#  This function creates a new model in the database which can subsequently be used for creating dut instances.
#  The Admin Console provides the same functionality in a GUI manner.
#  @param[in] modelName @b String : The name of the model to create.  This is case sensitive
#  @param[in] modelType @b String : The type of the model to create.  If such a type does not exist, it will be
#  created.  This value is case sensitive so it is possible to end up with types called 'zapper' and 'Zapper'.
#  @param[in] irDatabase @b String : The IR database to use for this model.  This must have already been created
#  using the IR Trainer applet in the Admin Tools.  This value is case sensitive so must match exactly the value
#  used in the IR Trainer.
#  @param[in] detailedInformation @ Dictionary of strings : A dictionary of extra information about the model in a
#  key value manner.  This allows future expansion of the range of information stored without breaking existing scripts.
#  The keys are NOT case sensitive but the values are.  Possible keys are: Description (a description of the model),
#  Manufacturer (the name of the model's manufacturer), ManufacturerModel (the model name given by the manufacturer to the
#  model being created), MajorHwVersion (the major version string of the model), MinorHwVersion (the minor version string
#  of the model), Broadcaster (the broadcaster that the model is tied to), VideoTransform (the transformation to apply
#  to the video between design to world coordinate space. Must be a CoordConverter instance).  All values are optional and if omitted will
#  default to empty strings - it is permissible to pass {} (the empty dictionary) as the detailedInformation parameter.
#  @param[in] permitDuplicateNames @b Bool : (optional) Set to true if the function should create a model with a duplicate
#  name if modelName already refers to an existing model.  Default for this, if omitted, is False so that model names
#  are unique.
#  @return @b List : List of status number (integer), status message (string), model id created (integer)
#  The status number is 0 on success and the model id is 0 on failure.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >># This will create a new model with a description set but all other fields empty and fail if there is a model called "model name"
#   >>info = {}
#   >>info["Description"] = "some description of the model"
#   >>ret = CreateDutModel("model name", "model type", "Existing Ir Database", info)
#   >>print(str(ret))
#   >>>[0,'OK',789]
#  @endcode
@ApiFunction
def CreateDutModel(modelName, modelType, irDatabase, detailedInformation, permitDuplicateNames = False):
    """
    Create a new model in the database.

    Return: List. Contents are [statusCode, message, model id]. The status code is 0 on success.

    modelName: (String) Name of the model to create.

    modelType: (String) Type of model to create.

    irDatabase: (String) The name of IR database to use for the model. This must have already been
      created using the GUI IrTrainer.

    detailedInformation: (Dictionary) Extra information relating to model. The keys allowed are:
      Description, Manufacturer, ManufacturerModel, MajorHwVersion, MinorHwVersion, Broadcaster, VideoTransform

    permitDuplicateNames: (Bool, optional) Flag to allow duplicate model names to be created.
    """
    return stormtest_client.stc.create_dut_model(modelName, modelType, irDatabase, detailedInformation, permitDuplicateNames)

## @par Description
#  This function updates and existing model.  The model may have been created either by CreateDutModel or manually via
#  the admin console.
#  @param[in] modelId @b Integer : Id of the model to update (see ListDutModels to get the ids of existing models)
#  @param[in] informationToUpdate @b Dictionary of strings : A dictionary of information about the model to be updated in a
#  key value manner.  This allows future expansion of the range of information stored without breaking existing scripts.
#  The keys are NOT case sensitive but the values are.  Possible keys are: Name (the name of the model as per CreateDutModel),
#  ModelType (the type of the model as per CreateDutModel), IrDatabase (the IR database to use as per CreateDutModel),
#  Description (a description of the model), Manufacturer (the name of the model's manufacturer), ManufacturerModel
#  (the model name given by the manufacturer to the model being created), MajorHwVersion (the major version string of the model),
#  MinorHwVersion (the minor version string of the model), Broadcaster (the broadcaster that the model is tied to),
#  VideoTransform (the transformation to apply to the video between design to world coordinate space. Must be a CoordConverter instance). If a key
#  is omitted then that value is left unchanged (unlike CreateDutModel, it will NOT be set to the empty string - to do that,
#  an empty string must be supplied explicitly)
#  @param[in] permitDuplicateNames @b Bool : (optional) Set to true if the function should change the model name if it would
#  result in a model with a duplicate name of an already existing model.  Default for this, if omitted, is False so that model names
#  are unique.  This flag can be ignored if no attempt is being made to change the model name itself (ie if Name is not used as a key)
#  @return @b List : List of status number (integer), status message(string). Status number is 0 on success.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >># This will update a model by changing the hw versions
#   >>info = {}
#   >>info["MajorHwVersion"] = "1"
#   >>info["MinorHwVersion"] = "0.8a"
#   >>ret = UpdateDutModel(789, info)
#   >>print(str(ret))
#   >>>[0,'OK']
#  @endcode
@ApiFunction
def UpdateDutModel(modelId, informationToUpdate, permitDuplicateNames = False):
    """
    Update the detail on a DUT model.

    Return: List. Contents are [statusCode, message] The statusCode is 0 on success.

    modelId: (Integer) The model id to update.

    informationToUpdate: (Dictionary) Information to update. Only the fields specified are updated.
      The keys allowed are: Name, ModelType, IrDatabase, Description, Manufacturer,
      ManufacturerModel, MajorHwVersion, MinorHwVersion, Broadcaster, VideoTransform

    permitDuplicateNames: (Bool, optional) Flag to allow a duplicate model name to be created by
      a change to the Name field of the model.
    """
    return stormtest_client.stc.update_dut_model(modelId, informationToUpdate, permitDuplicateNames)

## @par Description
#  This function deletes a model AND ALL DUTs which are of that model type.  Use with caution.
#  @param[in] modelId @b Integer : Id of the model to delete (see ListDutModels to get the ids of existing models)
#  @return @b List : List of status number (integer), status message(string). Status number is 0 on success.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >># This will delete a model
#   >>ret = DeleteDutModel(789)
#   >>print(str(ret))
#   >>>[0,'OK']
#  @endcode
@ApiFunction
def DeleteDutModel(modelId):
    """
    Delete a DUT model and all DUTs which are of that model.  Use with caution!.

    Return: List. Contents are [statusCode, message] The statusCode is 0 on success.

    modelId: (Integer) The model id to delete.
    """
    return stormtest_client.stc.delete_dut_model(modelId)

## @par Description
#  This function will return a list of all existing DUT models in the system
#  @param None
#  @return @b List : List of 3 objects.  The first element is the status and the second is the status message.  The
#  final element is a list of dictionaries.  Each element of the list represents a model in the system.  The contents
#  of the model information dictionary are key=value pairs, with the keys being that of UpdateDutModel plus the key
#  ModelId being set to the model id and VideoTransform being the video transform. This is a CoordConverter or None
#  if there is no transform specified in the database.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >># This will list all models
#   >>ret = ListDutModels()
#   >>print(str(ret))
#   >>>[0, 'OK',[{'ModelId': '789', 'Name': 'model name' ...
#  @endcode
@ApiFunction
def ListDutModels():
    """
    Get List of all models in the database.

    Return: List. Contents of list are: [statusCode, message, Models]. The statusCode is - on
      success. The Models is a list of Dictionaries.  Each Dictionary represents a model and has
      the keys: ModelId, Name, ModelType, IrDatabase, Description, Manufacturer,
      ManufacturerModel, MajorHwVersion, MinorHwVersion, Broadcaster, VideoTransform
    """
    return stormtest_client.stc.list_dut_models()

## @}

##  @defgroup Group16 Audio Video Analysis API
# These commands control the audio and video analysis feature of StormTest.  This is licensed separately from the main
# server on a per server basis.  These calls check for a valid license and will not work without a valid license.  There are
# two types of audio/video analysis supported by StormTest.  Video Quality Analysis (VQA) introduced in release 3.2.3 analyzes
# the video in a manner similar to a group of human viewers, generating a Mean Opinion Score (MOS).  Using this requires some
# knowledge of the way your video is generated and the API provides many options.  Functions and classes specific to this type
# of analysis are prefixed with VQA to distinguish them from the older video analysis.
# Release 3.2.5 added audio analyis, producing a similar MOS score.  The audio analyis works on chunks of audio of 1 second in
# length.
#
# VQA has an option to use memory to either perform a VQA analysis over a minute or 2 at full frame rate or to smooth out 
# variations in processing over a longer duration.  This is the backlog option.  The memory used is shared with the @ref Group9 
# For standard issue slave servers, the total memory available varies slightly over time due to dynamic memory allocation/deallocation in the server.
# However, it has been verified that if the total memory requested between VQA and all slots of High Speed Timer on the slave is less than 4.6656 billion then
# the requests will be satisfied.  (On HV16HD, there are four slaves, slots 1-4 being the first slave).
# Each image of video requires width * hight * 1.5 bytes. So from the above calculation, you could allocate all memory to VQA and at 1920 x 1080 that would
# mean a maximum backlog of 4665600000 / (1920 * 1080 * 1.5) => 1500.  Alternatively, you could allocate 375 to each slot of high speed timer and not use the VQA.
#
# A second method uses a reference stream supplied with predefined video and audio patterns.  This was introduced
# in release 2.4 of StormTest.
## @{

# Deprecated Class
## @par Deprecated
class PerceptualParameters(object):
    """
    DEPRECATED - please use VQAVideoOptions
    """
    def __init__(self, VideoFormat="H264", AllowJerkiness=True):
        if (VideoFormat == "H264") or (VideoFormat == "MPEG2"):
            self.videoFormat = VideoFormat
        else:
            raise NameError("Video Format '" + VideoFormat + "' is not defined")
        self.allowJerkiness = AllowJerkiness

    def ToString(self):
        return "videoFormat = " + self.videoFormat + "; allowJerkiness = " + str(self.allowJerkiness)


## @par Description
#  VideoFormat Enum. Defines the valid values of video format supported by VQA (and any other future
#  API that requires knowledge of video format)
#  @param MPEG2 : Video compressed to MPEG-2
#  @param H264 : Video compressed to ITU.T H.264 (also known as MPEG-4 Part 10 and AVC)
class VideoFormat:
    MPEG2       = "MPEG2"
    H264        = "H264"

## @par Description
#  The VQA Video options class.  This holds all the options that can be configured for VQA video analysis.
#  You can create a default object with the default parameters and adjust those that are necessary.
#
#  @param Enabled Bool : Whether video analysis should be performed. This is a new property in 3.2.5 to allow the
#  options of audio only VQA analysis. Default is True.
#
#  @param Format VideoFormat : The format of the source of the video that was supplied to StormTest.  Most HD Video
#  uses H.264 and this is the default value for the Format value.  You should change this to MPEG2 ONLY if you know
#  for certain that the video was originally encoded using MPEG2.  StormTest processes raw video frames but these
#  are supplied by a device - that device will have decoded the video from either H.264 or MPEG2 video.  Getting 
#  this value 'wrong' will alter how the VQA engine assesses the quality of the video and thus may generate unexpected 
#  scores for the quality.  If another format was originally used, then the VQA results from StormTest are not necessarily
#  representative of human perception of quality.
#
#  @param CaptureIsUpscaled Bool : Whether the captured image is upscaled from the source image.  The VQA engine is
#  designed to work on captured images which are the same size as the original source material.  However, it may be that
#  StormTest is capturing images from the device under test at a higher resolution than the original source material.  In
#  order to get more realistic MOS scores in this situation, set CaptureIsUpscaled to True.  Default is False.  This setting
#  was introduced in release 3.3.0
#
#  @param Backlog Integer : The number of frames used as a backlog queue.  It is possible that video is captured more
#  quickly than it can be analyzed.  In this case, StormTest keeps a queue of pending frames.  When that queue is full,
#  then frames are dropped.  This affects the MOS scores.  Setting a high value uses more memory but allows a longer
#  period from the start of video analysis before frames are dropped.  The minimum value is 16.  The maximum depends
#  on available memory: for an HD system with 8GB of RAM then the maximum is around 1500 for 1920 x 1080 frames.  The default
#  value is 500.
#
#  @param FrameRate Float : The frame rate to use for analysis.  If the actual frame rate is greater than this value
#  then frames are dropped in a deterministic manner to bring the frame rate down to the FrameRate value.  if you are
#  monitoring video for an extended period and the engine cannot process all frames then a deterministic drop of frames
#  will typically give better results (more consistent) than the non deterministic dropping on a full queue.  Best results
#  are achieved where the number of frames dropped can be expressed as 1 in n where n is integer, for example 20 for a 25 fps input video (1 in 5 frames dropped)
#  A value of 0 should be used to mean 'same as input rate'
#
#  @param Jerkiness Bool : Set to true to permit 'jerkiness' or 'image freezing' of the video to affect MOS score.  
#  If you expect smooth video then you should set this to True.  If, however, you expect your video to be jerky
#  with a lot of static frames then you may get a more realistic MOS score by setting this to False.  The default is True.  
#  You can adjust the detection parameters of what is considered a 'static picture'.  A picture is moving when it
#  exceeds the Activity OR the ChangingPixels OR is less than the MeanBrightness thresholds.
#
#  @param Activity Float : A threshold indicating temporaral activity, above which, we consider the video to be moving.
#  It ranges from 0 to 255.  Values lower than 5 are consider low motion, 5 to 15 is normal motion.  Default value for
#  Activity is 0.9 - only very slow moving pictures are considered 'static'.  This parameter has no effect if Jerkiness
#  is False
#
#  @param ChangingPixels Float : The percentage of pixels (0 - 100) which have a significant change compared to the previous
#  frame.  If the number exceeds this value, then the picture is considered moving.  The default is 0.01.  This parameter
#  has no effect if Jerkiness is False
#
#  @param MeanBrightness Float : The average value of brighness, below which the image is considered moving.  The default
#  value is 21 meaning that if the image is black (or near black), it is considered to be moving - this prevents dark frames
#  from being considered as jerky.  Quite often a video sequence can have black frames as a normal part of a scene change
#  and it is not a jerky video.  Setting a very high value will mean that the majority of frames would be considered as
#  moving and thus excluded from being jerky.
#  This parameter has no effect on the MOS score if Jerkiness is False.
#  
#  @param Crop List : A list of 4 integers representing a rectangle of the video in which the video analysis is performed.
#  The rectangle is specified as left, top, width, height.  It can be None to indicate no cropping and analysis on the full 
#  frame.  If the specified rectangle is greater than the video size then the full frame will be used.  After the VQA Engine
#  has started, the Crop value on the VideoOptions property of the engine can be read to find out the region of the video being 
#  analyzed.  The final crop region will be adjusted so that it is an even number of pixels in size in each direction and
#  the top left corner is on even pixels in each direction.  The minium final size of the Crop region is 176 x 144. A 
#  StormTestExceptions exception will be raised if the crop region is too small.   The default value for Crop is None.  
#  This property was introduced in version 3.3.3
# 
#  @param DesignSize List : A list of 2 integers representing the size of the video for which the options are designed. This
#  affects how the Crop is interpreted.  If the DesignSize is None then the Crop is considered to be an absolute rectangle. If
#  the DesignSize is not None then the VQA engine will scale the Crop rectangle as necessary so that the same intended region
#  will be analyzed if the actual video is not the same as DesignSize.  As an example, consider the case of DesignSize being 
#  [1920, 1080] and the Crop being [100, 50, 600, 300] but the raw video is 1280 x 720.  In this case analysis will be performed
#  on the rectangle [66, 34, 400, 200] because 1280 x 720 is 2/3 the size of 1920 x 1080 (The region is rounded to nearest even coordinates).  
#  The default value for DesignSize is 
#  None.  This property was introduced in version 3.3.3
#
#  @param FastBlockiness Integer : Selects the fast blockiness measurement algorithm. This algorithm is less precise than the normal algorithm but 
#  will operate significantly faster. This can be useful if you need to analyse HD video in realtime. The normal algorithm is the default (value 0).
#  Set this to 1 to select the fast algorithm.
#  This property was introduced in version 3.4.10
#
#  @param FastBlur Integer : Selects the fast blur measurement algorithm. This algorithm is less precise than the normal algorithm but 
#  will operate significantly faster. This can be useful if you need to analyse HD video in realtime. The normal algorithm is the default (value 0).
#  Set this to 1 to select the fast algorithm.
#  This property was introduced in version 3.4.10
#
#  @param HomeTVorMobileTVQualityScale Integer : allows the user to choose between two different scales for the quality measurement.
#  The Home TV quality scale (value 0) is the default and gives a result that assumes that the video being analysed will be viewed on a TV
#  screen in a normal home environment. The Mobile TV quality scale (value 1) was designed to measure the quality of TV on smartphones. It 
#  operates with the assumption that the smaller screen size means that the end user will be more forgiving of (or will not notice) artefacts
#  so readily and will give the video a higher MOS score.
#  This property was introduced in version 3.4.10
#
#  @param BlockinessMetric Integer : 0=Normal, 1=Heavy or 2=Combined => Use Normal up to threshold and Heavy above
#  The default value is 0 (normal algorithm).
#  This property was introduced in version 3.4.13
#
#  @param NormalBlockinessThreshold Float : Threshold used when BlockinessMetric is set to 2
#  The default value is 2.999.
#  This property was introduced in version 3.4.13
#
class VQAVideoOptions(object):
    __cache = {}
    """
    The VQA Video Options
    """
    ## @par Description
    # The constructor provides an object with the default VQA options.  You can then modify any option as needed.
    # @param None
    # @return @e VQAVideoOptions : The completely constructed VQAVideoOptions object.
    # @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>>vqaOptions = VQAVideoOptions()
    # >>>print(str((vqaOptions.Jerkiness, vqaOptions.Backlog, vqaOptions.Format)))
    # >>>(True, 500, "H264")
    # >>>vqaOptions.Backlog = 1500
    # >>>print(str((vqaOptions.Jerkiness, vqaOptions.Backlog, vqaOptions.Format)))
    # >>>(True, 1500, "H264")
    # @endcode
    def __init__(self):
        """
        Ctor - sets up default VQA video options
        """
        self.__cache = {}
        self.Enabled = True
        self.Format = VideoFormat.H264
        self.CaptureIsUpscaled = False
        self.Backlog = 500
        self.FrameRate = 0
        self.Jerkiness = True
        self.Activity = 0.9
        self.ChangingPixels = 0.01
        self.MeanBrightness = 21
        self.DesignSize = None
        self.Crop = None
        self.FastBlockiness = 0
        self.FastBlur = 0
        self.HomeTVorMobileTVQualityScale = 0
        self.BlockinessMetric = 0
        self.NormalBlockinessThreshold = 2.999


    def __getattr__(self, attr):
        return Imaging.GetVqaVideoOptionsProperty(self.__cache, attr)

    def __setattr__(self, attr, value):
        if attr.startswith("_VQAVideoOptions__"):
            object.__setattr__(self, attr, value)
        else:
            Imaging.SetVqaVideoOptionsProperty(self.__cache, attr, value)

    def __dir__(self):
        return Imaging.VqaVideoOptionsDir(list(VQAVideoOptions.__dict__.keys()))


## @par Description
#  VQASilenceMode Enum. Defines the valid values of custom audio silence detector supported by VQA
#  @param Disabled : The custom audio silence detector is disabled.
#  @param Amplitude : The custom audio silence detector examines the value of audio samples (the amplitude)
#  looking for values below a threshold.
#  @param StdDev : The custom audio silence detector examines the standard deviation of a group of samples
#  (1 frame, equal in length to the video frame time) and calculates the standard deviation of the amplitudes
#  and examines that in order to determine silence.
class VQASilenceMode:
    Disabled  = "Disabled"
    Amplitude = "Amplitude"
    StdDev    = "StdDev"

## @par Description
#  The VQA Audio options class.  This holds all the options that can be configured for VQA audio analysis.
#  You can create a default object with the default parameters and adjust those that are necessary.
#
#  @param Enabled Bool : Whether audio analysis should be performed.  Default is True.
#
#  @param SilenceInfluence Float : The percentage influence (0 - 100) that the silence detector has on the MOS score.
#  Silence is defined as 100mS or more of consecutive samples all having the same value.
#  The final MOS score is reduced by SilenceInfluence * MOS score.  So a value of 0 disables the silence detector while 100
#  causes any silence detected to push the MOS score to 0.  A value of 10 will remove 10% from a MOS score so if the raw MOS
#  was 85 and silence was detected during the sample, the resulting MOS score is 76.5 (85 - 10/100 * 85).  Default value for
#  SilenceInfluence is 0 (no effect).
#
#  @param BreaksInfluence Float : The percentage influence (0 - 100) that the break detector has on the MOS score.  A break is
#  defined as a significant difference between 2 consecutive samples that is not normal in audio.  As with SilenceInfluence, the
#  MOS score is reduced by BreaksInfluence * MOS score. Default value for BreaksInfluence is 0 (no effect).
#
#  @param SaturationInfluence Float : The percentage influence (0 - 100) that the saturation detector has on the MOS score.
#  Saturation is defined as 2 consecutive samples having either the maximum or minimum possible value.  As with SilenceInfluence, the
#  MOS score is reduced by SaturationInfluence * MOS score.  Default value for SaturationInfluence is 0 (no effect).
#
#  @param CustomSilenceInfluence Float : The percentage influence (0 - 100) that the custom silence detector has on the MOS score.  As with
#  SilenceInfluence the MOS score is reduced by CustomSilenceInfluence * MOS score.  Default value for CustomSilenceInfluence is 0 (no effect).
#
#  @note All the Influence parameters work on the original MOS score.  So if SilenceInfluence is 40 and BreaksInfluence is 40 and both occur
#  on a MOS score of 85 then the MOS score will be 17 (85 - 85 * 40/100 - 85 * 40/100).  There is no compounding of influences and this means the 
#  MOS score can become negative.
#
#  @param CustomSilence  VQASilenceMode : The type of custom silence detection used. Default value is Disabled.  The custom silence detector works
#  when any sample meets the criteria for silence unlike the standard silence detection which requires 100mS of samples to be 'silent'.
#
#  @param Threshold Float : The threshold for the custom silence detector.  In amplitude mode, this is in dBu using the same scale as the other
#  audio detection functions.  If a sample is below or equal to this value then it is considered silence.  In standard deviation mode, the value
#  is in the range 0 - 1.0 indicating a standard deviation between 0 and maximum audio sample value (not possible in practice so a value 
#  of 1.0 will always detect silence as the deviation will always be lower than 1.0).
class VQAAudioOptions(object):
    __cache = {}
    """
    The VQA Audio Options
    """
    ## @par Description
    # The constructor provides an object with the default VQA options.  You can then modify any option as needed.
    # @param None
    # @return @e VQAAudioOptions : The completely constructed VQAAudioOptions object.
    # @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>>vqaOptions = VQAAudioOptions()
    # >>>print(str((vqaOptions.SilenceInfluence, vqaOptions.BreaksInfluence)))
    # >>>(0, 0)
    # >>>vqaOptions.SilenceInfluence = 25
    # >>>print(str((vqaOptions.SilenceInfluence, vqaOptions.BreaksInfluence)))
    # >>>(25.0, 0)
    # @endcode
    def __init__(self):
        """
        Ctor - sets up default VQA audio options
        """
        self.__cache = {}
        self.Enabled = True
        self.SilenceInfluence = 0
        self.BreaksInfluence = 0
        self.SaturationInfluence = 0
        self.CustomSilenceInfluence = 0
        self.CustomSilence = VQASilenceMode.Disabled
        self.Threshold = 0


    def __getattr__(self, attr):
        return Imaging.GetVqaAudioOptionsProperty(self.__cache, attr)

    def __setattr__(self, attr, value):
        if attr.startswith("_VQAAudioOptions__"):
            object.__setattr__(self, attr, value)
        else:
            Imaging.SetVqaAudioOptionsProperty(self.__cache, attr, value)

    def __dir__(self):
        return Imaging.VqaAudioOptionsDir(list(VQAVideoOptions.__dict__.keys()))




## @par Description
#  The trigger condition.  This is used by several functions within VQA API to indicate when a function
#  should take action (be triggered).  Not all properties are appropriate for all functions and the 
#  individual API calls will indicate which properties are ignored.  It should be assumed that a property
#  is valid unless specified otherwise.  It is possible to specify multiple conditions on one trigger object and
#  in this case the condition is satisfied when any one of the conditions is met.  If any property is None then
#  it is ignored in considering the trigger.  This is the default value for many properties.
#
#  @param Delay float : A time in seconds.  Default value is None.
#  @param FrameCount integer : Number of frames as an integer.  Default value is None.
#  @param DroppedFrames integer : Number of dropped frames.  Useful to trigger on an error by setting to 1.  Default value is None.  This is not yet supported.
#  @param IRKey String : An IRKey stroke to use to trigger the analysis. Default value is None.  This is not yet supported and must be set to None
#  @param IRKeyRepeat integer : The number of times that the IRKey must be present before it is considered the trigger. Default value is 1
#  meaning the first occurrence of the IRKey will cause the trigger to be considered triggered.
#  @param Sdo ScreenDefinition : A screen definition to match each frame.  The Sdo may only include image, and color tests. Motion, audio and OCR
#  are forbidden as they take too long.  You should choose small regions to test so that the SDO can execute in less than 1 frame time.  A full image compare cannot
#  operate in real time.  In this release, you cannot use NamedRegions, NamedColors or NamedImages within an SDO.
#  Default value is None
#  @param SdoRepeat integer : Number of frames that must match the SDO for it to be considered a valid trigger. Default value is 1.  Only a value of 1 is currently supported.
#  @param FromNow bool : True to consider the delay, frame count etc to start 'now'.  If False, then the reference point is the most recent
#  logical point in the past.  This is not always sensible.  A useful case is setting it to False on the Stop() call with a fixed delay. This
#  means the Stop() will be exactly the specified value after Start() even if the script is a bit slow in calling Stop().  Useful for precise
#  timing.  Default value is True.
class TriggerCondition(object):
    __cache = {}

    ## @par Description
    # Constructor to make a default trigger object
    # @param None
    # @return @e TriggerCondition : the default trigger object.  This will simply trigger immediately.
    # @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>>create a trigger to trigger after 1000 frames
    # >>>trigger = TriggerCondition()
    # >>>trigger.FrameCount = 1000
    # @endcode
    def __init__(self):
        self.__cache = {}
        self.Delay = None
        self.FrameCount = None
        self.DroppedFrames = None
        self.IRKey = None
        self.IRKeyRepeat = 1
        self.Sdo = None
        self.SdoRepeat = 1
        self.FromNow = True

    def __getattr__(self, attr):
        return Imaging.GetVqaTriggerProperty(self.__cache, attr)

    def __setattr__(self, attr, value):
        if attr.startswith("_TriggerCondition__"):
            object.__setattr__(self, attr, value)
        else:
            Imaging.SetVqaTriggerProperty(self.__cache, attr, value)

    def __dir__(self):
        return Imaging.VqaTriggerDir(list(TriggerCondition.__dict__.keys()))


    ## @par Description
    # Generate a trigger condition from an image.  This will make the sdo for you and set it up to have one
    # image compare region.  You should consider the FromIcon method for optimum performance as full screen
    # images take time to send over the network.
    # @param[in] image StormTestImageObject : the image to use as the reference. It should be the same size as
    # the frames you are analyzing.
    # @param[in] rect List or Tuple : (optional) the region of interest within the image.  It must be a list or tuple of 
    # 4 elements representing left, top, width and height of the rectangle to use for comparison. It can be
    # None to mean the whole image should be compared.
    # @param[in] threshold double : (optional) the threshold for the image match as per CompareImageEx.
    # @return @e TriggerCondition : the completed trigger condition ready to use.
    # @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>>create a trigger to trigger on image but using rect at (0,0,400,300)
    # >>>trigger = TriggerCondition.FromImage(image, [0,0,400,300])
    # @endcode
    @staticmethod
    def FromImage(image, rect=None, threshold=98):
        trigger = TriggerCondition()
        sdo = ScreenDefinition()
        sdo.Name = "TriggerSdo"
        sdo.Comment = "Auto Generated in FromImage"
        sdo.ReturnScreenImage = ReturnScreen.Never
        imageRegion = ImageRegion()
        imageRegion.Threshold = threshold
        imageRegion.Name = "TriggerImage"
        imageRegion.Comment = "Auto Generated Image Region"
        imageRegion.Rect = rect
        imageRegion.IconMode = False
        imageRegion.ReferenceImage = image
        sdo.Regions.append(imageRegion)
        trigger.Sdo = sdo
        return trigger

    ## @par Description
    # Generate a trigger condition from an icon.  This will make the sdo for you and set it up to have one
    # image compare region.
    # @param[in] image StormTestImageObject : the image to use as the reference icon.
    # @param[in] location List or Tuple : the location of the icon within the image.  It must be a list or tuple of 
    # 2 elements representing left, top of the icon's location.
    # @param[in] threshold double : (optional) the threshold for the icon match as per CompareIconEx.
    # @return @e TriggerCondition : the completed trigger condition ready to use.
    # @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>>create a trigger to trigger on icon but using location at (89,77)
    # >>>trigger = TriggerCondition.FromIcon(image, [89,77])
    # @endcode
    @staticmethod
    def FromIcon(image, location, threshold=98):
        trigger = TriggerCondition()
        sdo = ScreenDefinition()
        sdo.Name = "TriggerSdo"
        sdo.Comment = "Auto Generated in FromIcon"
        sdo.ReturnScreenImage = ReturnScreen.Never
        icon = ImageRegion()
        icon.Threshold = threshold
        icon.Name = "TriggerIcon"
        icon.Comment = "Auto Generated Icon Region"
        icon.Rect = (location[0], location[1], 1, 1)    # convert to small rectangle as size is not important
        icon.IconMode = True
        icon.ReferenceImage = image
        sdo.Regions.append(icon)
        trigger.Sdo = sdo
        return trigger


    ## @par Description
    # Generate a trigger condition from a color.  This will make the sdo for you and set it up to have one
    # color compare region.
    # @param[in] rect List or Tuple : the region of interest within the screen capture.  It must be a list or tuple of 
    # 4 elements representing left, top, width and height of the rectangle to use for color comparison. It can be
    # None to mean the whole image should be compared.
    # @param[in] color List or Tuple : the color as a List or Tuple of Red, Green, Blue values.
    # @param[in] tolerance List or Tuple : (optional) the tolerance to apply to color comparison as per CompareColorEx
    # function.  Default is (4,4,4)
    # @param[in] flatness double : (optional) the flatness of the color as per CompareColorEx function.  Default is 98.
    # @param[in] peakError double : (optional) the peak error of the color as per CompareColorEx funcion.  Default is 0.
    # @return @e TriggerCondition : the completed trigger condition ready to use.
    # @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>>create a trigger to trigger on color black at (0,0, 400,100)
    # >>>trigger = TriggerCondition.FromColor((0,0,400,100), (0,0,0))
    # @endcode
    @staticmethod
    def FromColor(rect, color, tolerance=(4,4,4), flatness=98, peakError=0):
        trigger = TriggerCondition()
        sdo = ScreenDefinition()
        sdo.Name = "TriggerSdo"
        sdo.Comment = "Auto Generated in FromColor"
        sdo.ReturnScreenImage = ReturnScreen.Never
        clr = ColorRegion()
        clr.Name = "TriggerColor"
        clr.Comment = "Auto Generated Color Region"
        clr.Rect = rect
        clr.ReferenceColor = color
        clr.Tolerance = tolerance
        clr.Flatness = flatness
        clr.PeakError = peakError
        sdo.Regions.append(clr)
        trigger.Sdo = sdo
        return trigger

## @par Description
# VQAEventType Enum.  Defines the types of event - it is a field in the VQAEvent object.  Depending on 
# the value of this, the Value field of VQAEvent may have useful information.  If nothing is specified below
# then the Value will be None
# @param Start : The analysis has started after any trigger condition has been satisfied. 
#
# @param Stop : The analysis has stopped accepting new video frames but is still processing any pending frames.
#
# @param Finish : The analysis has processed all frames in the queue after Stop. No new data will be generated.
#
# @param DroppedFrame : The engine has been forced to drop frames due to overload. The Value is an Tuple indicating
# the number dropped since the last DroppedFrame event and the total dropped since the start of analysis.  Frames
# discarded due to the user setting a low frame rate in the options, are NOT counted or reported.
#
# @param ResChange : The resolution of the video has changed (the source maybe has switched video size).  The Value is
# a tuple of (width, height, frameRate) of the new resolution.  After a resolution change, video analysis stops.  Any
# pending frames at the original resolution are processed but no new frames are processed.
#
# @param VideoResult : Results of video VQA are available.  The Value is a List of VQAVideoResult objects.  This event is typically
# generated every few seconds during analysis.  In any case, it will not be generated more often than once per second.
#
# @param AudioResult : Results of audio VQA are available.  The Value is a List of VQAAudioResult objects.  This event is typically
# generated every few seconds during analysis.  In any case, it will not be generated more often than once per second.
class VQAEventType:
    Start = "Start"
    Stop = "Stop"
    Finish = "Finish"
    DroppedFrame = "DroppedFrame"
    ResChange = "ResChange"
    VideoResult = "VideoResult"
    AudioResult = "AudioResult"


## @par Description
# The event class.  An instance of this is returned to the user script for every event of interest that occurs
# during VQA processing.  It is not a requirement that all scripts process all events, many are for information
# which might be useful in some situations.  A script can choose which events to process.
# @param Type VQAEventType : type of event as an enumeration.  This indicates what the event signifies.
# @param Value object : extra values about the event.  This may be None but for some events, extra data
# @param TimeStamp double : The time stamp when the event was generated.  This is the time, in seconds since
# the Unix epoch (1/1/1970 00:00:00 UTC) and is related to the value returned from time.time() function.
# This timestamp is generated on the server so can be slightly different from time.time() if the client and server
# machine are not synchronised.
# @param FrameNumber Integer : The frame number associated with the event. Frame 0 is the first frame AFTER the
# trigger condition is satisfied.  Frames then increment sequentially as determined by the source video stream.
class VQAEvent(object):
    __cache = {}

    def __init__(self):
        self.__cache = {}
        self.Type = None
        self.TimeStamp = None
        self.Value = None
        self.FrameNumber = None

    def __getattr__(self, attr):
        return Imaging.GetVqaEventProperty(self.__cache, attr)

    def __setattr__(self, attr, value):
        if attr.startswith("_VQAEvent__"):
            object.__setattr__(self, attr, value)
        else:
            Imaging.SetVqaEventProperty(self.__cache, attr, value)

    def __dir__(self):
        return Imaging.VqaEventDir(list(VQAEvent.__dict__.keys()))



## @par Description
# The VQA video result object.  The properties here indicate various metrics about the video frames analyzed.
# There will be one result per frame of video processed.  However, not all properties are necessarily valid
# for all frames - in that case the value will be None instead of the value described here.
# @param FrameNumber integer : The frame number of this result.  The first frame analyzed is frame 0.  Frame numbers
# are counted from the captured frame and include all dropped frames (whether intentionally or not).  To be clear,
# if the queue is NOT overloaded and VQAVideoOptions.FrameRate is set to 15 for a 30 frame/sec source then you will
# get results with frameNumber value: 0, 2, 4, 6, 8 ... due to the deliberate dropping of frames.
# @param TimeStamp double : the timestamp of the result.  This is in seconds since the Unix epoch (1/1/1970 00:00:00 UTC)
# and is the time on the server when the result was generated.  This may increase unevenly due to threading and CPU load.
# It is useful for debugging should problems occur.
# @param MOS double : The raw MOS score. This is a number between 0 and 100.  The scores are:
#  @htmlonly
#  <TABLE ALIGN="center" BORDER=1 CELLSPACING=0 CELLPADDING=5>
#  <TR ALIGN="left" VALIGN="middle">
#    <TH>MOS Score</TH>
#    <TH>Meaning</TH>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <td>0 - 20</td><td>Bad Quality</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <td>20 - 40</td><td>Poor Quality</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <td>40 - 60</td><td>Rather Good Quality</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <td>60 - 80</td><td>Good Quality</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <td>80 - 100</td><td>Excellent Quality</td>
#  </TR>
#  </Table>
#  @endhtmlonly
#  @latexonly
#  \begin{center}
#  \begin{tabular}{ | l | r | }
#  \hline
#  MOS Score & Meaning \\ \hline\hline
#  0 - 20 & Bad Quality \\
#  20 - 40 & Poor Quality \\
#  40 - 60 & Rather Good Quality \\
#  60 - 80 & Good Quality \\
#  80 - 100 & Excellent Quality \\
#  \hline
#  \end{tabular}
#  \end{center}
#  @endlatexonly
# These terms are defined in standards such as BT.500 and BT.710.  The MOS score is an average of the frame qualities over time (as no human
# can determine the quality of a single frame at 30 frames per second).  It uses a 5 second window for the averaging so the first 5 seconds worth of values
# after starting are not valid.
# @param MOSDescription string : The String equivalent of the MOS score without the word Quality (i.e. Bad, Poor, Rather Good, Good or Excellent)
# @param FrameQuality double : The quality of a single frame.  The range and meaning is the same as MOS score.  MOS score is the average of the raw
# frame qualities.  The FrameQuality ignores the effect of prior frames.
# @param FrameQualityTemporal double : The quality of a single frame taking into accout the previous frames' scores.  This takes into account
# a property of the human visual system which is that we are "quick to criticize, slow to forgive". In order to understand this sentence, consider human
# observers watching a good quality video.  Now imagine that a visible distortion appears.  When
# the distortion appears, the quality judgment of the human observers decreases nearly instantly
# ("quick to criticize"). However, when this distortion disappears, their human judgment takes several
# seconds to come back to its previous state that was jusging that the video has a good quality ("slow to forgive").
# This is the temporarl effet implemented in this score computation.  It indicates the quality of each frame, taking into accout the previous
# judgments.
# @param Jerkiness double : The minimum value is 0 and no maximum.  It is the duration in mS during which video was frozen.
# @param Blockiness double : This indicates the blockiness on a range from 0 to 255.  It expresses the importance of the frontier between
# a block which is suspected as distored and its neighbourhood.  Typical values: 0 - 3 : OK, above 3 : distorted.
# @param Blur double : Blur ranges from 0 to the diagonal length of the picture (sqrt(width * width + height * height)). It indicates the 
# bluriness of the image. Values below 2 are OK, above 2 indicates a blurry picture.  This of course, may be the intention of the source video
# for artistic effect.
# @param Contrast double : This ranges from 0 to 2 and expresses the importance of details in the video, especially around macroblock boundaries
# where they are submitted to the H.264 deblocking filter.  This value only has meaning when the original video is H.264.  Values less than
# 0.15 indicate not enough detail, good video has values above 0.15
# @param TemporalActivity double :  This ranges from 0 to 255 and indicates how the pixel values change between 2 successive frames.  Typical
# values are 0 - 5 : low motion, 5 - 15 : normal motion and >15: important motion.
# @param MotionVector Tuple :  A tuple of the global motion vectors in (X,Y) directions indicating the general motion of this frame relative
# to the previous frame.
# @param YLevels Tuple : Tuple of minimum Y, maximum Y, average Y and standard deviation of Y.  Y is the brightness (luminance) of the
# video frame.  All values are doubles between 0 and 255.  The mean values can be interpreted as 0 - 50 : dark content, 
# 50 - 150 : normal content,  and above 150 : light content.  For the standard deviation values less the 20 indicate a homogeneous content.
# @param ULevels Tuple : Tuple of minimum U, maximum U, average U and stardard deviation of U. The U value is the difference between 
# Blue and the Brightness (part of YUV color space).  In this release the average and standard deviation will always be None as it is not supported.
# @param VLevels Tuple : Tuple of minimum V, maximum V, average V and stardard deviation of V. The V value is the difference between 
# Red and the Brightness (part of YUV color space).  In this release the average and standard deviation will always be None as it is not supported.
class VQAVideoResult(object):
    __cache = {}

    def __init__(self):
        self.__cache = {}
        self.FrameNumber = None
        self.TimeStamp = None
        self.MOS = None
        self.MOSDescription = None
        self.FrameQuality = None
        self.FrameQualityTemporal = None
        self.Jerkiness = None
        self.Blockiness = None
        self.Blur = None
        self.Contrast = None
        self.TemporalActivity = None
        self.MotionVector = (None, None)
        self.YLevels = (None, None, None, None)
        self.ULevels = (None, None, None, None)
        self.VLevels = (None, None, None, None)


    def __getattr__(self, attr):
        return Imaging.GetVqaVideoResultProperty(self.__cache, attr)

    def __setattr__(self, attr, value):
        if attr.startswith("_VQAVideoResult__"):
            object.__setattr__(self, attr, value)
        else:
            Imaging.SetVqaVideoResultProperty(self.__cache, attr, value)

    def __dir__(self):
        return Imaging.VqaVideoResultDir(list(VQAVideoResult.__dict__.keys()))


## @par Description
# The VQA audio result object.  The properties here indicate various metrics about the audio analyzed.  Audio is analyzed in
# chunks of 1 second, not video frame lengths.  However, not all properties are necessarily valid for all result records - in 
# that case the value will be None instead of the value described here.  If there is a long period of pure silence, the MOS score
# is None (a human would not say silence is 'good' or 'bad' but rather 'there is no audio'.\n\n
# The low level hardware supplies audio in packets of 8192 bytes (42.67 mS at 48 kHz audio) so 1 second is not a complete number
# of packets.  For this reason, you do not get exactly 1 result per 1 second of 30 frames of video (at 30 frames per second).  The
# audio is processed continually without error - the first audio result is generated when 24 packets of 42.67 mS have been received 
# (1.024 seconds).
# @param FrameNumber integer : The frame number of this result.  The first result analyzed is frame 30 +/-1 at a video rate of
# 30 frames per second.  Frame numbers are counted from the captured video frame and will increment at the raw video capture frame rate (+/- 1), 
# due to 1 result per second.
# @param TimeStamp double : the timestamp of the result.  This is in seconds since the Unix epoch (1/1/1970 00:00:00 UTC)
# and is the time on the server when the result was generated.  This may increase unevenly due to threading and CPU load.
# It is useful for debugging should problems occur.
# @param MOS double : The raw MOS score. This is a number normally between 0 and 100.  However, if the XXXInfluence
# parameters are set to high values and lots of errors occur, the result can be negative.  The scores are:
#  @htmlonly
#  <TABLE ALIGN="center" BORDER=1 CELLSPACING=0 CELLPADDING=5>
#  <TR ALIGN="left" VALIGN="middle">
#    <TH>MOS Score</TH>
#    <TH>Meaning</TH>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <td>&lt; 20</td><td>Bad Quality</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <td>20 - 40</td><td>Poor Quality</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <td>40 - 60</td><td>Rather Good Quality</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <td>60 - 80</td><td>Good Quality</td>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#  <td>80 - 100</td><td>Excellent Quality</td>
#  </TR>
#  </Table>
#  @endhtmlonly
#  @latexonly
#  \begin{center}
#  \begin{tabular}{ | l | r | }
#  \hline
#  MOS Score & Meaning \\ \hline\hline
#  < 20 & Bad Quality \\
#  20 - 40 & Poor Quality \\
#  40 - 60 & Rather Good Quality \\
#  60 - 80 & Good Quality \\
#  80 - 100 & Excellent Quality \\
#  \hline
#  \end{tabular}
#  \end{center}
#  @endlatexonly
# These terms are defined in standards such as BT.500 and BT.710.  The MOS score is an average of the qualities over time.  It uses a 10 second 
# window for the averaging so the first 10 seconds worth of values after starting are not valid.
# @param MOSDescription string : The String equivalent of the MOS score without the word Quality (i.e. Bad, Poor, Rather Good, Good or Excellent)
# @param AudioQuality double : The quality of a single 1 second piece of audio.  The range and meaning is the same as MOS score.  MOS score is the average of the raw
# audio qualities.  The AudioQuality ignores the effect of prior frames.
# @param AudioQualityTemporal double : The quality of a single 1 second piece of audio taking into account the previous pieces' scores.  This takes into account
# a property of the human audio system which is that we are "quick to criticize, slow to forgive". In order to understand this sentence, consider human
# observers listening to a good quality audio track.  Now imagine that an audible distortion appears.  When
# the distortion appears, the quality judgment of the human listeners decreases nearly instantly
# ("quick to criticize"). However, when this distortion disappears, their human judgment takes several
# seconds to come back to its previous state that was judging that the audio has a good quality ("slow to forgive").  Humans are generally more sensitive
# to audio distortion than video, so a longer (10 second) window is used for temporal calculations.
# This is the temporal effect implemented in this score computation.  It indicates the quality of each piece of audio, taking into account the previous
# judgments.
# @param CustomSilences double : Number of silences detected based on the custom silence detection algorithm selected.  It will be a number >= 0.
# @param Silences double : The number of audio silences detected using the standard silence detection algorithm.
# @param SilenceDuration double : The duration of audio silences detected using the standard silence detection algorithm (each silence is >= 100mS, this value
# is the sum of all silences).
# @param Saturations double : The number of times audio saturation was detected in the 1 second piece of audio.
# @param Breaks double : The number of breaks detected in the 1 second piece of audio.
# @param EstimatedBandwidth double : The estimaed bandwidth of the audio sample.  The maximum bandwidth is the audio sample rate/2.  A low value of the
# estimated bandwidth indicates possible distortion (but it may also simply be a feature of the source audio).
# @param HighFrequencyPresent double :  A value indicating the presence of high frequencies in the 1 second of audio.  It is an adaptive calculation which
# takes into account the ratio between low and high frequencies.  Values > 0.01 are generally OK, values lower than 0.0005 indicate heavy distortion.
class VQAAudioResult(object):
    __cache = {}

    def __init__(self):
        self.__cache = {}
        self.FrameNumber = None
        self.TimeStamp = None
        self.MOS = None
        self.MOSDescription = None
        self.AudioQuality = None
        self.AudioQualityTemporal = None
        self.CustomSilences = None
        self.Silences = None
        self.SilenceDuration = None
        self.Saturations = None
        self.Breaks = None
        self.EstimatedBandwidth = None
        self.HighFrequencyPresent = None


    def __getattr__(self, attr):
        return Imaging.GetVqaAudioResultProperty(self.__cache, attr)

    def __setattr__(self, attr, value):
        if attr.startswith("_VQAAudioResult__"):
            object.__setattr__(self, attr, value)
        else:
            Imaging.SetVqaAudioResultProperty(self.__cache, attr, value)

    def __dir__(self):
        return Imaging.VqaAudioResultDir(list(VQAVideoResult.__dict__.keys()))




## @par Description
# VQAEngineStatus Enum. This indicates the status of the VQAEngine.
# @param Idle : The engine is idle, it has not started analysis (this occurs from creation until the trigger
# condition specified in Start() has been met.
# @param Run : The engine is running and actively analyzing video samples.
# @param Stop : The engine has been stopped via a call to Stop() has been called.  The engine sets this state immediately
# upon you calling Stop().  However, if a trigger condition with a delay has been specified, the Stop event will be
# received when the delay expires.  The reason is that you can check the engine status to avoid calling stop multiple times.
# The actual stopping of the engine is asynchronous because it is on the server.  The engine will continue to analyze
# samples previously captured that remain in the backlog queue.
# @param Complete : The engine has completed its analysis, including all the samples in the backlog queue. No
# further action will be taken by the VQA engine
# @param Closed : The engine has been closed by using the Close() function. Any further calls to the engine
# are forbidden and will raise an exception.  You can use this state to check if Close() has been called, perhaps
# in a different thread by your application.
class VQAEngineStatus:
    Idle = "Idle"
    Run = "Run"
    Stop = "Stop"
    Complete = "Complete"
    Closed = "Closed"

## @par Description
#  The VQA Engine class.  This is the core engine.  You can create this object directly or use VQACreateEngine
#  function.  This engine can be passed to functions such as VQAStart or you can call methods directly on this
#  object.  
#
#  @param VideoOptions VQAVideoOptions : The video options used to create the engine.  This is read only.  You cannot
#  update the options once the engine has been created.
#  
#  @param AudioOptions VQAAudioOptions : The audio options used to create the engine.  This is read only. You cannot
#  update the options once the engine has been created.
#
#  @param Status VQAEngineStatus :  The status of the engine.  It is a value from the VQAEngineStatus.  You cannot
#  write to the status - it is read only and updated by the engine.
#
#  @param Slots List : List of slots that this engine is using.  It will be None until the engine has been started
#  and after that it will be the list of slots in use.  You cannot replace this list and if you try to update the
#  contents, then you will be confused (Python won't stop you modifying the contents).  The values are the logical
#  slots when under the daemon and can be passed to other API functions that take a slot number.
class VQAEngine(object):
    __cache = {}
    ## @par Description
    # The constructor makes a VQAEngine object.
    # @param[in] videoOptions @b VQAVideoOptions : The video options to use.  This may be None (the default) to get the
    # default settings.  You cannot change the options once the engine has been made.
    # @param[in] audioOptions @b VQAAudioOptions : The audio options.  This may be None (the defautl) to get the default settings.  
    # You cannot change the options once the engine has been made. 
    # @note vqa = VQAEngine(videoOptions, audioOptions) is the same as vqa = VQACreateEngine(videoOptions, audioOptions)
    # for those who prefer a function based API.
    # 
    # @return @e VQAEngine : The completely constructed VQAEngine object.
    # @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>>voptions = VQAVideoOptions()
    # >>>voptions.Backlog = 1500
    # >>>aoptions = VQAAudioOptions()
    # >>>aoptions.SilenceInfluence = 10
    # >>>vqa = VQAEngine(voptions, aoptions)
    # >>>print(str(vqa.Status))
    # >>>Idle
    # @endcode
    def __init__(self, videoOptions=None, audioOptions=None):
        self.__cache = {}
        if videoOptions is None:
            videoOptions = VQAVideoOptions()
        if audioOptions is None:
            audioOptions = VQAAudioOptions()

        Imaging.VqaEngineCtor(self, self.__cache, videoOptions, audioOptions)

    def __getattr__(self, attr):
        return Imaging.GetVqaEngineProperty(self.__cache, attr)

    def __setattr__(self, attr, value):
        if attr.startswith("_VQAEngine__"):
            object.__setattr__(self, attr, value)
        else:
            Imaging.SetVqaEngineProperty(self.__cache, attr, value)

    def __dir__(self):
        return Imaging.VqaEngineDir(list(VQAEngine.__dict__.keys()))


    ## @par Description
    # Start VQA analysis on one or more slots.  Multi slot VQA is an advanced issue and this release
    # of StormTest does not support that.  Only 1 slot may be used.
    # Once started, the VQA analysis proceeds asynchronously.  You may wait for results or be notified
    # using a callback.  The VQA will run until you stop it or until the slot is released.
    #
    # @param[in] trigger @b TriggerCondition : (optional) The trigger condition to start VQA analysis.  If omitted
    # analysis starts immediately.  You can set up a trigger condition to start VQA analysis on a specific
    # keystroke or when a specific video frame is detected.
    #
    # @param callbackFunction[in] @b VQACallback : (optional) The callback function to be called whenever an event of interest occurs.
    # The callback is called on another thread and you must be aware of that when handling the events. You should
    # not rely upon calling arbitrary StormTest functions.  However, you can call Stop and Close methods on the
    # VQAEngine.
    #
    # @param[in] slotNo @b Integer : (optional) The slot number to use.  If omitted or set to 0 then all reserved slots will be used.
    # In this release, if 0 is used for slotNo, then an exeption will be thrown if your script has reserved 2 or more
    # slots.
    #
    # @return None
    #
    #  @exception StormTestExceptions is thrown on an error (for example bad parameters, not enough memory,
    # invalid slot, no communication).
    # 
    # @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>>vqa = VQAEngine()
    # >>>vqa.Start()                # start on all reserved slots immediately and without a callback
    # @endcode
    #  @subsubsection _cb1 cb1:
    #  @b callbackFunction(slotNo, engine, event).
    #  @param[in] slotNo @b Integer: The slot number related to the event
    #  @param[in] engine @b VQAEngine: The engine that is calling the function (this allows a single callback to
    #  manage many engines)
    #  @param[in] event @b VQAEvent: The event object
    #  @return None
    #  @note You should return None from your callback - future versions of StormTest may define the return value
    #  to mean something.
    def Start(self, trigger=None, callbackFunction=None, slotNo=0):
        return Imaging.VqaEngineStart(self, self.__cache, trigger, callbackFunction, slotNo)

    ## @par Description
    # Stop a running VQA analysis.  This will stop further frames being queued up for analysis but will not stop
    # any pending frames from being analysed.  It is normal for there to be some frames waiting analysis - these will
    # be analysed after Stop is called.  Once you have called Stop() you may not call Start() again. To start a new analysis,
    # create a new VQAEngine.
    # @param[in] trigger @b TriggerCondition : (optional) the trigger condition to stop the analysis. If omitted analysis stops
    # immediately.  In release 3.2.3, only the FrameCount and Delay options of triggering are supported. In release 3.2.5 and later, if 
    # you are only doing audio VQA Analysis then only the Delay option is supported - FrameCount must be None.
    # This function is asynchronous and returns immediately.
    # @return None
    # @exception StormTestExceptions is thrown on an error (engine not running, invalid paramters, no communication)
    # @note If you create a new VQAEngine and start it on the same slot after calling Stop() but before calling Close() then
    # the system will automatically call Close() for you on the VQAEngine() which had been stopped but not closed.
    # @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>>vqa = VQAEngine()
    # >>>vqa.Start()
    # >>>stopCondition = TriggerCondition()
    # >>>stopCondition.Delay = 30
    # >>>vqa.Stop(stopCondition)    # stop on a trigger. That is set to 30 seconds so the stop will stop 30 seconds in the future.
    # @endcode
    def Stop(self, trigger=None):
        return Imaging.VqaEngineStop(self, self.__cache, trigger)

    ## @par Description
    # Closes a VQAEngine, stopping it if necessary and freeing all resources associated with the engine. Any pending
    # frames will not be analyzed and after calling Close(), you cannot call any other method on the engine.  You should
    # call this once you are finished with the analysis and you have got all your results.  This ensures all memory used
    # by the VQA has been freed.  You may receive a callback after Close() is called due to the asynchronouse nature of callbacks.
    # @param None
    # @return None
    # @note If you create a new VQAEngine and start it on the same slot after calling Stop() but before calling Close() then
    # the system will automatically call Close() for you on the VQAEngine() which had been stopped but not closed.
    # @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # # example to just run for a while, get no results and stop everything. Not the most useful program ever written.
    # >>>vqa = VQAEngine()
    # >>>vqa.Start()
    # >>>WaitSec(5)
    # vqa.Close()                   # stop everything and clean up
    # @endcode
    def Close(self):
        return Imaging.VqaEngineClose(self, self.__cache)


    ## @par Description
    # Wait for one or more events to occur.  You should not use this function for an event type AND also process
    # the same event type in the callback - this will cause confusion.  You should choose one method of the other.
    # If you specify a callback then events are posted to the callback.  If the callback handles the event then it
    # is no longer available to be retrieved from WaitEvent().  If an event is retrieved via WaitEvent() then it will
    # be still posted to the callback if a callback exists.
    # @param[in] eventList List of VQAEventType: list of events.  The call will return when any one of those events occur.  You can
    # set the list to be empty to mean 'any event'.  The call will return on the first event.
    # @return @e events List : List of VQAEvent objects.  Each event object identifies its type and some optional
    # parameters.
    # @note If you specify an event list which can never occur then this function will never return.
    # @note It is the script writers responsibility to process events in a timely manner. The queue of events is
    # limited - an event will be held for at least 15 seconds.
    # @subsubsection _eg1 eg1:
    # @b Example:
    # @code
    # >>>vqa = VQAEngine()
    # >>>vqa.Start()
    # >>>WaitSec(2)
    # >>>events = vqa.WaitEvent([])
    # >>>print("We have {0} events".format(len(events)))
    # >>>We have 25 events
    # @endcode
    def WaitEvent(self, eventList):
        return Imaging.VqaEngineWaitEvent(self, self.__cache, eventList)

## @par Description
# This function creates a VQAEngine.  This is identical to simply creating a 
# VQAEngine using code: VQAEngine(videoOptions, audioOptions)
# @param[in] videoOptions VQAVideoOptions : (optional) video options
# @param[in] audioOptions VQAAudioOptions : (optional) audio options
# @return engine @e VQAEngine : the VQAEngine object
# 
# @subsubsection _eg1 eg1:
# @b Example:
# @code
# >>>vqa = VQACreateEngine()  # this is identical to vqa = VQAEngine()
# @endcode
@ApiFunction
def VQACreateEngine(videoOptions=None, audioOptions=None):
    return VQAEngine(videoOptions, audioOptions)


## @par Description
# This function starts video analysis using a previously created VQAEngine.
# Please see the documentation for VQAEngine.Start() method for full details.  This function is
# identical to calling Start(trigger, callbackFunction, slotNo) on the VQAEngine object.
# @param[in] engine @b VQAEngine : the engine that has previously been created
# @param[in] trigger @b TriggerCondition : (optional) The trigger condition to start VQA analysis.
# @param callbackFunction[in] @b VQACallback : (optional) The callback function to be called whenever an event of interest occurs.
# @param[in] slotNo @b Integer : (optional) The slot number to use.  If omitted or set to 0 then all reserved slots will be used.
# 
# @return None
#
#  @exception StormTestExceptions is thrown on an error (for example bad parameters, not enough memory,
# invalid slot, no communication).
# 
# @subsubsection _eg1 eg1:
# @b Example:
# @code
# >>>vqa = VQACreateEngine()
# >>>VQAStartAnalysis(vqa)                # start on all reserved slots immediately and without a callback
# # the above code is identical in effect to:
# >>>vqa = VQAEngine()
# >>>vqa.Start()
# @endcode
@ApiFunction
def VQAStartAnalysis(engine, trigger=None, callbackFunction=None, slotNo=0):
    if engine == None or not isinstance(engine, VQAEngine):
        raise StormTestExceptions("VQAStartAnalysis was passed an invalid engine object")
    return engine.Start(trigger, callbackFunction, slotNo)

## @par Description
# This function stops video analysis using a previously created VQAEngine.
# Please see documentation for VQAEngine.Stop() method for full details.  This function is 
# identical to calling Stop(trigger) on the VQAEngine object.
# @param[in] engine @b VQAEngine : the engine that has previously been created
# @param[in] trigger @b TriggerCondition : (optional) the trigger condition to stop the analysis.
# @return None
# @exception StormTestExceptions is thrown on an error (engine not running, invalid paramters, no communication)
#
# @subsubsection _eg1 eg1:
# @b Example:
# @code
# >>>vqa = VQACreateEngine()
# >>>VQAStartAnalysis(vqa)
# >>>stopCondition = VQACreateTrigger()
# >>>stopCondition.Delay = 30
# >>>VQAStopAnalysis(vqa, stopCondition)    # stop on a trigger. That is set to 30 seconds so the stop will stop 30 seconds in the future.
# # The above code is identical to:
# >>>vqa = VQAEngine()
# >>>vqa.Start()
# >>>stopCondition = TriggerCondition()
# >>>stopCondition.Delay = 30
# >>>vqa.Stop(stopCondition)    # stop on a trigger. That is set to 30 seconds so the stop will stop 30 seconds in the future.
# @endcode
@ApiFunction
def VQAStopAnalysis(engine, trigger=None):
    if engine == None or not isinstance(engine, VQAEngine):
        raise StormTestExceptions("VQAStopAnalysis was passed an invalid engine object")
    return engine.Stop(trigger)


## @par Description
# This function close a video analyzer using a previously created VQAEngine.
# Please see documentation for VQAEngine.Close() method for full details.  This function is
# identical to calling Close() on the VQAEngine object.
# @param[in] engine @b VQAEngine : the engine that has previously been created
# @return None
# @exception StormTestExceptions is thrown on an error (engine not running, invalid paramters, no communication)
# @subsubsection _eg1 eg1:
# @b Example:
# @code
# # example to just run for a while, get no results and stop everything. Not the most useful program ever written.
# >>>vqa = VQACreateEngine()
# >>>VQAStartAnalysis(vqa)
# >>>WaitSec(5)
# >>>VQACloseAnalyzer(vqa)    # stop everything and clean up
# # The above code is identical to:
# >>>vqa = VQAEngine()
# >>>vqa.Start()
# >>>WaitSec(5)
# vqa.Close()                   # stop everything and clean up
# @endcode
@ApiFunction
def VQACloseAnalyzer(engine):
    if engine == None or not isinstance(engine, VQAEngine):
        raise StormTestExceptions("VQACloseAnalyzer was passed an invalid engine object")
    return engine.Close()


## @par Description
# This function waits for one or more events from a previously created VQAEngine.
# Please see documentation for vQAEngine.WaitEvent() method for full details.  This function
# is identical to calling WaitEvent(eventList) on the VQAEngine object.
# @param[in] engine @b VQAEngine : the engine that has previously been created
# @param[in] eventList List : list of events.  The call will return when any one of those events occur.
# @return @e events List : List of VQAEvent objects.  Each event object identifies its type and some optional
# parameters.
# @note You should be aware of threading issues with this call. In particular, you should not create multiple
# threads, each waiting on the same event.  If, for example, you create 2 threads, each waiting on the Start
# event, there is no guarantee that both threads will get the event - they might but it is highly likely that
# only 1 thread will get the event and the other would wait forever (or until engine is closed or slot released whichever
# comes first).
# @subsubsection _eg1 eg1:
# @b Example:
# @code
# >>>vqa = VQAEngine()
# >>>vqa.Start()
# >>>WaitSec(2)
# >>>events = VQAWaitEvent([])
# >>>print("We have {0} events".format(len(events)))
# >>>We have 25 events
# # The above code is identical to:
# >>>vqa = VQAEngine()
# >>>vqa.Start()
# >>>WaitSec(2)
# >>>events = vqa.WaitEvent([])
# @endcode

@ApiFunction
def VQAWaitEvent(engine, eventList):
    if engine == None or not isinstance(engine, VQAEngine):
        raise StormTestExceptions("VQAWaitEvent was passed an invalid engine object")
    return engine.WaitEvent(eventList)


## @par Description
# This function creates a default TriggerCondition object.  It is identical to creating
# the trigger object using trigger = TriggerCondition().
# @param None
# @return @e TriggerCondition : the default trigger object.  This will simply trigger immediately.
# @subsubsection _eg1 eg1:
# @b Example:
# @code
# >>>create a trigger to trigger after 1000 frames
# >>>trigger = VQACreateTrigger()
# >>>trigger.FrameCount = 1000
# @endcode
@ApiFunction
def VQACreateTrigger():
    return TriggerCondition()

## @par Description
# This function creates a trigger condition object from an image.  It is identical to 
# calling TriggerCondition.FromImage(image, rect).  Please see documentation for the
# FromImage() method of TriggerCondition for full details
# @param[in] image StormTestImageObject : the image to use as the reference.
# @param[in] rect List or Tuple : (optional) the region of interest within the image.
# @param[in] threshold double : (optional) the threshold for the image match as per CompareImageEx.
# @return @e TriggerCondition : the completed trigger condition ready to use.
# @subsubsection _eg1 eg1:
# @b Example:
# @code
# >>>create a trigger to trigger on image but using rect at (0,0,400,300)
# >>>trigger = VQACreateTriggerFromImage(image, [0,0,400,300])
# @endcode
@ApiFunction
def VQACreateTriggerFromImage(image, rect=None, threshold=98):
    return TriggerCondition.FromImage(image, rect, threshold)

## @par Description
# This function creates a trigger condition object from an icon.  It is identical to 
# calling TriggerCondition.FromIcon(image, location).  Please see documentation for the
# FromIcon() method of TriggerCondition for full details
# @param[in] image StormTestImageObject : the image to use as the reference icon.
# @param[in] location List or Tuple : the location of the icon within the image.
# @param[in] threshold double : (optional) the threshold for the icon match as per CompareIconEx.
# @return @e TriggerCondition : the completed trigger condition ready to use.
# @subsubsection _eg1 eg1:
# @b Example:
# @code
# >>>create a trigger to trigger on icon but using location at (89,77)
# >>>trigger = VQACreateTriggerFromIcon(image, [89,77])
# @endcode

@ApiFunction
def VQACreateTriggerFromIcon(image, location, threshold=98):
    return TriggerCondition.FromIcon(image, location, threshold)

## @par Description
# This function creates a trigger condition object from a color.  It is identical to 
# calling TriggerCondition.FromColor(rect, color, tolerance, flatness, peakError).  Please see documentation for the
# FromColor() method of TriggerCondition for full details
# @param[in] rect List or Tuple : the region of interest within the screen capture.
# @param[in] color List or Tuple : the color as a List or Tuple of Red, Green, Blue values.
# @param[in] tolerance List or Tuple : (optional) the tolerance to apply to color comparison as per CompareColorEx
# function.
# @param[in] flatness double : (optional) the flatness of the color as per CompareColorEx function.
# @param[in] peakError double : (optional) the peak error of the color as per CompareColorEx function.
# @return @e TriggerCondition : the completed trigger condition ready to use.
# @subsubsection _eg1 eg1:
# @b Example:
# @code
# >>>create a trigger to trigger on color black at (0,0, 400,100)
# >>>trigger = VQACreateTriggerFromColor((0,0,400,100), (0,0,0))
# @endcode
@ApiFunction
def VQACreateTriggerFromColor(rect, color, tolerance=(4,4,4), flatness=98, peakError=0):
    return TriggerCondition.FromColor(rect, color, tolerance, flatness, peakError)

## @par Description
# This function creates the default video options object.  It is identical to simply creating the
# object using the default constructor: options = VQAVideoOptions().
# @param None
# @return @e VQAVideoOptions : The completely constructed VQAVideoOptions object.
# @subsubsection _eg1 eg1:
# @b Example:
# @code
# >>>vqaOptions = VQACreateVideoOptions()
# >>>print(str((vqaOptions.Jerkiness, vqaOptions.Backlog, vqaOptions.Format)))
# >>>(True, 500, "H264")
# >>>vqaOptions.Backlog = 1500
# >>>print(str((vqaOptions.Jerkiness, vqaOptions.Backlog, vqaOptions.Format)))
# >>>(True, 1500, "H264")
# @endcode
@ApiFunction
def VQACreateVideoOptions():
    return VQAVideoOptions()


## @par Description
# This function creates the default audio options object.  It is identical to simply creating the
# object using the default constructor: options = VQAAudioOptions().
# @param None
# @return @e VQAAudioOptions : The completely constructed VQAAudioOptions object.
# @subsubsection _eg1 eg1:
# @b Example:
# @code
# >>>vqaOptions = VQACreateAudioOptions()
# >>>print(str((vqaOptions.SilenceInfluence, vqaOptions.Enabled)))
# >>>(0, True)
# >>>vqaOptions.SilenceInfluence = 25
# >>>print(str((vqaOptions.SilenceInfluence, vqaOptions.Enabled)))
# >>>(25, True)
# @endcode
@ApiFunction
def VQACreateAudioOptions():
    return VQAAudioOptions()


## @par Description
# Gets the VQA License information for one or more servers.  This function can be called before
# connecting to a server or reserving a slot.  It can only find out about servers in the current
# facility - this can be controlled via SetMasterConfigurationServer.  If SetMasterConfigurationServer
# is not called, the default facility set during installation of StormTest client software is used.
# @param[in] server String or List : The server name to query for VQA license info.  It can be a list
# of server names or the empty list to mean 'all servers'.
# @return licenseInfo @e List : List of licensing information.  Each item in the list is a Tuple of
# (serverName, slotNumber, expiryTime).  The expiryTime is the expiry time in seconds since the Unix
# epoch (1/1/1970 00:00:00 UTC) when the license will expire.  Perpetual licenses are returned with
# an expiryTime equal to the maximum intger.  Only server/slot combinations with a valid license are 
# returned.  If a server has all 16 slots licensed then there are 16 elements in the list.
# @subsubsection _eg1 eg1:
# @b Example:
# @code
# >>>print(str(VQAGetLicenseInfo("myServer")))
# >>>[(myServer,5,1499817600),(myServer,6,1499817600),(myServer,7,1499817600),(myServer,8,1499817600)]
# >>>print(str(VQAGetLicenseInfo("nonLicensedServer")))
# >>>[]
# @endcode
@ApiFunction
def VQAGetLicenseInfo(server):
    return Imaging.VqaGetLicenseInfo(server)

## @par Description
# Tests whether the slot is licensed for VQA or not.  It can only test reserved slots and is intended
# for scripts to easily determine whether they should start VQA video analysis or not.
# @param[in] slotNo Integer : (optional) slot number to test
# @return status Boolean : If slotNo is non zero then the return will be a simple True / False
# status as to whether the slot is licensed for VQA.  If slotNo is 0 then a list of tuples will be
# returned. Each tuple is (slotNo, status).
# @note It is theoretically possible to call this function a few seconds before a license expires and thus
# you could have a situation where VQAIsSlotLicensed returns True but VQAStartAnalysis fails due to an
# expired license. To prevent this, the VQAIsSlotLicensed call ensures that the license has at least
# 10 minutes to run.  You may, of course, ignore the return from VQAIsSlotLicensed and continue to 
# attempt VQAStartAnalysis().
# @exception StormTestExceptions is raised if slotNo is not reserved to the script.
# @subsubsection _eg1 eg1:
# @b Example:
# @code
# >>>print(str(VQAIsSlotLicensed(1)))
# >>>True
# >>>print(str(VQAIsSlotLicensed()))
# >>>[(1,True)]
# @endcode
@ApiFunction
def VQAIsSlotLicensed(slotNo=0):
    return Imaging.VqaIsSlotLicensed(slotNo)

## @par Description
# This API initiates the video analysis. It cannot be used while a High Speed Timer is reserved on the same slot.
# @param[in] fps @b Integer: The number of frames captured per seconds during analysis
# @param[in] testStream @b String: (optional) The test stream on which the video analysis is based, currently only TestStreamA is supported
# @param[in] useValuesFromDatabase @b Boolean: (optional) Instruct the call to read the database. This is new in 2.7 so tests using this parameter
# cannot run on 2.6 and earlier.
# @param[in] continueOnError @b Boolean: (optional) Instruct the call to continue the analysis if database has no values (using default
# values.) This is new in 2.7 so tests using this parameter cannot run on 2.6 and earlier
# @param[in] slotNo @b Integer: (optional) The slot number on which to start the video analysis.
# @return @b Boolean: status (True for success/False for failure). If slotNo is 0 then a list of items is returned. Each item is a list of [slotNo, bool]
#  where the bool is true or false as described earlier.
# @note 2.7 added parameters. Older scripts will run without modification as the API detects the type of the 3rd parameter
# an an integer, (if specified) OR it will use the defaults that a 2.6 test used. ie StartVideoAnalysis(fps) will behave the
# same on 2.7 and 2.6.  BUT StartVideoAnalysis(fps,"TestStreamA",True,False,0) will not work on 2.6
# @subsubsection _eg1 eg1:
# @b Example:
# @code
# ret = StartVideoAnalysis(5,"TestStreamA",True, False,1)
# print(str(ret))
# >>>True
# WaitSec(10)   # run the analysis for 10 seconds
# ret = StopVideoAnalysis()
# print(str(ret))
# >>>[[5,True]]
# @endcode
@ApiFunction
def StartVideoAnalysis(fps,testStream="TestStreamA", useValuesFromDatabase=True, continueOnError=True,slotNo=0):
    """
    Start video analysis on a slot.

    Return: Bool. Trur if video analysis started

    fps: (Integer) The frames/second at which to run the video analysis. Suggest max value of 5 if
      16 slots are to run simultaneously.

    testStream: (String, optional) The name of the test stream that is being sent to the slot. Only
      "TestStreamA" is currently supported.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.StartVideoAnalysis(fps,testStream,useValuesFromDatabase,continueOnError,slotNo)

## @par Description
# Stops the video analysis. This function can only be called after StartVideoAnalysis has been called.
# @param[in] slotNo @b Integer: (optional) The slot number on which to start the video analysis.
# @return @b Boolean: status (True for success/False for failure). If slotNo is 0 then a list of items is returned. Each item is a list of [slotNo, bool]
#  where the bool is true or false as described earlier.
# @subsubsection _eg1 eg1:
# @b Example:
# @code
# ret = StopVideoAnalysis()
# print(str(ret))
# >>>[[1,True]]
# @endcode
@ApiFunction
def StopVideoAnalysis(slotNo=0):
    """
    Stop the video analysis.

    Return: Bool. True if video analysis stopped.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.StopVideoAnalysis(slotNo)

## @par Description
#  Sets the video analysis parameters to the calData (a string).  The calData can be a @ref _stringObject.
#  Using a @ref _stringObject would be recommended as the format of data is complex.  After using this function,
#  StartVideoAnalysis() should be called by setting the useValuesFromDatabase parameter to False (otherwise
#  this functions operation will be overwritten)
#
#  @param[in] calData @b string : the calibration data.  A non documented format.  Can be obtained from ReadVideoCalibrationData
#  @param[in] slotNo @b integer :  (optional) The slot number where the calibration data is being set.
#
#  @return @e boolean: True for success.  If slotNo is 0 then a list of items is returned, each item is a list of [slotNo, bool] where
#  the bool is true or false as described earlier.
@ApiFunction
def SetVideoAnalysisParameters(calData, slotNo=0):
    """
    Sets the video analysis parameters to the calData (a string).  The calData can be a StringObject.
    Using a StringObject would be recommended as the format of data is complex.  After using this function,
    StartVideoAnalysis() should be called by setting the useValuesFromDatabase parameter to False (otherwise
    this functions operation will be overwritten)

    param calData string : the calibration data.  A non documented format.  Can be obtained from ReadVideoCalibrationData

    param slotNo integer :  (optional) The slot number where the calibration data is being set.

    return boolean: True for success.  If slotNo is 0 then a list of items is returned, each item is a list of [slotNo, bool] where
    the bool is true or false as described earlier.
    """
    return stormtest_client.stc.set_video_analysis_parameters(calData, slotNo)

## @par Description
#  Looks up the video data for the specified model id and hardware output.  The return is a string
#  (not documented for public use).  An exception is thrown on an error.   The returned string can
#  be passed to WriteVideoCalibrationData() or SetVideoAnalysisParameters().  This function can
#  be called without reserving a slot.
#
#  @param[in] modelId @b integer: The model id. These can be found from ListDutModels.
#  @param[in] hwOutput @b string: (Optional) The output of interest (valid only with a specific AVSwitch).  Can be None if no AVSwitch
#  is in system to mean 'default raw output'.
#
#  @return @e string: The calibration data (None if there is no data).  Format is undocumented.
@ApiFunction
def ReadVideoCalibrationData(modelId, hwOutput=None):
    """
    """
    return stormtest_client.stc.read_video_calibration_data(modelId, hwOutput)

## @par Description
#  Writes the video data for the specified model id and hardware output.  An exception is thrown
#  on an error.  This function can be called without reserving a slot.  This function is intended for
#  scripts doing maintenance functions where the data from a model may need to be cloned to many other
#  known similar models.  It would have limited use in a normal test script.
#
#  @param[in] modelId @b integer: The model id. These can be found from ListDutModels.
#  @param[in] data @b string: The calibration data to write.  This should be returned from ReadVideoCalibrationData.
#  @param[in] hwOutput @b string: (optional) The output of interest (valid only with a specific AVSwitch).  Can be None if no AVSwitch
#  is in system to mean 'default raw output'.
#
#  @return @e None
@ApiFunction
def WriteVideoCalibrationData(modelId, data, hwOutput=None):
    """
    Writes the video data for the specified model id and hardware output.  An exception is thrown
    on an error.  This function can be called without reserving a slot.  This function is intended for
    scripts doing maintenance functions where the data from a model may need to be cloned to many other
    known similar models.  It would have limited use in a normal test script.

    param modelId integer: The model id. These can be found from ListDutModels.
    param data string: The calibration data to write.  This should be returned from ReadVideoCalibrationData.
    param hwOutput string: (optional) The output of interest (valid only with a specific AVSwitch).  Can be None if no AVSwitch
    is in system to mean 'default raw output'.

    return None
    """
    return stormtest_client.stc.write_video_calibration_data(modelId, data, hwOutput)

## @par Description
#  Deletes the video data for the specified model id and hardware output.  An exception is thrown only
#  if there is a problem with communicating to the database or parameters are the wrong type.
#  No exception is thrown if there is no data to delete (either the model id is invalid or the
#  hwOutput does not exist).  This function can be called without reserving a slot.
#
#  @param[in] modelId @b integer: The model id. These can be found from ListDutModels.
#  @param[in] hwOutput @b string: (Optional) The output of interest (valid only with a specific AVSwitch).  Can be None if no AVSwitch
#  is in system to mean 'default raw output'.
#
#  @return @e None
@ApiFunction
def DeleteVideoCalibrationData(modelId, hwOutput=None):
    """
    """
    return stormtest_client.stc.delete_video_calibration_data(modelId, hwOutput)

## @par Description
# Retrieves the result of the video analysis result run from the server. This function can only be run after StopVideoAnalysis has been called.
# @param[in] slotNo @b Integer: (optional) The slot number on which to start the video analysis.
# @return @b Array: The return is a Array of arrays containing slot number, status (true/false) indicating whether the success or not of the retrieval. \n
# A list containing two bool values indicating pass/fail for the video quality and video timing measures respectively, and a third element
# which is an array of tuples consisting of the (Frames,Captured,Unmatched), (LumaVariance,MaxDetected,Threshold)
# (ChromaVariance,MaxDetected,Threshold), (MaxLuma,MaxLumaDiff,ToleranceLuma), (MaxChroma,MaxChromaDiff,ToleranceChroma),
# (MaxJitter,MaxDetected,Threshold), (ColorBlockErrorCount,Count)
# The returned results are described as follows: \n
# Frames Captured, is the number of video frames captured during the analysis. \n
# Frames Unmatched, is the number of frames where no pattern match could be found. \n
# LumaVariance MaxDetected, is the maximum luma variance value detected on all video frames analysed. \n
# LumaVariance Threshold, is the threshold that the LumaVariance is set to, which determines a success or failure. \n
# ChromaVariance MaxDetected, is the maximum chroma variance value detected on all video frames analysed. \n
# ChromaVariance Threshold, is the threshold that the ChromaVariance is set to, which determines a success or failure. \n
#.MaxLuma MaxLumaDiff, is the maximum luma difference found from the reference colors during the analysis. \n
# MaxLuma ToleranceLuma, is the threshold that the luma difference is set to, which determines a success or failure. \n
# MaxChroma MaxChromaDiff, is the maximum chroma difference found from the reference colors during the analysis. \n
# MaxChroma ToleranceChroma, is the threshold that the chroma difference is set to, which determines a success or failure. \n
# MaxJitter MaxDetected, is the maximum percentage that the jitter was calculated to be during the analysis. \n
# MaxJitter Threshold, is the threshold that the percentage jitter value is set to, which determines a success or failure. \n
# ColorBlockErrorCount Count, is the count of the number a blocks analysed which had errors in them. \n
# @subsubsection _eg1 eg1:
# @b Example:
# @code
# ret = GetVideoAnalysisResult(1)
# print(str(ret))
# >>( True, [(True, True)], [('Frames', 50, 0), ('LumaVariance', 2.1066948676325699, 4.2144000000000004),
# >>('ChromaVariance', 2.0231123477330399, 3.9857), ('MaxLumaDiff', 2, 15), ('MaxChromaDiff', 1, 15), ('MaxJitter', 37, 50),
# >>('ColorBlockErrorCount', 0)]) #A successful result
# @endcode
@ApiFunction
def GetVideoAnalysisResult(slotNo=0):
    """
    Gets the result of the video analysis.  Can only be called after StopVideoAnalysis.

    Return: Tuple. The Contents are: (Status,[QualityStatus, TimingStatus],[Details]). The details
      are Tuples.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.GetVideoAnalysisResult(slotNo)

## @par Description
# Retrieves the video analysis results from the last run video analysis sequence on the slot of interest. This function can only be run after StopVideoAnalysis has been called.
# @param[in] returnRawResult @b Bool: (optional) A flag to determine whether or not to return the raw result along with the processed data
# If the raw result is returned it is the last item in the result array
# @param[in] slotNo @b Integer: (optional) The slot number on which to get the video analysis data
# @return @b Array: An array of arrays containing slot number,status (true/false) indicating whether the success or not of the retrieval.\n
# The result array is described in the following manner (Frames,Captured,Unmatched), (LumaVariance,MaxDetected,Threshold),
# (ChromaVariance,Max Detected,Threshold), (MaxLuma,MaxLumaDiff,ToleranceLuma), (MaxChroma,MaxChromaDiff,ToleranceChroma), (MaxJitter,MaxDetected,Threshold),
# (MinColorValues,MinDetected), (MaxColorValues,MaxDetected), (AvgColorValues,AvgDetected), (ColorBlockErrorCount,Count)[rawResult])\n\n
# If returnRawResult is set to true the last item in the above array will be the actual raw data numbers.
# The returned results are described as per GetVideoAnalysisResult and:\n\n
# MinColorValues, is a string describing the  minimum color values detected during the analysis.\n
# MaxColorValues, is a string describing the maximum color values detected during the analysis.\n
# AvgColorValues, is a string describing the average color values detected during the analysis.\n
# @subsubsection _eg1 eg1:
# @b Example:
# @code
# ret = GetVideoAnalysisData(False,1)
# print(str(ret))
# (True, [('Frames', 50, 0), ('LumaVariance', 2.1290282747187601, 4.5122999999999998), ('ChromaVariance', 2.01698818979377, 3.6465999999999998),
# ('MaxLumaDiff', 1, 15), ('MaxChromaDiff', 5, 15), ('MinColorValues', u'grey\t119,128,128 white\t223,127,126 cyan\t161,166,12
# yellow\t200,12,146 green\t138,50,30 magenta\t100,203,223 blue\t38,240,109 red\t77,88,240'),
# ('MaxColorValues', 'grey\t120,128,128 white\t224,127,126 cyan\t162,166,13 yellow\t202,13,146 green\t139,51,31 magenta\t102,204,224
# blue\t39,241,109 red\t78,89,241'), ('AvgColorValues', u'grey\t119,128,128 white\t224,127,126 cyan\t162,166,12 yellow\t201,12,146
# green\t138,51,31 magenta\t101,203,224 blue\t39,241,109 red\t77,89,241'),('ColorBlockErrorCount', 0)])
# @endcode
@ApiFunction
def GetVideoAnalysisData(returnRawResult = False,slotNo=0):
    """
    Gets the full video analysis data for later offline processing. Can only be called after
    StopVideoAnalysis.

    Return: Tuple. 1st element is status as Bool, then complex collection of results.

    returnRawResult: (Boo, optional) falg to indicate that the raw results should also be returned.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.GetVideoAnalysisData(returnRawResult,slotNo)

## @par Description
# Clears the detailed results from a previous video analysis.  The results are stored after analysis and consume resources.  When you
# have finished retrieving the results, it is a good idea to clear them with this function.  After calling this function the
# overall summary result is still available but the detailed values will no longer be available.  The results will be cleared automatically
# when a slot is reserved, when a new Video analysis is started or when a High Speed Timer is reserved (the underlying
# implementation of video analysis uses the High Speed Timer infrastructure).
# @param[in] slotNo @b Integer: (optional) The slot number on which to clear the results
# @return @b None
# @subsection _eg1 eg1:
# @b Example:
# @code
# >> ClearVideoAnalysisResults()
# @endcode
@ApiFunction
def ClearVideoAnalysisResults(slotNo = 0):
    """
    Clear the results from a previous video analysis. Result storage consumes memory so after
    getting the results, the memory should be released.  The memory is release automatically on
    each start of video analysis.

    Return: None.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    stormtest_client.stc.ClearVideoAnalysisResults(slotNo)

## @par Description
#  This function resets the audio analysis parameters to the default values. These include the measurement time, tone parameters, impulse parameters
#  band for out of band power, band list for sub band power, band list for spurious tone detection.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>ResetAudioAnalysisParameters()
#  @endcode
@ApiFunction
def ResetAudioAnalysisParameters():
    """
    Clear audio analysis paramters and reset to the default values.

    Return: None.
    """
    return stormtest_client.stc.ResetAudioAnalysisParameters()

## @par Description
#  Sets the audio analysis parameters to the calData (a string).  The calData can be a @ref _stringObject.
#  Using a @ref _stringObject would be recommended as the format of data is complex.  After using this function,
#  StartAudioAnalysis() should be called by setting the useValuesFromDatabase parameter to False (otherwise
#  this functions operation will be overwritten)
#
#  @param[in] calData @b string : the calibration data.  A non documented format.  Can be obtained from ReadAudioCalibrationData
#  @param[in] slotNo @b integer :  (optional) The slot number where the calibration data is being set.
#
#  @return @e boolean: True for success.  If slotNo is 0 then a list of items is returned, each item is a list of [slotNo, bool] where
#  the bool is true or false as described earlier.
@ApiFunction
def SetAudioAnalysisParameters(calData, slotNo=0):
    """
    Sets the audio analysis parameters to the calData (a string).  The calData can be a StringObject.
    Using a StringObject would be recommended as the format of data is complex.  After using this function,
    StartAudioAnalysis() should be called by setting the useValuesFromDatabase parameter to False (otherwise
    this functions operation will be overwritten)

    param calData string : the calibration data.  A non documented format.  Can be obtained from ReadAudioCalibrationData

    param slotNo integer :  (optional) The slot number where the calibration data is being set.

    return boolean: True for success.  If slotNo is 0 then a list of items is returned, each item is a list of [slotNo, bool] where
    the bool is true or false as described earlier.
    """
    return stormtest_client.stc.set_audio_analysis_parameters(calData, slotNo)

## @par Description
#  Looks up the audio data for the specified model id and hardware output.  The return is a string
#  (not documented for public use).  An exception is thrown on an error.   The returned string can
#  be passed to WriteAudioCalibrationData() or SetAudiooAnalysisParameters().  This function can
#  be called without reserving a slot.
#
#  @param[in] modelId @b integer: The model id. These can be found from ListDutModels.
#  @param[in] hwOutput @b string: (Optional) The output of interest (valid only with a specific AVSwitch).  Can be None if no AVSwitch
#  is in system to mean 'default raw output'.
#
#  @return @e string: The calibration data (None if there is no data).  Format is undocumented.
@ApiFunction
def ReadAudioCalibrationData(modelId, hwOutput=None):
    """
    """
    return stormtest_client.stc.read_audio_calibration_data(modelId, hwOutput)

## @par Description
#  Writes the audio data for the specified model id and hardware output.  An exception is thrown
#  on an error.  This function can be called without reserving a slot.  This function is intended for
#  scripts doing maintenance functions where the data from a model may need to be cloned to many other
#  known similar models.  It would have limited use in a normal test script.
#
#  @param[in] modelId @b integer: The model id. These can be found from ListDutModels.
#  @param[in] data @b string: The calibration data to write.  This should be returned from ReadAudioCalibrationData.
#  @param[in] hwOutput @b string: (optional) The output of interest (valid only with a specific AVSwitch).  Can be None if no AVSwitch
#  is in system to mean 'default raw output'.
#
#  @return @e None
@ApiFunction
def WriteAudioCalibrationData(modelId, data, hwOutput=None):
    """
    Writes the audio data for the specified model id and hardware output.  An exception is thrown
    on an error.  This function can be called without reserving a slot.  This function is intended for
    scripts doing maintenance functions where the data from a model may need to be cloned to many other
    known similar models.  It would have limited use in a normal test script.

    param modelId integer: The model id. These can be found from ListDutModels.
    param data string: The calibration data to write.  This should be returned from ReadAudioCalibrationData.
    param hwOutput string: (optional) The output of interest (valid only with a specific AVSwitch).  Can be None if no AVSwitch
    is in system to mean 'default raw output'.

    return None
    """
    return stormtest_client.stc.write_audio_calibration_data(modelId, data, hwOutput)

## @par Description
#  Deletes the audio data for the specified model id and hardware output.  An exception is thrown only
#  if there is a problem with communicating to the database or parameters are the wrong type.
#  No exception is thrown if there is no data to delete (either the model id is invalid or the
#  hwOutput does not exist).  This function can be called without reserving a slot.
#
#  @param[in] modelId @b integer: The model id. These can be found from ListDutModels.
#  @param[in] hwOutput @b string: (Optional) The output of interest (valid only with a specific AVSwitch).  Can be None if no AVSwitch
#  is in system to mean 'default raw output'.
#
#  @return @e None
@ApiFunction
def DeleteAudioCalibrationData(modelId, hwOutput=None):
    """
    """
    return stormtest_client.stc.delete_audio_calibration_data(modelId, hwOutput)

##
#  MeasurementTime Enum. Defines the valid time period in which the audio power spectrum is measured and generated.
#  The valid time values are determined by the number of samples used by the audio analysis algorithms to compute a power spectrum result.
#  This enum helps users set the power based algorithms more intuitively by using the time period value than the actual number of samples.
#  @param OneSixteenthSec : 1/16 second (roughly the time for 1024 samples at 16 kHz).
#  @param OneEighthSec : 1/8 second (roughly the time for 2048 samples at 16 kHz).
#  @param OneFourthSec : 1/4 second (roughly the time for 4096 samples at 16 kHz).
#  @param HalfSec : 1/2 second (roughly the time for 8192 samples at 16 kHz).
#  @param OneSec : one seconds (roughly the time for 16384 samples at 16 kHz).
#  @param TwoSec : two seconds (roughly the time for 32768 samples at 16 kHz).
#  @param FourSec : four seconds (roughly the time for 65536 samples at 16 kHz).
#  @param EightSec : eight seconds (roughly the time for 131072 samples at 16 kHz).
class MeasurementTime:
    """
    Enumeration to define the measurement time for the audio analysis. Longer times result
    in better spectral resolution but take longer to run.
    """
    OneSixteenthSec = 1024
    OneEighthSec = 2048
    OneFourthSec = 4096
    HalfSec = 8192
    OneSec = 16384
    TwoSec = 32768
    FourSec = 65536
    EightSec = 131072

## @par Description
#  This function sets the time period within which the audio is measured and the power spectrum is generated.
#  @param[in] timePeriod @b MeasurementTime:  time to compute a power spectrum result.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetAudioMeasurementTime(MeasurementTime.OneEighthSec)
#  @endcode
#  @note The API makes an assumption of 16kHz audio.  The StormTest HD system uses a sampling value of 48kHz.  To preserve
#  readability of code, the enumerated types are converted to give an approximate time similar to that specified.  The actual
#  values for HD are thus: OneSixteenthSec = 85.3mS, OneEighthSec = 171mS, OneFourthSec = 341mS, HalfSec = 683mS, OneSec =
#  1.365sec, TwoSec, FourSec and EightSec = 2.731sec (the low level cannot use more than 128K sample length).  If you wish to
#  set the FFT sample count explicitly, remember that for an HD system, you need to set a value of 1/4 of what you want. So
#  for HD system to get 4096 samples, call SetAudioMeaurementTime(4096/4).  Only powers of 2 are permitted and the range for HD
#  is 1024 -> 32768 inclusive. (This will translate to 4096 -> 131072 samples, 85.3 mS -> 2.731 seconds).
#  @note Users should understand the trade-off between the time (how quickly a result can be obtained) and the frequency resolution to use this API.
#    The default is MeasurementTime.OneEighthSec (i.e. 2048 samples used for standard definition audio at 16 kHz to compute an FFT result)
@ApiFunction
def SetAudioMeasurementTime(timePeriod):
    """
    Set the audio analysis measurement time.

    Return: None.

    timePeriod: (MeasurementTime) The time period to use for each FFT. Use one of the pre-defined
      enumeration values.
    """
    return stormtest_client.stc.SetAudioMeasurementTime(timePeriod)

## @par Description
#  This function gets the time period within which the audio is measured and the power spectrum is generated.
#  @return @e Number of samples for computing an FFT result (see MeasurementTime) See note on SetAudioMeasurementTime
#  for HD systems.
@ApiFunction
def GetAudioMeasurementTime():
    """
    Get the audio analysis measurement time.

    Return: MeasurementTime. The current FFT 'time' - in reality the number of samples used.
    """
    return stormtest_client.stc.GetAudioMeasurementTime()

## @par Description
#  This function sets the channel to use on HD systems for audio analysis and audio detection
#  API calls. (GetAudioLevel, WaitAudioAbsence, WaitAudioPresence).  It has no effect on standard
#  definition systems.  By default, Left channel is used after reserving a slot until explicitly set
#  to Right.  It only effects the next audio operation and does not alter an audio analysis in progress.
#  @param[in] audioChannel: (@b AudioChannel) The audio channel to use.
#  @param[in] slotNo @b Integer : (optional) By default, function acts on all reserved slots, unless this parameter is used.
#  @return @e Boolean or List of Lists: When slot is zero this is a list of lists, each being [SlotNumber, Status] but just
#  status if slotNo is non zero. Return is True if successfully set, else false.
#  @note This setting is independent of any AV switch in the system. For standard definition systems, this will not follow
#  any setting of the AVSwitch.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetAudioAnalysisChannel(AudioChannel.Left)
#   >>[[5,True]]
#  @endcode
@ApiFunction
def SetAudioAnalysisChannel(audioChannel, slotNo=0):
    return stormtest_client.stc.set_audio_analysis_channel(audioChannel, slotNo)

## @par Description
#  This function gets the audio channel set by SetAudioAnalysisChannel. On standard definition systems
#  it always returns AudioChannel.Left.  It returns the current channel in use if any analysis is in progress
#  but otherwise the channel that will be used for the next analysis.
#
#  @param[in] slotNo @b Integer : (optional) By default, function acts on all reserved slots, unless this parameter is used.
#  @return @e AudioChannel or List of Lists: When slot is zero this is a list of lists, each being [SlotNumber, AudioChannel] but just
#  the AudioChannel if slotNo is non zero.
#  @note This setting is independent of any AV switch in the system. For standard definition systems, this will not follow
#  any setting of the AVSwitch.  It will always return Left.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>GetAudioAnalysisChannel()
#   >>[[5,Left], [6, Right]]
#  @endcode
@ApiFunction
def GetAudioAnalysisChannel(slotNo=0):
    return stormtest_client.stc.get_audio_analysis_channel(slotNo)

## @par Description
# Sets parameters for the tone detection algorithm
# The tone detection algorithm detects if a certain frequency, at an expected algorithm, is present within a defined tolerance.
# It also detects if a (configurable) number of successive measurements are the same, within that tolerance.
# The analysis allows for a "guard" tone, used to detect test stream loop points. If this is >0, then results
# containing that frequency are ignored.
#
#  @param[in] toneFrequency @b Double - Expected frequency in Hz of the tone
#  @param[in] toneAmplitude @b Double - Expected amplitude in dBu of the tone
#  @param[in] toneTolerance @b Double - Allowed tolerance in dB from the expected amplitude or average amplitude
#  @param[in] numOfTonesToAverage @b Integer - Number of sets of results to average
#  @param[in] guardFrequency @b Double - Expected frequency in Hz of the guard tone
#  @param[in] guardAmplitude @b Double - Expected amplitude in dBu of the guard tone
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   SetAudioToneParameters(125.0, -6.36, 9.0, 10, 90.0, -26.36)
#   # Sets the analysis tone parameters
#  @endcode
@ApiFunction
def SetAudioToneParameters(toneFrequency=125.0, toneAmplitude=2.0, toneTolerance=10.0, numOfTonesToAverage=10, guardFrequency = 90.0, guardAmplitude = -26.36):
    """
    Set the parameters for the audio tone detection analysis function.

    Return: None.

    toneFrequency: (Float, optional) Expected frequency in Hz of the tone.

    toneAmplitude: (Float, optional) Expected amplitude in dBu of the tone.

    toneTolerance: (Float, optional) Allowed tolerance in dB from the expected amplitude or
      average amplitude.

    numOfTonesToAverage: (Integer, optional) Number of sets of results to average.

    guardFrequency: (Float, optional) Expected frequency in Hz of the guard tone.

    guardAmplitude: (Float, optional) Expected amplitude in dBu of the guard tone.
    """
    return stormtest_client.stc.SetAudioToneParameters(toneFrequency, toneAmplitude, toneTolerance, numOfTonesToAverage, guardFrequency, guardAmplitude)

## @par Description
# Gets the current audio tone parameters
#  @return @e List - List of the tone analysis parameters. Same order as the SetAudioToneParameters routine
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#    >>toneParameters = GetAudioToneParameters()
#    >>print("Tone parameters: " + str(toneParameters))
#
#   # Retrieves the tone analysis parameters and prints them
#  @endcode
@ApiFunction
def GetAudioToneParameters():
    """
    Get the current audio tone detection analysis parameters.

    Return: List. The contents of the List are: [toneFrequency, toneAmplitude, toneTolerance,
      numOfTonesToAverage, guardFrequency, guardAmplitude]
    """
    return stormtest_client.stc.GetAudioToneParameters()

## @par Description
# Sets parameters for the impulse detection algorithm.
# The impulse detection algorithm detects detects impulse above a certain threshold, and will ignore a certain number per second.
# This is used for craxkle/pop detection.
#
#  @param[in] impulseThreshold @b Double - Maximum allowed impulse size in dBu
#  @param[in] maxAllowedPerSecond @b Integer - Maximum number allowed per second
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetAudioImpulseParameters(-40.34, 2)
#   # Sets the analysis tone parameters
#  @endcode
@ApiFunction
def SetAudioImpulseParameters(impulseThreshold=0.1,maxAllowedPerSecond=2):
    """
    Set the parameters for the audio impulse detection analysis.

    Return: None.

    impulseThreshold: (Float, optional) Maximum allowed impulse size in dBu.

    maxAllowedPerSecond: (Integer, optional) Maximum number allowed per second.
    """
    return stormtest_client.stc.SetAudioImpulseParameters(impulseThreshold, maxAllowedPerSecond)

## @par Description
# Gets the current audio impulse parameters
#  @return @e List - List of the tone impulse parameters. Same order as the SetAudioImpulseParameters routine
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#    >>impulseParameters = GetAudioImpulseParameters()
#    >>print("Impulse parameters: " + str(impulseParameters))
#
#   # Retrieves the audio impulse parameters and prints them
#  @endcode
@ApiFunction
def GetAudioImpulseParameters():
    """
    Get the current audio impulse detection parameters.

    Return: List. Contents of List are: [impulseThreshold, maxAllowedPerSecond]
    """
    return stormtest_client.stc.GetAudioImpulseParameters()

## @par Description
#  Set the list of bands from which the sub-band power algorithm will get the power results from.
#  @param[in] bandList @b List of tuples of doubles. Each tuple consists three doulbe values for start frequency in Hz,
#  end frequency in Hzand power threshold in dB. If bandList is empty list, the StormTest defaults will be used.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetSubBandPowerBandList([(100,1000,-12),(1000,7000,-24)])
#   # Sets the analysis tone parameters
#  @endcode
@ApiFunction
def SetSubBandPowerBandList(bandList = []):
    """
    Set the list of bands for the audio sub band power analysis.

    Return: None.

    bandList: (List, optional) List of Tuples. Each tuple is a sub-band and specified as:
      (StartFrequency, EndFrequency, PowerLevel) all as Floats and in Hz/dBu as appropriate.
    """
    return stormtest_client.stc.SetSubBandPowerBandList(bandList)

## @par Description
#  Get the list of bands from which the sub-band power algorithm will get the power results from.
#  @return @e List - List of the tuples.  Each tuple consists three doulbe values for start frequency in Hz,
#  end frequency in Hzand power threshold in dB.
@ApiFunction
def GetSubBandPowerBandList():
    """
    Get the current audio sub band power detection parameters.

    Return: List of Tuples. Each tuple is a sub band definition and is (StartFrequency,
      EndFrequency, PowerLevel)
    """
    return stormtest_client.stc.GetSubBandPowerBandList()

## @par Description
#  Set the band from which the out of band power algorithm will get the power results from.
#  @param[in] bandList @b List - consists list of tuples. Each tuple consits of three double values for start frequency in Hz,
#  end frequency in Hz and power threshold in dBu. If bandList is empty list, the StormTest defaults will be used.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetOutOfBandPowerBandList([(100,1000,-12),(1000,7000,-24)])
#   # Sets the analysis tone parameters
#  @endcode
@ApiFunction
def SetOutOfBandPowerBandList(bandList = []):
    """
    Set the list of bands for the audio out of band power analysis.

    Return: None.

    bandList: (List, optional) List of Tuples. Each tuple is a sub-band and specified as:
      (StartFrequency, EndFrequency, PowerLevel) all as Floats and in Hz/dBu as appropriate.
    """
    return stormtest_client.stc.SetOutOfBandPowerBandList(bandList)

## @par Description
#  Get the band from which the out of band power algorithm will get the power results from.
#  @return @e List - List of  three doulbe values for start frequency in Hz, end frequency in Hz and power threshold in dB.
#
@ApiFunction
def GetOutOfBandPowerBandList():
    """
    Get the current audio out of band power detection parameters.

    Return: List of Tuples. Each tuple is a sub band definition and is (StartFrequency,
      EndFrequency, PowerLevel)
    """
    return stormtest_client.stc.GetOutOfBandPowerBandList()

## @par Description
#  Set the list of bands from which the spurious tone detection algorithm will check for spurious tones.
#  @param[in] bandList @b List of tuples of doubles. Each tuple consists three doulbe values for start frequency in Hz,
#  end frequency in Hz and power threshold in dB. If bandList is empty list, the StormTest defaults will be used.
#  @return @e None
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetSpuriousToneBandList([(100,1000,-12),(1000,7000,-24)])
#   # Sets the analysis tone parameters
#  @endcode
@ApiFunction
def SetSpuriousToneBandList(bandList = []):
    """
    Set the list of bands for the audio spurious tone analysis.

    Return: None.

    bandList: (List, optional) List of Tuples. Each tuple is a sub-band and specified as:
      (StartFrequency, EndFrequency, PowerLevel) all as Floats and in Hz/dBu as appropriate.
    """
    return stormtest_client.stc.SetSpuriousToneBandList(bandList)

## @par Description
#  Get the list of bands from which the spurious tone detection algorithm will check for spurious tones.
#  @return @e List - List of the tuples.  Each tuple consists three doulbe values for start frequency in Hz,
#  end frequency in Hzand power threshold in dB.
#
@ApiFunction
def GetSpuriousToneBandList():
    """
    Get the current audio spurious tone detection parameters.

    Return: List of Tuples. Each tuple is a sub band definition and is (StartFrequency,
      EndFrequency, PowerLevel)
    """
    return stormtest_client.stc.GetSpuriousToneBandList()

## @par Description
#  This function starts running a set of audio analysis algorithms on the given slots and the results can be obtained afterwards for each of the algorithm.
#  @param[in] useValuesFromDatabase @b boolean : (optional) By default, the function reads the database for the
#  audio analysis parameters.  If >1 slot is used in one script this will cause a problem if the values are
#  different in the database as all audio analyses in a script must use the same set of parameters.
#  If using the database, the current setting of the AV switch (if used on the server as this is optional
#  hardware) will be read so that different DUT audio sources can use different parameters.
#  @param[in] continueOnError @b Boolean: (optional) Instruct the call to continue the analysis if database has no values (using default
#  values.) This is new in 2.7 so tests using this parameter cannot run on 2.6 and earlier
#  @param[in] slotNo @b Integer : (optional) By default, function acts on all reserved slots, unless this parameter is used.
#  @return @e boolean: whether the audio analysis has been started successfully.  Raises a StormTest exception
#  if there is no license for audio analysis. If slotNo is 0 then a list of items is returned. Each item is a list of [slotNo, bool]
#  where the bool is true or false as described earlier.
#  @note 2.7 added a parameter. Older scripts will run without modification as the API detects the type of the 2nd parameter
#  an an integer, (if specified) OR it will use the defaults that a 2.6 test used. ie StartAudioAnalysis() will behave the
#  same on 2.7 and 2.6.  BUT StartAudioAnalysis(True,False,0) will not work on 2.6
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  ret = StartAudioAnalysis(slotNo=16)
#  print(str(ret))
#  >>>True
#  WaitSec(10)  # run audio analysis for 10 seconds.
#  ret = StopAudioAnalysis()
#  print(str(ret))
#  >>>[[16,True]]
#  @endcode
@ApiFunction
def StartAudioAnalysis(useValuesFromDatabase = True, continueOnError = True, slotNo=0):
    """
    Start audio analysis.

    Return: Bool. Ture if started on all specified slots.

    useValuesFromDatabase: (Bool, True) Flag to control whether the audio analysis should read the
      parameters from StormTest database or use those previously set by the script.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.StartAudioAnalysis(useValuesFromDatabase, continueOnError, slotNo)

## @par Description
#  This function stops audio analysis that has been started previously.
#  @param[in] slotNo @b Integer : (optional) By default, function acts on all reserved slots, unless this parameter is used.
#  @return @e boolean: whether the audio analysis has been stopped successfully. If slotNo is 0 then a list of items is returned. Each item is a list of [slotNo, bool]
#  where the bool is true or false as described earlier.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>StopAudioAnalysis(16)
#   >>True
#  @endcode
@ApiFunction
def StopAudioAnalysis(slotNo=0):
    """
    Stop the audio analysis.

    Return: Bool.  True if stopped on all specified slots.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.StopAudioAnalysis(slotNo)

## @par Description
#  This function returns the overall results of audio analysis as a simple pass / fail list. The overall is a pass
#  if all the results are pass (excluding the GetResultPowerSpectrum which is just the raw information).  The other
#  returns are true/false on each of the six algoritms tested so a script can provide a simple summary easily.
#  Only useful if running on a pre-conditioned test stream - it is also much faster than getting all the
#  individual results and performing the logical AND of all the values.
#  @param[in] slotNo @b Integer : (optional) By default, function acts on all reserved slots, unless this parameter is used.
#  @return @e List: 7 booleans representing pass/fail on Overall, Tone, Average Tone, Sub Band Power, Out of Band Power,
#  Spurious Tone and Impulse Noise (in that order) - list of lists if used with slot 0
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>GetOverallAudioAnalysisStatus()
#   >>[[1,True, True, True, True, True, True, True],[2,False, True, True, True, True, False, True]
#   >>GetOverallAudioAnalysisStatus(2)
#   >>[False, True, True, True, True, False, True]
#   # Slot 2 failed with a spurious tone somewhere.
#  @endcode
@ApiFunction
def GetOverallAudioAnalysisStatus(slotNo=0):
    """
    Get the overall result of the audio analysis as a simple pass/fail list.

    Return: List of Lists (if slotNo is 0) or a List. The contents of the list are 7 Bools
      representing: overall result, Tone, AverageTone, Sub Band, Out of Band, Spurious Tone,
      Impulse Noise.

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.GetOverallAnalysisStatus(slotNo)

## @par Description
#  This function gets the power spectrum from the last audio analysis run.
#  @param[in] slotNo @b Integer : (optional) By default, function acts on all reserved slots, unless this parameter is used.
#  @return @e List: A list of power spectrum results. Each result is formated as [slot_num, status(True/False), power_spectrum_list]
#  where status indicates whether the power spectrums are obtained successfully and power_spectrum_list is a list of
#  power spectrum result that is a list of double values in dB.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>GetResultPowerSpectrum()
#   >>[[1,True, [ [-91.152053184410732, -80.712950600594866, -90.533206627045416, ...],[power_list_2], ..., [power_list_n] ] ],
#         [2,True, [ [-91.152053184410732, -80.712950600594866, -90.533206627045416, ...],[power_list_2], ..., [power_list_n] ] ]]
#   >>GetResultToneDetection(1)
#   >>[1,True, [ [-91.152053184410732, -80.712950600594866, -90.533206627045416, ...],[power_list_2], ..., [power_list_n] ] ]
#  @endcode
@ApiFunction
def GetResultPowerSpectrum(slotNo = 0):
    """
    Get the power spectrum results for the most recent audio analysis run.

    Return: List of Lists (if slotNo is 0) or a List.  Each List is: [SlotNumber, Status, Spectra]
      The Status is True if power spectra retrieved. The power spectra is a List of Lists - each
      List is a single power specturem and is a List of values in dBu across the frequency range
      0 - 8kHz (number of samples depends on the Audio analysis measurement time)

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.GetResultPowerSpectrum(slotNo)

## @par Description
#  This function gets the expected tone detection results from the last audio analysis run.
#  @param[in] slotNo @b Integer : (optional) By default, function acts on all reserved slots, unless this parameter is used.
#  @return @e List: A list of tone detection results, each of which consists [slot_num, overall_status(True/False), tone_detect_list]
#  where overall_status is True if all of the results in  tone_detect_list are True, otherwise False, and
#  tone_detect_list is [result(True/False), tone_amplitude, expected_tone_amplitude, tolerance]
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>GetResultToneDetection()
#   >>[[1, True, [[True, -7.0548659344779008, -9.0, 3.0], ...],...,  [True, -7.5334839270869569, -9.0, 3.0]],
#         [2,False, [[True, -7.0548659344779008, -9.0, 3.0], ...],...,  [True, -7.5334839270869569, -9.0, 3.0]] ]
#   >>GetResultToneDetection(1)
#   >>[1, True, [[True, -7.0548659344779008, -9.0, 3.0], ...],...,  [True, -7.5334839270869569, -9.0, 3.0]]
#  @endcode
@ApiFunction
def GetResultToneDetection(slotNo = 0):
    """
    Get the detailed tone detection result for the most recent audio analysis run.

    Return: List of Lists (if slotNo is 0) or a List.  Each List is: [SlotNumber, Status, Results]

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.GetResultToneDetection(slotNo)

## @par Description
#  This function gets the average tone amplitude results from the last audio analysis run.
#  @param[in] slotNo @b Integer : (optional) By default, function acts on all reserved slots, unless this parameter is used.
#  @return @e List: A list of average tone amplitude results, each of which consists [slot_num, overall_status(True/False), average_amplitude_list]
#  where overall_status is True if all of the results in  average_amplitude_list are True, otherwise False, and average_amplitude_list is
#  [result(True if max_deviation < tolerance, otherwise False), average_tone_amplitude, tolerance, max_deviation]. If the slotNo is specified
#  then the slot number is not returned and the result is as shown in the example below.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>GetResultAverageToneAmplitude()
#   >>[[1, True, [[True, -5.9446547899255577, 0.90000000000000002, 7.2353169855323793e-005], [True, -5.9446373227612934, 0.90000000000000002, -8.7687996836032585e-005]]]]
#   >>GetResultAverageToneAmplitude(1)
#   >>[True, [[True, -5.9446547899255577, 0.90000000000000002, 7.2353169855323793e-005], [True, -5.9446373227612934, 0.90000000000000002, -8.7687996836032585e-005]]]
#  @endcode
@ApiFunction
def GetResultAverageToneAmplitude(slotNo = 0):
    """
    Get the detailed average tone detection result for the most recent audio analysis run.

    Return: List of Lists (if slotNo is 0) or a List.  Each List is: [SlotNumber, Status, Results]

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.GetResultAverageToneAmplitude(slotNo)

## @par Description
#  This function gets the spurious tone detection results from the last audio analysis run.
#  @param[in] slotNo @b Integer : (optional) By default, function acts on all reserved slots, unless this parameter is used.
#  @return @e List: A list of spurious tone detection results, each of which consists [slot_num, overall_status(True/False), spurious_tone_list]
#  where overall_status is True if all of the results in  spurious_tone_list are True, otherwise False, and spurious_tone_list is
#  [result(True if none of the values in moving_sum_power_list is above the threshold, otherwise False), start_frequency, end_frequency, threshold, detected_spur_tone_list].
#  detected_spur_tone_list is a list of [start_fr, end_fr, threshold, detected_spur_tone_dBu].
#  within the band.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>GetResultSpuriousTone()
#   >>[[8, False, [[True, []], [True, []], [True, []], [True, []], [False, [[163.0, 7000.0, -40.0, -38.800262866466035]]], ... [True, []]]]]
#   >>GetResultSpuriousTone(8)
#   >>[False, [[True, []], [True, []], [True, []], [True, []], [False, [[163.0, 7000.0, -40.0, -38.800262866466035]]], [True, []], ... [True, []]]]
#  @endcode
@ApiFunction
def GetResultSpuriousTone(slotNo = 0):
    """
    Get the detailed spurious tone detection result for the most recent audio analysis run.

    Return: List of Lists (if slotNo is 0) or a List.  Each List is: [SlotNumber, Status, Results]

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.GetResultSpuriousTone(slotNo)

## @par Description
#  This function gets the subband power results from the last audio analysis run.
#  @param[in] slotNo @b Integer : (optional) By default, function acts on all reserved slots, unless this parameter is used.
#  @return @e List: A list of  subband power results, each of which consists [slot_num, overall_status(True/False), subband_power_list]
#  where overall_status is True if all of the results in  subband_power_list are True, otherwise False, and subband_power_list is
#  a list of list [result(True if band_power < threshold, otherwise False), start_frequency, end_frequency, threshold, band_power]
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetSubBandListSubBand([(0, 250, -20), (250,500,-50)]) # look at band of 0-250 Hz with toleranece -20 dB and 250-500 Hz with toleranece -50 dB.
#   >>GetResultSubbandPower()
#   >>[[1,False, [ [False, [[0, 250.0, -20.0, -25.180790459224692], [250.0, 500.0, -50.0, -33.346035032659643]]],
#                        [ [False, [[0, 250.0, -20.0, -25.180790459224692], [250.0, 500.0, -50.0, -33.346035032659643]]], ... ],
#         [2,False, [ [False, [[0, 250.0, -20.0, -25.180790459224692], [250.0, 500.0, -50.0, -33.346035032659643]]],
#                        [ [False, [[0, 250.0, -20.0, -25.180790459224692], [250.0, 500.0, -50.0, -33.346035032659643]]], ... ]]
#   >>GetResultSubbandPower(1)
#   >>[False, [ [False, [[0, 250.0, -20.0, -25.180790459224692], [250.0, 500.0, -50.0, -33.346035032659643]]],
#                        [ [False, [[0, 250.0, -20.0, -25.180790459224692], [250.0, 500.0, -50.0, -33.346035032659643]]], ... ]
#  @endcode
@ApiFunction
def GetResultSubbandPower(slotNo =0):
    """
    Get the detailed sub band detection result for the most recent audio analysis run.

    Return: List of Lists (if slotNo is 0) or a List.  Each List is: [SlotNumber, Status, Results]

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.GetResultSubbandPower(slotNo)

## @par Description
#  This function gets the out of band power results from the last audio analysis run.
#  @param[in] slotNo @b Integer : (optional) By default, function acts on all reserved slots, unless this parameter is used.
#  @return @e List: A list of out of band power results, each of which consists [slot_num, overall_status(True/False), oob_power_list]
#  where overall_status is True if all of the results in  oob_power_list are True, otherwise False, and oob_power_list is
#  a list of list [result(True if band_power < threshold, otherwise False), [[start_frequency, end_frequency, threshold, band_power]]]
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>SetBandListOutOfBand([100, 250, -20])
#   >>GetResultOutOfBandPower()
#   >>[[1,False, [[False, [[100, 250.0, -20.0, -25.180790459224692]]], [False, [[100, 250.0, -20.0, -25.180790459224692]]], ...],
#         [2, False, [[False, [[100, 250.0, -20.0, -25.180790459224692]]],  [False, [[100, 250.0, -20.0, -25.180790459224692]]], ...] ]
#   >>GetResultOutOfBandPower(1)
#   >>[False, [[False, [[100, 250.0, -20.0, -25.180790459224692]]],  [False, [[100, 250.0, -20.0, -25.180790459224692]]], ...]
#  @endcode
@ApiFunction
def GetResultOutOfBandPower(slotNo = 0):
    """
    Get the detailed out of band detection result for the most recent audio analysis run.

    Return: List of Lists (if slotNo is 0) or a List.  Each List is: [SlotNumber, Status, Results]

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.GetResultOutOfBandPower(slotNo)

## @par Description
#  This function gets the impulse noise results from the last audio analysis run.
#  @param[in] slotNo @b Integer : (optional) By default, function acts on all reserved slots, unless this parameter is used.
#  @return @e List: A list of  impulse noise results, each of which consists [slot_num, overall_status(True/False), impulse_noise_list]
#  where overall_status is True if all of the results in  impulse_noise_list are True, otherwise False, and impulse_noise_list is
#  [result(True if no impulse noise detected, otherwise False), num_impulses,  [top_5_impulse, top_5_impulse, top_5_impulse, top_5_impulse, top_5_impulse]]
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>GetResultImpulseNoise()
#   >>[[1,False, [[False, 22.0, [-57.834483053106744, -57.774108360047805, -57.644864977277592, -55.51915255490313, -55.196320383683108]],  ...],
#         [2,False, [[False, 22.0, [-57.834483053106744, -57.774108360047805, -57.644864977277592, -55.51915255490313, -55.196320383683108]], ...] ]
#   >>GetResultImpulseNoise(1)
#   >>[False, [[False, 22.0, [-57.834483053106744, -57.774108360047805, -57.644864977277592, -55.51915255490313, -55.196320383683108]],  ...]
#  @endcode
@ApiFunction
def GetResultImpulseNoise(slotNo = 0):
    """
    Get the detailed impulse detection result for the most recent audio analysis run.

    Return: List of Lists (if slotNo is 0) or a List.  Each List is: [SlotNumber, Status, Results]

    slotNo: (Integer, optional) The slot number to use. 0 means all reserved slots.
    """
    return stormtest_client.stc.GetResultImpulseNoise(slotNo)

## @}

# Deprecated Function
@ApiFunction
def StartTabletControl( slotNo=0 ):
    """
    DEPRECATED
    """
    return stormtest_client.stc.StartTabletControl( slotNo )

# Deprecated Function
@ApiFunction
def StopTabletControl( slotNo=0 ):
    """
    DEPRECATED
    """
    return stormtest_client.stc.StopTabletControl( slotNo )

# Deprecated Function
@ApiFunction
def SendTap( location, numTaps=1, slotNo=0 ):
    """
    DEPRECATED
    """
    return stormtest_client.stc.SendTap( location, numTaps, slotNo )

# Deprecated Function
@ApiFunction
def SendGesture( locations, interval=40, slotNo=0):
    """
    DEPRECATED
    """
    return stormtest_client.stc.SendGesture( locations, interval, slotNo )

# Deprecated Function
@ApiFunction
def MakeIOSTouch( touches, touchType, slotNo=0):
    """
    DEPRECATED
    """
    return stormtest_client.stc.MakeIOSTouch( touches, touchType, slotNo )

# Deprecated Function
@ApiFunction
def CallTabletFunction( name, params=None, slotNo=0 ):
    """
    DEPRECATED
    """
    return stormtest_client.stc.CallTabletFunction( name, params, slotNo )

# Deprecated Function
@ApiFunction
def StartMirror( filename, timeout=30, slotNo=0 ):
    """
    DEPRECATED
    """
    print("start Mirror")
    return stormtest_client.stc.StartMirror( filename, timeout, slotNo )

# Deprecated Class
## @par Deprecated
class TouchType_iOS:
    BEGAN = "TOUCHESBEGAN"
    MOVED = "TOUCHESMOVED"
    ENDED = "TOUCHESENDED"
    STATIONARY = "TOUCHESSTATIONARY"
    CANCELLED = "TOUCHESCANCELLED"

##  @defgroup Group15 Job Configuration API
# These commands control the job creation and configuration.
# This allows a user to submit jobs for remote execution on a StormTest server. This is a powerful feature which leverages
# the fact that each StormTest facility has a central database which holds the configuration of all servers/boxes in the facility
# and also has a central subversion repository that stores test scripts and reference images.\n\n
# A user can use this API to easily upload test scripts to the central repository, and then submit jobs to slots/boxes in the facility to run those
# tests. The tests will be scheduled at the earliest possible time and the user can then check the status of the test run at a later
# time. All logs generated by the test are then available for viewing via an ftp url.\n\n
# Access to this functionality is now provided via the StormTest Developer Suite application. This API is retained for legacy reasons.\n\n
# NOTE: All these functions require the SetMasterConfigurationServer() call to have been made prior to their use.  Failure to do this will result in a Stormtest exception being raised.
##  @{

## @par Description
#  This function gets the object to configure the jobs for remote execution on the StormTest server. See the "Remote Job Dispatcher Guide" for more
#  details on how to use this API.
#  @param None
#  @return @e jobConfig @b Object: Job configurator object.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#    >>SetMasterConfigurationServer("master_server")
#    >>jobCfg = GetJobConfigurator()
#  @endcode
@ApiFunction
def GetJobConfigurator():
    """
    Get the remote job configurator object.  This functionality is more conveniently exposed in
    the Developer Suite GUI.

    Return: Object. The job configurator object.
    """
    return stormtest_client.stc.JobConfig

## @}

##  @defgroup _globalParameters Global Variables
# There are a few global variables defined.  Most are read only and set by the API at start up.
# Some are writable.  Writing to global variables is usually discouraged but occasionally it
# is necessary
#
##  @{

## @par Description
#  When test scripts are written to run under the StormTest client daemon, these variables can be used to indicate if a reference
#  image is to be found in the public part of the repository or in the private part. This allows the user to write a test script that
#  will be uploaded to his private area but which relies on reference images that are in the public area of the subversion repository.\n\n
#  The default location for image files can be set using the SetDirectories() command.
#  @subsubsection _eg1 eg1:
#  @b Example 1:
#  @code
#    >>if STORMTEST_PUBLIC:    # Running under client daemon
#    >>    refImgDir = os.path.join(STORMTEST_PUBLIC,"path","to","refImages")
#    >>else:                   # Running interactively
#    >>    refImgDir = os.path.join("relativePath","onLocalPC","refImages")
#    >>
#    >>SetDirectories("logs", refImgDir) # logDir is ignored when running under client daemon
#    >>
#    >>result = CompareImage("Playback.bmp",None,None,10) # Searches for image in Public area
#  @endcode
#  A user can also override this setting for individual calls
#  to CompareImage() or CompareIcon() by passing in the full path to the image, including the PUBLIC/PRIVATE directory.
#  @subsubsection _eg2 eg2:
#  @b Example 2:
#  @code
#    >>privateImage = os.path.join(STORMTEST_PRIVATE,"path","to","refImages","Playback.bmp")
#    >>
#    >>result = CompareImage("Playback.bmp",None,None,10) # Searches for image in Public area due to the
#    >>                                                   # SetDirectories() call above
#    >>
#    >>result = CompareImage(privateImage,None,None,10) # Searches for image in private area
#  @endcode
STORMTEST_PUBLIC = stormtest_client.public_area

## @par Description
#  See the STORMTEST_PUBLIC description
STORMTEST_PRIVATE = stormtest_client.private_area

## @par Description
# Prior to version 3.0, there was a bug where a script called CaptureImageEx after calling ReserveSlot(..., videoFlag=False)
# in that the returned image would have a different color balance compared to calling CaptureImageEx after calling
# ReserveSlot(..., videoFlag=True).  This has been corrected in version 3.0 and both now return an image with the same
# color balance.  The effect was not noticable with the naked eye but CompareColorEx() could show it.  For any user
# who has a large number of scripts using ReserveSlot(..., videoFlag=False) and CompareColorEx() then it may be
# useful to restore the previous behavior.  Do this by setting _use_legacy_server_colors = True @b before calling
# ConnectToServer().  The setting will be used for the whole script.
_use_legacy_server_colors = False

## @par Description
# Starting from version 3.4.2 the more time efficient capture mechanizm for HD/4K systems was intoduced
# to speed up capturing process. However it does no longer support osd mask and string visibility 
# if such configured system by TriggerOsdMask() or TriggerOsdString() api. For any user who need 
# the osd string or mask still working on HD/4k systems it may be useful to restore the previous behaviour.  
# Do this by setting _use_legacy_capture = True @b before calling
# ConnectToServer().  The setting will be used for the whole script.
_use_legacy_capture = False

## @par Description
# Some 3.0 beta users relied upon the ValidateNavigatorScreen() validating an ignored screen.  This was a bug
# that has been fixed prior to 3.0 release (ignored screens are now fully ignored).  However, to restore the original
# behavior, this flag can be set to True.  It must be changed prior to opening a Navigator.  The flag
# affects @b all navigators opened after changing the flag.
# Changing it while a Navigator is open is undefined behavior - it probably won't do anything but the behavior @b cannot
# be relied upon in any way (including crashing the system).
# It should be changed only when all navigators are closed.  The recommendation is that it is part of the startup
# code of the script.
AllowIgnoredScreens = False

##  @}

##  @defgroup _FunctionParameters Function Parameters
# This section gives more detail on some of the parameters passed to functions in the StormTest API.
# It also explains and gives examples of the returned data from many of the StormTest API functions.
##  @{

##  @defgroup _serialParams Serial Port Setup Parameters
##  @{
# @par Description
#  These are the allowable serial port parameters and are constructed as part of an array.
#  @par These are the returned values:
#  [BAUDRATE, DATABITS, PARITIES, STOPBITS, FLOWCTRL, PREFIX]
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#  [19200,8,"none",1,"none"]
#  @endcode
#  @param BAUDRATE @b Integer
#  @note The following values are valid:
#  @code 50 75 110 134 150 200 300 600 1200 1800 2400 4800 9600 19200 38400 57600 115200 230400 @endcode
#  @param DATABITS @b Integer
#  @note The following values are valid:
#  @code  5 6 7 8 @endcode
#  @param PARITIES @b String
#  @note The following values are valid:
#  @code   "none" "even" "odd" @endcode
#  @param STOPBITS @b Integer
#  @note The following values are valid:
#  @code  1 2 @endcode
#  @param FLOWCTRL @b String
#  @note The following values are valid:
#  @code "none" "soft" "hard" "both" @endcode
#  @param PREFIX @b String: (optional) This value will prefix the log filename if the prefix is used.
##  @}

##  @defgroup _serialCommandRetValue Returned Serial Port Data
## @{
# @par Description
#  This is the data returned for each slot by the SendCommandViaSerial() function.
#  @par These are the returned values:
# [SLOTNUMBER, STATUS, EXPECTTEXT, LOG]
#  @param SLOTNUMBER @b Integer: The slot number the data is returned on.
#  @param STATUS @b Bool: True means the expected text was found on the serial output. False means there was a timeout before a match was found.
#  @param EXPECTTEXT @b Bytes: The expected text.
#  @param LOG @b Bytes: An extract from the serial log. The extract starts from the point that the command was sent to the set-top box, and continues until the line where the expected text was found.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>ret=SendCommandViaSerial(b"4", b"TEST PASSED", 60)
#   >>print(str(ret))
#   >>[(2, False, b'TEST PASSED', b'CMD> 4\n'),
#   >> (2, True, b'TEST PASSED', b'CMD> 4\nSome test output\nMore testoutput\nLine of text\
#                 containing TEST PASSED and some text until a newline character\n')]
#  @endcode
## @}

##  @defgroup _checkSlots Returned CheckSlots data
## @{
# @par Description
#  These are the parameters returned for each slot by the CheckSlots() function.
#  @par These are the returned values:
# [STATUS, USERNAME, DESCRIPTION]
#  @param  STATUS @b Integer: The status for the index.
#  @param  USERNAME @b String: The name of the user who reserved the slot as defined by the system.
#  @param  DESCRIPTION @b String: A user defined string passed in by ConnectToServer.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   # Return value structure (16 entries in the array)
#   [
#       [1, 'Baggio', 'Stress Test']
#           ...
#           ...
#       [0, ' ', ' ']
#   ]
#
#   >>ret=CheckSlots()
#   >>for i in range(16):
#   >>  if ret[i][0] == 1:  print(str(("Slot",i,"is reserved")))
#   >>  else:               print(str(("Slot",i,"is available")))
#  @endcode
#  @note These are the valid returned slot indicator values:
#  - 0: The slot is free.
#  - 1: The slot is reserved.
#  - 2: The slot is available but powered off.
## @}

##  @defgroup _checkDebugRetValue Debug Log Information
## @{
# @par Description
#  These are the parameters returned for each slot by the GetObserveLog() function.
#  @par These are the returned values:
# [SLOTNUMBER, LOGFILESIZE, FILENAME]
#  @param  SLOTNUMBER @b Integer: The slot that created the log.
#  @param  LOGFILESIZE @b Integer: The log file size. If this value is 0, it indicates that the log file is empty.
#  @param  FILENAME @b String: The log file name and path.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#   >>print(str(GetObserveLog()))
#   >>[(11, 0L, 'C:\\test\\Prefix_11_Timestamp_mon.log'),     # 0 bytes in the monitor log
#                                                             # for slot 11
#
#   >> (12, 25L, 'C:\\test\\Prefix_12_Timestamp_mon.log')]    # 25 bytes in the monitor log
#                                                             # for slot 12
#  @endcode
## @}

##  @defgroup _videoFormat Supported Video Formats
## @{
#  @par
# - "CIF"  CIF,         352 x 288 video resolution
# - "QCIF" Quarter CIF, 176 x 144 video resolution
# - "2CIF" 2xCIF,       704 x 288 video resolution
# - "DCIF" Double CIF,  528 x 384 video resolution
# - "4CIF" 4xCIF,       704 x 576 video resolution
# - For HD servers, the return is of the form "w x h" where w is the width in pixels and h is the height in pixels.
# For 4K servers, the return is as for HD but when setting the resolution the following values are supported:
# - "4CIF" (704 x 576)
# - "CIF" (352 x 288)
# - "QCIF" (176 x 144)
# - "704x576" (you can use "4CIF" or "704x576" to achieve this resolution)
# - "352x288" (you can use "CIF" or "352x288" to achieve this resolution)
# = "176x144" (you can use "QCIF" or "176x144" to achieve this resolution)
# - "640x480"
# - "720x480"
# - "720x576"
# - "800x600"
# - "1280x720"
# - "1920x1080"
# - There should be no spaces in the string.
## @}

##  @defgroup _stdImageReturn Multi-dimensional array of results
## @{
#  @par Description
#  This return type is used by a number of different functions in the StormTest API. It is a flexible return type that allow information on multiple slots to be returned to the test.
#  The return type is structured as an array of tuples. Each tuple consists of the slot number, the result of the function (True/False) and a filename.
#  \n\n
#  The filename can represent a number of things including a screen capture filename (for CompareImage()) or a video log filename (for StartVideoLog()). If there is no file name for that instance
#  of the return value, then @e None is returned in place of a filename.
#  \n\n
#  If the user passes a \a slotNo to the called function, then the return value will be one tuple, rather than an array of tuples.
#  \n\n
#  This type of return value is used by:
#  @li CompareImage()
#  @li CompareIcon()
#  @li CaptureScreen()
#  @li StartVideoLog()
#  @li StopVideoLog()
#  @li DetectMotion()
#  @par These are the returned values:
#  [SLOTNUMBER, STATUS, FILENAME]
#  @param SLOTNUMBER @b Integer: The slot that this status relates to.
#  @param STATUS @b Bool: Indicator as to success or failure of the called function. The actual meaning depends on the specific function called.
#  @param FILENAME @b String: The name of a file, including the path to it.
#  @subsubsection _eg1 eg1:
#  @b Example when \a slotNo is @b not passed to function:
#  @code
#   # Return value structure
#   [
#     (1, False, 'filename.bmp'),   # Index 0, result from slot 1 fail
#     (9, True, None)               # Index 1, result from slot 9 success
#   ]
#
#   # Example of accessing the return values:
#   >>ret=DetectMotion(None, 10)
#   >>for slot, result, file in ret
#   >>  if result == False:
#   >>      print("Motion not detected on slot"+str(slot))
#  @endcode
#  @subsubsection _eg1 eg1:
#  @b Example when \a slotNo @b is passed to function:
#  @code
#   # Return value structure
#   [1, False, 'filename.bmp']      # result from slot 1 fail
#
#   # Example of accessing the return value:
#   >>ret=DetectMotion(None, 10, slotNo=1)
#   >>if ret[1] == False:
#   >>  print("Motion not detected on slot"+str(ret[0]))
#  @endcode
## @}

##  @defgroup _stormTestImageObject StormTestImageObject
## @{
#  @par Description
#  This is the returned object type from a number of image comparison and capture functions.
#  The returned type is a object of class StormTestImageObject.  In Release 3.1 and later the
#  object can be constructed from a Pillow (Python Imaging Library) image.
#  The StormTestImageObject has a finalizer, however, you should call Close() as soon as you are
#  finished using the image - HD and 4K images in particular can be large and keeping them in memory longer
#  than necessary will risk an out of memory error from Python.
#  This type of return value is used by:
#  @li CaptureImageEx()
#  @li DetectMotionEx()
#  @li WaitImageMatch()
#  @li WaitImageNoMatch()
#  @li WaitIconMatch()
#  @li WaitIconNoMatch()
#  @li WaitColorMatch()
#  @li WaitColorNoMatch()
#  @par The following functions are available within this class:
#
# @par StormTestImageObject(img)
# The constructor allows you to construct a StormTestImageObject from another object.  This other
# object must be a Pillow image object.
# @param[in] img @b Pillow Image : A Python Imaging Library (Pillow) image object.  The Pillow
# image must be in RGBA format or capable of being converted to RGBA format.  An exception
# will be thrown if the image is not a valid Pillow Image.  The Pillow image is not altered so
# after the constructor there will be 2 images in memory.
# @return @e StormTestImageObject : The completely constructed StormTestImageObject.
# @note You can also create a StormTestImageObject from a file using the static method FromFile.
#
#  @par Save(filename, jpegQuality)
#  This will save a file to the log file @b and also to the log folder output (or a path relative to that folder).  If the output
#  is just a file name then the file will be in the log folder.  If a relative path is given then @b 2 @b copies of the file are produced:
#  one for the log file and one where the script has directed.  Under no circumstances will an existing file be overwritten.  A new
#  name will be made for the image.  This is to preserve the integrity of the log file.
#  @param filename @b String: The filename to save the image as. It will be saved relative to the output
#  directory so this must not be an absolute path
#  @param jpegQuality @b Integer: The jpeg quality for a saved jpeg image, range is 1 - 100.
#  @return @e Bool true/false
#
# @par FromFile(filePath)
# This is a static method to return a StormTestImageObject from a file path.  It will raise an exception
# if the file path cannot be read, does not exist, or the contents are not a valid image file.  The image
# file must be PNG, JPEG, BMP or TIFF format.
# @param filePath @b String: The path to the file to load.  It may be relative or absolute.  If an absolute
# path is not given then the path is assumed to be relative to the imgFolder set by SetDirectories()
# @return @e StormTestImageObject : The created object from the file.
# @note FromFile is available in release 3.3.3.
#
# @par GetLastSavedName()
# This function returns the last saved file name.  As the Save() method does not return the
# filename, you may need this to know just where the file was saved.
# @param None
# @return @e String : the full path of the file that was saved by the most recent Save() call
#
#  @par SaveToFile(filename, jpegQuality)
#  This will save a file to the hard disk.  It will not save the file into the log file nor the log folder.
#  It will @b overwrite any existing file without warning.  The path may be relative to the output folder or an absolute path.
#  @param filename @b String: The filename to save the image to.
#  @param jpegQuality @b Integer: The jpeg quality for a saved jpeg image, the range is 1 - 100
#  @return @e Bool true/false
#
#  @par Crop(rectangle)
#  @param rectangle @b Array: Area for cropping
#  @return see StormTestImageObject
#
#  @par ToPILImage(retainRawImage = False)
#  Converts the image to a Python Imaging Library (Pillow) Image
#  @param retainRawImage @b bool: If true, the raw image will remain in StormTestImageObject.  The default is to close it and free
#  memory on the assumption that the script will want to do further processing using Pillow.
#
# @par IsValid()
# This function checks whether the object constains a valid image.  This is one method that
# can be safely called after Close() - it will return False
# @param None
# @return @e Boolean : True if the StormTestImageObject is a valid image, otherwise False.
#
#  @par Clone()
#  This clones a StormTestImageObject returning an exact copy.
#  @param None
#  @return @e StormTestImageObject: the cloned image.  The original image is unmodified.
#
#  @par Offset(offset)
#  This offsets a StormTestImageObject by the specified amount.  Even if the offset is (0,0)
#  a copy of the image is returned.
#  @param[in] offset @b List: Offset as 2 integers for the x, y direction of the offset.
#  @return @e StormTestImageObject: the offset image.  The original image is unmodified.
#
# @par Transform(converter)
# Transforms an image using a CoordConverter object.  This function is provided when you have
# chosen to capture an image on a slot where a transform is needed.  So that you can examine
# the raw image, CaptureImageEx() will not apply the slot transform.  However, if you now need
# the transformed image, for example to process the image with some custom filtering prior to
# an OCR, you can use the Transform() method to transform the image.
# This is only availble in version 3.2 of StormTest
# @param[in] converter @b CoordConverter : the transformation to apply.  The final size of the
# image will be the WorldSize of this converter.
# @return @e StormTestImageObject : The transformed image.  The original image is not modified
# by the transform.
#
#  @par Close()
#  @param None: Frees image memory earlier than Garbage collector would. Highly advised if using a lot of images.  This must be the
#  last call used on the object (other than IsValid)
#  @subsubsection _eg1 eg1:
# @b Example using contructor:
# @code
#   from PIL import Image
#   pil = Image.open("myfile.png")
#   stormtestImage = Imaging.StormTestImageObject(pil)
# @endcode
# @b Example using FromFile()
# @code
#   stormtestImage = Imaging.StormTestImageObject.FromFile("myfile.png")
# @endcode
#  @b Example Using Save() and GetLastSavedName
#  @code
#    res = CaptureImageEx (None, None)
#    slot,res,image,filename = res[0]
#    image.Save("imgFromMemory.png")
#    print(str(image.GetLastSavedName()))
#    >>>C:\tests\sample_20140721_151525_66\imgFromMemory.png.png
#    image.Save("imgFromMemory.png")
#    print(str(image.GetLastSavedName()))
#    >>>C:\tests\sample_20140721_151525_66\imgFromMemory_2.png.png
#  @endcode
#  @subsubsection _eg1 eg1:
#  @b Example Using SaveToFile()
#  @code
#    res = CaptureImageEx (None, None)
#    slot,res,image,filename = res[0]
#    image.SaveToFile("c:\\myfolder\\imgFromMemory.png")
#  @endcode
#  @subsubsection _eg1 eg1:
#  @b Example Using Crop()
#  @code
#    rect = [100,100,100,100]
#    res = CaptureImageEx (None, None)
#    slot,res,image,filename = res[0]
#    newImage = image.Crop(rect)
#  @endcode
# @b Example using Close and IsValid
# @code
#    result = CaptureImageEx(None, None)
#    slot, status, image, filename = result[0]
#    print(str(image.IsValid()))
#    >>>True
#    image.Close()
#    print(str(image.IsValid()))
#    >>>False
# @endcode
# @b Example using Transform:
# @code
#   # example where we capture at HD but we know the image has been upscaled so we
#   # wish to downscale it back to SD and supply asymetric scaling and offset.
#   converter = CoordConverter()
#   converter.SetFromRectangles([0,0,1920,1080], [5,5,680,568])
#   converter.WorldSize = (704, 576)
#   res = CaptureImageEx (None, None)
#   slot,res,image,filename = res[0]
#   im2 = image.Transform(converter)
# @endcode
#  @b Example using Clone and Offset:
#  @code
#    res = CaptureImageEx (None, None)
#    slot,res,image,filename = res[0]
#    newImage = image.Offset((4,-2))
#    print(str((image.IsValid(), newImage.IsValid())))
#    >>>True, True
#    image.Close()
#    print(str((image.IsValid(), newImage.IsValid())))
#    >>>False, True
#  @endcode

## @}

##  @defgroup _regionObject NamedRegion
## @{
#  @par Description
#  This is the returned object from the FindNamedRegion function.  It is a shallow wrapper object that can be
#  used in many calls instead of a rectangle.  The constructor is not documented as this class is not intended
#  that user scripts should create instances of NamedRegion.
#  @par The following functions/properties are available within this class:
#  @par Name
#  This is the name of the object.  It is always just the name even for absolute objects.
#  @par IsAbsolute
#  This is bool, true if the object is an absolute object, created from an absolute path
#  @par LookupBySlot(slotNo, forceDutSpecific=False)
#  This will find the region as a tuple of the named region for the specified slot.  This
#  method follows the following steps:
# This will find the rectangle value for the specified slot from a NamedRegion.
# This method follows the following steps - the first look up that succeeds terminates the process.
#  -# Find DUT model for specified slot.
#  -# If NamedRegion is absolute find DUT specific model region in the explicit path.
#  -# If NamedRegion is absolute find the generic region in the explicit path.
#  -# If NamedRegion is relative, search the paths for the slotNo looking for DUT specific region.
#  -# If NamedRegion is relative, search the paths for the slotNo looking for generic region.
#  -# If NamedRegion is relative, search the 'all slots' paths looking for the DUT specific region.
#  -# If NamedRegion is relative, search the 'all slots' paths looking for the generic region.
#  If the region is not found, a StormTestExceptions exception is raised.
#  For some API calls, slotNo will be set to None.  In that case steps 1, 2, 4, 5, 6 above are skipped.
#  The LookupBySlot is cached - later calls with the same slot number will always return the same value and will
#  not incur network overhead in contacting the database.
#  @param[in] slotNo @b Integer : The slot number for which the lookup occurs.  0 is not permitted but None is.  A slotNo
#  of None will only look for an absolute region or one in the 'all slots' paths and DUT specific lookup is ignored.
#  @param[in] forceDutSpecific @b Boolean : Optional.  When true, forces a DUT specific lookup so that the generic version is never
#  returned.  Steps 3, 5 and 7 are omitted.  This parameter was introduced in version 3.2 of StormTest
#  @return @e Tuple : The 4 values of the rectangle as a tuple
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#    r = FindNamedRegion("/my projects/title")
#    print(str(r.LookupBySlot(4)))
#    >>>(0,0,100,67)
#    print(str(r.LookupBySlot(6)))
#    >>>(100,10,80,20)
#  @endcode
#
#  @par LookupByDut(dutModelId)
# This will find the rectangle value for the specified model from a NamedRegion.
# This method follows the following steps - the first look up that succeeds terminates the process.
#  -# If NamedRegion is absolute find DUT specific model region in the explicit path.
#  -# If NamedRegion is relative, search the 'all slots' paths looking for the DUT specific region.
#  If the region is not found, a StormTestExceptions exception is raised.
#  @param[in] dutModelId @b Integer or String : The DUT model, either as an integer id from determined by ListDutModels()
#  or as a string.
#  @return @e Tuple : The 4 values of the rectangle as a tuple
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#    r = FindNamedRegion("/my projects/title")
#    print(str(r.LookupByDut("My DUT")))
#    >>>(0,0,100,67)
#  @endcode
#
#  @par Refresh()
#  This will clear the cache for the object (for any and all slots that have been used)
#  @param None
#  @return @e None


## @}

##  @defgroup _colorObject NamedColor
## @{
#  @par Description
#  This is the returned object from the FindNamedColor function.  It is a shallow wrapper object that can be
#  used in many calls instead of a color.  When this happens, the tolerance, flatness and peak error parameters
#  of the associated call are retrieved from the NamedColor and any values passed in to the function concerned
#  are ignored.  Most functions do not require the tolerance, flatness or peak error in the sense that they are
#  marked as optional parameters.  The constructor is not documented as this class is not intended
#  that user scripts should create instances of NamedColor.
#  @par The following functions/properties are available within this class:
#  @par Name
#  This is the name of the object.  It is always just the name even for absolute objects.
#  @par IsAbsolute
#  This is bool, true if the object is an absolute object, created from an absolute path
#
#  @par LookupBySlot(slotNo, forceDutSpecific=False)
# This will find the color value for the specified slot from a NamedColor.
# This method follows the following steps - the first look up that succeeds terminates the process.
#  -# Find DUT model for specified slot.
#  -# If NamedColor is absolute find DUT specific model color in the explicit path.
#  -# If NamedColor is absolute find the generic color in the explicit path.
#  -# If NamedColor is relative, search the paths for the slotNo looking for DUT specific color.
#  -# If NamedColor is relative, search the paths for the slotNo looking for generic color.
#  -# If NamedColor is relative, search the 'all slots' paths looking for the DUT specific color.
#  -# If NamedColor is relative, search the 'all slots' paths looking for the generic color.
#  If the color is not found, a StormTestExceptions exception is raised.
#  For some API calls, slotNo will be set to None.  In that case steps 1, 2, 4, 5, 6 above are skipped.
#  The LookupBySlot is cached - later calls with the same slot number will always return the same value and will
#  not incur network overhead in contacting the database.
#  @param[in] slotNo @b Integer : The slot number for which the lookup occurs.  0 is not permitted but None is.  A slotNo
#  of None will only look for an absolute color or one in the 'all slots' paths and DUT specific lookup is ignored.
#  @param[in] forceDutSpecific @b Boolean : Optional.  When true, forces a DUT specific lookup so that the generic version is never
#  returned.  Steps 3, 5 and 7 are omitted.
#  @return @e Tuple : The value of the color as a tuple of (color tuple, tolerance tuple, flatness, peak error)
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#    r = FindNamedColor("/my projects/highlite color")
#    print(str(r.LookupBySlot(4)))
#    >>>((255,0,0), (8,8,8), 97.5, 1.0)
#    print(str(r.LookupBySlot(6)))
#    >>>((0,255,0), (20,20,20), 90, 2.0)
#  @endcode
#
#  @par LookupByDut(dutModelId)
# This will find the color value for the specified model from a NamedColor.
# This method follows the following steps - the first look up that succeeds terminates the process.
#  -# If NamedColor is absolute find DUT specific model color in the explicit path.
#  -# If NamedColor is relative, search the 'all slots' paths looking for the DUT specific color.
#  If the color is not found, a StormTestExceptions exception is raised.
#  @param[in] dutModelId @b Integer or String : The DUT model, either as an integer id from determined by ListDutModels()
#  or as a string.
#  @return @e Tuple : The value of the color as a tuple of (color tuple, tolerance tuple, flatness, peak error)
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#    r = FindNamedColor("/my projects/highlite color")
#    print(str(r.LookupByDut("My DUT")))
#    >>>((255,0,0), (8,8,8), 97.5, 1.0)
#  @endcode
#
#  @par Refresh()
#  This will clear the cache for the object (for any and all slots that have been used)
#  @param None
#  @return @e None

## @}

##  @defgroup _stringObject NamedString
## @{
#  @par Description
#  This is the returned object from the FindNamedString function.  It is a shallow wrapper object that can be
#  used in many calls instead of a string.  The constructor is not documented as this class is not intended
#  that user scripts should create instances of NamedString.
#  @par The following functions/properties are available within this class:
#  @par Name
#  This is the name of the object.  It is always just the name even for absolute objects.
#  @par IsAbsolute
#  This is bool, true if the object is an absolute object, created from an absolute path
#
#  @par LookupBySlot(slotNo, forceDutSpecific=False)
# This will find the string value for the specified slot from a NamedString.
# This method follows the following steps - the first look up that succeeds terminates the process.
#  -# Find DUT model for specified slot.
#  -# If NamedString is absolute find DUT specific model string in the explicit path.
#  -# If NamedString is absolute find the generic string in the explicit path.
#  -# If NamedString is relative, search the paths for the slotNo looking for DUT specific string.
#  -# If NamedString is relative, search the paths for the slotNo looking for generic string.
#  -# If NamedString is relative, search the 'all slots' paths looking for the DUT specific string.
#  -# If NamedString is relative, search the 'all slots' paths looking for the generic string.
#  If the string is not found, a StormTestExceptions exception is raised.
#  For some API calls, slotNo will be set to None.  In that case steps 1, 2, 4, 5, 6 above are skipped.
#  The LookupBySlot is cached - later calls with the same slot number will always return the same value and will
#  not incur network overhead in contacting the database.
#  @param[in] slotNo @b Integer : The slot number for which the lookup occurs.  0 is not permitted but None is.  A slotNo
#  of None will only look for an absolute string or one in the 'all slots' paths and DUT specific lookup is ignored.
#  @param[in] forceDutSpecific @b Boolean : Optional.  When true, forces a DUT specific lookup so that the generic version is never
#  returned.  Steps 3, 5 and 7 are omitted.
#  @return @e String : The value of the string
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#    r = FindNamedString("/my projects/title")
#    print(str(r.LookupBySlot(4)))
#    >>>'My super DUT'
#    print(str(r.LookupBySlot(6)))
#    >>>'Also a super DUT'
#  @endcode
#
# @par LookupByDut(dutModelId)
# This will find the string value for the specified model from a NamedString.
# This method follows the following steps - the first look up that succeeds terminates the process.
#  -# If NamedString is absolute find DUT specific model string in the explicit path.
#  -# If NamedString is relative, search the 'all slots' paths looking for the DUT specific string.
#  If the string is not found, a StormTestExceptions exception is raised.
#  @param[in] dutModelId @b Integer or String : The DUT model, either as an integer id from determined by ListDutModels()
#  or as a string.
#  @return @e String : The value of the string
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#    r = FindNamedString("/my projects/title")
#    print(str(r.LookupByDut("My DUT")))
#    >>>'My good DUT'
#  @endcode
#
#  @par Refresh()
#  This will clear the cache for the object (for any and all slots that have been used)
#  @param None
#  @return @e None

## @}

##  @defgroup _imageObject NamedImage
## @{
#  @par Description
#  This is the returned object from the FindNamedImage function.  It is a shallow wrapper object that can be
#  used in many calls instead of a StormTestImageObject.  The constructor is not documented as this class is not intended
#  that user scripts should create instances of NamedImage.
#  @par The following functions/properties are available within this class:
#  @par Name
#  This is the name of the object.  It is always just the name even for absolute objects.
#  @par IsAbsolute
#  This is bool, true if the object is an absolute object, created from an absolute path
#
#  @par LookupBySlot(slotNo, forceDutSpecific=False)
# This will find the image value for the specified slot from a NamedImage.
# This method follows the following steps - the first look up that succeeds terminates the process.
#  -# Find DUT model for specified slot.
#  -# If NamedImage is absolute find DUT specific model image in the explicit path.
#  -# If NamedImage is absolute find the generic image in the explicit path.
#  -# If NamedImage is relative, search the paths for the slotNo looking for DUT specific image.
#  -# If NamedImage is relative, search the paths for the slotNo looking for generic image.
#  -# If NamedImage is relative, search the 'all slots' paths looking for the DUT specific image.
#  -# If NamedImage is relative, search the 'all slots' paths looking for the generic image.
#  If the image is not found, a StormTestExceptions exception is raised.
#  For some API calls, slotNo will be set to None.  In that case steps 1, 2, 4, 5, 6 above are skipped.
#  The LookupBySlot is cached - later calls with the same slot number will always return the same value and will
#  not incur network overhead in contacting the database.
#  @param[in] slotNo @b Integer : The slot number for which the lookup occurs.  0 is not permitted but None is.  A slotNo
#  of None will only look for an absolute image or one in the 'all slots' paths and DUT specific lookup is ignored.
#  @param[in] forceDutSpecific @b Boolean : Optional.  When true, forces a DUT specific lookup so that the generic version is never
#  returned.  Steps 3, 5 and 7 are omitted.
#  @return @e Tuple : The StormTestImageObject, width and height of the image.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#    r = FindNamedImage("/my projects/logo")
#    print(str(r.LookupBySlot(4)))
#    >>>(<ClientAPI.Imaging.StormTestImageObject object>, 48, 24)
#    print(str(r.LookupBySlot(6)))
#    >>>(<ClientAPI.Imaging.StormTestImageObject object>, 64, 32)
#  @endcode
#
# @par LookupByDut(dutModelId)
# This will find the image value for the specified model from a NamedImage.
# This method follows the following steps - the first look up that succeeds terminates the process.
#  -# If NamedImage is absolute find DUT specific model image in the explicit path.
#  -# If NamedImage is relative, search the 'all slots' paths looking for the DUT specific image.
#  If the image is not found, a StormTestExceptions exception is raised.
#  @param[in] dutModelId @b Integer or String : The DUT model, either as an integer id from determined by ListDutModels()
#  or as a string.
#  @return @e Tuple : The StormTestImageObject, width and height of the image.
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#    r = FindNamedImage("/my projects/logo")
#    print(str(r.LookupByDut("My DUT")))
#    >>>(<ClientAPI.Imaging.StormTestImageObject object>, 48, 24)
#  @endcode
#    
#  @par Refresh()
#  This will clear the cache for the object (for any and all slots that have been used)
#  @param None
#  @return @e None

## @}

##  @defgroup _namedSdo NamedScreenDefinition
## @{
#  @par Description
#  This is the returned object from the FindNamedScreenDefinition function.  It is a shallow wrapper object.
#  The constructor is not documented as this class is not intended that user scripts should create instances of NamedScreenDefinition.
#  @par The following functions/properties are available within this class:
#  @par Name
#  This is the name of the object.  It is always just the name even for absolute objects.
#  @par IsAbsolute
#  This is bool, true if the object is an absolute object, created from an absolute path
#
#  @par LookupBySlot(slotNo, forceDutSpecific=False)
# This will find the screen definition value for the specified slot from a NamedScreenDefinition.
# This method follows the following steps - the first look up that succeeds terminates the process.
#  -# Find DUT model for specified slot.
#  -# If NamedScreenDefinition is absolute find DUT specific model ScreenDefinition in the explicit path.
#  -# If NamedScreenDefinition is absolute find the generic ScreenDefinition in the explicit path.
#  -# If NamedScreenDefinition is relative, search the paths for the slotNo looking for DUT specific ScreenDefinition.
#  -# If NamedScreenDefinition is relative, search the paths for the slotNo looking for generic ScreenDefinition.
#  -# If NamedScreenDefinition is relative, search the 'all slots' paths looking for the DUT specific ScreenDefinition.
#  -# If NamedScreenDefinition is relative, search the 'all slots' paths looking for the generic ScreenDefinition.
#  If the ScreenDefinition is not found, a StormTestExceptions exception is raised.
#  For some API calls, slotNo will be set to None.  In that case steps 1, 2, 4, 5, 6 above are skipped.
#  The LookupBySlot is cached - later calls with the same slot number will always return the same value and will
#  not incur network overhead in contacting the database.
#  @param[in] slotNo @b Integer : The slot number for which the lookup occurs.  0 is not permitted but None is.  A slotNo
#  of None will only look for an absolute color or one in the 'all slots' paths and DUT specific lookup is ignored.
#  @param[in] forceDutSpecific @b Boolean : Optional.  When true, forces a DUT specific lookup so that the generic version is never
#  returned.  Steps 3, 5 and 7 are omitted.
#  @return @e ScreenDefinition : The value of the ScreenDefinition
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#    r = FindNamedScreenDefinition("/my projects/sdo1")
#    print(str(r.LookupBySlot(4)))
#    >>><stormtest.ClientAPI.ScreenDefinition object>
#  @endcode
#
# @par LookupByDut(dutModelId)
# This will find the screen definition value for the specified model from a NamedScreenDefinition.
# This method follows the following steps - the first look up that succeeds terminates the process.
#  -# If NamedScreenDefinition is absolute find DUT specific model ScreenDefinition in the explicit path.
#  -# If NamedScreenDefinition is relative, search the 'all slots' paths looking for the DUT specific ScreenDefinition.
#  If the ScreenDefinition is not found, a StormTestExceptions exception is raised.
#  @param[in] dutModelId @b Integer or String : The DUT model, either as an integer id from determined by ListDutModels()
#  or as a string.
#  @return @e ScreenDefinition : The value of the ScreenDefinition
#  @subsubsection _eg1 eg1:
#  @b Example:
#  @code
#    r = FindNamedScreenDefinition("/my projects/sdo1")
#    print(str(r.LookupByDut("My DUT")))
#    >>><stormtest.ClientAPI.ScreenDefinition object>
#  @endcode
#
#  @par Refresh()
#  This will clear the cache for the object (for any and all slots that have been used)
#  @param None
#  @return @e None
    
## @}


##  @defgroup _supportedLangs Languages supported by the OCR engine
## @{
#  @par Description
#  The StormTest OCR engine is shipped with OCR dictionaries for the following languages. The user may improve the accuracy of the OCR engine by setting the OCR language to be one or more of the following languages.
#  \n\n
#  @htmlonly
#  <TABLE ALIGN="center" BORDER=1 CELLSPACING=0 CELLPADDING=5>
#  <TR ALIGN="left" VALIGN="middle">
#    <TH>Language</TH>
#    <TH>ISO 639-3 Code</TH>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>Afrikaans</TD>
#      <TD>afr</TD>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>Chinese (Mandarin)<SUP>1</SUP></TD>
#      <TD>cmn</TD>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>Czech</TD>
#      <TD>ces</TD>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>Danish</TD>
#      <TD>dan</TD>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>Dutch</TD>
#      <TD>nld</TD>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>English</TD>
#      <TD>eng</TD>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>Finnish</TD>
#      <TD>fin</TD>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>Flemmish</TD>
#      <TD>vls</TD>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>French</TD>
#      <TD>fra</TD>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>German</TD>
#      <TD>deu</TD>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>Greek</TD>
#      <TD>ell</TD>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>Hebrew<SUP>1</SUP></TD>
#      <TD>heb</TD>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>Irish</TD>
#      <TD>gle</TD>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>Italian</TD>
#      <TD>ita</TD>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>Japanese<SUP>1</SUP></TD>
#      <TD>jpn</TD>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>Korean<SUP>1</SUP></TD>
#      <TD>kor</TD>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>Norwegian (Bokmål)</TD>
#      <TD>nob</TD>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>Polish</TD>
#      <TD>pol</TD>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>Portuguese</TD>
#      <TD>por</TD>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>Russian</TD>
#      <TD>rus</TD>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>Spanish</TD>
#      <TD>spa</TD>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>Swedish</TD>
#      <TD>swe</TD>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>Thai<SUP>1</SUP></TD>
#      <TD>tha</TD>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>Turkish</TD>
#      <TD>tur</TD>
#  </TR>
#  <TR ALIGN="left" VALIGN="middle">
#      <TD>Vietnamese<SUP>1</SUP></TD>
#      <TD>vie</TD>
#  </TR>
#  </TABLE>
#  @endhtmlonly
#  @latexonly
#  \begin{center}
#  \begin{tabular}{ | l | r | }
#  \hline
#  Language & ISO 639-3 Code \\ \hline\hline
#  Afrikaans & afr \\
#  Chinese (Mandarin)(See Note 1) & cmn \\
#  Czech & ces \\
#  Danish & dan \\
#  Dutch & nld \\
#  English & eng \\
#  Finnish & fin \\
#  Flemmish & vls \\
#  French & fra \\
#  German & deu \\
#  Greek & ell \\
#  Hebrew(See Note 1) & heb \\
#  Irish & gle \\
#  Italian & ita \\
#  Japanese(See Note 1) & jpn \\
#  Korean(See Note 1) & kor \\
#  Norwegian (Bokmål) & nob \\
#  Polish & pol \\
#  Portuguese & por \\
#  Russian & rus \\
#  Spanish & spa \\
#  Swedish & swe \\
#  Thai(See Note 1) & tha \\
#  Turkish & tur \\
#  Vietnamese(See Note 1) & vie \\
#  \hline
#  \end{tabular}
#  \end{center}
#  @endlatexonly
#  \n The user may specify more than one language dictionary to be used by the OCR engine.
#  @note
#  -# An extra license will be required for these languages - contact StormTest support for details.
#  @subsubsection _eg1 eg1:
#  @b Example: Setting default dictionaries for the StormTest OCR engine
#  @code
#   # Tell the OCR engine to use the German dictionary.
#   >>result = OCRSetLanguage('deu')
#   >>print(str(result))
#   >>True
#
#   # Tell the OCR engine to use the Spanish, Portugese and French dictionaries.
#   >>result = OCRSetLanguage(('spa','por','fra'))
#   >>print(str(result))
#   >>True
#
#   # Tell the OCR engine to use an invalid dictionary - this will raise an exception
#   >>result = OCRSetLanguage('abc')
#    Exception in user code:
#    StormTestExceptions: Invalid language: [abc]
#  @endcode
## @}

## @}

## @defgroup _coordtransform Coordinate Transformations with Screen definition Objects
## @{
#  @par Description
#  When using screen definition objects, there is potential compexity in determining what the final
#  coordinates used will be.  It is affected by the DesignSize property of the object, the DesignSize property
#  of the screen definition, any CoordConverters attached to the screen definition object and the CoordConverter set
#  as the slot transformation in SetDesignToWorldTransform.
#
#  This note explains how the system calculates the coordinates.  The aim is to "do the right thing" and act sensibly.
#  Here, SDO means Screen Definition Object and converter refers to an instance of CoordConverter.  design size is taken to 
#  mean the DesignSize property.
#
#  When an SDO is executed, it has multiple regions which are really the things that are executed not the SDO which is a container.  
#  As an example, we'll discuse how a ColorRegion is executed.  There is a rectangle in the ColorRegion object - this is a set of numbers and we already have an image captured.
#  The first step is to find the design size of those coordinates.  It does this by looking in the Design Size property of the color test.  If this is null, 
#  it looks in the design size of the parent SDO, if that is null, the search continues up the chain.  The search stops on the first non null Design Size value.
#  If we reach the end of the chain without finding a design size, the next step is to look at the slot transform that has been set.  
#  If that has a design size then we use that as the design size of the color region test.  If no transform has been set (or a transform without a design size), 
#  we use the size of the image as the design size.
#
#  At this stage, we have a non zero design size for the coordinates.  This is guaranteed. We call this the "Test Design Size" internally.
#  If the slot transform has been set with a design size that is not equal to the Test Design Size then we convert the color region coordinates to the slot transform design size.  
#  To do this we search the coord converter list of the color region's parent SDO for a converter where that converters design size and world size match the Test Design Size and
#  the slot transform's design size respectively.  If no such converter exists, we walk up the parent list until we find one that matches.  Finally, if none match, we make one 
#  that is a simple linear conversion.  We use this to convert the coordinate of the color region into coordinates in the slot transform size.  This produces a rectangle in the 
#  "Final Design Size"  If the slot transform has not been set or has a zero design size, we skip this step and final design size is the same as test design size and the rectangle is unchanged.
#
#  We now have the rectangle in the final design size that we need.  If the slot transform has a non zero design size, we simply use the slot transform.  If the rotation is zero, 
#  we convert the coordinates and then examine the appropriate area of the captured image.  If the rotation is non zero, we modify the image not the coordinates and then use the 
#  design size coordinates in the converted image.
#
#  If the slot transform has an empty design size then we search the color region's parent coordinate converter list for a converter where the design size and world size match 
#  the final design size and captured image size respectively.  As before we search up the chain.  There is one little quirk here: if no matching coordinate converter is found
#  AND the final design size == captured image size then we do nothing, else we make a linear converter.  This allows a user to specify a custom transform for 1920x1080 -> 1920x1080
#  where the design size and captured image size are both 1920x1080.
#
#  If we have a converter, we proceed in the same manner as if a slot transform is set: we check for rotation and either convert the coordinates or the image.  One point to note is 
#  that we ignore rotation for detect motion - this is because the whole transform is intended for use with TV tester and rotation angles are < 1 degree and at that stage the error 
#  on a detect motion rectangle is minimal.

## @}

