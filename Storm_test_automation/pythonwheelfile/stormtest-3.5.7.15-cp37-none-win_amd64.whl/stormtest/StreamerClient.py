#############################################################################
# Copyright (c) 2009-2019 Accenture.
# All rights reserved.
# 
# This source code and any compilation or derivative thereof is the
# proprietary information of Accenture and is confidential in nature.
# 
# Use of this source code is subject to the terms of the applicable
# Accenture license agreement.
# 
# Under no circumstances is this component (or portion thereof) to be in any
# way affected or brought under the terms of any Open Source License without
# the prior express written permission of Accenture.
# 
# For the purpose of this clause, the term Open Source License includes:
#     (i) any license that requires as a condition of use, modification
#         and/or distribution of a software/component, that such software/
#         component:
#             a. be disclosed or distributed in source code form;
#             b. be licensed for the purpose of making derivative works; and/or
#             c. can be redistributed only free of enforceable intellectual property
#                 rights (e.g. patents); and/or
#     (ii) any license applicable to a software/component that contains, is derived in any  
#          manner (in whole or in part) from, or statically or dynamically links against any
#          software/component specified under (i).
# 
# -----------------------------------------------------
# http://www.accenture.com
# -----------------------------------------------------
#
#  MODULE: streamerclient.py
#
#  DESCRIPTION: This module provides a high level access to the
#  streamserver for Dektec stream player control.
#
###############################################################################

import xmlrpc.client
import os
if os.name == 'nt':
    import win32api

class StormTestStreamer:
    ServerVersion = None
    ServerStartTime = 0
    StreamerAPIVersion = None
    DektecDriver = None
    IsDriverCompatible = None

    def __init__ (self, svrUrl):
        self.__serverUrl = svrUrl
        if os.name == 'nt':
            self.__currentUser = win32api.GetUserName()
        elif os.name == 'posix':
            try:
                self.__currentUser = os.getlogin()
            except:
                self.__currentUser = os.environ.get("LOGNAME")
        else:
            raise Exception("unsupported operating System")

        # try connecting to the server (may fail) and update status
        self.__server = xmlrpc.client.ServerProxy("http://" + svrUrl)
        self.reconnect()

    def reconnect(self):
        """ reconnect to the user and get the version information """
        try:
            self.ServerVersion = self.__server.GetVersion()
            self.ServerStartTime = self.__server.GetStartTime()
            rawres = self.__server.GetStreamerVersions()
            if self.__isSuccess(rawres):
                versions = rawres[2]
                self.StreamerAPIVersion = versions[0]
                self.DektecDriver = versions[1]
                self.IsDriverCompatible = versions[2] == "Ok"
            else:
                self.StreamerAPIVersion = "unknown"
                self.DektecDriver = "unknown"
                self.IsDriverCompatible = False

        except:
            # failed
            self.ServerVersion = "Not Connected"
            self.ServerStartTime = ""
            self.StreamerAPIVersion = "unknown"
            self.DektecDriver = "unknown"
            self.IsDriverCompatible = False

    def getCardCount(self):
        """ Return number of PCI cards in server """
        try:
            rawres = self.__server.GetPciCardInfo(-1)
            if self.__isSuccess(rawres):
                return len(rawres[2])
            else:
                return 0
        except:
            return 0


    def getPortList(self):
        """ Return a list of ports in server that can be used for streaming files
        to a modulated output.  Each element in the list is an array of information
        about the port. The information is:
        port id (needed for all control functions)
        Description (card name and slot)
        Serial Number of Card
        Capabilities of Port
        """

        outports = []
        try:
            # get the card information (for the serial number)
            # and all the port information.
            rawres = self.__server.GetPciCardInfo(-1)
            if not self.__isSuccess(rawres):
                # on error, return empty list
                return outports

            cardList = rawres[2]

            rawres = self.__server.GetPciPortInfo(-1)
            if not self.__isSuccess(rawres):
                # this should never happen but ...
                return outports

            portList = rawres[2]

            for i in range (len(portList)):
                port = portList[i]
                if port[0] in ["MOD", "DVB-S", "QAM"] and port[4] == "Output":
                    # This is of type 'modulated' and direction 'Output' so we
                    # want to return this item in the list
                    #
                    # Note that we have observed the following values for port[0] (the 'Interface' type)
                    # from the various Dektec stream player card types.
                    #   "MOD"   : DTA-107S2, DTA-115
                    #   "DVB-S" : DTA-107
                    #   "QAM"   : DTA-110
                    #
                    returnData = []
                    returnData.append(i)                    # the port identifier for later use.
                    returnData.append(port[2])              # the description (human readable)
                    returnData.append(cardList[port[1]][1]) # the card serial number
                    returnData.append(port[6])              # the port capabilities (human readable)
                    outports.append(returnData)

        except:
            pass
        return outports

    def prepareToPlay(self, port, file, frequency="", symbolrate=0, bitrate=0, modulation=None, modulationParams=None, parseFile=True):
        """ Prepare to play the file. By default, the parameters are taken from the file
        but if they have a non default parameter, then that is used instead. If all
        parameters are being specified, then setting parseFile to False will speed up
        the process (as it takes time to parse the file and if all parameters are set, that is a waste of time)

        Return is a tuple: (Error Number, Error String) with the Error being 0 for success.
        """

        if parseFile:
            try:
                rawres = self.__server.GetModulationParameters(self.__currentUser, file)
                if not self.__isSuccess(rawres):
                    # failed to parse file, tell user.
                    return (rawres[0], rawres[1])
                # update the default parameters only, from the parsed file
                fileParams = rawres[2]
                if frequency == "":
                    frequency = fileParams[1]
                if symbolrate == 0:
                    symbolrate = fileParams[2]
                if bitrate == 0:
                    bitrate = fileParams[3]
                if modulation == None:
                    modulation = fileParams[0]
                if modulationParams == None:
                    modulationParams = fileParams[4]
            except:
                return (1000, "Failed to contact streamer server")

        # now ready to prepare the file.
        try:
            # reserve the port for our use - fail if another user has it.
            rawres = self.__server.ReservePort(self.__currentUser, port, False)
            if not self.__isSuccess(rawres):
                return (rawres[0], rawres[1] + " " + rawres[2])
            rawres = self.__server.SetPlayParameters(self.__currentUser, port, file, frequency, modulation, modulationParams, symbolrate, bitrate)
            if not self.__isSuccess(rawres):
                return (rawres[0], rawres[1] + " " + rawres[2])
            return (0, "Ok")
        except:
            return (1000, "Failed to contact streamer server")

    def play(self, port, loopcount=0):
        """
        Start playing on a port - must have been prepared prior to this. loopcount is # loops to play,
        with 0 meaning play forever.
        """
        try:
            rawres = self.__server.Play(self.__currentUser, port, loopcount, "StormTest StreamerClient.py High Level API")
            return (rawres[0], rawres[1])
        except:
            return (1000, "Failed to contact streamer server")

    def stop(self, port):
        """
        Stop a port playing.
        """
        try:
            rawres = self.__server.Stop(self.__currentUser, port)
            # ignore failure on stop and release reservation (but not forcibly as it should be reserved to us)
            self.__server.ReleasePort(self.__currentUser, port, False)
            # return the Stop status code
            return (rawres[0], rawres[1])
        except:
            return (1000, "Failed to contact streamer server")

    def playFile(self, port, file, loopcount=0,frequency="", symbolrate=0, bitrate=0, modulation=None, modulationParams=None, parseFile=True):
        """
        Does a prepare and play in one function call. The prepare can take several seconds so this method is not
        so precise in controlling the start time of the playback

        Parameters are similar to the compbination of play and prepare.
        """
        (status, msg) = self.prepareToPlay(port, file, frequency, symbolrate, bitrate, modulation, modulationParams, parseFile)
        if status == 0:
            (status, msg) = self.play(port, loopcount)
        return (status, msg)

    def getStatus(self, port):
        """
        Return status of the port. A list is returned. The values are:
        status (0=>free, 1=>idle,2=>ready,3=>playing,4=>finished loops,5=>stopped,6=>error, -1=>can't contact server)
        user (the user who reserved the port, "" if none)
        description (user's description - fixed in hi level api)
        loops completed
        bytes sent this loop
        total bytes sent
        file size
        bit rate
        """
        try:
            rawres = self.__server.GetPlayStatus(port)
            if self.__isSuccess(rawres):
                return rawres[2]
            else:
                return (-1, "" ,rawres[1], 0, 0.0, 0.0, 0.0, 0)
        except:
            return (-1, "", "Failed to contact streamer server", 0, 0.0, 0.0, 0.0, 0)


    def clearPort(self, port):
        """
        Clear port overrides other users and frees the specified port
        Use only in when nothing else seems to work to free a port
        """
        try:
            rawres = self.__server.ReleasePort(self.__currentUser, port, True)
            return (rawres[0], rawres[1])
        except:
            return (1000, "Failed to contact streamer server")


    #################################
    # Private functions
    #################################
    def __isSuccess(self, raw):
        # returns true if the XML result 'raw' succeeded (including warning)
        try:
            return raw[0] <= 0
        except:
            return False




